package com.kronos.auth.redis.cachefrmwrk.impl;

import java.util.concurrent.TimeUnit;

import javax.inject.Named;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.redis.connection.MessageListener;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.listener.ChannelTopic;
import org.springframework.data.redis.listener.RedisMessageListenerContainer;
import org.springframework.data.redis.listener.adapter.MessageListenerAdapter;

import com.kronos.auth.redis.api.AuthNRedisOperations;
import com.kronos.auth.redis.api.CustomAuthNRedisOps;
import com.kronos.auth.redis.api.RedisMessageCallback;
import com.kronos.cache.api.util.CacheConstants;

/**
 * Implementation of AuthNRedisOperations which will reuse cache framework's
 * Redis connection.
 * 
 * @author Sandeep.Agrrawal
 *
 */
@Named
@CustomAuthNRedisOps
@SuppressWarnings({ "unchecked", "rawtypes" })
public class AuthNCacheFrmwrkRedisOperationsImpl implements AuthNRedisOperations {
	static final Logger LOGGER = LoggerFactory.getLogger(AuthNCacheFrmwrkRedisOperationsImpl.class);

	@Autowired
	@Qualifier(CacheConstants.STR_REDIS_TEMPLATE)
	RedisTemplate redisTemplate;

	public AuthNCacheFrmwrkRedisOperationsImpl() {
		LOGGER.debug("Created AuthNCacheFrmwrkRedisOperationsImpl");
	}

	@Override
	public void add(String key, String value) {
		redisTemplate.opsForValue().set(key, value);
		LOGGER.debug("AuthNCacheFrmwrkRedisOperationsImpl: Added Key [{}] , Value [{}]", key, value);
	}

	@Override
	public void remove(String key) {
		redisTemplate.delete(key);
		LOGGER.debug("AuthNCacheFrmwrkRedisOperationsImpl: removed Key [{}] ", key);
	}

	@Override
	public String getValue(String key) {
		Object value = redisTemplate.opsForValue().get(key);
		LOGGER.debug("AuthNCacheFrmwrkRedisOperationsImpl: value of Key [{}] found as [{}]", key, value);
		return value != null ? (String) value : "";
	}

	@Override
	public void expire(String key) {
		redisTemplate.expire(key, 2, TimeUnit.SECONDS);
		LOGGER.debug("AuthNCacheFrmwrkRedisOperationsImpl: Key [{}] expiry set", key);
	}

	@Override
	public void getSubscription(String channel, RedisMessageCallback impl) {
		LOGGER.debug("AuthNCacheFrmwrkRedisOperationsImpl: Trying to Subscribe to Channel [{}]", channel);

		final RedisMessageListenerContainer container = getRedisMessageListenerContainer();
		container.setConnectionFactory(this.redisTemplate.getConnectionFactory());
		MessageListener listener = new MessageListenerAdapter(new RedisMessageListener(impl));
		container.addMessageListener(listener, new ChannelTopic(channel));
		container.start();

		LOGGER.debug("AuthNCacheFrmwrkRedisOperationsImpl: Successfully Subscribed to Channel [{}]", channel);
	}

	RedisMessageListenerContainer getRedisMessageListenerContainer() {
		return new RedisMessageListenerContainer();
	}

	class RedisMessageListener {
		RedisMessageCallback impl;

		public RedisMessageListener(RedisMessageCallback impl) {
			this.impl = impl;
		}

		public void handleMessage(String message, String channel) {
			this.impl.onMessage(channel, message);
		}
	}

	@Override
	public void publish(String channel, String message) {
		LOGGER.debug("AuthNCacheFrmwrkRedisOperationsImpl: Trying to Publish to Channel [{}]", channel);
		redisTemplate.convertAndSend(channel, message);
		LOGGER.debug("AuthNCacheFrmwrkRedisOperationsImpl: Successfully Published to Channel [{}]", channel);
	}

	@Override
	public boolean isEnvironmentRedis() {
		return false;
	}

}