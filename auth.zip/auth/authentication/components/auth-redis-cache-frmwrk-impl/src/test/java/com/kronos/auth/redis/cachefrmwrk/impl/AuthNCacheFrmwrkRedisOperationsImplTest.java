package com.kronos.auth.redis.cachefrmwrk.impl;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.data.redis.listener.ChannelTopic;
import org.springframework.data.redis.listener.RedisMessageListenerContainer;

@RunWith(PowerMockRunner.class)
@SuppressWarnings({ "unchecked", "rawtypes" })
public class AuthNCacheFrmwrkRedisOperationsImplTest {

	RedisTemplate redisTemplate;
	ValueOperations operations;
	AuthNCacheFrmwrkRedisOperationsImpl impl;

	@Before
	public void setUp() {
		impl = Mockito.spy(AuthNCacheFrmwrkRedisOperationsImpl.class);
		redisTemplate = Mockito.mock(RedisTemplate.class);
		impl.redisTemplate = redisTemplate;
		operations = Mockito.mock(ValueOperations.class);
		Mockito.doReturn(operations).when(redisTemplate).opsForValue();
		Mockito.doNothing().when(redisTemplate).delete(Mockito.anyString());
		Mockito.doReturn(true).when(redisTemplate).expire(Mockito.anyObject(), Mockito.anyInt(), Mockito.anyObject());
		Mockito.doNothing().when(redisTemplate).convertAndSend(Mockito.anyString(), Mockito.anyString());
		Mockito.doNothing().when(operations).set(Mockito.anyString(), Mockito.anyString());
		Mockito.doReturn("temp").when(operations).get(Mockito.anyString());
	}

	@Test
	public void testAdd() {
		impl.add("Key", "Value");
		Mockito.verify(operations,Mockito.times(1)).set("Key", "Value");
	}

	@Test
	public void testRemove() {
		impl.remove("Key");
		Mockito.verify(redisTemplate,Mockito.times(1)).delete("Key");
	}
	
	@Test
	public void testGetValue() {
		String value = impl.getValue("Key");
		Assert.assertEquals("temp", value);
	}

	@Test
	public void testGetValue_NULL() {
		Mockito.doReturn(null).when(operations).get(Mockito.anyString());
		String value = impl.getValue("Key");
		Assert.assertEquals("", value);
		Assert.assertFalse(impl.isEnvironmentRedis());
	}
	
	@Test
	public void testExpire() {
		impl.expire("Key");
		Mockito.verify(redisTemplate,Mockito.times(1)).expire("Key", 2, TimeUnit.SECONDS);
	}

	@Test
	public void testGetSubscription() {
		RedisConnectionFactory factory = Mockito.mock(RedisConnectionFactory.class);
		Mockito.doReturn(factory).when(redisTemplate).getConnectionFactory();
		RedisMessageListenerContainer container = Mockito.mock(RedisMessageListenerContainer.class);
		Mockito.doNothing().when(container).setConnectionFactory(factory);
		Mockito.doNothing().when(container).addMessageListener(Mockito.anyObject(), Mockito.any(ChannelTopic.class));
		Mockito.doNothing().when(container).start();
		Mockito.doReturn(container).when(impl).getRedisMessageListenerContainer();
		
		impl.getSubscription("channel", (channel, message) -> {});
	}
	
	@Test
	public void testPublish() {
		impl.publish("channel", "message");
		Mockito.verify(redisTemplate,Mockito.times(1)).convertAndSend("channel", "message");
	}
	
	
}