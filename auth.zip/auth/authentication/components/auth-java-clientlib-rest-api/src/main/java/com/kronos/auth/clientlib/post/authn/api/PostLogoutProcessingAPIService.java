package com.kronos.auth.clientlib.post.authn.api;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

/**
 * This Interface will perform logout and notification for same 
 * 
 * @author Sandeep.Agrrawal
 *
 */
@Path("/AuthN/V1/Logout")
public interface PostLogoutProcessingAPIService {

	/**
	 * Will perform logout for this application
	 * 
	 * @return
	 */
	@POST
	@Path("/")
	@Consumes(MediaType.MEDIA_TYPE_WILDCARD)
	public Response performLogout();
}
