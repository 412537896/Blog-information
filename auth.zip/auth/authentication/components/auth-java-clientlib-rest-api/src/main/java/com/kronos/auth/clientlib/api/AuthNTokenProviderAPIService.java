package com.kronos.auth.clientlib.api;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.kronos.auth.clientlib.exception.AuthNPublicException;
import com.kronos.auth.domain.SSOSessionInfo;
import com.kronos.auth.domain.UserInfo;

/**
 * Interface to validate tokens from httpRequest and provide userInfo
 */
@Path("/AuthN/V1")
public interface AuthNTokenProviderAPIService {
	/**
	 * Provides UserInfo object from the httpRequest
	 * @param request HttpServletRequest
	 * @return userInfo - UserInfo object. Returns null if request doesn't contain valid userToken
	 * @throws AuthNPublicException 
	 */
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/getUserInfo")
	public UserInfo getUserInfo() throws AuthNPublicException;

	/**
	 * Checks if given SSO session is valid and active or not.
	 * @param token SSO Token to check
	 * @return true if given Token is valid & active, false otherwise
	 * @throws AuthNPublicException
	 */
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/isSSOSessionValid")
 	public boolean isSSOSessionValid() throws AuthNPublicException;
	
	/**
	 * Checks if given SSO session is valid and returns the information about
	 * session.
	 * @param token SSO Token to check
	 * @return SSOSessionInfo
	 * @throws AuthNPublicException
	 */
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/getSSOSessionInfo")
	public SSOSessionInfo getSSOSessionInfo() throws AuthNPublicException;
	
	/** Provides Session-Out time /max-idle time per session from openam
	 * @return
	 * @throws AuthNPublicException 
	 */
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/getSessionTimeout")
	public Response getSessionTimeOut() throws AuthNPublicException;
	
	/** This is dummy call to extend backend session
	 * @return success
	 * @throws AuthNPublicException 
	 */
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/extendSession")
	public Response extendSession() throws AuthNPublicException;
	
}
