package com.kronos.auth.clientlib.api;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.kronos.auth.clientlib.exception.AuthNPublicException;

/**
 * Interface to issue access tokens for logged in user.
 */
@Path("/AuthN/V1")
public interface AccessTokenProvider {
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/accessToken")
	public Response getAccessToken(@QueryParam("clientId") String clientId, @QueryParam("targetUrl") String targetUrl) throws AuthNPublicException;
}
