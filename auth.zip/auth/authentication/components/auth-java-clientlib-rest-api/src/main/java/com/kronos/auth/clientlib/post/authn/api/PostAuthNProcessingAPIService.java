package com.kronos.auth.clientlib.post.authn.api;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

/** This Interface will perform post authentication session initialization
 *  - like setting cookies
 * 
 * @author Amit.Grover
 *
 */
@Path("/AuthN/V1/Authenticate")
public interface PostAuthNProcessingAPIService {
	
	/**
	 * Will perform Post AuthN session initialization at any other falcon component End
	 *  - like setting session cookies
	 * @return
	 * @throws AuthNTokenPublicException
	 * @throws AuthNPublicException
	 */
	@POST
	@Path("/")
	@Consumes(MediaType.MEDIA_TYPE_WILDCARD)
	public Response performPostAuthNInitializeSession();
}
