package com.kronos.auth.clientlib.api;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import com.kronos.auth.clientlib.exception.AuthNPublicException;
import com.kronos.auth.clientlib.impl.AccessToken;
import com.kronos.auth.domain.OpenAmConfigAttrDTO;
import com.kronos.auth.domain.SSOSessionInfo;
import com.kronos.auth.domain.UserInfo;

/**
 * Interface to validate tokens from httpRequest and provide userInfo and tenantInfo
 */
public interface AuthNTokenProvider {

	/**
	 * Provides UserInfo object with cookies as the passed parameter
	 * @param cookies - Request cookies
	 * @return userInfo - UserInfo object.
	 * @throws AuthNPublicException
	 */
	public UserInfo getUserInfo(Cookie[] cookies)throws AuthNPublicException;


	/** Provides Session-Out time /max-idle time per session from openam
	 * @deprecated
	 * @return
	 * @throws AuthNPublicException
	 */
	@Deprecated
	public OpenAmConfigAttrDTO getSessionTimeOut(HttpServletRequest  httpReq)throws AuthNPublicException;

	/**
	 * Provides UserInfo object from the httpRequest
	 * @param request HttpServletRequest
	 * @return userInfo - UserInfo object.
	 * @throws AuthNPublicException
	 */
	public UserInfo getUserInfo(HttpServletRequest request)throws AuthNPublicException;


	/**
	 * @deprecated
	 * Returns the AuthNCookies corresponding to the input parameter username and password
	 * @param username: Input Username
	 * @param password: Input Password
	 * @return: Returns the cookies
	 * @throws AuthNPublicException
	 */
	@Deprecated
	public Cookie[] getAuthNCookies(String username, String password)throws AuthNPublicException;
	
	/**
	 * Returns the AuthNCookies corresponding to the input parameter username and password and tenantID
	 * @param username
	 * @param password
	 * @param tenantId
	 * @return the cookies
	 * @throws AuthNPublicException
	 */
	public Cookie[] getAuthNCookies(String username, String password, String tenantId) throws AuthNPublicException;

	/**
	 * Returns the AuthNCookies corresponding to the input parameter username and password and tenantId by
	 * authenticating against the given URL.
	 * @param username
	 * @param password
	 * @param tenantId
	 * @param authUrl
	 * @return
	 * @throws AuthNPublicException
	 */
	public Cookie[] getAuthNCookies(String username, String password, String tenantId,
			String openAmBaseURL) throws AuthNPublicException;

	/**
	 * Returns the AuthNCookies corresponding to the input parameter user name, password, tenantID & OnBehalfUser
	 * This method is intended to login system user i.e. user name given should be a system user
	 * @param username
	 * @param password
	 * @param tenantId
	 * @param onBehalfUser
	 * @return
	 * @throws AuthNPublicException
	 */
	public Cookie[] getSystemUserAuthNCookies(String username, String password, 
			String tenantId, String onBehalfUser) throws AuthNPublicException;

	/**
	 * Returns the AuthNCookies corresponding to the input parameter user name,
	 * password, tenantID, firstName and lastName This method is intended to
	 * login system user i.e. user name given should be a system user. The authn
	 * token returned will have the user details having first name and last name
	 * as provided in the API.
	 * 
	 * @param userName
	 * @param password
	 * @param tenantID
	 * @param firstName
	 * @param lastName
	 * @param authServerUrl
	 *            If this value is not provided, the value for openam URL will
	 *            be taken from the configured value in the system.
	 * @return
	 * @throws AuthNPublicException
	 */
	public Cookie[] getSystemUserAuthNCookies(String userName, String password, 
			String tenantID, String firstName, String lastName, String authServerUrl) throws AuthNPublicException;

	/**
	 * Returns the AuthNCookies corresponding to the input parameter user name, password, tenantID & OnBehalfUser
	 * by authenticating against the given URL.
	 * This method is intended to login system user i.e. user name given should be a system user
	 * @param username
	 * @param password
	 * @param tenantId
	 * @param onBehalfUser
	 * @param authUrl
	 * @return
	 * @throws AuthNPublicException
	 */
	public Cookie[] getSystemUserAuthNCookies(String username, String password, 
			String tenantId, String onBehalfUser, String openAmBaseURL) throws AuthNPublicException;

	/**
	 * Clears given cookies and cleanups the session
	 * @param cookies
	 * @return
	 * @throws AuthNPublicException
	 */
	public boolean clearAuthNCookies(Cookie[] cookies) throws AuthNPublicException;
	
	/**
	 * Clears given cookies and cleanups the session from given OpenAM Server
	 * @param cookies
	 * @param openAmBaseUrl
	 * @return
	 * @throws AuthNPublicException
	 */
	public boolean clearAuthNCookies(Cookie[] cookies, String openAmBaseUrl) throws AuthNPublicException;

	/**
	 * Check if given token is valid and active or not.
	 * @param request Request which has SSO Token to check
	 * @return True if token is valid otherwise false
	 * @throws AuthNPublicException
	 */
	public boolean checkSSOToken(HttpServletRequest request) throws AuthNPublicException;
	
	/**
	 * Check if given token is valid and if valid then returns it's properties.
	 * @param request Request which has SSO Token to check
	 * @return JSON containing SSO session information.
	 * @throws AuthNPublicException
	 */
	public SSOSessionInfo getSSOSessionInfo(HttpServletRequest request) throws AuthNPublicException;
	
	/**
	 * 
	 * @return Cookie name mentioned in openam.properties
	 * else fallback to default value
	 */
	public String getOpenAMCookieName();
	
	public AccessToken getAccessToken(HttpServletRequest request,String clientId) throws AuthNPublicException;
}
