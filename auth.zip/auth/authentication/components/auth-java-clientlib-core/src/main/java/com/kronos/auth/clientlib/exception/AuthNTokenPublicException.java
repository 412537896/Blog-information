/**
 * 
 */
package com.kronos.auth.clientlib.exception;

import javax.inject.Named;


/** AuthNTokenPublicException is a root exception to validate the token for successful authentication  
 * @author Amit.Grover
 *
 */
@Named
public class AuthNTokenPublicException extends AuthNPublicException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4177871330295862445L;
	
	public AuthNTokenPublicException() {
		super();
	}
	
	public AuthNTokenPublicException(String message) {
		super(message);
	}
	/**
	 * @param message
	 */
	public AuthNTokenPublicException(String message, String status) {
		super(message, status);
	}

	/**
	 * @param message
	 * @param ex
	 */
	public AuthNTokenPublicException(String message, String status, Throwable ex) {
		super(message, status, ex);
	}
	
	/**
	 * @return - status
	 */
	@Override
	public String getStatus() {
		return this.status;
	}
	
}
