package com.kronos.auth.clientlib.post.authn.api;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.kronos.auth.clientlib.exception.AuthNPublicException;

/**
 * This will refresh application session and send notification to others
 * 
 * @author Sandeep.Agrrawal
 *
 */
public interface PostRefreshProcessingService {
	
	/** 
	 * This method will refresh application session and send notification to others
	 * @return ACCEPTED(202, "Accepted")
	 * @throws AuthNPublicException
	 */
	public String performPostRefresh(HttpServletRequest req,HttpServletResponse resp) throws AuthNPublicException;
}