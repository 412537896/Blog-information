package com.kronos.auth.clientlib.post.authn.api;

import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.kronos.auth.clientlib.exception.AuthNPublicException;

/**
 * This Interface will clear session cookies which can be
 * implemented by falcon components to perform customized operations
 * 
 */
@Named
public interface PostLogoutProcessor {
	/**
	 * Implemented by falcon components for customized operations
	 * @param req
	 * @param resp
	 * @throws AuthNPublicException
	 */
	default void processLogout(HttpServletRequest req, HttpServletResponse resp) throws AuthNPublicException {
	}
}
