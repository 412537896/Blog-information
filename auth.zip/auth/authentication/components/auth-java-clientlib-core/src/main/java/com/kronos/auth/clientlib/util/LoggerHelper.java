package com.kronos.auth.clientlib.util;

import org.slf4j.Logger;
/**
 * Helper class for logging.<br>
 * Logs particular message after checking if that log level is enabled.
 * @author Abhay.Singh
 *
 */
public class LoggerHelper {

	private LoggerHelper(){
		
	}
	/**
	 * Log a message at the DEBUG level if DEBUG is enabled.
	 * @param Logger
	 * @param message
	 */
	public static void debug(Logger log,String message){
		if(log.isDebugEnabled()){
			log.debug(message);
		}
	}
	/**
	 * Log an exception (throwable) at the DEBUG level with an accompanying message if DEBUG is enabled.
	 * @param log
	 * @param message
	 * @param t
	 */
	public static void debug(Logger log,String message,Throwable t){
		if(t==null){
			LoggerHelper.debug(log, message);
		}else{
			if(log.isDebugEnabled()){
				log.debug(message, t);
			}
		}
	}
	/**
	 * Log a message at the DEBUG level according to the specified format and arguments if DEBUG is enabled.
	 *	This form avoids superfluous string concatenation when the logger is disabled for the DEBUG level.<br> However, this variant incurs the hidden (and relatively small) cost of creating an Object[] before invoking the method, even if this logger is disabled for DEBUG. The variants taking one and two arguments exist solely in order to avoid this hidden cost.
	 * @param log
	 * @param message
	 * @param obj
	 */
	public static void debug(Logger log,String message,Object... obj){
		if(log.isDebugEnabled()){
			log.debug(message,obj);
		}
	}
	/**
	 * Log a message at the INFO level if INFO is enabled
	 * @param log
	 * @param message
	 */
	public static void info(Logger log,String message){
		if(log.isInfoEnabled()){
			log.info(message);
		}
	}
	/**
	 * Log a message at the INFO level according to the specified format and arguments.<br>
		This form avoids superfluous object creation when the logger is disabled for the INFO level.
	 * @param log
	 * @param message
	 * @param obj
	 */
	public static void info(Logger log,String message,Object... obj){
		if(log.isInfoEnabled()){
			log.info(message,obj);
		}
	}

	/**
	 * Log a message at ERROR Level
	 * 
	 * @param log
	 *            Logger instance
	 * @param message
	 *            Message to be printed in logs
	 * @param obj
	 *            Objects used in substitution
	 */
	public static void error(Logger log, String message, Object... obj) {
		log.error(message, obj);
	}
}
