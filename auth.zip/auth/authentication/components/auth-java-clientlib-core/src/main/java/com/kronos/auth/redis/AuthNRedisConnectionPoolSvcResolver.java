package com.kronos.auth.redis;

import java.util.Optional;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.inject.Named;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kronos.auth.redis.api.AuthNRedisConnectionPoolService;
import com.kronos.auth.redis.api.AuthNRedisPoolSvc;
import com.kronos.auth.redis.api.CustomAuthNRedisPoolSvc;
import com.kronos.auth.redis.impl.AuthNRedisConnectionPoolServiceImpl;

/**
 * Class to find appropriate implementation of AuthNRedisConnectionPoolService
 * to use.
 * 
 * With DI: CustomAuthNRedisConnectionPoolService will be injected if available.
 * CustomAuthNRedisConnectionPoolService will be given preference other Default
 * AuthNRedisConnectionPoolService will be used which acts as fall back.
 * 
 * Without DI: Default AuthNRedisConnectionPoolService implementation will used
 * and object will be created via explicit constructor call.
 * 
 * FUTURE: Creating CustomAuthNRedisConnectionPoolService even if DI is not
 * available.
 * 
 * @author Sandeep.Agrrawal
 *
 */
@Named
public class AuthNRedisConnectionPoolSvcResolver {
	private static final Logger LOGGER = LoggerFactory.getLogger(AuthNRedisConnectionPoolSvcResolver.class);

	@Inject
	@AuthNRedisPoolSvc
	AuthNRedisConnectionPoolService defaultRedisConnPoolSvc;

	@Inject
	@CustomAuthNRedisPoolSvc
	Optional<AuthNRedisConnectionPoolService> customRedisConnPoolSvc;

	/**
	 * Constructor
	 */
	public AuthNRedisConnectionPoolSvcResolver() {
		LOGGER.info("AuthNRedisConnectionPoolSvcResolver : Creation Done");
	}

	/**
	 * For logging purpose only, to check injection status
	 */
	@PostConstruct
	public void logStatus() {
		LOGGER.info("AuthNRedisConnectionPoolSvcResolver : @AuthNRedisPoolSvc Injected - "
				+ (defaultRedisConnPoolSvc != null));
		LOGGER.info("AuthNRedisConnectionPoolSvcResolver : @CustomAuthNRedisPoolSvc Injected - "
				+ (customRedisConnPoolSvc != null && customRedisConnPoolSvc.isPresent()));
	}

	/**
	 * Selects proper Redis connection pool service class to use based on
	 * injected objects
	 * 
	 * @return
	 */
	public AuthNRedisConnectionPoolService getAuthNRedisConnectionPoolService() {
		if (customRedisConnPoolSvc != null && customRedisConnPoolSvc.isPresent()
				&& customRedisConnPoolSvc.get().isEnvironmentRedis()) {
			LOGGER.info("AuthNRedisConnectionPoolSvcResolver : Using CustomAuthNRedisConnectionPoolService");
			return customRedisConnPoolSvc.get();
		} else if (defaultRedisConnPoolSvc == null) {
			LOGGER.info("AuthNRedisConnectionPoolSvcResolver : Using AuthNRedisConnectionPoolService");
			defaultRedisConnPoolSvc = new AuthNRedisConnectionPoolServiceImpl();
		}
		return defaultRedisConnPoolSvc;
	}

	/**
	 * Does cleanup, avoid calling this as it is for testing purpose only.
	 */
	public final void cleanUp() {
		defaultRedisConnPoolSvc = null;
		customRedisConnPoolSvc = null;
	}
}