package com.kronos.auth.clientlib.impl;

public class AccessToken {
	
	  private String accessToken;
	  private String tokenType;
	  private Long validforMillis;
	  
		public String getAccessToken() {
			return accessToken;
		}
		public void setAccessToken(String accessToken) {
			this.accessToken = accessToken;
		}
		public String getTokenType() {
			return tokenType;
		}
		public void setTokenType(String tokenType) {
			this.tokenType = tokenType;
		}
		public Long getValidforMillis() {
			return validforMillis;
		}
		public void setValidforMillis(Long validforMillis) {
			this.validforMillis = validforMillis;
		}
		
}
