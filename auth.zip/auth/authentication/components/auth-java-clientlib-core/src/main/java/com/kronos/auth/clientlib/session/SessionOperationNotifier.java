package com.kronos.auth.clientlib.session;

import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;

/**
 * Interface which performs action when application session is created, accessed
 * or destroyed.
 * 
 * @author Sandeep.Agrrawal
 *
 */
@Named
public interface SessionOperationNotifier {

	/**
	 * This method will be called when session is created.
	 * 
	 * @param request
	 */
	public void sessionCreated(HttpServletRequest request);

	/**
	 * This method will be called when session is accessed in any request.
	 * 
	 * @param request
	 */
	public void sessionAccessed(HttpServletRequest request);

	/**
	 * This method will be called when session is destroyed i.e. logout happens.
	 * 
	 * @param request
	 */
	public void sessionLogout(HttpServletRequest request);
}
