package com.kronos.auth.redis.impl;

import javax.inject.Inject;
import javax.inject.Named;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kronos.auth.clientlib.util.PropertyFileHelper;
import com.kronos.auth.redis.AuthNRedisConnectionPoolSvcResolver;
import com.kronos.auth.redis.api.AuthNRedisConnectionPoolService;
import com.kronos.auth.redis.api.AuthNRedisOperations;
import com.kronos.auth.redis.api.AuthNRedisOps;
import com.kronos.auth.redis.api.RedisMessageCallback;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPubSub;

@Named
@AuthNRedisOps
public class AuthNRedisOperationsImpl implements AuthNRedisOperations {
	static final Logger LOGGER = LoggerFactory.getLogger(AuthNRedisOperationsImpl.class);
	
	@Inject
	private AuthNRedisConnectionPoolSvcResolver redisConnPoolResolver;

	private AuthNRedisConnectionPoolService getAuthNRedisConnectionPoolService() {
		if(redisConnPoolResolver == null) {
			LOGGER.info("AuthNRedisOperationsImpl: AuthNRedisConnectionPoolService created (not injected)");
			redisConnPoolResolver = new AuthNRedisConnectionPoolSvcResolver();
		}
		return redisConnPoolResolver.getAuthNRedisConnectionPoolService();
	}
	
	/**
	 * This is for testing purpose only.
	 * @param resolver
	 */
	public void setAuthNRedisConnectionPoolSvcResolver(AuthNRedisConnectionPoolSvcResolver resolver) {
		this.redisConnPoolResolver = resolver;
	}
	
	/**
	 * add/update specified value against given Key and extends TTL
	 * 
	 * @param key
	 * @param value
	 */
	@Override
	public void add(String key, String value) {
		LOGGER.debug("AuthNRedisOperationsImpl: Trying to add Key [{}] , Value [{}]", key, value);
		Jedis client = getAuthNRedisConnectionPoolService().getJedisConnection();
		client.set(key, value);
		client.expire(key, PropertyFileHelper.getRedisKeyTTL());
		getAuthNRedisConnectionPoolService().returnJedisConnection(client);
		LOGGER.debug("AuthNRedisOperationsImpl: Added Key [{}] , Value [{}]", key, value);
	}

	/**
	 * Return value for given Key
	 * 
	 * @param key
	 * @return
	 */
	@Override
	public String getValue(String key) {
		LOGGER.debug("AuthNRedisOperationsImpl: Trying to Retrieve value of Key [{}] ", key);
		Jedis client = getAuthNRedisConnectionPoolService().getJedisConnection();
		String result = client.get(key);
		getAuthNRedisConnectionPoolService().returnJedisConnection(client);
		LOGGER.debug("AuthNRedisOperationsImpl: value of Key [{}] found as [{}]", key, result);
		return result;
	}

	/**
	 * delete given key from Redis cache.
	 * 
	 * @param key
	 */
	@Override
	public void remove(String key) {
		LOGGER.debug("AuthNRedisOperationsImpl: Trying to delete Key [{}] ", key);
		Jedis client = getAuthNRedisConnectionPoolService().getJedisConnection();
		long kysRemoved = client.del(key);
		getAuthNRedisConnectionPoolService().returnJedisConnection(client);
		LOGGER.debug("AuthNRedisOperationsImpl: removed Key [{}] times [{}]", key, kysRemoved);
	}

	@Override
	public void expire(String key) {
		Jedis client = getAuthNRedisConnectionPoolService().getJedisConnection();
		client.expire(key, 2);
		getAuthNRedisConnectionPoolService().returnJedisConnection(client);
		LOGGER.debug("AuthNRedisOperationsImpl: Key [{}] will expire", key);
	}

	/**
	 * returns a {@link RedisSubscription} which acts like a listener for
	 * publisher.
	 * 
	 * @param channel
	 * @param impl
	 * @return
	 */
	@Override
	public void getSubscription(String channel, RedisMessageCallback impl) {
		LOGGER.debug("AuthNRedisOperationsImpl: Trying to Subscribe to Channel [{}]", channel);
		RedisSubscription sub = new RedisSubscription(channel, new JedisPubSub() {
			@Override
			public void onMessage(String channel, String message) {
				impl.onMessage(channel, message);
			}
		}, getAuthNRedisConnectionPoolService());
		sub.start();
		LOGGER.debug("AuthNRedisOperationsImpl: Successfully Subscribed to Channel [{}]", channel);
	}

	/**
	 * Publish given message to specified channel.
	 * @param channel
	 * @param message
	 */
	@Override
	public void publish(String channel, String message) {
		LOGGER.debug("AuthNRedisOperationsImpl: Trying to Publish to Channel [{}]", channel);
		Jedis client = getAuthNRedisConnectionPoolService().getJedisConnection();
		client.publish(channel, message);
		LOGGER.debug("AuthNRedisOperationsImpl: Successfully Published to Channel [{}]", channel);
		getAuthNRedisConnectionPoolService().returnJedisConnection(client);
	}

	@Override
	public boolean isEnvironmentRedis() {
		return true;
	}
}
