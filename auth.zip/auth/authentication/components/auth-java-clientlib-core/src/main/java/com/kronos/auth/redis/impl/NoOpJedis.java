package com.kronos.auth.redis.impl;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPubSub;
import redis.clients.util.Pool;

/**
 * Class represents Redis connection and connection with no operations. It will used when connection to 
 * Redis is not available or we don't want to connect to Redis at all.
 *  
 * @author Sandeep.Agrrawal
 *
 */
public class NoOpJedis extends Jedis {
	public static final String REDIS_KEY = "SomeKey";
	public static final String REDIS_VALUE = "SomeValue";
	
	public NoOpJedis() {
		super(REDIS_VALUE);
	}

	@Override
	public Long publish(String channel, String message) {
		return 0L;
	}

	@Override
	public void subscribe(JedisPubSub jedisPubSub, String... channels) {
		// No operation
	}

	@Override
	public boolean isConnected() {
		return true;
	}

	@Override
	public String set(String key, String value) {
		return REDIS_VALUE;
	}

	@Override
	public String get(String key) {
		return REDIS_VALUE;
	}

	@Override
	public Long del(String key) {
		return 0L;
	}

	@Override
	public Long expire(String key, int seconds) {
		return 0L;
	}
	
	@Override
	public void close() {
		// No operation
	}
}

class NoOpJedisPool extends Pool<Jedis> {
	
	@Override
	public void returnResourceObject(Jedis arg0) {
		// No operation
	}

	@Override
	public Jedis getResource() {
		return new NoOpJedis();
	}
	
	@Override
	public void close() {
		// No operation
	}
}