package com.kronos.auth.domain;

public class UserLocaleProfile {
	/**
	 * refernceId from wfc database
	 */
	private String localeProfileId;
	private String country;
	private String language;
	
	/**
	 * @return the localeProfileId
	 */
	public String getLocaleProfileId() {
		return localeProfileId;
	}
	/**
	 * @param localeProfileId the localeProfileId to set
	 */
	public void setLocaleProfileId(String localeProfileId) {
		this.localeProfileId = localeProfileId;
	}
	/**
	 * @return the country
	 */
	public String getCountry() {
		return country;
	}
	/**
	 * @param country the country to set
	 */
	public void setCountry(String country) {
		this.country = country;
	}
	/**
	 * @return the language
	 */
	public String getLanguage() {
		return language;
	}
	/**
	 * @param language the language to set
	 */
	public void setLanguage(String language) {
		this.language = language;
	}
	
	@Override
	public String toString() {
		return "UserLocaleProfile [localeProfileId=" + localeProfileId + ", country=" + country + ", language=" + language + "]";
	}
}
