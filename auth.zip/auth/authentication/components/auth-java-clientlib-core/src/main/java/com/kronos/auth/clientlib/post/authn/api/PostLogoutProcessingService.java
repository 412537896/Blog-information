package com.kronos.auth.clientlib.post.authn.api;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.kronos.auth.clientlib.exception.AuthNPublicException;

/**
 * This will logout application and send notification to others
 * 
 * @author Sandeep.Agrrawal
 *
 */
public interface PostLogoutProcessingService {
	
	/** 
	 * This method will logout application and send notification to others
	 * Responses -  
	 *       - ACCEPTED(202, "Accepted")
	 *       - UNAUTHORIZED(401, "Unauthorized")
	 * @return
	 * @throws AuthNPublicException
	 */
	public String performPostLogout(HttpServletRequest req,HttpServletResponse resp) throws AuthNPublicException;
}
