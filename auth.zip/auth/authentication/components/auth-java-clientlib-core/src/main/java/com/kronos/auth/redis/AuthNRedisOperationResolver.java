package com.kronos.auth.redis;

import java.util.Optional;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.inject.Named;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kronos.auth.redis.api.AuthNRedisOperations;
import com.kronos.auth.redis.api.AuthNRedisOps;
import com.kronos.auth.redis.api.CustomAuthNRedisOps;
import com.kronos.auth.redis.impl.AuthNRedisOperationsImpl;

/**
 * Class to find appropriate implementation of AuthNRedisOperation to use.
 * 
 * With DI: CustomAuthNRedisOperations and default AuthNRedisOperations will be
 * injected if available. CustomAuthNRedisOperations will be given preference as
 * default AuthNRedisOperations is fall back.
 * 
 * Without DI: Default AuthNRedisOperations implementation will used and object
 * will be created via explicit call.
 * 
 * FUTURE: Creating CustomAuthNRedisOperations even if DI is not available.
 * 
 * @author Sandeep.Agrrawal
 *
 */
@Named
public class AuthNRedisOperationResolver {
	private static final Logger LOGGER = LoggerFactory.getLogger(AuthNRedisOperationResolver.class);

	@Inject
	@AuthNRedisOps
	AuthNRedisOperations authnRedisOperations;

	@Inject
	@CustomAuthNRedisOps
	Optional<AuthNRedisOperations> customRedisOperations;

	/**
	 * Constructor
	 */
	public AuthNRedisOperationResolver() {
		LOGGER.info("AuthNRedisOperationResolver : Creation Done");
	}

	/**
	 * For logging purpose only, to check injection status
	 */
	@PostConstruct
	public void logStatus() {
		LOGGER.info("AuthNRedisOperationResolver : @AuthNRedisOps Injected - " + (authnRedisOperations != null));
		LOGGER.info("AuthNRedisOperationResolver : @CustomAuthNRedisOps Injected - "
				+ (customRedisOperations != null && customRedisOperations.isPresent()));
	}

	/**
	 * Selects proper Redis operation class to use based on injected objects
	 * @return
	 */
	public AuthNRedisOperations getAuthNRedisOperations() {
		if (customRedisOperations != null && customRedisOperations.isPresent()
				&& customRedisOperations.get().isEnvironmentRedis()) {
			LOGGER.info("AuthNRedisOperationResolver : Using CustomAuthNRedisOperations");
			return customRedisOperations.get();
		} else if (authnRedisOperations == null) {
			LOGGER.info("AuthNRedisOperationResolver : Using AuthNRedisOperations");
			authnRedisOperations = new AuthNRedisOperationsImpl();
		}
		return authnRedisOperations;
	}

	/**
	 * Does cleanup, avoid calling this as it is for testing purpose only.
	 */
	public final void cleanUp() {
		authnRedisOperations = null;
		customRedisOperations = null;
	}
}
