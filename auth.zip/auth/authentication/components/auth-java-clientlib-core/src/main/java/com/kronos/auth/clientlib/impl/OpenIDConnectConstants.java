package com.kronos.auth.clientlib.impl;

/**
 * Constants for OpenID Connect elements
 * 
 * @author Manish.Sharma
 *
 */
public class OpenIDConnectConstants {
	public static final String KEY_ID = "kid";
	
	/**
	 * No need to instantiate this class as all members and methods are static
	 */
	private OpenIDConnectConstants(){
		
	}
}
