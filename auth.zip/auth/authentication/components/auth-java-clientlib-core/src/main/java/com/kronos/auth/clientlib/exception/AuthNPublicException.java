/**
 * 
 */
package com.kronos.auth.clientlib.exception;

import javax.inject.Named;

import com.kronos.auth.clientlib.util.AuthConstants;


/** AuthNPublicException is root exception class related to authentication exceptions
 * @author Amit.Grover
 *
 */
@Named
public class AuthNPublicException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2210860657079581479L;
	
	protected final String status;
	
	public AuthNPublicException() {
		this.status = AuthConstants.INTERNAL_SERVER_ERROR;
	}
	
	public AuthNPublicException(String message) {
		this.status = AuthConstants.INTERNAL_SERVER_ERROR;
	}

	/**
	 * @param message
	 */
	public AuthNPublicException(String message, String status) {
		super(message);
		this.status = status;
	}

	/**
	 * @param message
	 * @param ex
	 */
	public AuthNPublicException(String message, String status, Throwable ex) {
		super(message, ex);
		this.status = status;
	}
	
	/**
	 * @return
	 */
	public String getStatus() {
		return this.status;
	}

}
