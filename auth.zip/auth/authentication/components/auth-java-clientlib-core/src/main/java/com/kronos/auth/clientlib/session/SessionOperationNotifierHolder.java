package com.kronos.auth.clientlib.session;

import javax.inject.Inject;
import javax.inject.Named;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Class to hold object for SessionOperationNotifier which will be populated by 
 * Spring. This is required to get reference to SessionOperationNotifier, in objects 
 * which are not created by Spring (i.e. Servlet Filter etc.) 
 * @author Sandeep.Agrrawal
 *
 */
@Named
public class SessionOperationNotifierHolder {
	static final Logger LOGGER = LoggerFactory.getLogger(SessionOperationNotifierHolder.class);
	
	private static SessionOperationNotifier globalSessionOperationNotifier;
	
	/**
	 * Method which will be used by Spring to inject reference to SessionOperationNotifier
	 * @param notifierImpl
	 */
	@Inject
	public final void setSessionOperationNotifier(SessionOperationNotifier notifierImpl) {
		LOGGER.info("setSessionOperationNotifier : Setting Notifier Start");
		SessionOperationNotifierHolder.setSessionOperationNotifierImpl(notifierImpl);
		LOGGER.info("setSessionOperationNotifier : Setting Notifier End " + (notifierImpl != null));
	}
	
	private static final void setSessionOperationNotifierImpl(SessionOperationNotifier notifierImpl) {
		SessionOperationNotifierHolder.globalSessionOperationNotifier = notifierImpl;
	}
	
	/**
	 * Method to get reference to SessionOperationNotifier object
	 * @return
	 */
	public static final SessionOperationNotifier getSessionOperationNotifierImpl() {
		return SessionOperationNotifierHolder.globalSessionOperationNotifier;
	}
}
