package com.kronos.auth.clientlib.post.authn.api;

import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.kronos.auth.clientlib.exception.AuthNPublicException;

/**
 * This Interface will refresh session
 * 
 */
@Named
public interface PostRefreshProcessor {
	/**
	 * Implemented by falcon components for customized operations
	 * @param req
	 * @param resp
	 * @throws AuthNPublicException
	 */
	default void processRefresh(HttpServletRequest req, HttpServletResponse resp) throws AuthNPublicException {
	}
}