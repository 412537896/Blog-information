package com.kronos.auth.clientlib.post.authn.api;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.kronos.auth.clientlib.exception.AuthNPublicException;
import com.kronos.auth.clientlib.exception.AuthNTokenPublicException;

/**
 * This Interface will set post authentication session cookies which can be implemented by falcon components to achieve this 
 * @author Amit.Grover
 *
 */
public interface PostAuthNProcessingService {
	
	/** 
	 * this method will set session cookies after SSO authentication
	 * Responses -  
	 *       - ACCEPTED(202, "Accepted") (if validated and session initalization)
	 *       - UNAUTHORIZED(401, "Unauthorized") (if not validated)
	 * @return
	 * @throws AuthNTokenPublicException
	 * @throws AuthNPublicException
	 */
	public String performPostAuthNInitializeSession(HttpServletRequest req,HttpServletResponse resp) throws AuthNPublicException;
}
