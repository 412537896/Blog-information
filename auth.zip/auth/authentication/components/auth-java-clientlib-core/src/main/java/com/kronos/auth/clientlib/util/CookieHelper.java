package com.kronos.auth.clientlib.util;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Class with helper functions
 * 
 * @author Sandeep.Agrrawal
 *
 */
public class CookieHelper {

	static final Logger LOGGER = LoggerFactory.getLogger(CookieHelper.class);
	
	private static final String ANYWHERE_IN_DOMAIN = "/";

	static final String REFRESH_API = "/restcall/AuthN/V1/Refresh";
	static final String LOGOUT_API = "/restcall/AuthN/V1/Logout";

	CookieHelper() {
		// empty
	}

	/**
	 * This will delete the given cookie by setting its max age to 0
	 * @param httpReq
	 * @param httpResp
	 * @param cookieName
	 */
	public static void deleteCookie(HttpServletRequest httpReq, HttpServletResponse httpResp, String cookieName) {
		LoggerHelper.info(LOGGER, ".deleteCookie(HttpServletRequest,HttpServletResponse,String)");
		Cookie cookie = CookieHelper.getCookie(httpReq, cookieName);
		if (cookie != null) {
			cookie.setMaxAge(0);
			httpResp.addCookie(cookie);
		}
	}

	/**
	 * It will return the cookie object for given cookie name
	 * @param request
	 * @param cookieName
	 * @return
	 */
	public static Cookie getCookie(HttpServletRequest request, String cookieName) {
		if (request.getCookies() != null) {
			for (Cookie cookie : request.getCookies()) {
				if (cookie.getName().equals(cookieName) || (AuthConstants.IPLANET_COOKIE.equals(cookieName)
						&& AuthConstants.OPENAM_COOKIE_AUTHN_SSID.equals(cookie.getName()))) {
					return cookie;
				}
			}
		}
		return null;
	}

	/**
	 * Find the cookie value for given cookie name in http request object.
	 * @param request
	 * @param cookieName
	 * @return
	 */
	public static String getCookieValue(HttpServletRequest request, String cookieName) {
		LoggerHelper.info(LOGGER, ".getCookieValue(HttpServletRequest,String) Start");
		String value = null;
		if (null != request && null != request.getCookies() && request.getCookies().length > 0) {
			Cookie[] cookies = request.getCookies();
			value = CookieHelper.getCookieValue(cookies, cookieName);
		}
		LoggerHelper.info(LOGGER, ".getCookieValue(HttpServletRequest,String) End");
		return value;
	}

	/**
	 * Find the cookie value 
	 * @param cookies
	 * @param cookieName
	 * @return
	 */
	public static String getCookieValue(Cookie[] cookies, String cookieName) {
		LoggerHelper.info(LOGGER, ".getCookieValue(Cookie[],String) Start");
		String value = null;
		// check value for passed in cookieName which is iPlanetDirectoryPro
		if (null != cookies && cookies.length > 0) {
			for (int i = 0; i < cookies.length; i++) {
				if (cookies[i].getName().compareToIgnoreCase(cookieName) == 0) {
					value = cookies[i].getValue();
					value = value.replaceAll(AuthConstants.QUOTES, AuthConstants.BLANK);
				}
			}
			// if value was null for iPlanetDirectoryPro then check value for
			// authn_ssid
			if (value == null && AuthConstants.IPLANET_COOKIE.equals(cookieName)) {
				for (int i = 0; i < cookies.length; i++) {
					if (cookies[i].getName().compareToIgnoreCase(AuthConstants.OPENAM_COOKIE_AUTHN_SSID) == 0) {
						value = cookies[i].getValue();
						value = value.replaceAll(AuthConstants.QUOTES, AuthConstants.BLANK);
					}
				}
			}
		}
		LoggerHelper.debug(LOGGER, ".getCookieValue(Cookie[],String) Returning Cookie value [{}]", value);
		LoggerHelper.info(LOGGER, ".getCookieValue(Cookie[],String) End");
		return value;
	}

	/**
	 * Sets properties of given cookie to provided values
	 * @param cookie
	 * @param cookieValue
	 * @param domain
	 * @param isSecure
	 * @return
	 */
	public static Cookie setCookieProperties(Cookie cookie, String cookieValue, String domain, boolean isSecure) {
		cookie.setValue(cookieValue);
		cookie.setMaxAge(-1);
		cookie.setDomain(domain);
		cookie.setSecure(isSecure);
		cookie.setPath(CookieHelper.ANYWHERE_IN_DOMAIN);
		cookie.setHttpOnly(true);
		return cookie;
	}

	/**
	 * Creates refresh and logout REST end point URLs
	 * @param baseUrl
	 * @param refresh
	 * @return
	 */
	public static String getNotificationURL(boolean refresh) {
		StringBuilder compUrl = new StringBuilder(PropertyFileHelper.getApplicationURL());
		compUrl.append(refresh ? CookieHelper.REFRESH_API : CookieHelper.LOGOUT_API);
		return compUrl.toString();
	}

	/**
	 * Returns base url based on given request
	 * @param request
	 * @return
	 */
	public static String getBaseUrl(HttpServletRequest request) {
		StringBuilder url = new StringBuilder(request.getScheme());
		url.append(AuthConstants.COLON_SLASH_SLASH);
		url.append(request.getServerName()).append(AuthConstants.COLON).append(request.getServerPort());
		url.append(request.getContextPath());
		return url.toString();
	}

}
