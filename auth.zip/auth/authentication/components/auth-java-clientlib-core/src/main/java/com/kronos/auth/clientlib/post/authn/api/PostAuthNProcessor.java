package com.kronos.auth.clientlib.post.authn.api;

import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.kronos.auth.clientlib.exception.AuthNPublicException;


/*
 * This Interface will set post authentication session cookies which can be implemented by falcon components to achieve this 
 *  
 */
@Named
public interface PostAuthNProcessor {
	default void setSessionCookies(HttpServletRequest req, HttpServletResponse resp) throws AuthNPublicException{
	}


}
	