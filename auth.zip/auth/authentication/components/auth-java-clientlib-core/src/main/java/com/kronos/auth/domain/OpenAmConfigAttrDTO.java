/**
 * 
 */
package com.kronos.auth.domain;


/**
 * @author Amit.Grover
 * 
 * OpenAmConfigAttrDTO - Openam Config attributes
 *
 */
public class OpenAmConfigAttrDTO {
	
	private String sessionTimeout ;

	/**
	 * @return the sessionTimeout
	 */
	public String getSessionTimeout() {
		return sessionTimeout;
	}

	/**
	 * @param sessionTimeout the sessionTimeout to set
	 */
	public void setSessionTimeout(String sessionTimeout) {
		this.sessionTimeout = sessionTimeout;
	}

	@Override
	public String toString() {
		return "OpenAmConfigAttrDTO [sessionTimeout=" + sessionTimeout + "]";
	}
	
}
