package com.kronos.auth.clientlib.util;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.concurrent.locks.ReentrantLock;

import javax.servlet.http.Cookie;

import org.apache.commons.pool2.impl.GenericObjectPoolConfig;
import org.jose4j.jws.JsonWebSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kronos.auth.clientlib.cache.AuthNCacheObject;
import com.kronos.auth.clientlib.exception.AuthNPublicException;
import com.kronos.auth.clientlib.impl.AccessToken;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;
import redis.clients.jedis.JedisSentinelPool;
import redis.clients.util.Pool;

/**
 * No need to instantiate this class as all members and methods are static
 */
public class AuthUtil {

	
	private static final String EXPIRES_IN = "expires_in";
	private static final String TOKEN_TYPE = "token_type";
	private static final String COOKIE = "Cookie";
	private static final String EQUAL = "=";
	public static final String REQUEST_TYPE_POST = "POST";
	public static final String REQUEST_TYPE_GET = "GET";
	private static final String CONTENT_TYPE = "Content-Type";
	private static final String CONTENT_TYPE_JSON = "application/json";
	private static final String API_VERSION_ACCEPT = "Accept-API-Version";
	private static final String API_VERSION_V1 = "resource=1.0, protocol=1.0";
	private static final String OPENAM_USERNAME = "X-OpenAM-Username";
	private static final String OPENAM_PASS = "X-OpenAM-Password";
	private static final String OPENAM_SERVICE = "authIndexType=service&authIndexValue";
	private static final String OPENAM_SYSTEM_AUTH_SERVICE = "SystemUserAuthService";
	private static final String ON_BEHALF_USER_HEADER = "X-Kronos-OnBehalfUser";

	private static final String RESPONSE_TYPE_PARAM = "response_type";
	private static final String RESPONSE_TYPE_PARAM_VALUE = "token";
	private static final String CLIENT_ID_PARAM = "client_id";
	private static final String SCOPE_PARAM = "scope";
	private static final String SCOPE_PARAM_VAL = "givenName sn mail uid";
	private static final String SAVE_CONSENT_PARAM = "save_consent";
	private static final String SAVE_CONSENT_PARAM_VAL = "on";
	private static final String REDIRECT_URI_PARAM = "redirect_uri";
	private static final String DECISION_PARAM = "decision";
	private static final String DECISION_PARAM_VAL = "Allow";
	private static final String ACCESS_TOKEN_SERACH_PATTERN = "access_token";
	private static final String NONCE_PARAM = "nonce";
	private static final String NONCE_PARAM_VAL = "<Dn-0S6_WzA2Mj";
	private static final String REDIRECT_URL = "http://google.com";
	private static final String LOCATION_HEADER = "Location";
	private static final String CSRF_PARAM = "csrf";

	private static final String COOKIE_DELIMITER = ";";
	private static final String PARAM_SYSTEM_USER_AUTH_LAST_NAME = "X-KRONOS-SYSTEM-USER-AUTH-LAST-NAME";
	private static final String PARAM_SYSTEM_USER_AUTH_FIRST_NAME = "X-KRONOS-SYSTEM-USER-AUTH-FIRST-NAME";
	
	static final Logger LOGGER = LoggerFactory.getLogger(AuthUtil.class);

	/**
	 * No need to instantiate this class as all members and methods are static
	 */
	private AuthUtil() {
	}

	public static AccessToken processAuthorizeRequest(String authzUrl,
			String openAmCookieValue, String userName, String clientId) throws AuthNPublicException {
		AccessToken accessToken = null;
		HttpURLConnection connection = null;
		try {
			LoggerHelper.debug(LOGGER, "processAuthorizeRequest called with url : {}, cookie vale : {} , user name :{}, ClientId : {}", 
					authzUrl, openAmCookieValue, userName, clientId );
			Map<String, String> headersMap = new HashMap<>();
			headersMap.put(OPENAM_USERNAME, userName);
			headersMap.put(COOKIE, AuthConstants.DEFAULT_COOKIE_NAME_AUTHN_SSID + "="
					+ openAmCookieValue);

			Map<String, String> data = createAuthzRequestData(openAmCookieValue, clientId);

			connection = postRequest(authzUrl, data, headersMap);
			int statusCode = connection.getResponseCode();
			LoggerHelper.info(LOGGER, "Response status from openAM :{}", statusCode);
			if (statusCode == 302) {
				accessToken = getAuthToken(connection);
			}else {
				String errorMessage = readError(connection);
				LoggerHelper.error(LOGGER, "Error message", errorMessage);
				throw new AuthNPublicException(errorMessage, Integer.toString(statusCode));
			}
		} catch (IOException e) {
			LoggerHelper.debug(LOGGER, "Error while accessing " + authzUrl, e);
			throw new AuthNPublicException("Error while getting access token", "500");
		}finally {
			closeConnection(connection);
		}
		return accessToken;
	}

	private static String readError(HttpURLConnection connection) throws IOException {
		
		InputStream stream = connection.getErrorStream();
	    if (stream == null) {
	        stream = connection.getInputStream();
	    }
	    
	    try (Scanner scanner = new Scanner(stream)) {
	        scanner.useDelimiter("\\Z");
	        return scanner.next();
	    }
		
	}

	private static Map<String, String> createAuthzRequestData(String openAmCookieValue, String clientId) {
		Map<String, String> data = new HashMap<>();
		data.put(RESPONSE_TYPE_PARAM, RESPONSE_TYPE_PARAM_VALUE);
		data.put(CLIENT_ID_PARAM, clientId);
		data.put(SCOPE_PARAM, SCOPE_PARAM_VAL);
		data.put(SAVE_CONSENT_PARAM, SAVE_CONSENT_PARAM_VAL);
		data.put(REDIRECT_URI_PARAM, REDIRECT_URL);
		data.put(DECISION_PARAM, DECISION_PARAM_VAL);
		data.put(NONCE_PARAM, NONCE_PARAM_VAL);
		data.put(CSRF_PARAM, openAmCookieValue);
		return data;
	}

	public static HttpURLConnection postRequest(String url, Map<String, String> data, Map<String, String> headers)
			throws IOException {
		HttpURLConnection con = null;
		DataOutputStream wr = null;
		StringBuilder body = new StringBuilder();
		con = getURLConnection(url);
		con.setRequestMethod(REQUEST_TYPE_POST);
		con.setInstanceFollowRedirects(false);
		con.setUseCaches(false);
		con.setDoOutput(true);
		for (Map.Entry<String, String> header : headers.entrySet()) {
			con.setRequestProperty(header.getKey(), header.getValue());
		}
		for (Map.Entry<String, String> entry : data.entrySet()) {
			body = body.append(entry.getKey() + "=" + URLEncoder.encode(entry.getValue(), "UTF-8") + "&");
		}
		String bodyString = body.toString().substring(0, body.length() - 1);
		wr = new DataOutputStream(con.getOutputStream());
		wr.writeBytes(bodyString);
		wr.flush();
		wr.close();
		return con;
	}

	private static void closeConnection(HttpURLConnection con){
		if (con != null) {
			con.disconnect();
		}
	}

	private static AccessToken getAuthToken(HttpURLConnection con) throws IOException {
		List<String> tokensList = null;
		Map<String, List<String>> map = con.getHeaderFields();
		for (Map.Entry<String, List<String>> entry : map.entrySet()) {
			if (entry.getKey() != null && LOCATION_HEADER.equalsIgnoreCase(entry.getKey())) {
				tokensList = entry.getValue();
				break;
			}
		}
			return  extractAccessToken(tokensList);
		}

	private static AccessToken extractAccessToken(List<String> tokensList) {
		AccessToken accessToken = null;
		if(tokensList != null && tokensList.size() > 0) {
			Map<String,String> responseValues=null;
			String headerElementValue = tokensList.get(0);
			LoggerHelper.info(LOGGER, "location header is:" + headerElementValue);
			headerElementValue = headerElementValue.substring(headerElementValue.indexOf("#")+1);
			String[] tokens = headerElementValue.split("&");
			responseValues = new HashMap<>();
			for (String tokenValue : tokens) {
				String[] params = tokenValue.split("=");
				responseValues.put(params[0], params[1]);
			}
			accessToken = new AccessToken();
			accessToken.setAccessToken(responseValues.get(ACCESS_TOKEN_SERACH_PATTERN));
			accessToken.setTokenType(responseValues.get(TOKEN_TYPE));
			accessToken.setValidforMillis(Long.parseLong(responseValues.get(EXPIRES_IN)));
		}
		
		return accessToken;
	}


	

	/**
	 * This method opens the http connection to the provided URL.
	 * 
	 * @param userName	username for authentication of request
	 * @param password  password for authentication of request
	 * @param authURL   The API url
	 * @param apiVersionHeaderValue  Api version header value. 
	 * 				If the value is null, "resource=1.0, protocol=1.0" is used as default value. 
	 * @return
	 * @throws IOException
	 */
	public static HttpURLConnection getHttpConnection(final String userName,
			final String password, final String authURL, final String apiVersionHeaderValue) throws IOException {
		LoggerHelper.info(LOGGER,
				"getHttpConnection(String,String,String) : Start");
		URL url = new URL(authURL);
		LoggerHelper
		.debug(LOGGER,
				"getHttpConnection(String,String,String) : trying to connect to server [{}]",
				authURL);
		HttpURLConnection con = (HttpURLConnection) url.openConnection();
		LoggerHelper
		.debug(LOGGER,
				"getHttpConnection(String,String,String) : connected to server [{}]",
				authURL);
		String apiVersion = apiVersionHeaderValue == null ? API_VERSION_V1: apiVersionHeaderValue;
		con.setRequestMethod(REQUEST_TYPE_POST);
		con.setRequestProperty(CONTENT_TYPE, CONTENT_TYPE_JSON);
		con.setRequestProperty(API_VERSION_ACCEPT, apiVersion);
		if (userName != null) {
			con.setRequestProperty(OPENAM_USERNAME, userName);
		}
		if (password != null) {
			con.setRequestProperty(OPENAM_PASS, password);
		}
		con.setDoOutput(true);
		LoggerHelper.info(LOGGER,
				"getHttpConnection(String,String,String) : End");
		return con;
	}

	/**
	 * Should be used for system user login only
	 * 
	 * @param userName
	 * @param password
	 * @param authURL
	 * @param onBehalfUser
	 * @return
	 * @throws IOException
	 */
	public static HttpURLConnection getSystemUserAuthHttpConnection(
			final String userName, final String password, final String authURL,
			final String onBehalfUser) throws IOException {
		LoggerHelper.info(LOGGER, "getSystemUserAuthHttpConnection : Start");
		String authzURL = authURL + "?" + OPENAM_SERVICE + '='
				+ OPENAM_SYSTEM_AUTH_SERVICE;
		LoggerHelper.debug(LOGGER,
				"getSystemUserAuthHttpConnection : authzURL is [{}]", authURL);
		HttpURLConnection con = AuthUtil.getHttpConnection(userName, password,
				authzURL,API_VERSION_V1);
		con.setRequestProperty(ON_BEHALF_USER_HEADER, onBehalfUser);
		LoggerHelper.info(LOGGER, "getSystemUserAuthHttpConnection : End");
		return con;
	}
	
	
	/**
	 * This method returns the http connection for system user login with
	 * required first name and last name value in the header passed to login
	 * chain.
	 * 
	 * @param userName
	 * @param password
	 * @param firstName
	 * @param lastName
	 * @param authURL
	 * @return
	 * @throws IOException
	 */
	public static HttpURLConnection getSystemUserAuthConnection(final String userName, final String password,
			final String firstName, final String lastName, final String authURL) throws IOException {
		LoggerHelper.info(LOGGER, "getSystemUserAuthConnection(String,String,String,String,String,String) : Start");
		String authzURL = authURL + "?" + OPENAM_SERVICE + '=' + OPENAM_SYSTEM_AUTH_SERVICE;
		LoggerHelper.debug(LOGGER,
				"getSystemUserAuthConnection(String,String,String,String,String,String) : authzURL is [{}]", authURL);
		HttpURLConnection con = AuthUtil.getHttpConnection(userName, password, authzURL,API_VERSION_V1);
		con.setRequestProperty(PARAM_SYSTEM_USER_AUTH_FIRST_NAME, firstName);
		con.setRequestProperty(PARAM_SYSTEM_USER_AUTH_LAST_NAME, lastName);
		LoggerHelper.info(LOGGER, "getSystemUserAuthConnection(String,String,String,String,String,String) : End");
		return con;
	}

	/**
	 * If the http request returns a response 200 Ok, then 
	 * this method reads the response stream and returns the response.
	 * 
	 * @param cookies
	 * @param url
	 * @return
	 * @throws IOException
	 */
	public static StringBuilder getResponseFromUrl(final Cookie[] cookies,
			final String url, final String reqType) throws IOException {
		LoggerHelper
		.info(LOGGER, "getResponseFromUrl(Cookie[],String) : Start");
		URL obj = new URL(url);
		LoggerHelper
		.debug(LOGGER,
				"getHttpConnection(Cookie[],String) : trying to connect to server [{}]",
				url);
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();
		LoggerHelper
		.debug(LOGGER,
				"getResponseFromUrl(Cookie[],String) : connected to server [{}]",
				url);
		// optional default is GET
		con.setRequestMethod(reqType);
		for (Cookie cookie : cookies) {
			LoggerHelper
			.debug(LOGGER,
					"getResponseFromUrl(Cookie[],String) : adding request header key [{}] and Value [{}]",
					cookie.getName(), cookie.getValue());
			// add request header
			con.addRequestProperty(COOKIE,
					cookie.getName() + EQUAL + cookie.getValue());
		}
		LoggerHelper.info(LOGGER, "getResponseFromUrl(Cookie[],String) : End");
		return AuthUtil.getResponseFromConn(con);
	}

	public static StringBuilder getResponseFromUrl(final Cookie[] cookies,
			final String url) throws IOException {
		return AuthUtil.getResponseFromUrl(cookies, url, REQUEST_TYPE_GET);
	}
	
	public static StringBuilder getResponseFromConn(HttpURLConnection con)
			throws IOException {
		LoggerHelper.info(LOGGER,
				"getResponseFromConn(HttpURLConnection) : Start");
		StringBuilder response = null;
		BufferedReader in = null;
		try {
			int responseCode = con.getResponseCode();
			if (200 == responseCode) {
				in = new BufferedReader(new InputStreamReader(con.getInputStream()));
				String inputLine = null;
				response = new StringBuilder();
				while ((inputLine = in.readLine()) != null) {
					response.append(inputLine);
				}
			}
		} finally {
			if (in != null)
				in.close();
			if (con != null)
				con.disconnect();
		}
		LoggerHelper
		.debug(LOGGER,
				"getResponseFromConn(HttpURLConnection) : Returning Response [ {} ]",
				response);
		LoggerHelper.info(LOGGER,
				"getResponseFromConn(HttpURLConnection) : End");
		return response;
	}

	public static HttpURLConnection getURLConnection(String uri)
			throws IOException {
		LoggerHelper.info(LOGGER, "getURLConnection(String) : Start");
		URL obj = new URL(uri);
		LoggerHelper.debug(LOGGER,
				"getURLConnection(String) : trying to connect to server [{}]",
				uri);
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();
		LoggerHelper.debug(LOGGER,
				"getURLConnection(String) : connected to server [{}]", uri);
		LoggerHelper.info(LOGGER, "getURLConnection(String) : End");
		return con;
	}

	public static JsonWebSignature getJsonWebSignature() {
		return new JsonWebSignature();
	}

	public static boolean invokeUrl(String urlStr, String requestType, List<Cookie> cookiesToSend) {
		HttpURLConnection con = null;
		try {
			con = getURLConnection(urlStr);
			con.setRequestMethod(requestType);
			con.setInstanceFollowRedirects(false);
			con.setUseCaches(false);
			con.setDoOutput(true);
			StringBuilder cookieValue = new StringBuilder();
			for (Cookie cookie : cookiesToSend) {
				cookieValue.append(cookie.getName() + EQUAL + cookie.getValue() + COOKIE_DELIMITER);
			}
			con.setRequestProperty(COOKIE, cookieValue.toString());

			int statusCode = con.getResponseCode();
			LoggerHelper.info(LOGGER, "http status code is:" + statusCode);
			if(statusCode == 200 || statusCode == 202) {
				return true;
			}
		} catch(Exception ex) {
			LoggerHelper.debug(LOGGER, ex.getMessage(), ex);
		} finally {
			if (con != null) {
				con.disconnect();
			}
		}
		return false;
	}

	public static void notifySelf(AuthNCacheObject authObj, boolean refreshCall) {
		LoggerHelper.info(LOGGER, "notifySelf : Start");
		String reqType = refreshCall ? REQUEST_TYPE_GET : REQUEST_TYPE_POST;

		List<Cookie> cookies = new ArrayList<>();
		cookies.add(new Cookie(AuthConstants.IPLANET_COOKIE, authObj.getSsoToken()));
		cookies.add(new Cookie(AuthConstants.OPENAM_COOKIE_AUTHN_SSID, authObj.getSsoToken()));
		cookies.add(new Cookie(PropertyFileHelper.getOpenAMCookieName(), authObj.getAuthNToken()));
		cookies.add(new Cookie(AuthConstants.JSESSION_ID, authObj.getjSessionId()));

		invokeUrl(CookieHelper.getNotificationURL(refreshCall), reqType, cookies);

		LoggerHelper.info(LOGGER, "notifySelf : End");
	}

	public static Pool<Jedis> getJedisPool(GenericObjectPoolConfig poolConfig, String host, int port, int timeout,
			String password) {
		if(!AuthUtil.isEmpty(password)){
			return new JedisPool(poolConfig, host, port, timeout, password);
		}else{
			return new JedisPool(poolConfig, host, port, timeout);
		}
	}

	public static Pool<Jedis> getJedisSentinelPool(GenericObjectPoolConfig poolConfig, String masterName, 
			Set<String> sentinels, int timeout, String password) {
		if (!AuthUtil.isEmpty(password)) {
			return new JedisSentinelPool(masterName, sentinels, poolConfig, timeout, password);
		} else {
			return new JedisSentinelPool(masterName, sentinels, poolConfig, timeout);
		}
	}
	
	public static JedisPoolConfig getJedisPoolConfig(){
		return new JedisPoolConfig();
	}
	
	public static ReentrantLock getReentrantLock(){
		return new ReentrantLock();
	}
	
	@SuppressWarnings("rawtypes")
	public static boolean isEmpty(Object object){
		if(object==null){
			return true;
		}
		if(object instanceof String){
			String s = (String) object;
			if("".equals(s.trim())){
				return true;
			}
		}else if(object instanceof Collection){
			Collection c = (Collection) object;
			if(c.isEmpty()){
				return true;
			}

		}

		return false;
	}

}