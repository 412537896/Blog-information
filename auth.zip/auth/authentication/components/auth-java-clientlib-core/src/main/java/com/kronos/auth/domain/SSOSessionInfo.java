package com.kronos.auth.domain;

/**
 * This class represents the data related with SSO token
 * 
 * @author sandeep.agrrawal
 *
 */
public class SSOSessionInfo {

	private long idleTtl = -1;

	/**
	 * Returns the TTL remaining before SSO session timeout due to being idle.
	 * Value of -1 indicates that session is not valid or expired
	 * 
	 * @return
	 */
	public long getIdleTtl() {
		return idleTtl;
	}

	/**
	 * Sets SSO Session TTL, this is not set in OpenAM
	 * @param idleTtl
	 */
	public void setIdleTtl(long idleTtl) {
		this.idleTtl = idleTtl;
	}
	
}
