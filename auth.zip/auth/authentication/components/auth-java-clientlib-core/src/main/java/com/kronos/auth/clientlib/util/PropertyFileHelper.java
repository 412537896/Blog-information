package com.kronos.auth.clientlib.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashSet;
import java.util.Properties;
import java.util.Set;
import java.util.StringTokenizer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import redis.clients.jedis.Protocol;

/**
 * This class is responsible for reading the property file and maintaining the parameters.
 * It will load the values during startup and keep it in memory.
 *  
 * @author Sandeep.Agrrawal
 *
 */
public class PropertyFileHelper {

	private static final Logger LOGGER = LoggerFactory.getLogger(PropertyFileHelper.class);

	static final String OPENAM_HOST = "openam_host";
	static final String OPENAM_PORT = "openam_port";
	static final String OPENAM_CONTEXT = "openam_context";
	static final String OPENAM_SCHEME = "openam_scheme";
	static final String OPENAM_COOKIENAME = "openam_cookieName";
	static final String OPENAM_CONFIG = "openamConfigFile";
	static final String CATALINA_BASE = "catalina.base";
	static final String SKIP_TENANT_NAME_CHECK_STR = "skiptenantnamecheck";
	static final String OPENAM_URL = "openam_url";
	static final String APP_BASE_URL = "app_base_url";
	static final String APP_CONTEXT = "app_context";
	static final String REDIS_MASTER = "redis_master";
	static final String REDIS_HOSTS_PORTS = "redis_hosts_ports";
	static final String REDIS_TIMEOUT = "redis_timeout";
	static final String REDIS_AUTH = "redis_auth";
	static final String REDIS_MAX_ACTIVE = "redis_maxactive";
	static final String REDIS_KEY_TTL = "redis_key_ttl";
	static final String OPENAM_PROPERTIES_NAME = "openam.properties";
	static final String DEFAULT_PROPERTIES_PATH = File.separator + "conf" + File.separator + OPENAM_PROPERTIES_NAME;
	static final String DEFAULT_REDIS_TTL_STR = "1800"; 
	static final Integer DEFAULT_REDIS_TTL = 1800;

	static final String IPLANET_COOKIE_NAME = "iplanet_cookie_name";
	
	private static String openAMURL = null;
	private static String appBaseUrl = null;
	private static String appContext = null;
	private static String openAMCookieName = null;
	private static boolean skipTenantNameCheck = true;
	private static String redisMaster = null;
	private static String redisHostsPorts = null;
	private static String redisTimeout = null;
	private static String redisAuth = null;
	private static String redisMaxActive = null;
	private static Integer redisKeyTTL;
	private static String redisMaxActiveValue = "10000";

	private static Object lock = new Object();

	private static String openAMiPlanetCookieName = null;

	static {
		initOpenAMConfig();
	}

	PropertyFileHelper() {
		// empty
	}



	/**
	 * Reads the OpenAM config file
	 * @param: configFile
	 */
	static  void readConfig(String configFile) {
		LoggerHelper.info(LOGGER, ".readConfig() : Start");
		Properties openAMProps = FileStreamCreator.getPropsInstance();
			try (FileInputStream inputStream = FileStreamCreator.getFileInputStream(configFile)) {
				openAMProps.load(inputStream);
				populateOpenAM(openAMProps);
				populateRedis(openAMProps);
				populateOthers(openAMProps);
				logDetails();
			} catch (IOException ioe) {
				throw new IllegalArgumentException("Unable to set OpenAM Properties", ioe);
		}
	}

	private static synchronized void populateOthers(Properties openAMProps) {
		String value = openAMProps.getProperty(SKIP_TENANT_NAME_CHECK_STR);
		if (value != null) {
			skipTenantNameCheck = Boolean.parseBoolean(value);
		}
		appContext = openAMProps.getProperty(APP_CONTEXT);
		appBaseUrl = openAMProps.getProperty(APP_BASE_URL,AuthConstants.URL_LOCALHOST);
	}

	private static synchronized void populateRedis(Properties openAMProps) {
		redisMaster = openAMProps.getProperty(REDIS_MASTER);
		redisHostsPorts = openAMProps.getProperty(REDIS_HOSTS_PORTS);

		redisAuth= openAMProps.getProperty(REDIS_AUTH);
		redisMaxActive = openAMProps.getProperty(REDIS_MAX_ACTIVE);
		redisTimeout=openAMProps.getProperty(REDIS_TIMEOUT);
		String ttl = openAMProps.getProperty(REDIS_KEY_TTL, DEFAULT_REDIS_TTL_STR);
		try {
			redisKeyTTL=Integer.parseInt(ttl);
		} catch (NumberFormatException e) {
			redisKeyTTL = DEFAULT_REDIS_TTL;
			LoggerHelper.error(LOGGER, "Invalid value for redis TTL [{}], defaulting to [{}]", ttl , DEFAULT_REDIS_TTL_STR, DEFAULT_REDIS_TTL);
		}
	}



	private static synchronized void populateOpenAM(Properties openAMProps) {
		openAMURL = openAMProps.getProperty(OPENAM_URL);
		if (null == openAMURL || openAMURL.isEmpty()) {
			String openAmHost = getProperty(openAMProps, OPENAM_HOST);
			String openAmPort = getProperty(openAMProps, OPENAM_PORT);
			String openAmContext = getProperty(openAMProps, OPENAM_CONTEXT);
			String openAmScheme = getProperty(openAMProps, OPENAM_SCHEME);
			openAMURL = openAmScheme + AuthConstants.COLON_SLASH_SLASH + openAmHost + AuthConstants.COLON + openAmPort
					+ AuthConstants.SLASH + openAmContext;
		} else {
			LoggerHelper.info(LOGGER, "OpenAMURL Property set, host/port/context/scheme values will not be read");
		}
		
		String iPlanetCookie = openAMProps.getProperty(IPLANET_COOKIE_NAME);
		openAMiPlanetCookieName  = isEmpty(iPlanetCookie) ? AuthConstants.OPENAM_COOKIE_AUTHN_SSID : iPlanetCookie;
		String cookieName = openAMProps.getProperty(OPENAM_COOKIENAME);
		openAMCookieName = isEmpty(cookieName) ? AuthConstants.FALLBACK_AUTHN_TOKEN : cookieName;
	}

	/**
	 * Returns a property from properties file, raise an exception if the
	 * property is not found
	 * 
	 * @param props
	 *            Properties file
	 * @param key
	 *            The key for the property
	 * @return Value for the property Or IllegalArgumentException in case
	 *         property value is not found.
	 */
	private static String getProperty(Properties props, String key) {
		String value = props.getProperty(key);
		if (isEmpty(value)) {
			throw new IllegalArgumentException("Required property not found:" + key);
		}
		return value;
	}
	
	private static boolean isEmpty(String property) {
		return property == null || property.isEmpty();
	}

	private static void logDetails() {
		LoggerHelper.debug(LOGGER, ".readConfig : openamURL - [{}]", openAMURL);
		LoggerHelper.debug(LOGGER, ".readConfig : SKIP_TENANT_NAME_CHECK - [{}]", skipTenantNameCheck);
		LoggerHelper.debug(LOGGER,".readConfig : redisMaster [{}]", redisMaster);
		LoggerHelper.debug(LOGGER,".readConfig : redisHostsPorts [{}]", redisHostsPorts);
		LoggerHelper.debug(LOGGER,".readConfig : redisTimeout [{}]", redisTimeout);
		LoggerHelper.debug(LOGGER,".readConfig : redisAuth [{}]", redisAuth);
		LoggerHelper.debug(LOGGER,".readConfig : redisMaxActive [{}]", redisMaxActive);
		LoggerHelper.debug(LOGGER,".readConfig : redisKeyTTL [{}]", redisKeyTTL);
	}

	/**
	 * Created to help with unit testing but required for normal functionality as well.
	 * @author Sandeep.Agrrawal
	 *
	 */
	public static class FileStreamCreator {
		FileStreamCreator() {
			//empty
		}
		public static FileInputStream getFileInputStream(String fileName) throws FileNotFoundException {
			return new FileInputStream(fileName);
		}
		/**
		 * Returns the Properties instance
		 * @return: Properties
		 */
		public static Properties getPropsInstance() {
			return new Properties();
		}
	}

	/**
	 * Initializes the OpenAM config params
	 */
	static synchronized void initOpenAMConfig() {
		LoggerHelper.info(LOGGER,".initOpenAMConfig() : Start");
		//Try to read from system property first, default to CATALINA_HOME/conf/openam.properties
		String configFile = System.getProperty(OPENAM_CONFIG, System.getProperty(CATALINA_BASE)+DEFAULT_PROPERTIES_PATH);
		if(configFile==null)
		{
			throw new IllegalArgumentException("Could not get OpenAM properties location");
		}
		LoggerHelper.info(LOGGER, "OpenAM Config File:",configFile);
		readConfig(configFile);
		LoggerHelper.info(LOGGER,".initOpenAMConfig() : End");
	}

	public static boolean getSkipTenantNameCheck() {
		return skipTenantNameCheck;
	}

	/**
	 * Get the OpenAM Service URL
	 * @return: The OpemAM Server URL that needs to be hit
	 */
	public static String getOpenAMServerURL() {
		return openAMURL;
	}
	
	public static String getOpenAMCookieName() {
		return openAMCookieName;
	}

	public static String getApplicationURL() {
		return appBaseUrl + AuthConstants.SLASH + appContext;
	}

	public static String getRedisMaster(){
		return redisMaster;
	}

	public static Set<String> getSentinelHostsAndPorts() {
		Set<String> sentinelsSet = new HashSet<>(10);
		if (!AuthUtil.isEmpty(redisHostsPorts)) {
			StringTokenizer st = new StringTokenizer(redisHostsPorts, ",");
			while (st.hasMoreTokens()) {
				sentinelsSet.add(st.nextToken());
			}
		}
		return sentinelsSet;
	}

	public static String getRedisTimeout() {
		if(AuthUtil.isEmpty(redisTimeout)){
			synchronized (lock) {
				redisTimeout = Integer.toString(Protocol.DEFAULT_TIMEOUT);
			}
		}
		return redisTimeout;
	}

	public static String getRedisAuth() {
		return redisAuth;
	}
	
	/**
	 * TTL in seconds
	 * @return
	 */
	public static int getRedisKeyTTL() {
		return redisKeyTTL;
	}

	/**
	 * Max active sessions
	 * @return
	 */
	public static String getRedisMaxActive() {
		if(AuthUtil.isEmpty(redisMaxActive)){
			synchronized (lock) {
				redisMaxActive = redisMaxActiveValue;
			}
		}
		return redisMaxActive;
	}

	/**
	 * @return the openAMiPlanateCookieName
	 */
	public static String getOpenAMiPlanetCookieName() {
		return openAMiPlanetCookieName;
	}



	
	
}
