package com.kronos.auth.clientlib.post.authn.impl;

import java.util.Optional;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kronos.auth.clientlib.api.AuthNTokenProvider;
import com.kronos.auth.clientlib.exception.AuthNPublicException;
import com.kronos.auth.clientlib.post.authn.api.PostRefreshProcessingService;
import com.kronos.auth.clientlib.post.authn.api.PostRefreshProcessor;
import com.kronos.auth.clientlib.util.AuthConstants;
import com.kronos.auth.clientlib.util.LoggerHelper;

@Named("PostRefreshProcessingServiceClientLibImpl")
public class PostRefreshProcessingServiceImpl implements PostRefreshProcessingService {
	static final Logger LOGGER = LoggerFactory.getLogger(PostRefreshProcessingServiceImpl.class);

	@Inject
	Optional<PostRefreshProcessor> postRefreshProcessorExists;

	@Inject
	AuthNTokenProvider authNTokenProvider;

	@Override
	public String performPostRefresh(HttpServletRequest req, HttpServletResponse resp) throws AuthNPublicException {
		LoggerHelper.info(LOGGER, ".performPostRefresh(HttpServletRequest,HttpServletResponse) : Start");
		if (authNTokenProvider.getUserInfo(req) != null) {
			if (null != postRefreshProcessorExists && postRefreshProcessorExists.isPresent()) {
				PostRefreshProcessor postRefreshProcessor = postRefreshProcessorExists.get();
				postRefreshProcessor.processRefresh(req, resp);
			}

			LoggerHelper.info(LOGGER, ".performPostRefresh(HttpServletRequest,HttpServletResponse) : End");
			return AuthConstants.ACCEPTED;
		} else {
			LoggerHelper.debug(LOGGER,
					".performPostRefresh(HttpServletRequest,HttpServletResponse) : Failed to get userInfo returning status - "
							+ AuthConstants.UNAUTHORIZED);
			return AuthConstants.UNAUTHORIZED;
		}
	}

}
