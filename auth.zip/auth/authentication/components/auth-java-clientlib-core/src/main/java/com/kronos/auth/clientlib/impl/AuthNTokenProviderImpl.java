package com.kronos.auth.clientlib.impl;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import javax.inject.Named;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kronos.auth.clientlib.api.AuthNTokenProvider;
import com.kronos.auth.clientlib.exception.AuthNPublicException;
import com.kronos.auth.clientlib.exception.AuthNTokenPublicException;
import com.kronos.auth.clientlib.util.AuthConstants;
import com.kronos.auth.clientlib.util.AuthUtil;
import com.kronos.auth.clientlib.util.CookieHelper;
import com.kronos.auth.clientlib.util.LoggerHelper;
import com.kronos.auth.clientlib.util.PropertyFileHelper;
import com.kronos.auth.domain.OpenAmConfigAttrDTO;
import com.kronos.auth.domain.SSOSessionInfo;
import com.kronos.auth.domain.UserInfo;
import com.kronos.auth.domain.UserLocaleProfile;
import com.kronos.auth.encryption.util.EncryptionUtils;

@Named("AuthNTokenProviderImplClientLibImpl")
public class AuthNTokenProviderImpl implements AuthNTokenProvider {
	
	private static final String REASON = ", Reason [";
	private static final String LANGUAGE = "language";
	private static final String COUNTRY = "country";
	private static final String LOCALE_PROFILE_ID = "localeProfileId";
	private static final String REALM = "realm";
	private static final String UID = "uid";
	private static final String MAIL = "mail";
	private static final String FULLNAME = "fullName";
	private static final String LASTNAME = "lastName";
	private static final String FIRSTNAME = "firstName";
	private static final String SUPPORT_USER_ROLE = "userRole";
	private static final String ON_BEHALF_USER = "onBehalfUser";
	private static final String IS_SYSTEM_USER = "systemUser";
	private static final String ERROR_MESSAGE = "There is Problem while getting the sessionTimeOut- ";
	private static final String OPENAM_CONNECT_ERROR_MSG = "Some error occured while processing at OpenAM server - ";
	private static final String ERROR_FETCHING_OPENAM_URL_MSG = "Error occured while fetching OpenAM server URL";
	private static final String EQUAL = "=";
	private static final String ATTRIBUTENAMES_MAXIDLETIME = "/identity/attributes?attributenames=maxidletime";
	private static final String ATTRIBUTENAMES_TIMELEFT = "/identity/attributes?attributenames=timeLeft";
	private static final String COOKIE_DELIMETER = "|";
	private static final String JSON_AUTHENTICATE = "/json/authenticate";
	private static final String JSON = "/json";
	private static final String AUTHENTICATE = "/authenticate";
	
	private static final String CONNECT_JWK_URI_ENDPOINT = "/connect/jwk_uri";
	private static final String OAUTH = "oauth2";
	private static final String TOKENID = "tokenId";
	private static final String DEFAULT = "DEFAULT";
	private static final String TENANT_ID = "tenantId";
	private static final String JSON_LOGOUT = "/json/sessions/?_action=logout";
	private static final String COOKIE = "Cookie";
	private static final String AUTHORIZE = "/authorize";
    private static final String SUPPORT_USER_FIRST_NAME = "supportUserFName";
    private static final String SUPPORT_USER_LAST_NAME = "supportUserLName";
    private static final String SUPPORT_USER_NAME = "supportUserName";
    private static final String API_SESSION_INFO = "/json/sessions/?_action=getSessionInfo&tokenId=";
    
	public static final Logger LOGGER = LoggerFactory.getLogger(AuthNTokenProviderImpl.class);
	
	private static final String USER_LOCALE_PROFILE = "userLocaleProfile";
	private static final String SET_COOKIE ="Set-Cookie";
	private static final String TICKET_REASON ="ticketReason";
	private static final String MFA_REQUIRED ="mfaRequired";
	private static final String USER_AUTH_TYPE ="userAuthType";
	private static final String USR_LOGON_PROFILE ="logonProfile";
	private static final String EXCLUDE_COOKIE_KEYWORDS = "Version, Domain, Path";
	private static final String OPENAM_CONNECT_ERROR_MSG_USER_PASS_BLANK = "username/password is blank";
	private static final String BLANK_STRING= "";
	private static final String IDLE_EXPTIME = "maxIdleExpirationTime";
	private static final String SESSION_EXPTIME = "maxSessionExpirationTime";

	/**
	 * This method returns userinfo instance from httprequest
	 * @param request
	 * @return usrInfo
	 * @throws AuthNTokenPublicException
	 */
	@Override
	public UserInfo getUserInfo(HttpServletRequest request) throws AuthNPublicException {
		LoggerHelper.info(LOGGER,".getUserInfo Start");
		UserInfo userInfo = null;
		if(null!= getOpenAMServerURL(request.getCookies())) {
			String jwkUri = getOpenAMServerURL(request.getCookies()) + AuthConstants.SLASH + OAUTH + CONNECT_JWK_URI_ENDPOINT;
			String authNToken = CookieHelper.getCookieValue(request, PropertyFileHelper.getOpenAMCookieName());
			Cookie[] cookies = request.getCookies();
			UserInfo usrInfo = getUserInfoFromJWTToken(userInfo, jwkUri, authNToken, cookies,request);
			if(null!=usrInfo) {
			addOAuthTokenToUserInfo(cookies, usrInfo);
			}
			LoggerHelper.info(LOGGER,".getUserInfo : End");
			return usrInfo;
		}else{
			throw getAuthNException("Failed to retrieve server URL found : [" + PropertyFileHelper.getOpenAMServerURL() + 
					"]. System environment variable defining openAM server information may not be set.", null);
		}
	}

	/**
	 * This method returns userinfo instance from cookies
	 * @param cookies
	 * @return usrInfo
	 * @throws AuthNTokenPublicException
	 */
	@Override
	public UserInfo getUserInfo(Cookie[] cookies) throws AuthNTokenPublicException{
		LoggerHelper.info(LOGGER,".getUserInfo(Cookie[]) Start");
		UserInfo userInfo = null;
		String jwkUri = getOpenAMServerURL(cookies) + AuthConstants.SLASH + OAUTH + CONNECT_JWK_URI_ENDPOINT;
		String  authNToken = CookieHelper.getCookieValue(cookies, PropertyFileHelper.getOpenAMCookieName());
		UserInfo usrInfo = getUserInfoFromJWTToken(userInfo, jwkUri, authNToken, cookies,null);
		if (null != usrInfo) {
			addOAuthTokenToUserInfo(cookies, usrInfo);
		}
		LoggerHelper.debug(LOGGER, ".getUserInfo(Cookie[]) Returning usrInfo [{}]",usrInfo);
		LoggerHelper.info(LOGGER,".getUserInfo(Cookie[]) End");
		return usrInfo;
	}

	/**
	 * This method is used for setting auth token to userinfo instance
	 * @param cookies
	 * @param usrInfo
	 */
	private void addOAuthTokenToUserInfo(Cookie[] cookies, UserInfo usrInfo) {
		String authzUrl = getAuthzURL(usrInfo);
		usrInfo.setOpenAmAuthzUrl(authzUrl);
		usrInfo.setOpenAmCookie(CookieHelper.getCookieValue(cookies, AuthConstants.IPLANET_COOKIE));
	}

	private String getAuthzURL(UserInfo usrInfo) {
		String authzUrl = PropertyFileHelper.getOpenAMServerURL();
		if(usrInfo != null) {
			String realm = usrInfo.getTenantShortName();
			if (null == realm || realm.isEmpty() || realm.equals(AuthConstants.SLASH)) {
				authzUrl = authzUrl + AuthConstants.SLASH + OAUTH + AUTHORIZE;
			} else {
				authzUrl = authzUrl + AuthConstants.SLASH + OAUTH + AuthConstants.SLASH + realm + AUTHORIZE;	
			}
		}
		return authzUrl;
	}
	
	/**
	 * This methos is used to get userinfo from jwt token
	 * @param userInfo
	 * @param jwkUri
	 * @param authNToken
	 * @param cookies
	 * @param request
	 * @return usrInfo
	 * @throws AuthNTokenPublicException 
	 */
	private UserInfo getUserInfoFromJWTToken(UserInfo userInfo, String jwkUri, String authNToken, Cookie[] cookies, HttpServletRequest request) throws AuthNTokenPublicException{
		LoggerHelper.info(LOGGER,".getUserInfoFromJWTToken : Start");
		String encrypUserDtls = null;
		UserInfo usrInfo = userInfo;
		String authToken = authNToken;
		if(null != authToken && authToken.contains(COOKIE_DELIMETER)){
			String[] cookieValues = authToken.split(Pattern.quote(COOKIE_DELIMETER));
			authToken = cookieValues[0];
			encrypUserDtls = getDecodedUserInfo(encrypUserDtls, cookieValues);
		}
		usrInfo = getJWTPayLoad(jwkUri, authNToken, cookies, usrInfo, authToken);
		if(null != encrypUserDtls && null != usrInfo){
			updateUserInfo(usrInfo, encrypUserDtls, request);
		}
		LoggerHelper.debug(LOGGER, ".getUserInfoFromJWTToken Returning usrInfo [{}]",usrInfo);
		LoggerHelper.info(LOGGER,".getUserInfoFromJWTToken : End");
		return 	usrInfo;
	}

	/**
	 * This method is used for extracting the jwt payload
	 * @param jwkUri
	 * @param authNToken
	 * @param cookies
	 * @param usrInfo
	 * @param authToken
	 * @return userInfo
	 * @throws AuthNTokenPublicException 
	 */
	private UserInfo getJWTPayLoad(String jwkUri, String authNToken,
			Cookie[] cookies, UserInfo usrInfo, String authToken)
					throws AuthNTokenPublicException {
		LoggerHelper.info(LOGGER,".getJWTPayLoad : Start");
		UserInfo userInfo = usrInfo;
		if (null !=jwkUri && null != authToken) 
		{
			try {
				String jwtPayload = JWTTokenProcessor.getJWTPayload(jwkUri, authToken);
				if (null != jwtPayload) {
					userInfo = getUser(jwtPayload, cookies);
				}
			}catch(AuthNTokenPublicException ex){
				throw ex;
			}catch (Exception e) {
				throw  getAuthNException("Error parsing json web token from json web key from uri [" + jwkUri+"] and JWT_Token is ["+authNToken+"] , Reason ["+e.getMessage()+"]",e);
			}
		}
		LoggerHelper.debug(LOGGER, ".getJWTPayLoad Returning usrInfo [{}]",userInfo);
		LoggerHelper.info(LOGGER,".getJWTPayLoad : End");
		return 	userInfo;
	}

	/**
	 * This method returns the decoded user info
	 * @param encrUserDetails
	 * @param cookieValues
	 * @return encryUserDetails
	 */
	private String getDecodedUserInfo(String encrUserDetails,
			String[] cookieValues) {
		LoggerHelper.info(LOGGER,".getDecodedUserInfo : Start");
		String encryUserDetails = encrUserDetails;
		if((null!=cookieValues)&&(cookieValues.length!=0)){
			java.util.Base64.Decoder decoder = java.util.Base64.getDecoder();
			byte[] decodedValue = decoder.decode(cookieValues[1]);
			encryUserDetails = new String(decodedValue);
		}
		LoggerHelper.info(LOGGER,".getDecodedUserInfo : End");
		return encryUserDetails;
	}


	/**
	 * THis method is used for updating the user info instance 
	 * @param userInfo
	 * @param encrUserDetails
	 * @param request
	 * @throws AuthNTokenPublicException
	 */
	private void updateUserInfo(UserInfo userInfo, String encrUserDetails, HttpServletRequest request)
			throws AuthNTokenPublicException {
		LoggerHelper.info(LOGGER,".updateUserInfo(UserInfo) : Start");
		String userDetails = getDecryptUserDetails(encrUserDetails);
		LoggerHelper.debug(LOGGER, ".updateUserInfo(UserInfo) : DecryptUserDetails [{}]",userDetails);
		JSONObject userDetailsJson = null;
		try {
			userDetailsJson = new JSONObject(userDetails);
		} catch (JSONException e) {
			throw getAuthNException("Problem while json conversion for -" + userDetails +", Reason["+e.getMessage()+"]",e);
		}
		try {
			if(validateUser(userInfo, userDetailsJson, request)){
				setUserInfoDetails(userInfo, userDetailsJson);
			} else {
				throw new AuthNTokenPublicException("User Validation failed ::: User token doesn't belong to the tenant id sent in the request", AuthConstants.UNAUTHORIZED);
			}
		} catch (JSONException e) {
			throw getAuthNException("Problem while json conversion for -" + userDetailsJson +REASON+e.getMessage()+"]",e);
		}
		LoggerHelper.info(LOGGER,".updateUserInfo(UserInfo) : End");
	}

	/**
	 * This method is used for setting user info details
	 * @param userInfo
	 * @param userDetailsJson
	 * @throws JSONException
	 */
	private void setUserInfoDetails(UserInfo userInfo,
			JSONObject userDetailsJson) {
		LoggerHelper.info(LOGGER,".setUserInfoDetails(UserInfo,JSONObject) : Start");
		if(!userDetailsJson.isNull(FIRSTNAME))
			userInfo.setFirstName(userDetailsJson.getString(FIRSTNAME));
		if(!userDetailsJson.isNull(LASTNAME))
			userInfo.setLastName(userDetailsJson.getString(LASTNAME));
		if(!userDetailsJson.isNull(FULLNAME))
			userInfo.setFullName(userDetailsJson.getString(FULLNAME));
		if(!userDetailsJson.isNull(MAIL))
			userInfo.setMail(userDetailsJson.getString(MAIL));
		if(!userDetailsJson.isNull(UID))
			userInfo.setUsername(userDetailsJson.getString(UID));
		if(!userDetailsJson.isNull(USER_LOCALE_PROFILE))
			setUserLocaleProfile(userInfo, userDetailsJson);
		if(!userDetailsJson.isNull(USR_LOGON_PROFILE))
			userInfo.setLogonProfile(userDetailsJson.getString(USR_LOGON_PROFILE));
		setSupportAndSystemUserDetails(userInfo, userDetailsJson);
		LoggerHelper.debug(LOGGER, ".setUserInfoDetails(UserInfo,JSONObject) : Updated userInfo [{}] ",userInfo);
		LoggerHelper.info(LOGGER,".setUserInfoDetails(UserInfo,JSONObject) : End");
	}

	/**
	 * This method is used for setting details w.r.t system and support user
	 * @param userInfo
	 * @param userDetailsJson
	 */
	private void setSupportAndSystemUserDetails(UserInfo userInfo, JSONObject userDetailsJson) {
		if(!userDetailsJson.isNull(ON_BEHALF_USER))
			userInfo.setOnBehalfUser(userDetailsJson.getString(ON_BEHALF_USER));
		if(!userDetailsJson.isNull(IS_SYSTEM_USER))
			userInfo.setSystemUser(userDetailsJson.getBoolean(IS_SYSTEM_USER));
		if(!userDetailsJson.isNull(SUPPORT_USER_ROLE))
			userInfo.setSupportUserRole(userDetailsJson.getString(SUPPORT_USER_ROLE));
        if(!userDetailsJson.isNull(SUPPORT_USER_FIRST_NAME))
            userInfo.setSupportUserFirstName(userDetailsJson.getString(SUPPORT_USER_FIRST_NAME));
        if(!userDetailsJson.isNull(SUPPORT_USER_LAST_NAME))
            userInfo.setSupportUserLastName(userDetailsJson.getString(SUPPORT_USER_LAST_NAME));
        if(!userDetailsJson.isNull(TICKET_REASON))
            userInfo.setTicketReason(userDetailsJson.getString(TICKET_REASON));
        if(!userDetailsJson.isNull(SUPPORT_USER_NAME)) 
            userInfo.setSupportUserName(userDetailsJson.getString(SUPPORT_USER_NAME));
        if(!userDetailsJson.isNull(MFA_REQUIRED))
            userInfo.setMfaRequired(userDetailsJson.getBoolean(MFA_REQUIRED));
        if(!userDetailsJson.isNull(USER_AUTH_TYPE))
            userInfo.setUserAuthType(userDetailsJson.getString(USER_AUTH_TYPE));
	}
	
	/**
	 * This method is used for setting user locale profile
	 * @param userInfo
	 * @param userDetailsJson
	 */
	protected void setUserLocaleProfile(UserInfo userInfo,
			JSONObject userDetailsJson) {
			UserLocaleProfile userLocaleProfile = new UserLocaleProfile();
			JSONObject userProfileJsonObj = userDetailsJson.getJSONObject(USER_LOCALE_PROFILE);
			if(!userProfileJsonObj.isNull(LOCALE_PROFILE_ID) ){
				userLocaleProfile.setLocaleProfileId(userProfileJsonObj.getString(LOCALE_PROFILE_ID));
			}
			if(!userProfileJsonObj.isNull(COUNTRY) ){
				userLocaleProfile.setCountry(userProfileJsonObj.getString(COUNTRY));
			}
			if(!userProfileJsonObj.isNull(LANGUAGE)){
				userLocaleProfile.setLanguage(userProfileJsonObj.getString(LANGUAGE));
			}
			userInfo.setUserLocaleProfile(userLocaleProfile);
			LoggerHelper.debug(LOGGER,"UserLocaleProfile set in user Info object: " + userLocaleProfile);
	}

	/**
	 * This method is used for decrypting the user details
	 * @param encrUserDetails
	 * @return userDetails
	 * @throws AuthNTokenPublicException
	 */
	private String getDecryptUserDetails(String encrUserDetails)
			throws AuthNTokenPublicException {
		LoggerHelper.info(LOGGER,".getDecryptUserDetails(String) : Start");
		String userDetails = null;
		try {
			userDetails = EncryptionUtils.decrypt(encrUserDetails);
		} catch (Exception e) {
			throw getAuthNException("Problem while decrypting the userdetails cookie-" + encrUserDetails+ REASON +e.getMessage()+"]",e);
		}
		LoggerHelper.info(LOGGER,".getDecryptUserDetails(String) : End");
		return userDetails;
	}
	/**
	 * @param userInfo
	 * @param jsonObject
	 * @param request
	 * @return
	 * @throws JSONException
	 */
	private boolean validateUser(UserInfo userInfo, JSONObject jsonObject, HttpServletRequest request) {
		return userInfo.getUsername().equalsIgnoreCase(jsonObject.getString(UID)) && validateTenant(userInfo, jsonObject, request);
	}

	/**
	 * @param userInfo
	 * @param jsonObject
	 * @param request
	 * @return
	 * @throws JSONException
	 */
	private boolean validateTenant(UserInfo userInfo, JSONObject jsonObject, HttpServletRequest request) {
		LoggerHelper.info(LOGGER,".validateTenant(UserInfo,JSONObject) : Start");
		String tenantName = userInfo.getTenantShortName();
		LoggerHelper.debug(LOGGER, ".validateTenant(UserInfo,JSONObject) : tenantName [{}] , realm [{}]",tenantName,jsonObject.getString(REALM));
		
		if(request==null || (request.getParameter(TENANT_ID)==null)) {
			return tenantName.equalsIgnoreCase(jsonObject.getString(REALM));
		} else {
			String tenantNameReqParam = request.getParameter(TENANT_ID);
			if(DEFAULT.equalsIgnoreCase(tenantNameReqParam)){
				tenantNameReqParam="/";
			}
			boolean checkVal = tenantName.equalsIgnoreCase(jsonObject.getString(REALM));
			if (!PropertyFileHelper.getSkipTenantNameCheck()) {
				checkVal &= tenantNameReqParam.equalsIgnoreCase(jsonObject.getString(REALM));
			} else {
				LoggerHelper.debug(LOGGER,".validateTenant(UserInfo,JSONObject) : Skipping request realm check");
			}
			return checkVal;
		}
	}

	/**
	 * This method is used for fetching user info details from jwt payload
	 * @param jwtPayload
	 * @param cookies
	 * @return userInfo
	 * @throws AuthNPublicException
	 */
	private UserInfo getUser(String jwtPayload, Cookie[] cookies) throws AuthNPublicException {
		LoggerHelper.info(LOGGER,".getUser(String,Cookie[]) : Start");
		UserInfo userInfo = null;
		JSONObject jsonObject = new JSONObject(jwtPayload);
		String username = jsonObject.getString("sub");
		String tenantName = jsonObject.getString(REALM);
		long expireTime = jsonObject.getLong("exp");
		if (null != username && null != tenantName) {
			userInfo = new UserInfo(username, tenantName);
			if (System.currentTimeMillis() >= expireTime * 1000) {
				LoggerHelper.debug(LOGGER, ".getUser(String,Cookie[]) : token session expired, system time [{}] and token time [{}]",System.currentTimeMillis(),expireTime);
				try {
					userInfo = isUserSessionValid(cookies, userInfo);
				} catch (IOException e) {
					throw getAuthNException(ERROR_MESSAGE + e.getMessage(),e);
				}

			}
		}
		LoggerHelper.info(LOGGER,".getUser : End");
		LoggerHelper.debug(LOGGER,".getUser : Returning userInfo ["+userInfo+"]");
		return userInfo;

	} 

	/**
	 * This method is used to check if the provided user's session is valid or not
	 * @param cookies
	 * @param userInfo
	 * @return userInfo
	 * @throws IOException, AuthNPublicException
	 */
	private UserInfo isUserSessionValid(Cookie[] cookies, UserInfo userInfo)
			throws IOException, AuthNPublicException {
		LoggerHelper.info(LOGGER,".isUserSessionValid(Cookie[],UserInfo) : Start");
		String url = getOpenAMServerURL(cookies) + ATTRIBUTENAMES_TIMELEFT;
		LoggerHelper.debug(LOGGER,".isUserSessionValid : url ["+url+"]");
		StringBuilder response = AuthUtil.getResponseFromUrl(cookies,url);
		if (response != null) {
			try{
				String body = response.toString();
				LoggerHelper.debug(LOGGER,".isUserSessionValid(Cookie[],UserInfo) : response form server [{}]",body);
				int startIndex = body.lastIndexOf(EQUAL);
				String userSessionTimeLeft = body.substring(startIndex + 1,
						body.length() - 1);
				if (Integer.valueOf(userSessionTimeLeft) <= 0) {
					throw getAuthNException("Could not validate User Session - User session has expired",null);
				} else{
					LoggerHelper.debug(LOGGER,".isUserSessionValid : Returning userInfo ["+userInfo+"]");
					LoggerHelper.info(LOGGER,".isUserSessionValid(Cookie[],UserInfo) : End");
					return userInfo;
				}
			}catch(RuntimeException rex){
				LoggerHelper.debug(LOGGER,".isUserSessionValid(Cookie[],UserInfo) : response from URL [{}]is [{}]",url,rex.getMessage());
				throw getAuthNException(rex.getMessage(),rex);
			}
		} else{
			LoggerHelper.debug(LOGGER,".isUserSessionValid(Cookie[],UserInfo) : response from URL [{}]is null",url);
			throw getAuthNException("Could not validate User Session - SSO Token is missing",null);
		}
	}

	/**
	 * This method returns the value of session timeout
	 * @param httpReq
	 * @return OpenAmConfigAttrDTO
	 * @throws AuthNPublicException
	 */
	@Override
	public OpenAmConfigAttrDTO getSessionTimeOut(HttpServletRequest httpReq) throws AuthNPublicException{
		LoggerHelper.info(LOGGER,".getSessionTimeOut : Start");
		try{
			Cookie[] cookies = httpReq.getCookies();
			if(cookies == null){
				LoggerHelper.debug(LOGGER,".getSessionTimeOut : could not get SessionTimeout Time as cookie was null");
				LoggerHelper.info(LOGGER,".getSessionTimeOut : End");
				throw new AuthNPublicException("No cookies received from request........", AuthConstants.INTERNAL_SERVER_ERROR);
			}
			String url = null;
			if(null!= getOpenAMServerURL(cookies)) {
				url = getOpenAMServerURL(cookies) + ATTRIBUTENAMES_MAXIDLETIME;
			}
			StringBuilder response = AuthUtil.getResponseFromUrl(cookies, url);
			OpenAmConfigAttrDTO attrDTO = null;
			if(response!=null)
			{
				LoggerHelper.debug(LOGGER,".getSessionTimeOut : Response from server [{}] is [{}]",url,response.toString());
				attrDTO = getAttrDTO(response.toString());
			}else{
				LoggerHelper.debug(LOGGER,".getSessionTimeOut : Response from server [ {} ] is [ {} ]",url,response);
			}
			LoggerHelper.debug(LOGGER,".getSessionTimeOut : attrDTO ["+attrDTO+"]");
			LoggerHelper.info(LOGGER,".getSessionTimeOut : End");
			return attrDTO;
		}catch(IOException e){
			LOGGER.error(e.getMessage(),e);
			throw getAuthNException(ERROR_MESSAGE +e.getMessage(),e);
		}
	}

	/**
	 * @param response
	 * @return OpenAmConfigAttrDTO
	 */
	private OpenAmConfigAttrDTO getAttrDTO(String response) {
		LoggerHelper.info(LOGGER,".getAttrDTO(String) : Start");
		String body = response;
		int startIndex = body.lastIndexOf(EQUAL);
		String sessionTimeOutVal = body.substring(startIndex + 1, body.length());
		OpenAmConfigAttrDTO attrDTO = new OpenAmConfigAttrDTO();
		attrDTO.setSessionTimeout(sessionTimeOutVal.trim());
		LoggerHelper.debug(LOGGER,".getAttrDTO(String) : Returning attrDTO [{}]  "+attrDTO);
		LoggerHelper.info(LOGGER,".getAttrDTO(String) : End");
		return attrDTO;
	}
	
	/**
	 * @deprecated
	 * Get the OpenAM Service URL
	 * @param cookies: The cookies that are obtained from the server
	 * @return: The OpemAM Server URL that needs to be hit
	 */
	@Deprecated
	public String getOpenAMServerURL(Cookie[] cookies) {
		LoggerHelper.info(LOGGER,".getOpenAMServerURL(Cookie[]) : Start");
		String url = PropertyFileHelper.getOpenAMServerURL();
		if (null!=url) {
			LoggerHelper.debug(LOGGER,".getOpenAMServerURL(Cookie[]) : Returning URL from System Env - "+url);
			LoggerHelper.info(LOGGER,".getOpenAMServerURL(Cookie[]) : End");
			return  url;
		} 
		LoggerHelper.debug(LOGGER,".getOpenAMServerURL(Cookie[]) : Could not find openAM URL through System Env or Cookies, Returning URL as null");
		LoggerHelper.info(LOGGER,".getOpenAMServerURL(Cookie[]) : End");
		return null;
	}

	/**
	 * @deprecated
	 * @return
	 */
	@Deprecated
	public String getOpenAMServerURL() {
		return PropertyFileHelper.getOpenAMServerURL();
	}

	/**
	 * Generates desired cookies from cookiesList
	 * and Excludes Version, Path, Domain from cookieList
	 * @param cookiesList
	 * @return Cookie[]
	 */
	private Cookie[] generateCookies(List<String> cookiesList){
		LoggerHelper.info(LOGGER,".generateCookies : Start");
		String logString = "created cookie [{}] with value [{}]";
		List<Cookie> cookieList = new ArrayList<>();
		for(String returnedString: cookiesList){
			for(String retVal: returnedString.split(";")) {
				int index = retVal.indexOf('=');
				if (index < 0) {
					continue;
				}
				String key = retVal.substring(0, index);
				String value = retVal.substring(index + 1, retVal.length());
				if(!EXCLUDE_COOKIE_KEYWORDS.contains(key.trim())){
					cookieList.add(new Cookie(key, value));
				}
				LoggerHelper.debug(LOGGER,logString,key,value);
			}
		}
		Cookie[] cookieType = {};
		Cookie[] cookies = cookieList.toArray(cookieType);
		LoggerHelper.info(LOGGER,".generateCookies : End");
		return cookies;
	}

	/**
	 * @deprecated
	 * Returns the AuthNCookies corresponding to the input parameter username and password
	 * @param username: Input Username
	 * @param password: Input Password
	 * @return: Returns the cookies if found or NULL
	 * @throws AuthNTokenPublicException 
	 */
	@Deprecated
	@Override
	public Cookie[] getAuthNCookies(String userName, String password) throws AuthNTokenPublicException {
		LoggerHelper.info(LOGGER,".getAuthNCookies(String,String) : Start");
		String authURL = null;
		validateUserPass(userName, password);
		String openAmUrl = PropertyFileHelper.getOpenAMServerURL();
		if (null!= openAmUrl) {
			try {
				authURL = openAmUrl + JSON_AUTHENTICATE;  	
				HttpURLConnection con = AuthUtil.getHttpConnection(userName, password, authURL, null);
				List<String> cookiesList = null;
				Map<String, List<String>> map = con.getHeaderFields();
				for (Map.Entry<String, List<String>> entry : map.entrySet()) {
					if (entry.getKey() != null && SET_COOKIE.equals(entry.getKey())) {
						cookiesList = entry.getValue();
					}
				}
				List<String> modifiedCookieList = addIPlanetCookie(con, cookiesList);
				LoggerHelper.debug(LOGGER, ".getAuthNCookies(String,String) : Generating Cookies for [{}]",modifiedCookieList);
				LoggerHelper.info(LOGGER,".getAuthNCookies(String,String) : End");
				return generateCookies(modifiedCookieList);

			} catch (IOException e) {
				throw getAuthNException(OPENAM_CONNECT_ERROR_MSG + authURL+ REASON +e.getMessage()+"]",e);
			}
		}else{
			throw getAuthNException(ERROR_FETCHING_OPENAM_URL_MSG + openAmUrl,null);     
		}

	}
	
	/**
	 * This method is used for getting the value of authn cookies corresponding to a specific tenant user
	 * @param userName
	 * @param password
	 * @param tenantID
	 * @return Cookie[]
	 * @throws AuthNTokenPublicException
	 */
	@Override
	public Cookie[] getAuthNCookies(String userName, String password, String tenantID) throws AuthNPublicException {
		LoggerHelper.info(LOGGER,".getAuthNCookies(String,String,String) : Start");
		Cookie[] cookies = this.getAuthNCookies(userName, password, tenantID, null);
		LoggerHelper.info(LOGGER,".getAuthNCookies(String,String,String) : End");
		return cookies;
	}

	/**
	 * @param userName
	 * @param password
	 * @param tenantID
	 * @param openAmBaseURL
	 * @return Cookie[]
	 * @throws AuthNTokenPublicException
	 */
	@Override
	public Cookie[] getAuthNCookies(String userName, String password, String tenantID, String openAmBaseURL) throws AuthNPublicException {
		LoggerHelper.info(LOGGER,".getAuthNCookies(String,String,String,String) : Start");
		String authURL = null;
		validateUserPass(userName, password);
		try {
			authURL = getOpenAMAuthenticationURL(tenantID, openAmBaseURL);
			HttpURLConnection con = AuthUtil.getHttpConnection(userName, password, authURL,null);
			List<String> cookiesList = null;
			Map<String, List<String>> map = con.getHeaderFields();
			for (Map.Entry<String, List<String>> entry : map.entrySet()) {
				if (entry.getKey() != null && SET_COOKIE.equals(entry.getKey())) {
					cookiesList = entry.getValue();
				}
			}
			List<String> modifiedCookieList = addIPlanetCookie(con, cookiesList);
			LoggerHelper.debug(LOGGER, ".getAuthNCookies(String,String,String,String) : Generating Cookies for [{}]",modifiedCookieList);
			LoggerHelper.info(LOGGER,".getAuthNCookies(String,String,String,String) : End");
			return generateCookies(modifiedCookieList);

		} catch (IOException e) {
			throw getAuthNException(OPENAM_CONNECT_ERROR_MSG + authURL+ REASON +e.getMessage()+"]",e);
		}
	}

	
	/**
	 * This method returns the authenticate url corresponding to the server
	 * @param tenantID
	 * @return openAMAuthenticationURL
	 * @throws AuthNPublicException
	 */
	String getOpenAMAuthenticationURL(String tenantID) throws AuthNPublicException {
		return this.getOpenAMAuthenticationURL(tenantID, null);
	}
	
	/**
	 * @param tenantID
	 * @param oamBaseUrl
	 * @return authURL
	 * @throws AuthNPublicException
	 */
	String getOpenAMAuthenticationURL(String tenantID, String oamBaseUrl) throws AuthNPublicException {
		String openAmBaseUrl = oamBaseUrl;
		if (openAmBaseUrl == null) {
			openAmBaseUrl = PropertyFileHelper.getOpenAMServerURL();
		}
		
		String tenantURL = null;
		if (null != tenantID && !tenantID.isEmpty() && !DEFAULT.equalsIgnoreCase(tenantID) && !AuthConstants.SLASH.equals(tenantID)) {
			tenantURL = AuthConstants.SLASH + tenantID;
		}
		if (null != openAmBaseUrl) {
			String authURL = openAmBaseUrl + JSON;
			if (null != tenantURL) {
				authURL = authURL + tenantURL + AUTHENTICATE;
			} else {
				authURL = authURL + AUTHENTICATE;
			}
			return authURL;
		} else {
			throw getAuthNException(ERROR_FETCHING_OPENAM_URL_MSG + openAmBaseUrl, null);    
		}
	}

	@Override
	public Cookie[] getSystemUserAuthNCookies(String userName, String password, 
			String tenantID, String onBehalfUser) throws AuthNPublicException {
		LoggerHelper.info(LOGGER,".getSystemUserAuthNCookies(String,String,String,String) : Start");
		Cookie[] cookies = this.getSystemUserAuthNCookies(userName, password, tenantID, onBehalfUser, null);
		LoggerHelper.info(LOGGER,".getSystemUserAuthNCookies(String,String,String,String) : End");
		return cookies;
	}

	@Override
	public Cookie[] getSystemUserAuthNCookies(String userName, String password, 
			String tenantID, String onBehalfUser, String openAmBaseUrl) throws AuthNPublicException {
		LoggerHelper.info(LOGGER,".getSystemUserAuthNCookies(String,String,String,String,String) : Start");
		String authURL = null;
		validateUserPass(userName, password);
		try {
			authURL = getOpenAMAuthenticationURL(tenantID, openAmBaseUrl);
			HttpURLConnection con = AuthUtil.getSystemUserAuthHttpConnection(userName, password, authURL, onBehalfUser);
			return getAuthCookies(con);
		} catch (IOException e) {
			throw getAuthNException(OPENAM_CONNECT_ERROR_MSG + authURL + REASON + e.getMessage() + "]", e);
		}
	}
	
	
	@Override
	public AccessToken getAccessToken(HttpServletRequest request,String clientId) throws AuthNPublicException {
			LoggerHelper.info(LOGGER, "getAccessToken(HttpServletRequest request,String clientId) called");
			Cookie[] cookies = request.getCookies();
			UserInfo userInfo = getUserInfo(cookies);
			String authzURL = getAuthzURL(userInfo);
			return AuthUtil.processAuthorizeRequest(authzURL, 
							CookieHelper.getCookieValue(cookies, PropertyFileHelper.getOpenAMiPlanetCookieName()), userInfo.getUsername(),clientId);
	}
	
	@Override
	public Cookie[] getSystemUserAuthNCookies(String userName, String password, String tenantID, String firstName,
			String lastName, String openAmBaseUrl) throws AuthNPublicException {
		LoggerHelper.info(LOGGER, ".getSystemUserAuthNCookies(String,String,String,String,String,String) : Start");
		String authURL = null;
		validateUserPass(userName, password);
		try {
			authURL = getOpenAMAuthenticationURL(tenantID, openAmBaseUrl);
			HttpURLConnection con = AuthUtil.getSystemUserAuthConnection(userName, password, firstName,
					lastName, authURL);
			Cookie[] returnCookies = getAuthCookies(con);
			LoggerHelper.info(LOGGER, ".getSystemUserAuthNCookies(String,String,String,String,String,String) : End");
			return returnCookies;
		} catch (Exception e) {
			throw getAuthNException(OPENAM_CONNECT_ERROR_MSG + authURL + REASON + e.getMessage() + "]", e);
		}
	}

	/**
	 * @param con
	 * @return returnCookies
	 * @throws IOException
	 */
	private Cookie[] getAuthCookies(HttpURLConnection con) throws IOException {
		LoggerHelper.info(LOGGER,".getAuthCookies : Start");
		List<String> cookiesList = null;
		Map<String, List<String>> map = con.getHeaderFields();
		for (Map.Entry<String, List<String>> entry : map.entrySet()) {
			if (SET_COOKIE.equals(entry.getKey())) {
				cookiesList = entry.getValue();
			}
		}
		List<String> modifiedCookieList = addIPlanetCookie(con, cookiesList);
		LoggerHelper.debug(LOGGER,
				".getAuthCookies(HttpURLConnection) : Generating Cookies for [{}]",
				modifiedCookieList);
		LoggerHelper.info(LOGGER, ".getAuthCookies(HttpURLConnection) : End");
		Cookie[] returnCookies = generateCookies(modifiedCookieList);
		LoggerHelper.info(LOGGER,".getAuthCookies : Start");
		return returnCookies;
	}

	/**
	 * adds the IPlanetCookie.
	 * @param con
	 * @param cookiesList
	 * @return
	 * @throws IOException
	 */
	private List<String> addIPlanetCookie(HttpURLConnection con, List<String> cookiesList) throws IOException {
		LoggerHelper.info(LOGGER,".addIPlanetCookie(HttpURLConnection,List<String>) : Start");
		String iPlanet = getIPlanetFromResponse(con);
		List <String> modifiableCookieList = cookiesList;
		if(iPlanet!=null){
			modifiableCookieList = new ArrayList<>(cookiesList);
			// add the new IPlanetDirectoryPro cookie for further use.
			LoggerHelper.debug(LOGGER, ".addIPlanetCookie(HttpURLConnection,List<String>) : added  iPlanet cookie [{}] in CookieList {{}}",iPlanet,modifiableCookieList);
			modifiableCookieList.add(iPlanet);
			String cookieValue = iPlanet.contains("=") ? iPlanet.split("=")[1] :"";
			modifiableCookieList.add(AuthConstants.OPENAM_COOKIE_AUTHN_SSID + "=" + cookieValue);
		}
		LoggerHelper.info(LOGGER,".addIPlanetCookie(HttpURLConnection,List<String>) : End");
		return modifiableCookieList;
	}

	/**
	 * @param errorMessage
	 * @param t
	 * @return
	 */
	private AuthNTokenPublicException getAuthNException(String errorMessage,Throwable t){
		String message = " : "+errorMessage;
		LOGGER.error(message,t);
		String rootCause = "";
		if(t!=null && t.getStackTrace()!=null && t.getStackTrace().length>0){
				rootCause = t.getStackTrace()[0].getClassName();
				if(rootCause == null)
					rootCause = "";
				else
					rootCause= rootCause+"  :  ";
		}
		return new AuthNTokenPublicException(rootCause+errorMessage, AuthConstants.UNAUTHORIZED);
	}
	/**
	 * get the iPlanetDirectoryPro value from the server
	 * @param con
	 * @return
	 * @throws IOException
	 */
	private String getIPlanetFromResponse(HttpURLConnection con) throws IOException{
		LoggerHelper.info(LOGGER,".getIPlanetFromResponse(HttpURLConnection) : Start");
		StringBuilder sb = new StringBuilder();
		InputStream in = con.getInputStream();
		int i;
		while((i=in.read())!=-1)
		{
			// converts integer to character and add it to StringBuffer.
			sb.append((char)i);
		}
		String iPlanetValue = parseForIPlanetValue(sb.toString());
		if(iPlanetValue!=null){
			LoggerHelper.debug(LOGGER, ".getIPlanetFromResponse(HttpURLConnection) : Returning iPlanetCookie Value [{}]",iPlanetValue);
			LoggerHelper.info(LOGGER,".getIPlanetFromResponse(HttpURLConnection) : End");
			return  AuthConstants.IPLANET_COOKIE+"="+iPlanetValue;
		}
		LoggerHelper.info(LOGGER,".getIPlanetFromResponse(HttpURLConnection) : End");
		LoggerHelper.debug(LOGGER, ".getIPlanetFromResponse(HttpURLConnection) : Returning iPlanetCookie Value [{}]","null");
		return null;

	}
	/**
	 * Parse the JSON response and look's for iPlanetDirectoryPro value is contained against tokenId key in the response.
	 * @param iPlanetCookie
	 * @return iPlanetDirectoryPro
	 */
	private String parseForIPlanetValue(String iPlanetCookie){
		LoggerHelper.info(LOGGER,".getIPlanetFromResponse(String) : Start");
		String temp = iPlanetCookie;
		String iplanetValue = null;
		if(temp!=null){
			List<String> cookies = Arrays.asList(temp.split(","));
			LoggerHelper.debug(LOGGER, ".getIPlanetFromResponse(String) : Looking for tokenId value in [{}]",cookies);
			for (Iterator<String> iterator = cookies.iterator(); iterator.hasNext();) {
				String value = iterator.next();
				if(value!=null){
					String [] iplanetCookie = value.split(AuthConstants.COLON);
					iplanetValue = getIplanetCookieValue(iplanetCookie);
				}
				if(iplanetValue!=null){
					break;
				}
			}
		}
		LoggerHelper.debug(LOGGER, ".getIPlanetFromResponse(String) : Returning tokenId value [{}]",iplanetValue);
		LoggerHelper.info(LOGGER,".getIPlanetFromResponse(String) : End");
		return iplanetValue;
	}
	/**
	 * iPlanetDirectoryPro value is contained against tokenId key in the response.
	 * @param iplanetCookie
	 * @return iPlanetDirectoryPro value
	 */
	private String getIplanetCookieValue(String [] iplanetCookie){
		if(iplanetCookie[0]!=null && iplanetCookie.length>1 && iplanetCookie[0].contains(TOKENID) && iplanetCookie[1] !=null){
			String tokenId = iplanetCookie[1];
			// filtering for value from JSON
			tokenId = tokenId.replaceAll("\"", AuthConstants.BLANK);
			tokenId = tokenId.replaceAll("}", AuthConstants.BLANK);
			//remove spaces
			tokenId = tokenId.replaceAll(" ", AuthConstants.BLANK);
			return tokenId;
		}
		return null;
	}

	@Override
	public boolean clearAuthNCookies(Cookie[] cookies) throws AuthNPublicException {
		LoggerHelper.info(LOGGER,".clearAuthNCookies() : Start");
		boolean retValue = this.clearAuthNCookies(cookies, PropertyFileHelper.getOpenAMServerURL());
		LoggerHelper.info(LOGGER,".clearAuthNCookies() : End");
		return retValue;
	}
	
	@Override
	public boolean clearAuthNCookies(Cookie[] cookies, String openAmBaseUrl) throws AuthNPublicException {
		LoggerHelper.info(LOGGER,".clearAuthNCookies(openAmBaseUrl) : Start");
		String logoutURL = null;
		if (null != openAmBaseUrl) {
			try {
				logoutURL = openAmBaseUrl + JSON_LOGOUT;  	
				HttpURLConnection connection = AuthUtil.getHttpConnection(null, null, logoutURL,null);
				
				StringBuilder builder = new StringBuilder();
				for (Cookie cookie : cookies) {
					builder.append(cookie.getName() + "=" + cookie.getValue() + ";");
				}
				connection.setRequestProperty(COOKIE, builder.toString());
				int resCode = connection.getResponseCode();
				if (resCode != 200) {
					throw getAuthNException(OPENAM_CONNECT_ERROR_MSG + openAmBaseUrl, null);
				}
				
				LoggerHelper.info(LOGGER,".clearAuthNCookies(openAmBaseUrl) : End");

			} catch (IOException e) {
				throw getAuthNException(OPENAM_CONNECT_ERROR_MSG + logoutURL+ " ,Reason[" + e.getMessage() + "]", e);
			}
		} else{
			throw getAuthNException(ERROR_FETCHING_OPENAM_URL_MSG + openAmBaseUrl ,null);   
		}
		
		return true;
	}
		
	@Override
	public boolean checkSSOToken(HttpServletRequest request) throws AuthNPublicException {
		try {
			LoggerHelper.info(LOGGER,".checkSSOToken(request) : Start");
			boolean isTokenValid = getSessionInfoResponse(request) != null;
			LoggerHelper.info(LOGGER,".checkSSOToken(request) : End");
			return isTokenValid;
		} catch (Exception e) {
			throw getAuthNException(OPENAM_CONNECT_ERROR_MSG + REASON + e.getMessage() + "]", e);
		}
	}
	
	@Override
	public SSOSessionInfo getSSOSessionInfo(HttpServletRequest request) throws AuthNPublicException {
		try {
			LoggerHelper.info(LOGGER,".getSSOSessionInfo(request) : Start");
			SSOSessionInfo sessionInfo = new SSOSessionInfo();
			StringBuilder response = getSessionInfoResponse(request);
			if (response != null) {
				JSONObject json = new JSONObject(response.toString());
				String timeStr = json.getString(IDLE_EXPTIME);
				Instant dateTime = Instant.parse(timeStr);
				String maxSessStr = json.getString(SESSION_EXPTIME);
				Instant sessDateTime = Instant.parse(maxSessStr);
	
				Duration sdu = Duration.between(Instant.now(), sessDateTime);
				Duration du = Duration.between(Instant.now(), dateTime);
				sessionInfo.setIdleTtl( du.getSeconds() < sdu.getSeconds() ? du.getSeconds() : sdu.getSeconds() );
			}
			LoggerHelper.info(LOGGER,".getSSOSessionInfo(request) : End");
			return sessionInfo;
		} catch (Exception e) {
			throw getAuthNException(OPENAM_CONNECT_ERROR_MSG + REASON + e.getMessage() + "]", e);
		}
	}
	
	private StringBuilder getSessionInfoResponse(HttpServletRequest request) throws AuthNTokenPublicException, IOException {
		String vUrl = PropertyFileHelper.getOpenAMServerURL();
		if (vUrl == null) {
			throw getAuthNException(ERROR_FETCHING_OPENAM_URL_MSG + vUrl, null);    
		}
		vUrl = vUrl + API_SESSION_INFO + CookieHelper.getCookieValue(request,  PropertyFileHelper.getOpenAMiPlanetCookieName());
		LoggerHelper.debug(LOGGER, ".getSessionInfoResponse(request) : URL " + vUrl);
		HttpURLConnection con = AuthUtil.getHttpConnection(null, null, vUrl, AuthConstants.API_VERSION_V2);
		StringBuilder response = AuthUtil.getResponseFromConn(con);
		LoggerHelper.debug(LOGGER, ".getSessionInfoResponse(request) : response " + response);
		return response;
	}
	
	@Override
	public String getOpenAMCookieName() {
		return PropertyFileHelper.getOpenAMCookieName();
	}
	
	/*
	 *Method to validate username and password 
	 * @param userName
	 * @param password
	 * @throws AuthNTokenPublicException
	 */
	private void validateUserPass(String userName, String password) throws AuthNTokenPublicException {
		if ((null==userName || BLANK_STRING.equals(userName)) || (null==password || BLANK_STRING.equals(password))) {
			throw getAuthNException(
					OPENAM_CONNECT_ERROR_MSG + REASON + OPENAM_CONNECT_ERROR_MSG_USER_PASS_BLANK + "]",
					null);
		}
	}
	
}
