package com.kronos.auth.clientlib.util;

public class AuthConstants {
	
	public static final String INTERNAL_SERVER_ERROR = "internal server error";
	public static final String UNAUTHORIZED = "unauthorized";
	public static final String ACCEPTED = "accepted";
	public static final String BAD_GATEWAY = "bad gateway";
	public static final String NOT_AUTHORIZED = "Not Authorized !!";
	public static final String SSO_TOKEN_VALIDATON_FAILED = "SSO Token Validaton Failed !! ";
	public static final String SLASH = "/";
	static final String OPENAM_COOKIE_NAME_ENDPOINT = "identity/getCookieNameForToken";
	static final String DEFAULT_COOKIE_NAME_AUTHN_SSID = "authn_ssid";
	
	public static final String IPLANET_COOKIE = "iPlanetDirectoryPro";
	public static final String OPENAM_COOKIE_AUTHN_SSID = "authn_ssid";
	public static final String JSESSION_ID = "JSESSIONID";
	public static final String FALLBACK_AUTHN_TOKEN = "AUTHN_TOKEN";
	
	public static final String BLANK = "";
	public static final String QUOTES = "\"";
	public static final String COLON = ":";
	public static final String COLON_SLASH_SLASH = "://";
	
	public static final String LOGOUT_CHANNEL = "LOGOUT_CHANNEL";
	public static final String URI_AUTHENTICATE = "Authenticate";
	public static final String URI_LOGOUT = "Logout";
	public static final String URL_LOCALHOST = "http://localhost:8080";
	public static final String API_VERSION_V2 = "resource=2.0";
	
	private AuthConstants(){
		
	}
	
}
