package com.kronos.auth.redis.impl;

import java.util.concurrent.locks.Lock;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kronos.auth.clientlib.util.AuthUtil;
import com.kronos.auth.redis.api.AuthNRedisConnectionPoolService;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPubSub;

/**
 * 
 * @author Abhay.Singh <br/>
 *         Wrapper to act as Subscriber in Publisher/Subscriber paradigm
 */
public class RedisSubscription {

	static final Logger LOGGER = LoggerFactory.getLogger(RedisSubscription.class);
	Jedis client;
	final String channel;
	final JedisPubSub impl;
	final AuthNRedisConnectionPoolService serv;
	Thread subscription;
	final Lock lockObj;

	public RedisSubscription(String channel, JedisPubSub impl, AuthNRedisConnectionPoolService serv) {
		super();
		this.serv = serv;
		client = serv.getJedisConnection();
		this.channel = channel;
		this.impl = impl;
		lockObj = AuthUtil.getReentrantLock();
	}

	public String getSubscribingChannel() {
		return channel;
	}

	/**
	 * starts listening process for channel in a separate {@link Thread}
	 * 
	 */
	public void start() {
		if (AuthUtil.isEmpty(channel)) {
			return;
		}
		if (subscription == null || !subscription.isAlive()) {
			LOGGER.debug("Trying to Start subscription of channel [{}] in a new thread",channel);
			subscription = new Thread(() -> { 
				lockObj.lock();
				try {
					// This is blocking operation
					client.subscribe(impl, channel);
				} catch (Exception e) {
					LOGGER.debug(e.getMessage(), e);
				}
				lockObj.unlock();
				if(client.isConnected()){
					serv.returnJedisConnection(client);
				}

			});
			subscription.start();
			LOGGER.debug("Subscription Started of channel [{}] in Thread [{}]", channel, subscription.getName());
		} else {
			serv.returnJedisConnection(client);
			LOGGER.error("Could not start Subscription as Channel is NOT specified");
		}
	}

	public void unSubscribe() {
		if (this.impl != null) {
			this.impl.unsubscribe();
			serv.returnJedisConnection(client);
			client = null;
			subscription = null;
		}
	}

	/**
	 * returns true if subscription is still active
	 * 
	 * @return
	 */
	public boolean isSubscribed() {
		if (lockObj.tryLock() || subscription == null || !this.impl.isSubscribed()) {
			lockObj.unlock();
			return false;
		} else {
			return true;
		}

	}

}
