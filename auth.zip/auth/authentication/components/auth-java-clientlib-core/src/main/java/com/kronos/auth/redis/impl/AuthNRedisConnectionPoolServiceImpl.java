package com.kronos.auth.redis.impl;

import java.util.Set;
import java.util.StringTokenizer;

import javax.inject.Named;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kronos.auth.clientlib.util.AuthUtil;
import com.kronos.auth.clientlib.util.PropertyFileHelper;
import com.kronos.auth.redis.api.AuthNRedisConnectionPoolService;
import com.kronos.auth.redis.api.AuthNRedisPoolSvc;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPoolConfig;
import redis.clients.util.Pool;

/**
 * Connection pool which will be used to work with Redis. This will be used as
 * fall back as well when no other component has provided Redis connection pool.
 * 
 * @author Sandeep.Agrrawal
 *
 */
@Named
@AuthNRedisPoolSvc
public class AuthNRedisConnectionPoolServiceImpl implements AuthNRedisConnectionPoolService {
	private static final Logger LOGGER = LoggerFactory.getLogger(AuthNRedisConnectionPoolServiceImpl.class);

	/**
	 * This method will return jedis instance.
	 * 
	 * @return jedis
	 */
	@Override
	public Jedis getJedisConnection() {
		LOGGER.debug("JedisConnectionPoolService: Getting Connection");
		return JedisConnectionPoolService.getInstance().getJedisPool().getResource();
	}

	/**
	 * Return the connection to pool
	 */
	@Override
	public void returnJedisConnection(Jedis jedis) {
		JedisConnectionPoolService jService = JedisConnectionPoolService.getInstance();
		jService.getJedisPool().returnResourceObject(jedis);
		LOGGER.debug("JedisConnectionPoolService: Returned Connection");
	}

	@Override
	public boolean isEnvironmentRedis() {
		return true;
	}
}

/**
 * Redis connection pool service class
 * 
 * @author Abhay.Singh
 */
final class JedisConnectionPoolService {
	private static final Logger LOGGER = LoggerFactory.getLogger(JedisConnectionPoolService.class);

	private static class SingletonHolder {
		private static final JedisConnectionPoolService INSTANCE = new JedisConnectionPoolService();

		private SingletonHolder() {
			// do nothing
		}
	}

	private Pool<Jedis> jedisPool = null;

	/**
	 * Constructor - Should not be called any client
	 */
	JedisConnectionPoolService() {
		createJedisConnectionPoolService();
	}
	
	private void createJedisConnectionPoolService() {
		try {
			String masterHostName = PropertyFileHelper.getRedisMaster();
			String hostName = null;
			String portNumber = null;
			// If masterHostName is null then NoOpJedisPool should be selected
			if (masterHostName.contains(":")) {
				StringTokenizer st = new StringTokenizer(masterHostName, ":");
				hostName = st.nextToken();
				portNumber = st.nextToken();
			}
			Set<String> sentinels = PropertyFileHelper.getSentinelHostsAndPorts();
			String timeout = PropertyFileHelper.getRedisTimeout();
			String auth = PropertyFileHelper.getRedisAuth();

			JedisPoolConfig poolConfig = this.getJedisPoolConfig();
			if (hostName != null) {
				jedisPool = AuthUtil.getJedisPool(poolConfig, hostName, Integer.parseInt(portNumber),
						Integer.parseInt(timeout), auth);
			} else {
				jedisPool = AuthUtil.getJedisSentinelPool(poolConfig, masterHostName, sentinels,
						Integer.parseInt(timeout), auth);
			}
			LOGGER.info("JedisConnectionPoolService: Connection to server [{}] made successfully", masterHostName);
		} catch (Exception ex) {
			jedisPool = new NoOpJedisPool();
			LOGGER.info("JedisConnectionPoolService: NoOpJedisPool Selected");
			LOGGER.debug("NoOpJedisPool Selected", ex);
		}
	}

	private JedisPoolConfig getJedisPoolConfig() {
		String maxActive = PropertyFileHelper.getRedisMaxActive();
		JedisPoolConfig poolConfig = AuthUtil.getJedisPoolConfig();
		poolConfig.setMaxTotal(Integer.parseInt(maxActive));
		poolConfig.setMaxIdle(Integer.parseInt(maxActive));
		poolConfig.setBlockWhenExhausted(false);
		return poolConfig;
	}

	public Pool<Jedis> getJedisPool() {
		return jedisPool;
	}

	/**
	 * Get the singleton JedisConnPoolService instance
	 * 
	 * @return the singleton JedisConnPoolService object
	 */
	public static JedisConnectionPoolService getInstance() {
		return SingletonHolder.INSTANCE;
	}

}
