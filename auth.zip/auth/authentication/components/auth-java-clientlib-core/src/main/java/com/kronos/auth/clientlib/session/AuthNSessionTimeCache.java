package com.kronos.auth.clientlib.session;

import java.time.LocalDateTime;
import java.time.format.DateTimeParseException;

import javax.inject.Inject;
import javax.inject.Named;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kronos.auth.clientlib.util.AuthConstants;
import com.kronos.auth.redis.AuthNRedisOperationResolver;
import com.kronos.auth.redis.api.AuthNRedisOperations;
import com.kronos.auth.redis.api.RedisMessageCallback;

/**
 * Class which interacts with Redis to keep information about Session Valid Time
 * 
 * @author Sandeep.Agrrawal
 *
 */
@Named
public class AuthNSessionTimeCache {

	static final Logger LOGGER = LoggerFactory.getLogger(AuthNSessionTimeCache.class);

	@Inject
	AuthNRedisOperationResolver redisOpResolver;

	private AuthNRedisOperations getAuthNRedisOperations() {
		if (redisOpResolver == null) {
			LOGGER.info("AuthNSessionTimeCache: AuthNRedisOperations created (not injected)");
			redisOpResolver = new AuthNRedisOperationResolver();
		}
		return redisOpResolver.getAuthNRedisOperations();
	}

	/**
	 * Returns date-time associated with given token
	 * 
	 * @param ssoToken
	 * @return
	 */
	public LocalDateTime getSessionValidTime(String ssoToken) {
		LOGGER.info("getSessionValidTime: Start");
		String value = getAuthNRedisOperations().getValue(ssoToken);
		LocalDateTime dateTime = null;
		try {
			dateTime = LocalDateTime.parse(value);
		} catch (DateTimeParseException | NullPointerException ex) {
			LOGGER.info("getSessionValidTime: could not parse date time. ", ex);
		}
		return dateTime;
	}

	/**
	 * Stores token and date time in Redis store
	 * 
	 * @param ssoToken
	 * @param timestamp
	 */
	public void setSessionValidTime(String ssoToken, LocalDateTime timestamp) {
		LOGGER.info("setSessionValidTime: Start");
		getAuthNRedisOperations().add(ssoToken, timestamp.toString());
	}

	/**
	 * Removes entry from Redis store for given token
	 * 
	 * @param ssoToken
	 */
	public void removeSessionValidTime(String ssoToken) {
		LOGGER.info("removeSessionValidTime: Start");
		getAuthNRedisOperations().remove(ssoToken);
	}

	/**
	 * Start the subscription on given channel
	 * 
	 * @param channel
	 * @param impl
	 */
	public void getSubscription(String channel, RedisMessageCallback impl) {
		LOGGER.info("getSubscription: Start");
		getAuthNRedisOperations().getSubscription(channel, impl);
	}

	/**
	 * Uses pub-sub of Redis to publish given token on logout channel
	 * 
	 * @param ssoToken
	 */
	public void publishLogoutMessage(String ssoToken) {
		LOGGER.info("publishLogoutMessage: Start");
		getAuthNRedisOperations().publish(AuthConstants.LOGOUT_CHANNEL, ssoToken);
	}
}
