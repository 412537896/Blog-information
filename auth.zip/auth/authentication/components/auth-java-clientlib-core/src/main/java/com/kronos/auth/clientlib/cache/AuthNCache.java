package com.kronos.auth.clientlib.cache;

import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.RemovalListener;

/**
 * This class represents the local cache.
 * @author Sandeep.Agrrawal
 *
 */
public class AuthNCache {

	// In future this might come from property file if we use eviction
	private static final String CACHE_SPECS = "maximumSize=100000";

	private static AuthNCache authnCache;

	private Cache<String, AuthNCacheObject> guavaCache;

	private AuthNCache(RemovalListener<String, AuthNCacheObject> listener) {
		guavaCache = CacheBuilder.from(CACHE_SPECS).removalListener(listener).build();
	}
	
	/**
	 * This method should be called first, it creates object of AuthNCache
	 * @param listener
	 */
	public static synchronized AuthNCache createAuthNCache(RemovalListener<String, AuthNCacheObject> listener) {
		if (authnCache == null) {
			authnCache = new AuthNCache(listener);
		}
		return getAuthNCache();
	}

	/**
	 * Returns single object of AuthNCache
	 * @return
	 */
	public static synchronized AuthNCache getAuthNCache() {
		return authnCache;
	}

	/**
	 * Returns the value from cache for the given key
	 * @param key
	 * @return
	 */
	public AuthNCacheObject getValue(String key) {
		return guavaCache.getIfPresent(key);
	}
	
	/**
	 * Puts key and value into cache
	 * @param key
	 * @param value
	 * @return
	 */
	public boolean putValue(String key, AuthNCacheObject value) {
		if (value == null) {
			return false;
		}
		guavaCache.put(key, value);
		return true;
	}

	/**
	 * Removes entry of given key
	 * @param key
	 */
	public void removeKey(String key) {
		guavaCache.invalidate(key);
	}

	/**
	 * Checks the existence of key in cache
	 * @param key
	 * @return null if key is not present in cache
	 */
	public Object checkKey(String key) {
		return guavaCache.getIfPresent(key);
	}
}
