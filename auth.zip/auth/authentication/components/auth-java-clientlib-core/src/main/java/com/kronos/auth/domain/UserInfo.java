package com.kronos.auth.domain;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.kronos.auth.clientlib.exception.AuthNPublicException;
import com.kronos.auth.clientlib.util.AuthUtil;

/**
 * Class holding userInfo
 */
public class UserInfo implements Serializable{

	private static final long serialVersionUID = -5294784975992300097L;
	private static final String EMPTY = "";
	private String userName;
	private String tenantName;
	private String firstName;
	private String lastName;
	private String fullName;
	private String mail;
	private String oAuthToken;
	private String openAmCookie;
	private String openAmAuthzUrl;
	
	private String onBehalfUser;
	private boolean isSystemUser;
	private String userRole;
	private UserLocaleProfile userLocaleProfile;
	
    private String supportUserFirstName;
    private String supportUserLastName;
    private String supportUserName;
    
    
	private String ticketReason;
    private boolean isMfaRequired;
    private String userAuthType;
    private String logonProfile;
    
    
	/**
	 * constructs userInfo object
	 * @param username String
	 * @param tenantName
	 */
	public UserInfo(String username, String tenantName) {
		this.userName = username;
		this.tenantName = tenantName;
	}

	/**
	 * @return the oAuthToken
	 * @throws AuthNPublicException 
	 * 
	 */
	@JsonIgnore
	@Deprecated
	public String getOAuthToken(){
		if (oAuthToken == null) {
			try {
				oAuthToken = AuthUtil.processAuthorizeRequest(openAmAuthzUrl, openAmCookie, this.userName,null).getAccessToken();
			} catch (AuthNPublicException e) {
				//Deprecated method supposedly not used anywhere so no need to log
			}

		}
		return oAuthToken;
	}

	/**
	 * @param oAuthToken the oAuthToken to set
	 */
	public void setOAuthToken(String oAuthToken) {
		this.oAuthToken = oAuthToken;
	}

	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * @return the lastname
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * @param lastname the lastname to set
	 */
	public void setLastName(String lastname) {
		this.lastName = lastname;
	}

	/**
	 * @return the fullname
	 */
	public String getFullName() {
		return fullName;
	}

	/**
	 * @param fullname the fullname to set
	 */
	public void setFullName(String fullname) {
		this.fullName = fullname;
	}

	/**
	 * @param fullname the fullname to set
	 */
	public void setUsername(String userName) {
		this.userName = userName;
	}

	/**
	 * @return the mail
	 */
	public String getMail() {
		return mail;
	}

	/**
	 * @param mail the mail to set
	 */
	public void setMail(String mail) {
		this.mail = mail;
	}

	/**
	 * Provides username
	 * @return username String 
	 */
	public String getUsername() {
		return userName;
	}

	/**
	 * Provides tenantShortName
	 * @return tenantShortName String 
	 */
	public String getTenantShortName() {
		String tenant = this.tenantName;
		if(tenant!=null && tenant.trim().length()>1){
			//remove preceding slash as it is not required except in case of top level realm
			tenant = tenant.replaceFirst("/", "");
		}
		return tenant;
	}
		
	/**
	 * Sets the support user name
	 * @param supportUserName
	 */
	public void setSupportUserName(String supportUserName) {
		this.supportUserName = supportUserName;
	}

	/**
	 * @return Returns user name on whose behalf system user has logged in. Applicable for system user login only.
	 */
	public String getOnBehalfUser() {
		return EMPTY.equals(onBehalfUser)?null:onBehalfUser;
	}
	
	/**
	 * User on whose behalf system user has logged in
	 * @param onBehalfUser
	 */
	public void setOnBehalfUser(String onBehalfUser) {
		this.onBehalfUser = onBehalfUser;
	}
	
	/**
	 * 
	 * @return
	 */
	public boolean isSystemUser() {
		return isSystemUser;
	}

	/**
	 * 
	 * @param isSystemUser
	 */
	public void setSystemUser(boolean isSystemUser) {
		this.isSystemUser = isSystemUser;
	}

	public String getSupportUserRole() {
		return userRole;
	}

	public void setSupportUserRole(String userRole) {
		this.userRole = userRole;
	}

	public void setOpenAmCookie(String openAmCookie) {
		this.openAmCookie = openAmCookie;
	}
	public void setOpenAmAuthzUrl(String openAmAuthzUrl) {
		this.openAmAuthzUrl = openAmAuthzUrl;
	}
	
	/**
     * @deprecated use getTenantShortName()
     * Provides tenantName
     * @return tenantName String 
     */
	@Deprecated
    public String getTenantName() {
        return tenantName;
    }
	
	/**
	 * @return the userLocaleProfile
	 */
	public UserLocaleProfile getUserLocaleProfile() {
		return userLocaleProfile;
	}

	/**
	 * @param userLocaleProfile the userLocaleProfile to set
	 */
	public void setUserLocaleProfile(UserLocaleProfile userLocaleProfile) {
		this.userLocaleProfile = userLocaleProfile;
	}
	
    public void setSupportUserFirstName(String supportUserFirstName) {
        this.supportUserFirstName = supportUserFirstName;
    }

    public void setSupportUserLastName(String supportUserLastName) {
        this.supportUserLastName = supportUserLastName;
    }
    
    public String getSupportUserName() {
    	return supportUserName;
    }
    
	public String getTicketReason() {
		return ticketReason;
	}

	public void setTicketReason(String ticketReason) {
		this.ticketReason = ticketReason;
	}
	
	public boolean isMfaRequired() {
		return isMfaRequired;
	}

	public void setMfaRequired(boolean isMfaRequired) {
		this.isMfaRequired = isMfaRequired;
	}

	public String getUserAuthType() {
		return userAuthType;
	}

	public void setUserAuthType(String userAuthType) {
		this.userAuthType = userAuthType;
	}
	
	public String getLogonProfile() {
		return logonProfile;
	}

	public void setLogonProfile(String logonProfile) {
		this.logonProfile = logonProfile;
	}

	@Override
	public String toString() {
		return "UserInfo [userName=" + userName + ", tenantName=" + tenantName
				+ ", firstName=" + firstName + ", lastName=" + lastName
				+ ", fullName=" + fullName + ", mail=" + mail + ", oAuthToken="
				+ oAuthToken + ", openAmCookie=" + openAmCookie
				+ ", openAmAuthzUrl=" + openAmAuthzUrl + ", onBehalfUser="
				+ onBehalfUser + ", isSystemUser=" + isSystemUser
				+ ", userRole=" + userRole + ", userLocaleProfile="
				+ userLocaleProfile + ", supportUserFirstName="
				+ supportUserFirstName + ", supportUserLastName="
				+ supportUserLastName + ",ticketReason="+ticketReason+", isMfaRequired= "+isMfaRequired+" ,userAuthType= "+userAuthType+", logonProfile="+logonProfile+" ]";
	}

	
	

}

