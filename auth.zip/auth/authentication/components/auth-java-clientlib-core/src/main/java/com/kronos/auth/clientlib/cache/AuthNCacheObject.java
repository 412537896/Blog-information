package com.kronos.auth.clientlib.cache;

import java.time.LocalDateTime;

/**
 * This represents an object which is kept in local cache
 * @author Sandeep.Agrrawal
 *
 */
public class AuthNCacheObject {
	private final String ssoToken;
	private final String authnToken;
	private final String jSessionId;
	private final LocalDateTime localDateTime;
	private boolean publishMessage;
	
	/**
	 * Constructor
	 * @param token
	 * @param sessionId
	 * @param authNToken
	 * @param dateTime
	 */
	public AuthNCacheObject(String token, String sessionId, String authNToken, LocalDateTime dateTime) {
		this.ssoToken = token;
		this.jSessionId = sessionId;
		this.localDateTime = dateTime;
		this.authnToken = authNToken;
		this.publishMessage = true;
	}

	public String getSsoToken() {
		return ssoToken;
	}

	public String getjSessionId() {
		return jSessionId;
	}

	public LocalDateTime getLocalDateTime() {
		return localDateTime;
	}
	
	public String getAuthNToken() {
		return authnToken;
	}

	public boolean isPublishMessage() {
		return publishMessage;
	}

	public void setPublishMessage(boolean publishMessage) {
		this.publishMessage = publishMessage;
	}
}
