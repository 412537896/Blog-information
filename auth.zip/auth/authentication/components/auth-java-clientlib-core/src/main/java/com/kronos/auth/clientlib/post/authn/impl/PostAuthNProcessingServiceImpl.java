package com.kronos.auth.clientlib.post.authn.impl;

import java.util.Optional;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kronos.auth.clientlib.api.AuthNTokenProvider;
import com.kronos.auth.clientlib.exception.AuthNPublicException;
import com.kronos.auth.clientlib.post.authn.api.AuthzAccessValidator;
import com.kronos.auth.clientlib.post.authn.api.PostAuthNProcessingService;
import com.kronos.auth.clientlib.post.authn.api.PostAuthNProcessor;
import com.kronos.auth.clientlib.session.SessionOperationNotifier;
import com.kronos.auth.clientlib.util.AuthConstants;
import com.kronos.auth.clientlib.util.LoggerHelper;


@Named("PostAuthNProcessingServiceClientLibImpl")
public class PostAuthNProcessingServiceImpl implements PostAuthNProcessingService{

	static final Logger LOGGER = LoggerFactory.getLogger(PostAuthNProcessingServiceImpl.class);

	@Inject
	Optional<PostAuthNProcessor> postAuthNProcessorExists;
	
	@Inject
	AuthNTokenProvider authNTokenProvider;

	@Inject
	Optional<AuthzAccessValidator> accessValidator;

	@Inject
	Optional<SessionOperationNotifier> sessionOpNotifierExists;

	public PostAuthNProcessingServiceImpl() {
		// Empty
	}

	/**
	 * validates User token and set session Cookies
	 * @return Response
	 */
	
	@Override
	public String performPostAuthNInitializeSession(HttpServletRequest httpReq, HttpServletResponse httpResp) {
		LoggerHelper.info(LOGGER,".performPostAuthNInitializeSession(HttpServletRequest,HttpServletResponse) : Start");
		try {
			if (null != accessValidator && accessValidator.isPresent()) {
				accessValidator.get().validateAccess(httpReq);
			}
			LoggerHelper.info(LOGGER,".performPostAuthNInitializeSession(HttpServletRequest,HttpServletResponse) : End");
			return postAuthNSessionInit(httpReq, httpResp);
		} catch (Exception e) {
			LOGGER.error(".performPostAuthNInitializeSession(HttpServletRequest,HttpServletResponse) : "+e.getMessage(),e);
			return AuthConstants.UNAUTHORIZED; 
		}
	}

	private String postAuthNSessionInit(HttpServletRequest httpReq, HttpServletResponse httpResp) throws AuthNPublicException{
		LoggerHelper.info(LOGGER,".postAuthNSessionInit(HttpServletRequest,HttpServletResponse) : Start");
				if(null!=authNTokenProvider.getUserInfo(httpReq) ){
					if(null!= postAuthNProcessorExists && postAuthNProcessorExists.isPresent()){
						PostAuthNProcessor postAuthNProcessor = postAuthNProcessorExists.get();
						postAuthNProcessor.setSessionCookies(httpReq, httpResp);
					}
					
					// Call to perform action during login for keep alive & SLO
					if (sessionOpNotifierExists != null && sessionOpNotifierExists.isPresent()) {
						sessionOpNotifierExists.get().sessionCreated(httpReq);
					}
					
					LoggerHelper.info(LOGGER,".postAuthNSessionInit(HttpServletRequest,HttpServletResponse) : End");
					return AuthConstants.ACCEPTED;
				}else{
					LoggerHelper.debug(LOGGER, ".postAuthNSessionInit(HttpServletRequest,HttpServletResponse) : "
							+ "Failed to get userInfo returning status - "+AuthConstants.UNAUTHORIZED);
					return AuthConstants.UNAUTHORIZED;
				}
	}

}
