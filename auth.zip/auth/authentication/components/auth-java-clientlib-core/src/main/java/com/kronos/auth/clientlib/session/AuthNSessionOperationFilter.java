package com.kronos.auth.clientlib.session;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kronos.auth.clientlib.util.AuthConstants;

/**
 * Filter for Session Sync related work.
 * 
 * @author Sandeep.Agrrawal
 *
 */
// @WebFilter("/*")
public class AuthNSessionOperationFilter implements Filter {

	private static final Logger LOGGER = LoggerFactory.getLogger(AuthNSessionOperationFilter.class);

	@Override
	public void init(FilterConfig arg0) throws ServletException {
		// Empty
	}

	@Override
	public void destroy() {
		// Empty
	}

	@Override
	public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
			throws IOException, ServletException {
		HttpServletRequest request = (HttpServletRequest) req;
		SessionOperationNotifier notifier = SessionOperationNotifierHolder.getSessionOperationNotifierImpl();

		String reqUri = request.getRequestURI();
		if (!reqUri.contains(AuthConstants.URI_AUTHENTICATE) && !reqUri.contains(AuthConstants.URI_LOGOUT)
				&& notifier != null) {
			LOGGER.info("doFilter: Calling sessionAccessed");
			notifier.sessionAccessed(request);
		}

		chain.doFilter(req, res);
	}

}
