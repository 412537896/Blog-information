package com.kronos.auth.clientlib.post.authn.impl;

import java.util.Optional;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kronos.auth.clientlib.api.AuthNTokenProvider;
import com.kronos.auth.clientlib.exception.AuthNPublicException;
import com.kronos.auth.clientlib.post.authn.api.PostLogoutProcessingService;
import com.kronos.auth.clientlib.post.authn.api.PostLogoutProcessor;
import com.kronos.auth.clientlib.session.SessionOperationNotifier;
import com.kronos.auth.clientlib.util.AuthConstants;
import com.kronos.auth.clientlib.util.LoggerHelper;

@Named("PostLogoutProcessingServiceClientLibImpl")
public class PostLogoutProcessingServiceImpl implements PostLogoutProcessingService {
	static final Logger LOGGER = LoggerFactory.getLogger(PostLogoutProcessingServiceImpl.class);

	@Inject
	Optional<PostLogoutProcessor> postLogoutProcessorExists;

	@Inject
	AuthNTokenProvider authNTokenProvider;

	@Inject
	Optional<SessionOperationNotifier> sessionOpNotifierExists;

	@Override
	public String performPostLogout(HttpServletRequest httpReq, HttpServletResponse httpResp)
			throws AuthNPublicException {
		LoggerHelper.info(LOGGER, ".performPostLogout(HttpServletRequest,HttpServletResponse) : Start");
		if (authNTokenProvider.getUserInfo(httpReq) != null) {
			if (null != postLogoutProcessorExists && postLogoutProcessorExists.isPresent()) {
				PostLogoutProcessor postLogoutProcessor = postLogoutProcessorExists.get();
				postLogoutProcessor.processLogout(httpReq, httpResp);
			}
			
			// Call to perform action during login for keep alive
			if (sessionOpNotifierExists != null && sessionOpNotifierExists.isPresent()) {
				sessionOpNotifierExists.get().sessionLogout(httpReq);
			}

			if (httpReq.getSession(false) != null) {
				LoggerHelper.info(LOGGER, ".performPostLogout(HttpServletRequest,HttpServletResponse) : Invalidating Session");
				httpReq.getSession(false).invalidate();
			}

			LoggerHelper.info(LOGGER, ".performPostLogout(HttpServletRequest,HttpServletResponse) : End");
			return AuthConstants.ACCEPTED;
		} else {
			LoggerHelper.debug(LOGGER,
					".performPostLogout(HttpServletRequest,HttpServletResponse) : Failed to get userInfo returning status - "
							+ AuthConstants.UNAUTHORIZED);
			return AuthConstants.UNAUTHORIZED;
		}
	}

}
