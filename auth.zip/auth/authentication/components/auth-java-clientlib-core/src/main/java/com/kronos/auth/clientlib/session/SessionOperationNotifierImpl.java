package com.kronos.auth.clientlib.session;

import java.time.LocalDateTime;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.cache.RemovalCause;
import com.google.common.cache.RemovalListener;
import com.google.common.cache.RemovalNotification;
import com.kronos.auth.clientlib.cache.AuthNCache;
import com.kronos.auth.clientlib.cache.AuthNCacheObject;
import com.kronos.auth.clientlib.util.AuthConstants;
import com.kronos.auth.clientlib.util.AuthUtil;
import com.kronos.auth.clientlib.util.CookieHelper;
import com.kronos.auth.clientlib.util.PropertyFileHelper;
import com.kronos.auth.redis.api.RedisMessageCallback;

/**
 * Class which performs actions based on session operation i.e. login, logout,
 * session timeout, access
 * 
 * @author Sandeep.Agrrawal
 *
 */
@Named
public class SessionOperationNotifierImpl
		implements SessionOperationNotifier, RemovalListener<String, AuthNCacheObject>, RedisMessageCallback {

	static final Logger LOGGER = LoggerFactory.getLogger(SessionOperationNotifierImpl.class);

	private static final int SESSION_TIMEOUT = 30;
	private static final int SVT_UPDATE_WAIT_TIME = SESSION_TIMEOUT - 10;

	private final AuthNCache authNCache;

	@Inject
	AuthNSessionTimeCache authNRedis;

	/**
	 * Constructor, initializes required cache and redis set up
	 */
	public SessionOperationNotifierImpl() {
		LOGGER.info("SessionOperationNotifierImpl: Constructor Start");
		this.authNCache = AuthNCache.createAuthNCache(this);
		LOGGER.info("SessionOperationNotifierImpl: Constructor End");
	}

	/**
	 * This method will start the Redis subscription. Should not be called
	 * explicitly by any client.
	 * 
	 * Note, this will be called only when DI is available and authNRedis is
	 * injected. If DI is not available then authNRedis will be created in
	 * <code>getAuthNSessionTimeCache</code> method and subscription will also
	 * be started.
	 */
	@PostConstruct
	public void startSubscription() {
		authNRedis.getSubscription(AuthConstants.LOGOUT_CHANNEL, this);
	}

	private AuthNSessionTimeCache getAuthNSessionTimeCache() {
		if (authNRedis == null) {
			LOGGER.info("SessionOperationNotifierImpl: AuthNSessionTimeCache created (not injected)");
			authNRedis = new AuthNSessionTimeCache();
			authNRedis.getSubscription(AuthConstants.LOGOUT_CHANNEL, this);
		}
		return authNRedis;
	}

	/**
	 * Method which should be called once login is done in application
	 */
	@Override
	public void sessionCreated(HttpServletRequest request) {
		try {
			LOGGER.info("sessionCreated: Start");
			String ssoToken = CookieHelper.getCookieValue(request.getCookies(), AuthConstants.IPLANET_COOKIE);
			String authnToken = CookieHelper.getCookieValue(request.getCookies(), PropertyFileHelper.getOpenAMCookieName());
			if (ssoToken != null) {
				// Add to Redis for session sync
				LocalDateTime nowTime = LocalDateTime.now();
				//LocalDateTime svttime = nowTime.plusMinutes(SESSION_TIMEOUT)
				//getAuthNSessionTimeCache().setSessionValidTime(ssoToken, svttime)

				// Add to local cache
				AuthNCacheObject cacheObject = new AuthNCacheObject(ssoToken, request.getSession(false).getId(),
						authnToken, nowTime);
				authNCache.putValue(ssoToken, cacheObject);
				LOGGER.info("sessionCreated: Updated Redis and Local Cache");
			}
		} catch (Exception ex) {
			LOGGER.error("sessionCreated: ", ex);
		}
	}

	/**
	 * Method should be called whenever any operation is performed by user. This
	 * indicates that session is accessed by user.
	 */
	@Override
	public void sessionAccessed(HttpServletRequest request) {
		try {
			LOGGER.info("sessionAccessed: Start");
			String ssoToken = CookieHelper.getCookieValue(request.getCookies(), AuthConstants.IPLANET_COOKIE);
			String authnToken = CookieHelper.getCookieValue(request.getCookies(), PropertyFileHelper.getOpenAMCookieName());
			if (ssoToken != null) {
				AuthNCacheObject cacheObject = authNCache.getValue(ssoToken);
				LocalDateTime nowTime = LocalDateTime.now();
				if (cacheObject != null
						&& cacheObject.getLocalDateTime().plusMinutes(SVT_UPDATE_WAIT_TIME).isBefore(nowTime)) {
					LocalDateTime svttime = nowTime.plusMinutes(SESSION_TIMEOUT);
					getAuthNSessionTimeCache().setSessionValidTime(ssoToken, svttime);

					cacheObject = new AuthNCacheObject(ssoToken, request.getSession(false).getId(), authnToken,
							nowTime);
					authNCache.putValue(ssoToken, cacheObject);
					LOGGER.info("sessionAccessed: Updated Redis and Local Cache");
				}
			}
		} catch (Exception ex) {
			LOGGER.error("sessionAccessed: ", ex);
		}
	}

	/**
	 * Method should be called whenever logout operation is performed by user.
	 */
	@Override
	public void sessionLogout(HttpServletRequest request) {
		try {
			LOGGER.info("sessionLogout(request): Start");
			String ssoToken = CookieHelper.getCookieValue(request.getCookies(), AuthConstants.IPLANET_COOKIE);
			LOGGER.info("sessionLogout(request): Got SSO " + ssoToken);

			boolean publish = false;
			if (ssoToken != null && authNCache.getValue(ssoToken) != null) {
				publish = authNCache.getValue(ssoToken).isPublishMessage();
				// Remove SVT key from Redis and cached object
				//getAuthNSessionTimeCache().removeSessionValidTime(ssoToken)
				authNCache.removeKey(ssoToken);
			}

			if (publish) {
				// Notify Redis about logout
				getAuthNSessionTimeCache().publishLogoutMessage(ssoToken);
			}

			LOGGER.info("sessionLogout(request): End");
		} catch (Exception ex) {
			LOGGER.error("sessionLogout(request): ", ex);
		}
	}

	/**
	 * This is callback method which will be called when Redis logout event is
	 * received.
	 */
	@Override
	public void onMessage(String channel, String ssoToken) {
		LOGGER.debug("onMessage: Channel " + channel + " Message " + ssoToken);
		if(channel == null || !channel.equalsIgnoreCase(AuthConstants.LOGOUT_CHANNEL)) {
			return;
		}
		if (ssoToken != null && !ssoToken.isEmpty()) {
			this.handleSessionLogout(ssoToken);
		}
	}

	/*
	 * It will send logout rest call to itself. It will lead call to
	 * sessionLogout method which will publish logout method and do necessary
	 * clean up.
	 * 
	 * @param ssoToken
	 */
	void handleSessionLogout(String ssoToken) {
		try {
			LOGGER.info("handleSessionLogout: Start");
			// Self Logout message
			AuthNCacheObject cacheObj = authNCache.getValue(ssoToken);
			if (cacheObj != null) {
				cacheObj.setPublishMessage(false);
				AuthUtil.notifySelf(cacheObj, false);
			} else {
				LOGGER.debug("handleSessionLogout: Self Call, Ignored");
			}
		} catch (Exception ex) {
			LOGGER.error("handleSessionLogout: ", ex);
		}
	}

	/**
	 * Callback method which will be called when local cache TTL expired event
	 * is triggered
	 */
	@Override
	public void onRemoval(RemovalNotification<String, AuthNCacheObject> rNotification) {
		// No operation for now
		// this.handleOnRemoval(rNotification.getCause(),
		// rNotification.getKey(), rNotification.getValue())
		LOGGER.info("onRemoval: SSO Key Removed " + rNotification.getKey());
	}

	void handleOnRemoval(RemovalCause cause, String ssoToken, AuthNCacheObject cacheObj) {
		try {
			LOGGER.info("handleOnRemoval: Start");
			if (cause == RemovalCause.EXPIRED && ssoToken != null && cacheObj != null) {
				LocalDateTime svtTime = getAuthNSessionTimeCache().getSessionValidTime(ssoToken);
				LocalDateTime nowTime = LocalDateTime.now();
				LOGGER.debug("handleOnRemoval: svtTime(Redis) " + svtTime + " local time " + nowTime);

				if (nowTime.isBefore(svtTime)) {
					LOGGER.info("handleOnRemoval: Sending Refresh Call");
					// Send Refresh Call, AuthUtil notifySelf ( cacheObj , true)

					// Update the local TTL
					AuthNCacheObject cacheObject = new AuthNCacheObject(ssoToken, cacheObj.getjSessionId(),
							cacheObj.getAuthNToken(), nowTime);
					authNCache.putValue(ssoToken, cacheObject);
				}
			}
		} catch (Exception ex) {
			LOGGER.error("handleOnRemoval: ", ex);
		}
	}
}
