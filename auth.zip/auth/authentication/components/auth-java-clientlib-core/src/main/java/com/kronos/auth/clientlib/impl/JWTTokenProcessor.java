package com.kronos.auth.clientlib.impl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigInteger;
import java.net.HttpURLConnection;
import java.net.ProtocolException;
import java.security.Key;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.RSAPublicKeySpec;
import java.util.HashMap;
import java.util.Map;

import org.jose4j.jws.JsonWebSignature;
import org.jose4j.lang.JoseException;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kronos.auth.clientlib.exception.AuthNPublicException;
import com.kronos.auth.clientlib.util.AuthConstants;
import com.kronos.auth.clientlib.util.AuthUtil;
import com.kronos.auth.clientlib.util.LoggerHelper;


/**
 * Simple JWT processor.
 * No need to instantiate this class as all members and methods are static
 */
public class JWTTokenProcessor { 

	private static Map<String, Key> keyMap = new HashMap<String, Key>();
	
	static final Logger LOGGER = LoggerFactory.getLogger(JWTTokenProcessor.class);
	
	/**
	 * No need to instantiate this class as all members and methods are static
	 */
	private JWTTokenProcessor(){
		
	}

	/**
	 * This method is used to get JWT payload
	 * @param jwkuri
	 * @param jwtToken
	 * @return payload
	 * @throws AuthNPublicException
	 * @throws InvalidKeySpecException
	 * @throws NoSuchAlgorithmException
	 * @throws JoseException
	 */
	protected static String getJWTPayload(String jwkuri, String jwtToken) throws AuthNPublicException, InvalidKeySpecException, NoSuchAlgorithmException, JoseException  {
			LoggerHelper.info(LOGGER,".getJWTPayload(String, jwtToken) : Start");
			String payload = null;
			
			int getPayloadTries = 0;
			while( getPayloadTries <= 1) {
				populatePublicKeysMap(jwkuri, ((getPayloadTries > 0) ? true : false));
				JsonWebSignature jws = AuthUtil.getJsonWebSignature();
				// Set the compact serialization on the JWS
			    jws.setCompactSerialization(jwtToken);
			    PublicKey pk = (PublicKey) keyMap.get(jwkuri);
				jws.setKey(pk);
				boolean signatureVerified = jws.verifySignature();
				if (signatureVerified) {
					payload = jws.getPayload();
					break;
				} else {
					LoggerHelper.debug(LOGGER,".getJWTPayload(String, jwtToken) : reloading public key for jwkuri [{}] ", jwkuri);
					getPayloadTries++;
				}
			}

			LoggerHelper.info(LOGGER,".getJWTPayload(String, jwtToken) : End");
			LoggerHelper.debug(LOGGER,".getJWTPayload(String, jwtToken) : Returning payload [{}]",payload);
			return payload;
	}
	
	/**
	 * @param jwkuri
	 * @param replaceKey
	 * @throws InvalidKeySpecException
	 * @throws NoSuchAlgorithmException
	 * @throws AuthNPublicException
	 */
	private static void populatePublicKeysMap(final String jwkuri, final boolean replaceKey) 
			throws InvalidKeySpecException, NoSuchAlgorithmException, AuthNPublicException {
		LoggerHelper.info(LOGGER,".populatePublicKeysMap(String) : Start");
		if(keyMap.containsKey(jwkuri) && !replaceKey) {
			LoggerHelper.debug(LOGGER, ".populatePublicKeysMap(String) : keyMap contains jwkuri[{}] with value [{}]", jwkuri, keyMap.get(jwkuri));
			return;
		}
		
		JSONObject obj = getJsonWebKeyObject(jwkuri);
		LoggerHelper.debug(LOGGER,".populatePublicKeysMap(String) : JSONObject is [{}]",obj);
		
		JSONArray childrenObject = obj.getJSONArray("keys");
		if(childrenObject!=null && childrenObject.length()>0) {
			for(int i=0; i<childrenObject.length();i++) {
			JSONObject keyJson = childrenObject.getJSONObject(i);
			 if (keyJson.getString("use") != null
			          && "sig".equals(keyJson.getString("use"))) {
			            PublicKey key = buildPublicKey(keyJson);
			            if (key != null) {
			            	LoggerHelper.debug(LOGGER,".populatePublicKeysMap(String) : populating keyMap with key [{}] and Value [{}]",jwkuri,key);
			            	keyMap.put(jwkuri, key);
			            }
			        }
			}
		}
		LoggerHelper.info(LOGGER,".populatePublicKeysMap(String) : End");
	}
	
	
	/**
	 * @param keyJson
	 * @return rsaPublicKey
	 * @throws InvalidKeySpecException
	 * @throws NoSuchAlgorithmException
	 */
	private static PublicKey buildPublicKey(final org.json.JSONObject  keyJson) throws InvalidKeySpecException, NoSuchAlgorithmException {
		LoggerHelper.info(LOGGER,".buildPublicKey(JSONObject) : Start");
		String kty = keyJson.getString("kty");
	    if ("RSA".equals(kty)) {
	    	LoggerHelper.debug(LOGGER, ".buildPublicKey(JSONObject) : choosing Encryption Algo as RSA");
	    	LoggerHelper.info(LOGGER,".buildPublicKey(JSONObject) : End");
	        return buildRSAPublicKey(keyJson);
	    }
	    LoggerHelper.debug(LOGGER, ".buildPublicKey(JSONObject) : Not Supported Encryption Algo found as [{}], Returing null",kty);
	    LoggerHelper.info(LOGGER,".buildPublicKey(JSONObject) : End");
	    return null;
	}
	
	/**
	 * @param keyJson
	 * @return rsaPublicKey
	 * @throws InvalidKeySpecException
	 * @throws NoSuchAlgorithmException
	 */
	private static PublicKey buildRSAPublicKey(final org.json.JSONObject  keyJson) throws InvalidKeySpecException, NoSuchAlgorithmException {
		LoggerHelper.info(LOGGER,".buildRSAPublicKey(JSONObject) : Start");
		java.util.Base64.Decoder base64Url = java.util.Base64.getUrlDecoder();

		BigInteger modulus = new BigInteger(base64Url.decode(keyJson.getString("n")));
		BigInteger publicExponent = new BigInteger(base64Url.decode(keyJson.getString("e")));
		LoggerHelper.info(LOGGER,".buildRSAPublicKey(JSONObject) : End");
		return KeyFactory.getInstance("RSA").generatePublic(
				new RSAPublicKeySpec(modulus, publicExponent));
	}
	
	/**
	 * @param uri
	 * @param requestMethod
	 * @param requestProperties
	 * @return response
	 * @throws AuthNPublicException
	 */
	protected static String getRequest(String uri, String requestMethod, Map<String, String> requestProperties) throws AuthNPublicException
	{
		LoggerHelper.info(LOGGER,".getRequest(String,String,Map) : Start");
		try
		{
			HttpURLConnection con = prepareConnection(uri, requestMethod, requestProperties);
			con.setDoOutput(true);
			BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
			String inputLine;
			StringBuilder response = new StringBuilder();
			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();
			LoggerHelper.debug(LOGGER, ".getRequest(String,String,Map) : Response from uri [{}] is [{}]",uri,response);
			LoggerHelper.info(LOGGER,".getRequest(String,String,Map) : End");
			return response.toString();
		}catch(IOException e)
		{
			LOGGER.error(".getRequest(String,String,Map) : IOException occured : "+e.getMessage(),e);
			throw new AuthNPublicException(e.getMessage(), AuthConstants.UNAUTHORIZED, e);
		}
	}

	/**
	 * prepares connection i.e. sets RequestProperty
	 * @param uri
	 * @param requestMethod
	 * @param requestProperties
	 * @return con
	 * @throws IOException
	 * @throws ProtocolException
	 */
	private static HttpURLConnection prepareConnection(String uri, String requestMethod,
			Map<String, String> requestProperties) throws IOException {
		LoggerHelper.info(LOGGER,".prepareConnection(String,String,Map) : Start");
		HttpURLConnection con = AuthUtil.getURLConnection(uri);
		con.setRequestMethod(requestMethod);
		if(requestProperties!=null)
		{
			for (Map.Entry<String, String> entry : requestProperties.entrySet()) {
				con.setRequestProperty(entry.getKey(), entry.getValue());
				LoggerHelper.debug(LOGGER, ".prepareConnection(String,String,Map) : added request property - Key [{}] and Value [{}]",entry.getKey(),entry.getValue());
			}
		}
		LoggerHelper.info(LOGGER,"..prepareConnection(String,String,Map) : End");
		return con;
	}
		
	
	/**
	 * @param jwkUri
	 * @return jsonObject
	 * @throws AuthNPublicException
	 */
	private static JSONObject getJsonWebKeyObject(String jwkUri) throws AuthNPublicException {
		LoggerHelper.info(LOGGER,".getJsonWebKeyObject(String) : End");
		String jsonWebKey = getRequest(jwkUri, "GET", null);
		LoggerHelper.debug(LOGGER, ".getJsonWebKeyObject(String) : Returning jsonWebKey [{}]",jsonWebKey);
		LoggerHelper.info(LOGGER,".getJsonWebKeyObject(String) : End");
		return new JSONObject(jsonWebKey);
		
	}
	
	
}