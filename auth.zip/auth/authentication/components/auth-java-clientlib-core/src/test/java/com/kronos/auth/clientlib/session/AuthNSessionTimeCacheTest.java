package com.kronos.auth.clientlib.session;

import java.time.LocalDateTime;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.core.classloader.annotations.SuppressStaticInitializationFor;
import org.powermock.modules.junit4.PowerMockRunner;

import com.kronos.auth.redis.AuthNRedisOperationResolver;
import com.kronos.auth.redis.impl.AuthNRedisOperationsImpl;

/**
 * Unit Test for AuthNSessionTimeCache
 * @author Sandeep.Agrrawal
 *
 */
@RunWith(PowerMockRunner.class)
@SuppressStaticInitializationFor("com.kronos.auth.clientlib.util.PropertyFileHelper")
public class AuthNSessionTimeCacheTest {
	AuthNSessionTimeCache svtCache;
	LocalDateTime date;
	AuthNRedisOperationsImpl redisOpImpl;
	AuthNRedisOperationResolver resolver;

	@Before
	public void setUp() throws Exception {
		redisOpImpl = Mockito.mock(AuthNRedisOperationsImpl.class);
		resolver = Mockito.mock(AuthNRedisOperationResolver.class);
		Mockito.doReturn(redisOpImpl).when(resolver).getAuthNRedisOperations();
		date = LocalDateTime.now();
		Mockito.doReturn(date.toString()).when(redisOpImpl).getValue(Mockito.anyString());
		Mockito.doNothing().when(redisOpImpl).add(Mockito.anyString(), Mockito.anyString());
		Mockito.doNothing().when(redisOpImpl).remove(Mockito.anyString());

		svtCache = Mockito.spy(AuthNSessionTimeCache.class);
		svtCache.redisOpResolver = resolver;
	}
	
	@Test
	public void testGetSessionValidTime() {
		LocalDateTime now = svtCache.getSessionValidTime(Mockito.anyString());
		Assert.assertTrue(now.isEqual(date));
	}
	
	@Test
	public void testGetSessionValidTime_resolver_null() {
		svtCache.redisOpResolver = null;
		LocalDateTime now = svtCache.getSessionValidTime(Mockito.anyString());
		Assert.assertNull(now);
	}
	
	@Test
	public void testGetSessionValidTime_exception() {
		Mockito.doReturn(null).when(redisOpImpl).getValue(Mockito.anyString());
		LocalDateTime now = svtCache.getSessionValidTime(Mockito.anyString());
		Assert.assertNull(now);
	}

	@Test
	public void testSetSessionValidTime() {
		svtCache.setSessionValidTime("tempString", date);
		Mockito.verify(redisOpImpl, Mockito.times(1)).add(Mockito.anyString(), Mockito.anyString());
	}

	@Test
	public void testRemoveSessionValidTime() {
		svtCache.removeSessionValidTime(Mockito.anyString());
		Mockito.verify(redisOpImpl, Mockito.times(1)).remove(Mockito.anyString());
	}
	
	@Test
	public void testGetSubscription() {
		svtCache.getSubscription(Mockito.anyString(), Mockito.anyObject());
		Mockito.verify(redisOpImpl, Mockito.times(1)).getSubscription(Mockito.anyString(), Mockito.anyObject());
	}

	@Test
	public void testPublishLogoutMessage() {
		svtCache.publishLogoutMessage(Mockito.anyString());
		Mockito.verify(redisOpImpl, Mockito.times(1)).publish(Mockito.anyString(), Mockito.anyString());
	}
}
