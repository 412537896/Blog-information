package com.kronos.auth.clientlib.util;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.api.mockito.PowerMockito;
import org.slf4j.Logger;

import com.kronos.auth.clientlib.exception.AuthNPublicException;

@RunWith(MockitoJUnitRunner.class)
public class LoggerHelperMicroTest {
	@InjectMocks
	Logger log  = Mockito.mock(Logger.class);
	private static final String testData = "testData";
	private static final String testDataFormated = "testData [{}]";

	@Test
	public void testDebug(){
		PowerMockito.when(log.isDebugEnabled()).thenReturn(true);
		LoggerHelper.debug(log, testData);
		Mockito.verify(log,Mockito.times(1)).debug(testData);
	}
	@Test
	public void testDebug_DebugOff(){
		PowerMockito.when(log.isDebugEnabled()).thenReturn(false);
		LoggerHelper.debug(log, testData);
		Mockito.verify(log,Mockito.times(0)).debug(testData);
	}
	@Test
	public void testDebugWithThroable_DebugOn(){
		AuthNPublicException t = PowerMockito.mock(AuthNPublicException.class);
		PowerMockito.when(log.isDebugEnabled()).thenReturn(true);
		LoggerHelper.debug(log, testData,t);
		Mockito.verify(log,Mockito.times(1)).debug(testData,t);
	}
	@Test
	public void testDebugWithThroable_DebugOff(){
		AuthNPublicException t = PowerMockito.mock(AuthNPublicException.class);
		PowerMockito.when(log.isDebugEnabled()).thenReturn(false);
		LoggerHelper.debug(log, testData,t);
		Mockito.verify(log,Mockito.times(0)).debug(testData,t);
	}
	@Test
	public void testDebugWithThroable_DebugOnNoThrowable(){
		AuthNPublicException t = null;
		PowerMockito.when(log.isDebugEnabled()).thenReturn(true);
		LoggerHelper.debug(log, testData,t);
		Mockito.verify(log,Mockito.times(1)).debug(testData);
	}
	@Test
	public void testDebugWithThroable_DebugOnStringFormating(){
		String replacement = "this should be formated";
		PowerMockito.when(log.isDebugEnabled()).thenReturn(true);
		LoggerHelper.debug(log, testDataFormated,replacement,replacement,replacement);
		Mockito.verify(log,Mockito.times(1)).debug(testDataFormated,replacement,replacement,replacement);
	}
	@Test
	public void testDebugWithThroable_DebugOffStringFormating(){
		String replacement = "this should be formated";
		PowerMockito.when(log.isDebugEnabled()).thenReturn(false);
		LoggerHelper.debug(log, testDataFormated,replacement,replacement);
		Mockito.verify(log,Mockito.times(0)).debug(replacement,replacement,replacement);
	}
	@Test
	public void testInfo(){
		PowerMockito.when(log.isInfoEnabled()).thenReturn(true);
		LoggerHelper.info(log, testData);
		Mockito.verify(log,Mockito.times(1)).info(testData);
	}
	@Test
	public void testDebug_InfoOff(){
		PowerMockito.when(log.isInfoEnabled()).thenReturn(false);
		LoggerHelper.info(log, testData);
		Mockito.verify(log,Mockito.times(0)).info(testData);
	}
	@Test
	public void testDebugWithThroable_InfoOnStringFormating(){
		String replacement = "this should be formated";
		PowerMockito.when(log.isInfoEnabled()).thenReturn(true);
		LoggerHelper.info(log, testDataFormated,replacement,replacement,replacement);
		Mockito.verify(log,Mockito.times(1)).info(testDataFormated,replacement,replacement,replacement);
	}
	@Test
	public void testInfoWithThroable_InfoOffStringFormating(){
		String replacement = "this should be formated";
		PowerMockito.when(log.isInfoEnabled()).thenReturn(false);
		LoggerHelper.info(log, testDataFormated,replacement,replacement);
		Mockito.verify(log,Mockito.times(0)).info(replacement,replacement,replacement);
	}
	
	@Test
	public void testError(){
		String replacement = "this should be formated";
		PowerMockito.when(log.isErrorEnabled()).thenReturn(true);
		LoggerHelper.error(log, testDataFormated,replacement,replacement,replacement);
		Mockito.verify(log,Mockito.times(1)).error(testDataFormated,replacement,replacement,replacement);
	}
}
