package com.kronos.auth.clientlib.post.authn.impl;

import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.kronos.auth.clientlib.exception.AuthNPublicException;
import com.kronos.auth.clientlib.impl.AuthNTokenProviderImpl;
import com.kronos.auth.clientlib.post.authn.api.PostLogoutProcessor;
import com.kronos.auth.clientlib.session.SessionOperationNotifier;
import com.kronos.auth.clientlib.util.AuthConstants;
import com.kronos.auth.domain.UserInfo;
import com.mockrunner.mock.web.MockHttpServletRequest;
import com.mockrunner.mock.web.MockHttpServletResponse;

import junit.framework.TestCase;

@RunWith(PowerMockRunner.class)
@PrepareForTest({AuthNTokenProviderImpl.class,PostLogoutProcessor.class, Optional.class})
public class PostLogoutProcessingServiceImplMicroTest extends TestCase{

	@InjectMocks
	AuthNTokenProviderImpl authNTokenProviderImpl = PowerMockito.mock(AuthNTokenProviderImpl.class);
	
	@Mock
    private HttpServletRequest request = PowerMockito.mock(MockHttpServletRequest.class);
	
	@Mock
	private HttpServletResponse response = PowerMockito.mock(MockHttpServletResponse.class);
	
	@Mock 
	PostLogoutProcessor postLogoutProcessorMock = PowerMockito.mock(PostLogoutProcessor.class);
	
	@Mock SessionOperationNotifier sessionOpNotifierMock = PowerMockito.mock(SessionOperationNotifier.class);
	
	private PostLogoutProcessingServiceImpl fixture = PowerMockito.spy(new PostLogoutProcessingServiceImpl());
	
	public PostLogoutProcessingServiceImplMicroTest() {
	}

	@Test
	/**
	 * covers the basic flow.
	 */
	public void testPerformPostRefresh_happy() throws AuthNPublicException{
		UserInfo infoUser = new UserInfo("Test1", "t1");
		fixture.authNTokenProvider = authNTokenProviderImpl;
		fixture.postLogoutProcessorExists = Optional.of(postLogoutProcessorMock);
		fixture.sessionOpNotifierExists = Optional.of(sessionOpNotifierMock);
		PowerMockito.when(authNTokenProviderImpl.getUserInfo(request)).thenReturn(infoUser);
				
		String result = fixture.performPostLogout(request, response);
		assertTrue(result!=null);
		//verifying the set response.
		assertTrue(result.equalsIgnoreCase(AuthConstants.ACCEPTED));
	}
	
	@Test(expected=AuthNPublicException.class)
	public void testPerformPostRefresh_Exception() throws AuthNPublicException{
		UserInfo infoUser = new UserInfo("Test1", "t1");
		fixture.authNTokenProvider = authNTokenProviderImpl;
		fixture.postLogoutProcessorExists = Optional.of(postLogoutProcessorMock);
		PowerMockito.when(authNTokenProviderImpl.getUserInfo(request)).thenReturn(infoUser);

		Mockito.doThrow(new AuthNPublicException()).when(postLogoutProcessorMock).processLogout(request, response);
		fixture.performPostLogout(request, response);
	}
	
	@Test
	public void testPerformPostRefresh_UserInfo_Null() throws AuthNPublicException{
		fixture.authNTokenProvider = authNTokenProviderImpl;
		fixture.postLogoutProcessorExists = Optional.of(postLogoutProcessorMock);
		PowerMockito.when(authNTokenProviderImpl.getUserInfo(request)).thenReturn(null);
		fixture.performPostLogout(request, response);
	}
	
	@Test
	public void testPerformPostRefresh_postLogoutProcessorExists_null() throws AuthNPublicException{
		UserInfo infoUser = new UserInfo("Test1", "t1");
		fixture.authNTokenProvider = authNTokenProviderImpl;
		fixture.postLogoutProcessorExists = null;
		PowerMockito.when(authNTokenProviderImpl.getUserInfo(request)).thenReturn(infoUser);
				
		PowerMockito.when(request.getSession(false)).thenReturn(null);

		String result = fixture.performPostLogout(request, response);
		assertTrue(result!=null);
		//verifying the set response.
		assertTrue(result.equalsIgnoreCase(AuthConstants.ACCEPTED));
	}

	@Test
	public void testPerformPostRefresh_postLogoutProcessorExists_empty() throws AuthNPublicException{
		UserInfo infoUser = new UserInfo("Test1", "t1");
		fixture.authNTokenProvider = authNTokenProviderImpl;
		fixture.postLogoutProcessorExists = Optional.empty();
		PowerMockito.when(authNTokenProviderImpl.getUserInfo(request)).thenReturn(infoUser);
		
		HttpSession session = Mockito.mock(HttpSession.class);
		PowerMockito.doNothing().when(session).invalidate();
		PowerMockito.when(request.getSession(false)).thenReturn(session);

		String result = fixture.performPostLogout(request, response);
		assertTrue(result!=null);
		//verifying the set response.
		assertTrue(result.equalsIgnoreCase(AuthConstants.ACCEPTED));
	}

	@Test
	public void testPerformPostRefresh_sessionOpNotifierExists_null() throws AuthNPublicException{
		UserInfo infoUser = new UserInfo("Test1", "t1");
		fixture.authNTokenProvider = authNTokenProviderImpl;
		fixture.sessionOpNotifierExists = null;
		PowerMockito.when(authNTokenProviderImpl.getUserInfo(request)).thenReturn(infoUser);
				
		PowerMockito.when(request.getSession(false)).thenReturn(null);

		String result = fixture.performPostLogout(request, response);
		assertTrue(result!=null);
		//verifying the set response.
		assertTrue(result.equalsIgnoreCase(AuthConstants.ACCEPTED));
	}

	@Test
	public void testPerformPostRefresh_sessionOpNotifierExists_empty() throws AuthNPublicException{
		UserInfo infoUser = new UserInfo("Test1", "t1");
		fixture.authNTokenProvider = authNTokenProviderImpl;
		fixture.sessionOpNotifierExists = Optional.empty();
		PowerMockito.when(authNTokenProviderImpl.getUserInfo(request)).thenReturn(infoUser);
		
		HttpSession session = Mockito.mock(HttpSession.class);
		PowerMockito.doNothing().when(session).invalidate();
		PowerMockito.when(request.getSession(false)).thenReturn(session);

		String result = fixture.performPostLogout(request, response);
		assertTrue(result!=null);
		//verifying the set response.
		assertTrue(result.equalsIgnoreCase(AuthConstants.ACCEPTED));
	}}