package com.kronos.auth.domain;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

/**
 * @author abhay.singh
 * Test Class for @UserInfo.class
 */

@RunWith(JUnit4.class)
public class UserInfoMicroTest {
	private static final String TICKET_REASON = "tktrsn";
	private static final String LNAME = "lname";
	private static final String FNAME = "fname";
	private static final String uname = "supportuser";
	private String TestUsername = "fixtureUsername";
	private String TestTenantname = "FixtureTenantname";
	
	UserInfo fixture = new UserInfo(TestUsername,TestTenantname);
	
	@Test
	public void testGetOAuthToken(){
		String testData = "dummyOAuthToken";
		fixture.setOAuthToken(testData);
		assertTrue(fixture.getOAuthToken().equals(testData));
	}
	
	@Test
	public void testGetFirstName(){
		String testData = "dummyFirstName";
		fixture.setFirstName(testData);
		assertTrue(fixture.getFirstName().equals(testData));
	}
	
	@Test
	public void testGetLastname(){
		String testData = "dummyLastname";
		fixture.setLastName(testData);
		assertTrue(fixture.getLastName().equals(testData));
	}
	
	@Test
	public void testGetFullname(){
		String testData = "dummyFullname";
		fixture.setFullName(testData);
		assertTrue(fixture.getFullName().equals(testData));
	}
	
	@Test
	public void testGetMail(){
		String testData = "dummyMail";
		fixture.setMail(testData);
		assertTrue(fixture.getMail().equals(testData));
	}
	
	@Test
	public void testGetUsername(){
		assertTrue(fixture.getUsername().equals(TestUsername));
	}
	
	@Test
	public void testGetUserLocale(){
		UserLocaleProfile testUserLocale = new UserLocaleProfile();
		fixture.setUserLocaleProfile(testUserLocale);
		assertTrue(fixture.getUserLocaleProfile().equals(testUserLocale));
	}
	

	@Test
	public void testOnBehalfUser(){
		String testData = "dummyOnBehalfUser";
		fixture.setOnBehalfUser(testData);
		assertTrue(fixture.getOnBehalfUser().equals(testData));
	}
	
	@Test
	public void testOpenAmAuthzUrl(){
		String testOpenAmAuthzUrl = "authZurl";
		fixture.setOpenAmAuthzUrl(testOpenAmAuthzUrl);
	}
	

	@Test
	public void testOpenAmCookie(){
		String testOpenAmCookie = "dummyCookie";
		fixture.setOnBehalfUser(testOpenAmCookie);
	}
	
	@Test
	public void testOnBehalfUser_empty(){
		String testData = "";
		fixture.setOnBehalfUser(testData);
		assertNull(fixture.getOnBehalfUser());
	}
	
	@Test
	public void testGetSupportUserName() {
		fixture.setSupportUserFirstName(FNAME);
		fixture.setSupportUserLastName(LNAME);
		fixture.setSupportUserName(uname);
		assertTrue(fixture.getSupportUserName().equals(uname));
	}
	
	@Test
	public void testGetSupportUserName_Null() {
		fixture.setSupportUserFirstName(null);
		fixture.setSupportUserLastName(null);
		assertNull(fixture.getSupportUserName());
	}
	
	@Test
	public void testGetSupportUserName_FNameNull() {
		fixture.setSupportUserFirstName(null);
		fixture.setSupportUserLastName(LNAME);
		fixture.setSupportUserName(uname);
		assertTrue(fixture.getSupportUserName().equals(uname));
	}
	
	@Test
	public void testGetSupportUserName_LNameNull() {
		fixture.setSupportUserFirstName(FNAME);
		fixture.setSupportUserLastName(null);
		fixture.setSupportUserName(uname);
		assertTrue(fixture.getSupportUserName().equals(uname));
	}
	
	@Test
	public void testGetTicketReason() {
		fixture.setTicketReason(TICKET_REASON);
		assertTrue(fixture.getTicketReason().equals(TICKET_REASON));
	}
}

