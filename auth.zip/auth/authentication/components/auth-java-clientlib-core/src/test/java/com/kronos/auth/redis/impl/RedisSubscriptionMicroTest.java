package com.kronos.auth.redis.impl;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.locks.ReentrantLock;

import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.kronos.auth.clientlib.util.AuthUtil;
import com.kronos.auth.clientlib.util.PropertyFileHelper;
import com.kronos.auth.redis.AuthNRedisConnectionPoolSvcResolver;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPoolConfig;
import redis.clients.jedis.JedisPubSub;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ AuthUtil.class, PropertyFileHelper.class, AuthNRedisConnectionPoolServiceImpl.class})
public class RedisSubscriptionMicroTest {
	@Mock
	static JedisPoolConfig poolConfig = PowerMockito.mock(JedisPoolConfig.class);

	private AuthNRedisConnectionPoolSvcResolver resolver;
	
	@BeforeClass
	public static void startUp() {
		PowerMockito.mockStatic(PropertyFileHelper.class);
		PowerMockito.mockStatic(AuthUtil.class);

		PowerMockito.doReturn("someHost:8080").when(PropertyFileHelper.class);
		PropertyFileHelper.getRedisMaster();

		Set<String> sentinals = new HashSet<>();
		PowerMockito.doReturn(sentinals).when(PropertyFileHelper.class);
		PropertyFileHelper.getSentinelHostsAndPorts();

		PowerMockito.doReturn("1000").when(PropertyFileHelper.class);
		PropertyFileHelper.getRedisTimeout();

		PowerMockito.doReturn("password").when(PropertyFileHelper.class);
		PropertyFileHelper.getRedisAuth();

		PowerMockito.doReturn("80").when(PropertyFileHelper.class);
		PropertyFileHelper.getRedisMaxActive();

		PowerMockito.doReturn(poolConfig).when(AuthUtil.class);
		AuthUtil.getJedisPoolConfig();

		ReentrantLock lock = PowerMockito.mock(ReentrantLock.class);
		PowerMockito.doReturn(lock).when(AuthUtil.class);
		AuthUtil.getReentrantLock();
		PowerMockito.doNothing().when(lock).lock();

	}

	@Test
	public void testStart() {
		// prepare mock
		PowerMockito.mockStatic(AuthNRedisConnectionPoolServiceImpl.class);
		Jedis client = PowerMockito.mock(Jedis.class);
		JedisPubSub pubSubImpl = PowerMockito.mock(JedisPubSub.class);
		AuthNRedisConnectionPoolServiceImpl serv = PowerMockito.mock(AuthNRedisConnectionPoolServiceImpl.class);
		
		serv = PowerMockito.mock(AuthNRedisConnectionPoolServiceImpl.class);
		resolver = PowerMockito.mock(AuthNRedisConnectionPoolSvcResolver.class);
		PowerMockito.doReturn(serv).when(resolver).getAuthNRedisConnectionPoolService();
		
		PowerMockito.doReturn(client).when(serv).getJedisConnection();
		PowerMockito.doNothing().when(client).subscribe(pubSubImpl, "testChannel");
		RedisSubscription spy = PowerMockito.spy(new RedisSubscription("testChannel", pubSubImpl,serv));
		spy.subscription = null;
		// actual test
		spy.start();
		sleep();
		// verification
		Mockito.verify(client, Mockito.times(1)).subscribe(pubSubImpl, "testChannel");
		Mockito.verify(pubSubImpl, Mockito.times(0)).unsubscribe();
	}

	private void sleep() {
		try {
			Thread.sleep(2000L);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testUnSubscribe() {
		PowerMockito.mockStatic(AuthNRedisConnectionPoolServiceImpl.class);
		AuthNRedisConnectionPoolServiceImpl serv = PowerMockito.mock(AuthNRedisConnectionPoolServiceImpl.class);
		Jedis client = PowerMockito.mock(Jedis.class);

		serv = PowerMockito.mock(AuthNRedisConnectionPoolServiceImpl.class);
		resolver = PowerMockito.mock(AuthNRedisConnectionPoolSvcResolver.class);
		PowerMockito.doReturn(serv).when(resolver).getAuthNRedisConnectionPoolService();

		PowerMockito.doReturn(client).when(serv).getJedisConnection();
		JedisPubSub pubSubImpl = PowerMockito.mock(JedisPubSub.class);
		PowerMockito.doNothing().when(client).subscribe(pubSubImpl, "testChannel");
		RedisSubscription spy = PowerMockito.spy(new RedisSubscription("testChannel", pubSubImpl, serv));
		spy.unSubscribe();
		Mockito.verify(client, Mockito.times(0)).subscribe(pubSubImpl, "testChannel");
		Mockito.verify(pubSubImpl, Mockito.times(1)).unsubscribe();
	}

	@Test
	public void testIsSubscribed_false() {
		PowerMockito.mockStatic(AuthNRedisConnectionPoolServiceImpl.class);
		PowerMockito.mockStatic(AuthUtil.class);
		AuthNRedisConnectionPoolServiceImpl serv = PowerMockito.mock(AuthNRedisConnectionPoolServiceImpl.class);
		Jedis client = PowerMockito.mock(Jedis.class);
		serv = PowerMockito.mock(AuthNRedisConnectionPoolServiceImpl.class);
		resolver = PowerMockito.mock(AuthNRedisConnectionPoolSvcResolver.class);
		PowerMockito.doReturn(serv).when(resolver).getAuthNRedisConnectionPoolService();
		PowerMockito.doReturn(client).when(serv).getJedisConnection();
		JedisPubSub pubSubImpl = PowerMockito.mock(JedisPubSub.class);
		PowerMockito.doNothing().when(client).subscribe(pubSubImpl, "testChannel");
		PowerMockito.doReturn(new Boolean(true)).when(pubSubImpl).isSubscribed();
		ReentrantLock lock = PowerMockito.mock(ReentrantLock.class);
		PowerMockito.doReturn(lock).when(AuthUtil.class);
		AuthUtil.getReentrantLock();
		RedisSubscription spy = PowerMockito.spy(new RedisSubscription("testChannel", pubSubImpl,serv));
		PowerMockito.doReturn(new Boolean(true)).when(lock).tryLock();
		spy.start();
		boolean result = spy.isSubscribed();
		assertFalse(result);
	}

	@Test
	public void testIsSubscribed_false_subscription() {
		PowerMockito.mockStatic(AuthNRedisConnectionPoolServiceImpl.class);
		PowerMockito.mockStatic(AuthUtil.class);
		AuthNRedisConnectionPoolServiceImpl serv = PowerMockito.mock(AuthNRedisConnectionPoolServiceImpl.class);
		Jedis client = PowerMockito.mock(Jedis.class);
		serv = PowerMockito.mock(AuthNRedisConnectionPoolServiceImpl.class);
		resolver = PowerMockito.mock(AuthNRedisConnectionPoolSvcResolver.class);
		PowerMockito.doReturn(serv).when(resolver).getAuthNRedisConnectionPoolService();
		PowerMockito.doReturn(client).when(serv).getJedisConnection();
		JedisPubSub pubSubImpl = PowerMockito.mock(JedisPubSub.class);
		PowerMockito.doNothing().when(client).subscribe(pubSubImpl, "testChannel");
		PowerMockito.doReturn(new Boolean(false)).when(pubSubImpl).isSubscribed();
		ReentrantLock lock = PowerMockito.mock(ReentrantLock.class);
		PowerMockito.doReturn(lock).when(AuthUtil.class);
		AuthUtil.getReentrantLock();
		RedisSubscription spy = PowerMockito.spy(new RedisSubscription("testChannel", null, serv));
		PowerMockito.doReturn(new Boolean(true)).when(lock).tryLock();

		spy.unSubscribe();
	}

	@Test
	public void testIsSubscribed_true() {
		PowerMockito.mockStatic(AuthNRedisConnectionPoolServiceImpl.class);
		PowerMockito.mockStatic(AuthUtil.class);
		AuthNRedisConnectionPoolServiceImpl serv = PowerMockito.mock(AuthNRedisConnectionPoolServiceImpl.class);
		Jedis client = PowerMockito.mock(Jedis.class);
		serv = PowerMockito.mock(AuthNRedisConnectionPoolServiceImpl.class);
		resolver = PowerMockito.mock(AuthNRedisConnectionPoolSvcResolver.class);
		PowerMockito.doReturn(serv).when(resolver).getAuthNRedisConnectionPoolService();
		PowerMockito.doReturn(client).when(serv).getJedisConnection();
		JedisPubSub pubSubImpl = PowerMockito.mock(JedisPubSub.class);
		PowerMockito.doNothing().when(client).subscribe(pubSubImpl, "testChannel");
		PowerMockito.doReturn(new Boolean(true)).when(pubSubImpl).isSubscribed();
		ReentrantLock lock = PowerMockito.mock(ReentrantLock.class);
		PowerMockito.doReturn(lock).when(AuthUtil.class);
		AuthUtil.getReentrantLock();
		PowerMockito.doReturn(new Boolean(false)).when(lock).tryLock();
		RedisSubscription spy = PowerMockito.spy(new RedisSubscription("testChannel", pubSubImpl, serv));
		spy.start();
		boolean result = spy.isSubscribed();
		assertTrue(result);
	}

	@Test
	public void testStart_emptyChannel() {
		PowerMockito.mockStatic(AuthNRedisConnectionPoolServiceImpl.class);
		AuthNRedisConnectionPoolServiceImpl serv = PowerMockito.mock(AuthNRedisConnectionPoolServiceImpl.class);
		Jedis client = PowerMockito.mock(Jedis.class);
		serv = PowerMockito.mock(AuthNRedisConnectionPoolServiceImpl.class);
		resolver = PowerMockito.mock(AuthNRedisConnectionPoolSvcResolver.class);
		PowerMockito.doReturn(serv).when(resolver).getAuthNRedisConnectionPoolService();
		PowerMockito.doReturn(client).when(serv).getJedisConnection();
		JedisPubSub pubSubImpl = PowerMockito.mock(JedisPubSub.class);
		PowerMockito.doNothing().when(client).subscribe(pubSubImpl, "testChannel");
		RedisSubscription spy = PowerMockito.spy(new RedisSubscription(null, pubSubImpl, serv));
		spy.start();
		sleep();
		Mockito.verify(client, Mockito.times(0)).subscribe(pubSubImpl, "testChannel");
		Mockito.verify(pubSubImpl, Mockito.times(0)).unsubscribe();
	}

	@Test
	public void testStart_error() {
		PowerMockito.mockStatic(AuthNRedisConnectionPoolServiceImpl.class);
		PowerMockito.mockStatic(AuthUtil.class);
		AuthNRedisConnectionPoolServiceImpl serv = PowerMockito.mock(AuthNRedisConnectionPoolServiceImpl.class);
		Jedis client = PowerMockito.mock(Jedis.class);
		serv = PowerMockito.mock(AuthNRedisConnectionPoolServiceImpl.class);
		resolver = PowerMockito.mock(AuthNRedisConnectionPoolSvcResolver.class);
		PowerMockito.doReturn(serv).when(resolver).getAuthNRedisConnectionPoolService();
		PowerMockito.doReturn(client).when(serv).getJedisConnection();
		JedisPubSub pubSubImpl = PowerMockito.mock(JedisPubSub.class);
		PowerMockito.doThrow(new RuntimeException()).when(client).subscribe(pubSubImpl, "testChannel");
		PowerMockito.doReturn(new Boolean(true)).when(client).isConnected();
		ReentrantLock lock = PowerMockito.mock(ReentrantLock.class);
		PowerMockito.doReturn(lock).when(AuthUtil.class);
		AuthUtil.getReentrantLock();
		PowerMockito.doNothing().when(lock).lock();
		RedisSubscription spy = PowerMockito.spy(new RedisSubscription("testChannel", pubSubImpl, serv));
		spy.start();
		sleep();
		Mockito.verify(client, Mockito.times(1)).subscribe(pubSubImpl, "testChannel");
		Mockito.verify(pubSubImpl, Mockito.times(0)).unsubscribe();
		Mockito.verify(serv, Mockito.times(1)).returnJedisConnection(client);
	}

	@Test
	public void testStart_with_subscription() {
		PowerMockito.mockStatic(AuthNRedisConnectionPoolServiceImpl.class);
		PowerMockito.mockStatic(AuthUtil.class);
		AuthNRedisConnectionPoolServiceImpl serv = PowerMockito.mock(AuthNRedisConnectionPoolServiceImpl.class);
		Jedis client = PowerMockito.mock(Jedis.class);
		serv = PowerMockito.mock(AuthNRedisConnectionPoolServiceImpl.class);
		resolver = PowerMockito.mock(AuthNRedisConnectionPoolSvcResolver.class);
		PowerMockito.doReturn(serv).when(resolver).getAuthNRedisConnectionPoolService();
		PowerMockito.doReturn(client).when(serv).getJedisConnection();
		JedisPubSub pubSubImpl = PowerMockito.mock(JedisPubSub.class);
		PowerMockito.doThrow(new RuntimeException()).when(client).subscribe(pubSubImpl, "testChannel");
		PowerMockito.doReturn(new Boolean(true)).when(client).isConnected();
		ReentrantLock lock = PowerMockito.mock(ReentrantLock.class);
		PowerMockito.doReturn(lock).when(AuthUtil.class);
		AuthUtil.getReentrantLock();
		PowerMockito.doNothing().when(lock).lock();
		RedisSubscription spy = PowerMockito.spy(new RedisSubscription("testChannel", pubSubImpl, serv));
		spy.start();
		spy.start();
		sleep();
		Mockito.verify(serv, Mockito.times(2)).returnJedisConnection(client);
	}

}
