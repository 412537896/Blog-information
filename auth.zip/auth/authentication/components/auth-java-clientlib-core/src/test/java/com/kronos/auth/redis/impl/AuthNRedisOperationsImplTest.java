package com.kronos.auth.redis.impl;

import java.util.HashSet;
import java.util.Set;

import org.apache.commons.pool2.impl.GenericObjectPoolConfig;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.kronos.auth.clientlib.util.AuthConstants;
import com.kronos.auth.clientlib.util.AuthUtil;
import com.kronos.auth.clientlib.util.PropertyFileHelper;
import com.kronos.auth.redis.AuthNRedisConnectionPoolSvcResolver;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ AuthUtil.class, PropertyFileHelper.class, AuthNRedisConnectionPoolServiceImpl.class })
public class AuthNRedisOperationsImplTest {

	private JedisPool jedisPool = null;
	private JedisPoolConfig jedisPoolConfig = null;
	private Jedis jedis = null;
	private AuthNRedisConnectionPoolServiceImpl serv = null;
	
	private AuthNRedisOperationsImpl rOpImpl = null;

	private AuthNRedisConnectionPoolSvcResolver resolver;
	
	/**
	 * prepare mocks before class is loaded
	 */
	@Before
	public void startUp() {
		PowerMockito.mockStatic(PropertyFileHelper.class);
		PowerMockito.mockStatic(AuthUtil.class);

		PowerMockito.when(PropertyFileHelper.getOpenAMCookieName()).thenReturn(AuthConstants.FALLBACK_AUTHN_TOKEN);
		
		PowerMockito.doReturn("someHost:8080").when(PropertyFileHelper.class);
		PropertyFileHelper.getRedisMaster();

		Set<String> sentinals = new HashSet<>();
		PowerMockito.doReturn(sentinals).when(PropertyFileHelper.class);
		PropertyFileHelper.getSentinelHostsAndPorts();
		
		PowerMockito.doReturn("1000").when(PropertyFileHelper.class);
		PropertyFileHelper.getRedisTimeout();
		
		PowerMockito.doReturn("password").when(PropertyFileHelper.class);
		PropertyFileHelper.getRedisAuth();
		
		PowerMockito.doReturn("80").when(PropertyFileHelper.class);
		PropertyFileHelper.getRedisMaxActive();
		
		jedisPool = PowerMockito.mock(JedisPool.class);
		jedisPoolConfig = PowerMockito.mock(JedisPoolConfig.class);
		
		PowerMockito.doReturn(jedisPool).when(AuthUtil.class);
		AuthUtil.getJedisPool(Mockito.any(GenericObjectPoolConfig.class), Mockito.anyString(), Mockito.anyInt(),
				Mockito.anyInt(), Mockito.anyString());
		
		PowerMockito.doReturn(jedisPoolConfig).when(AuthUtil.class);
		AuthUtil.getJedisPoolConfig();
		
		jedis = PowerMockito.mock(Jedis.class);
		
		serv = PowerMockito.mock(AuthNRedisConnectionPoolServiceImpl.class);
		resolver = PowerMockito.mock(AuthNRedisConnectionPoolSvcResolver.class);
		PowerMockito.doReturn(serv).when(resolver).getAuthNRedisConnectionPoolService();
		
		PowerMockito.doReturn(jedis).when(serv).getJedisConnection();
		PowerMockito.doReturn(100L).when(jedis).expire(Mockito.anyString(),Mockito.anyInt());

		 rOpImpl = PowerMockito.spy(new AuthNRedisOperationsImpl());
		 rOpImpl.setAuthNRedisConnectionPoolSvcResolver(resolver);
	}

	@Test
	public void testPublish() {
		rOpImpl.publish("channel1", "sad");
		Mockito.verify(serv,Mockito.times(1)).returnJedisConnection(jedis);
	}

	@Test
	public void testExpire() {
		rOpImpl.expire("sad");
		Mockito.verify(serv,Mockito.times(1)).returnJedisConnection(jedis);
	}

	@Test
	public void testAdd() {		
		rOpImpl.add("test", "test1");
		Mockito.verify(jedis,Mockito.times(1)).set("test", "test1");
		Mockito.verify(serv,Mockito.times(1)).returnJedisConnection(jedis);
	}

	@Test
	public void testGetValue(){		
		rOpImpl.getValue("test");
		Mockito.verify(jedis,Mockito.times(1)).get("test");
		Mockito.verify(serv,Mockito.times(1)).returnJedisConnection(jedis);
	}
	
	@Test
	public void testRemove(){
		rOpImpl.remove("test");
		Mockito.verify(jedis,Mockito.times(1)).del("test");
		Mockito.verify(serv,Mockito.times(1)).returnJedisConnection(jedis);
	}

	@Test
	public void testGetSubscription() {
		rOpImpl.getSubscription(null, (channel, message) -> {});
		Assert.assertTrue(rOpImpl.isEnvironmentRedis());
	}
	
	@Test
	public void testGetSubscription_resolver_null() {
		rOpImpl.setAuthNRedisConnectionPoolSvcResolver(null);
		rOpImpl.getSubscription(null, (channel, message) -> {});
		Assert.assertTrue(rOpImpl.isEnvironmentRedis());
	}

}
