/**
 * 
 */
package com.kronos.auth.domain;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

/**
 * @author abhay.singh
 * Test Class for @OpenAmConfigAttrDTO.class
 */
@RunWith(JUnit4.class)
public class OpenAmConfigAttrDTOMicroTest {
	OpenAmConfigAttrDTO fixture = new OpenAmConfigAttrDTO();
	
	@Test
	public void testGetSessionTimeout(){
		fixture.setSessionTimeout("50000");
		Assert.assertTrue(fixture.getSessionTimeout().equals("50000"));
	}
	
}
