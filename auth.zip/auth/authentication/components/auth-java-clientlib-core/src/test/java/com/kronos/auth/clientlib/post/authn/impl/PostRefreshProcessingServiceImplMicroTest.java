package com.kronos.auth.clientlib.post.authn.impl;

import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.kronos.auth.clientlib.exception.AuthNPublicException;
import com.kronos.auth.clientlib.impl.AuthNTokenProviderImpl;
import com.kronos.auth.clientlib.post.authn.api.PostRefreshProcessor;
import com.kronos.auth.clientlib.util.AuthConstants;
import com.kronos.auth.clientlib.util.AuthUtil;
import com.kronos.auth.clientlib.util.CookieHelper;
import com.kronos.auth.domain.UserInfo;
import com.mockrunner.mock.web.MockHttpServletRequest;
import com.mockrunner.mock.web.MockHttpServletResponse;

import junit.framework.TestCase;

@RunWith(PowerMockRunner.class)
@PrepareForTest({AuthNTokenProviderImpl.class,PostRefreshProcessor.class, Optional.class, AuthUtil.class})
public class PostRefreshProcessingServiceImplMicroTest extends TestCase{

	@InjectMocks
	AuthNTokenProviderImpl authNTokenProviderImpl = PowerMockito.mock(AuthNTokenProviderImpl.class);
	
	@Mock
    private HttpServletRequest request = PowerMockito.mock(MockHttpServletRequest.class);
	
	@Mock
	private HttpServletResponse response = PowerMockito.mock(MockHttpServletResponse.class);
	
	@Mock 
	PostRefreshProcessor postRefreshProcessorMock = PowerMockito.mock(PostRefreshProcessor.class);
	
	private PostRefreshProcessingServiceImpl fixture = PowerMockito.spy(new PostRefreshProcessingServiceImpl());
	
	public PostRefreshProcessingServiceImplMicroTest() {
	}


	@Test
	/**
	 * covers the basic flow.
	 */
	@PrepareForTest({ CookieHelper.class})
	public void testPerformPostRefresh_happy() throws AuthNPublicException{
		UserInfo infoUser = new UserInfo("Test1", "t1");
		fixture.authNTokenProvider = authNTokenProviderImpl;
		fixture.postRefreshProcessorExists = Optional.of(postRefreshProcessorMock);
		PowerMockito.when(authNTokenProviderImpl.getUserInfo(request)).thenReturn(infoUser);
		
		String result = fixture.performPostRefresh(request, response);
		assertTrue(result!=null);
		//verifying the set response.
		assertTrue(result.equalsIgnoreCase(AuthConstants.ACCEPTED));
	}
	
	@Test(expected=AuthNPublicException.class)
	public void testPerformPostRefresh_Exception() throws AuthNPublicException{
		UserInfo infoUser = new UserInfo("Test1", "t1");
		fixture.authNTokenProvider = authNTokenProviderImpl;
		fixture.postRefreshProcessorExists = Optional.of(postRefreshProcessorMock);
		PowerMockito.when(authNTokenProviderImpl.getUserInfo(request)).thenReturn(infoUser);

		Mockito.doThrow(new AuthNPublicException()).when(postRefreshProcessorMock).processRefresh(request, response);
		fixture.performPostRefresh(request, response);
	}
	
	@Test
	public void testPerformPostRefresh_Null() throws AuthNPublicException{
		fixture.authNTokenProvider = authNTokenProviderImpl;
		fixture.postRefreshProcessorExists = Optional.of(postRefreshProcessorMock);
		PowerMockito.when(authNTokenProviderImpl.getUserInfo(request)).thenReturn(null);
		fixture.performPostRefresh(request, response);
	}
}
