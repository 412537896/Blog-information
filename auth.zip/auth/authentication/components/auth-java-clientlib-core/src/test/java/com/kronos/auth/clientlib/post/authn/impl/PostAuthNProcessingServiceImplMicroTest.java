package com.kronos.auth.clientlib.post.authn.impl;

import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.kronos.auth.clientlib.exception.AuthNPublicException;
import com.kronos.auth.clientlib.impl.AuthNTokenProviderImpl;
import com.kronos.auth.clientlib.post.authn.api.PostAuthNProcessor;
import com.kronos.auth.clientlib.session.SessionOperationNotifier;
import com.kronos.auth.clientlib.util.AuthConstants;
import com.kronos.auth.clientlib.util.CookieHelper;
import com.kronos.auth.domain.UserInfo;
import com.mockrunner.mock.web.MockHttpServletRequest;
import com.mockrunner.mock.web.MockHttpServletResponse;

import junit.framework.TestCase;

@RunWith(PowerMockRunner.class)
@PrepareForTest({AuthNTokenProviderImpl.class,PostAuthNProcessor.class})
public class PostAuthNProcessingServiceImplMicroTest extends TestCase{

	@InjectMocks
	AuthNTokenProviderImpl authNTokenProviderImpl = PowerMockito.mock(AuthNTokenProviderImpl.class);
	
	@Mock
    private HttpServletRequest request = PowerMockito.mock(MockHttpServletRequest.class);
	@Mock
	private HttpServletResponse response = PowerMockito.mock(MockHttpServletResponse.class);
	@Mock PostAuthNProcessor postAuthProcessorMock = PowerMockito.mock(PostAuthNProcessor.class);
	@Mock SessionOperationNotifier sessionOpNotifierMock = PowerMockito.mock(SessionOperationNotifier.class);
	@Mock
	private PostAuthNProcessingServiceImpl fixture = PowerMockito.spy(new PostAuthNProcessingServiceImpl());
	public PostAuthNProcessingServiceImplMicroTest() {
	}

	@Test
	/**
	 * covers the basic flow.
	 */
	@PrepareForTest({ CookieHelper.class})
	public void testperformPostAuthNInitializeSession_happy() throws AuthNPublicException{
		UserInfo infoUser = new UserInfo("Test1", "t1");
		fixture.authNTokenProvider = authNTokenProviderImpl;
		fixture.postAuthNProcessorExists = Optional.of(postAuthProcessorMock);
		fixture.sessionOpNotifierExists = Optional.of(sessionOpNotifierMock);
		PowerMockito.when(authNTokenProviderImpl.getUserInfo(request)).thenReturn(infoUser);
		
		HttpSession session = Mockito.mock(HttpSession.class);
		PowerMockito.when(session.getId()).thenReturn("dummySession");
		PowerMockito.when(request.getSession(false)).thenReturn(session);
		PowerMockito.mockStatic(CookieHelper.class);
		PowerMockito.when(CookieHelper.getBaseUrl(request)).thenReturn("dummyValue");
		
		String result = fixture.performPostAuthNInitializeSession(request, response);
		assertTrue(result!=null);
		//verifying the set response.
		assertTrue(result.equalsIgnoreCase(AuthConstants.ACCEPTED));
	}
	
	@Test
	public void testperformPostAuthNInitializeSession_Exception_2() throws AuthNPublicException{
		fixture.authNTokenProvider = authNTokenProviderImpl;
		fixture.postAuthNProcessorExists = Optional.of(postAuthProcessorMock);
		UserInfo infoUser = new UserInfo("Test1", "t1");
		PowerMockito.when(authNTokenProviderImpl.getUserInfo(request)).thenReturn(infoUser);
		Mockito.doThrow(new AuthNPublicException()).when(postAuthProcessorMock).setSessionCookies(request, response);
		fixture.performPostAuthNInitializeSession(request, response);
	}
	
	@Test
	public void testperformPostAuthNInitializeSession_Null() throws AuthNPublicException{
		fixture.authNTokenProvider = authNTokenProviderImpl;
		fixture.postAuthNProcessorExists = Optional.of(postAuthProcessorMock);
		PowerMockito.when(authNTokenProviderImpl.getUserInfo(request)).thenReturn(null);
		fixture.performPostAuthNInitializeSession(request, response);
	}
	
	@Test
	public void testperformPostAuthNInitializeSession_postAuthNProcessorExists_null() throws AuthNPublicException {
		fixture.authNTokenProvider = authNTokenProviderImpl;
		fixture.postAuthNProcessorExists = null;
		UserInfo infoUser = new UserInfo("Test1", "t1");
		PowerMockito.when(authNTokenProviderImpl.getUserInfo(request)).thenReturn(infoUser);
		fixture.performPostAuthNInitializeSession(request, response);
	}

	@Test
	public void testperformPostAuthNInitializeSession_postAuthNProcessorExists_empty() throws AuthNPublicException {
		fixture.authNTokenProvider = authNTokenProviderImpl;
		fixture.postAuthNProcessorExists = Optional.empty();
		UserInfo infoUser = new UserInfo("Test1", "t1");
		PowerMockito.when(authNTokenProviderImpl.getUserInfo(request)).thenReturn(infoUser);
		fixture.performPostAuthNInitializeSession(request, response);
	}

	@Test
	public void testperformPostAuthNInitializeSession_sessionOpNotifierExists_null() throws AuthNPublicException {
		fixture.authNTokenProvider = authNTokenProviderImpl;
		fixture.sessionOpNotifierExists = null;
		UserInfo infoUser = new UserInfo("Test1", "t1");
		PowerMockito.when(authNTokenProviderImpl.getUserInfo(request)).thenReturn(infoUser);
		fixture.performPostAuthNInitializeSession(request, response);
	}

	@Test
	public void testperformPostAuthNInitializeSession_sessionOpNotifierExists_empty() throws AuthNPublicException {
		fixture.authNTokenProvider = authNTokenProviderImpl;
		fixture.sessionOpNotifierExists = Optional.empty();
		UserInfo infoUser = new UserInfo("Test1", "t1");
		PowerMockito.when(authNTokenProviderImpl.getUserInfo(request)).thenReturn(infoUser);
		fixture.performPostAuthNInitializeSession(request, response);
	}
}
