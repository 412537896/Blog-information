package com.kronos.auth.clientlib.session;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.powermock.api.mockito.PowerMockito;

public class AuthNSessionOperationFilterTest {
	
	@InjectMocks
	private SessionOperationNotifierImpl implMock;
	private AuthNSessionOperationFilter filter;
	
    HttpServletRequest httpServletRequest;
    HttpServletResponse httpServletResponse;
    FilterChain filterChain;
    FilterConfig mockFilterConfig;

	@Before
	public void setUp() throws Exception {
		implMock = PowerMockito.mock(SessionOperationNotifierImpl.class);
		
	    httpServletRequest = PowerMockito.mock(HttpServletRequest.class);
	    httpServletResponse = PowerMockito.mock(HttpServletResponse.class);
	    filterChain = PowerMockito.mock(FilterChain.class);
	    mockFilterConfig = PowerMockito.mock(FilterConfig.class);

	    filter = new AuthNSessionOperationFilter();
	    PowerMockito.doNothing().when(implMock).sessionAccessed(httpServletRequest);
	}
	
	@Test
	public void testDoFilter() throws IOException, ServletException {
		SessionOperationNotifierHolder holder = new SessionOperationNotifierHolder();
		holder.setSessionOperationNotifier(implMock);

	    PowerMockito.when(httpServletRequest.getRequestURI()).thenReturn("/somepage.jsp");
	    filter.init(mockFilterConfig);
	    filter.doFilter(httpServletRequest, httpServletResponse, filterChain);
	    filter.destroy();
	}

	@Test
	public void testDoFilter_NOtifier_NULL() throws IOException, ServletException {
	    PowerMockito.when(httpServletRequest.getRequestURI()).thenReturn("/somepage.jsp");
	    filter.init(mockFilterConfig);
	    filter.doFilter(httpServletRequest, httpServletResponse, filterChain);
	    filter.destroy();
	}
	
	@Test
	public void testDoFilter_LogoutURI() throws IOException, ServletException {
	    // mock the getRequestURI() response
	    PowerMockito.when(httpServletRequest.getRequestURI()).thenReturn("/Logout");
	    filter.init(mockFilterConfig);
	    filter.doFilter(httpServletRequest, httpServletResponse, filterChain);
	    filter.destroy();
	}

	@Test(expected = Exception.class)
    public void testDoFilterException() throws IOException, ServletException { 
        filter.init(mockFilterConfig);
        filter.doFilter(httpServletRequest, httpServletResponse, filterChain);
        filter.destroy();
    }
}
