package com.kronos.auth.clientlib.impl;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.json.JSONObject;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.classloader.annotations.SuppressStaticInitializationFor;
import org.powermock.modules.junit4.PowerMockRunner;

import com.kronos.auth.clientlib.api.AuthNTokenProvider;
import com.kronos.auth.clientlib.exception.AuthNPublicException;
import com.kronos.auth.clientlib.exception.AuthNTokenPublicException;
import com.kronos.auth.clientlib.util.AuthConstants;
import com.kronos.auth.clientlib.util.AuthUtil;
import com.kronos.auth.clientlib.util.CookieHelper;
import com.kronos.auth.clientlib.util.PropertyFileHelper;
import com.kronos.auth.clientlib.util.PropertyFileHelper.FileStreamCreator;
import com.kronos.auth.domain.OpenAmConfigAttrDTO;
import com.kronos.auth.domain.SSOSessionInfo;
import com.kronos.auth.domain.UserInfo;
import com.mockrunner.mock.web.MockHttpServletRequest;

import junit.framework.TestCase;

@PrepareForTest({JWTTokenProcessor.class,URL.class,Cookie.class,AuthUtil.class,MockHttpServletRequest.class,PropertyFileHelper.class, FileStreamCreator.class, CookieHelper.class})
@RunWith(PowerMockRunner.class)
@PowerMockIgnore({"javax.crypto.*" })
@SuppressStaticInitializationFor("com.kronos.auth.clientlib.util.PropertyFileHelper")
public class AuthNTokenProviderImplMicroTest extends TestCase {
	
	@Mock
	private OpenAmConfigAttrDTO configAttrDTO;
	
	@Mock
    private HttpServletRequest request = PowerMockito.mock(MockHttpServletRequest.class);
	
	@Mock 
	private URL urlMock;
	
	@InjectMocks
    AuthNTokenProviderImpl authNTokenProviderImpl = PowerMockito.spy(new AuthNTokenProviderImpl());
	
	@InjectMocks
	AuthNTokenProvider authNTokenProvider = new AuthNTokenProviderImpl();
	
	private final static String AUTHN_TOKEN = "AUTHN_TOKEN";
	private final static String IPLANET_COOKIE = "authn_ssid";
	private final static String AUTHN_TOKEN_INCORRECT = "eyAidHlwIjogIkpXVCIsICJraWQiOiAiMTI3ZjRmMjYtNmM2MS00Y2ZhLWExOGUtNmVmZDg5NjJjYTM2IiwgImN0eSI6ICJKV1QiLCAiYWxnIjogIlJTMjU2IiB9.eyAiYXRfaGFzaCI6ICI4d3BTRHhuMkpBbzhsSnNEcFVPRHp3IiwgInN1YiI6ICJmY2hpbiIsICJpc3MiOiAiaHR0cDovL3JoZWw3LWF1dGg5LmludC5rcm9ub3MuY29tOjgwODAvb3BlbmFtL29hdXRoMiIsICJ0b2tlbk5hbWUiOiAiaWRfdG9rZW4iLCAiYXVkIjogWyAia3Jvbm9zIiBdLCAib3BzIjogImM4ODU3MjM2LWM4YmMtNGM1MC1iODNiLWEwNTBiMmM3YmFhMSIsICJhenAiOiAia3Jvbm9zIiwgImF1dGhfdGltZSI6IDE0NDg2MDQ0MDYsICJyZWFsbSI6ICIvIiwgImV4cCI6IDIwNDg2MDQ0MDYsICJ0b2tlblR5cGUiOiAiSldUVG9rZW4iLCAiaWF0IjogMTQ0ODYwNDQwNiB9.Q6PduQp7kO_Ji1O0mR0uSNoTgzBunfp9qo0uIK-BqgmcBY21gTtMmfsL6LItVrgDkoafs59Ap13aVcaQ66PrdYipvsWg6XhJ1wqVhCL1Zzb-cO8XzpLhrHTofl1TlVY4nsZXkcy2mo4SUxYsH-CWtFcUEeDeV52EGgUM-DXjYFu0j6nH7eGn6sK3Tk2HkzqUjzElhHnoQQ23tHjzm_7BNAGxbHE0wlkAU3NBwgt-bZLQsB5M9n6PYJIT6C4nNd1nCfoGajy23XPADivXVc23gSwxwL7JQqfkbJxLUJEttngBn72Ce4iQHRfxUdWwtTi9rs1zumb6sfyWbgmG5JphIQ|ZllENzc3U3M3YjBBMC82bkdtQ0R2U2NyaHJob0x3Z05Vc1pmZjd0TEgxQ2J2TDFWTXhPU29YQjdFanVLdVpqK1FjSVZaVkNLTmJoakxKTEpOVGU1M0tBSWxsYkhwalpTeFAyVnk4UmlwK3BVNENSaTlXMUJRZ09VcDZZT3ZnZzcxMG5oSkRPb0xBUHVUVDhjQ1pTUjNRLS0=";
	private final static String AUTHN_TOKEN_COOKIE_VALUE_CORRECT = "eyAidHlwIjogIkpXVCIsICJraWQiOiAiMTI3ZjRmMjYtNmM2MS00Y2ZhLWExOGUtNmVmZDg5NjJjYTM2IiwgImN0eSI6ICJKV1QiLCAiYWxnIjogIlJTMjU2IiB9.eyAiYXRfaGFzaCI6ICI4d3BTRHhuMkpBbzhsSnNEcFVPRHp3IiwgInN1YiI6ICJmY2hpbiIsICJpc3MiOiAiaHR0cDovL3JoZWw3LWF1dGg5LmludC5rcm9ub3MuY29tOjgwODAvb3BlbmFtL29hdXRoMiIsICJ0b2tlbk5hbWUiOiAiaWRfdG9rZW4iLCAiYXVkIjogWyAia3Jvbm9zIiBdLCAib3BzIjogImM4ODU3MjM2LWM4YmMtNGM1MC1iODNiLWEwNTBiMmM3YmFhMSIsICJhenAiOiAia3Jvbm9zIiwgImF1dGhfdGltZSI6IDE0NDg2MDQ0MDYsICJyZWFsbSI6ICIvIiwgImV4cCI6IDIwNDg2MDQ0MDYsICJ0b2tlblR5cGUiOiAiSldUVG9rZW4iLCAiaWF0IjogMTQ0ODYwNDQwNiB9.Q6PduQp7kO_Ji1O0mR0uSNoTgzBunfp9qo0uIK-BqgmcBY21gTtMmfsL6LItVrgDkoafs59Ap13aVcaQ66PrdYipvsWg6XhJ1wqVhCL1Zzb-cO8XzpLhrHTofl1TlVY4nsZXkcy2mo4SUxYsH-CWtFcUEeDeV52EGgUM-DXjYFu0j6nH7eGn6sK3Tk2HkzqUjzElhHnoQQ23tHjzm_7BNAGxbHE0wlkAU3NBwgt-bZLQsB5M9n6PYJIT6C4nNd1nCfoGajy23XPADivXVc23gSwxwL7JQqfkbJxLUJEttngBn72Ce4iQHRfxUdWwtTi9rs1zumb6sfyWbgmG5JphIQ|ZllENzc3U3M3YjBBMC82bkdtQ0R2VVlDM2RXWG4xZlRwZ08raFNkMmZYOUI2RFlKRG0zQ1lBWllSKzE3T01LTGZ3QUZyTzBoK3o1RndCWnA2TWhUN1ZldGpVSE9UWHpSaGlIcVdBUXBoNEpXYjBkRXB5Q3NSVmFnV1NvaHlpYzZzNHZQdWxqeFdCUEtTQVlQSkdRcXNBLS0=";
	private final static String AUTHN_TOKEN_COOKIE_VALUE_CORRECT_WITHOUTUSERINFO = "eyAidHlwIjogIkpXVCIsICJraWQiOiAiMTI3ZjRmMjYtNmM2MS00Y2ZhLWExOGUtNmVmZDg5NjJjYTM2IiwgImN0eSI6ICJKV1QiLCAiYWxnIjogIlJTMjU2IiB9.eyAiYXRfaGFzaCI6ICI4d3BTRHhuMkpBbzhsSnNEcFVPRHp3IiwgInN1YiI6ICJmY2hpbiIsICJpc3MiOiAiaHR0cDovL3JoZWw3LWF1dGg5LmludC5rcm9ub3MuY29tOjgwODAvb3BlbmFtL29hdXRoMiIsICJ0b2tlbk5hbWUiOiAiaWRfdG9rZW4iLCAiYXVkIjogWyAia3Jvbm9zIiBdLCAib3BzIjogImM4ODU3MjM2LWM4YmMtNGM1MC1iODNiLWEwNTBiMmM3YmFhMSIsICJhenAiOiAia3Jvbm9zIiwgImF1dGhfdGltZSI6IDE0NDg2MDQ0MDYsICJyZWFsbSI6ICIvIiwgImV4cCI6IDIwNDg2MDQ0MDYsICJ0b2tlblR5cGUiOiAiSldUVG9rZW4iLCAiaWF0IjogMTQ0ODYwNDQwNiB9.Q6PduQp7kO_Ji1O0mR0uSNoTgzBunfp9qo0uIK-BqgmcBY21gTtMmfsL6LItVrgDkoafs59Ap13aVcaQ66PrdYipvsWg6XhJ1wqVhCL1Zzb-cO8XzpLhrHTofl1TlVY4nsZXkcy2mo4SUxYsH-CWtFcUEeDeV52EGgUM-DXjYFu0j6nH7eGn6sK3Tk2HkzqUjzElhHnoQQ23tHjzm_7BNAGxbHE0wlkAU3NBwgt-bZLQsB5M9n6PYJIT6C4nNd1nCfoGajy23XPADivXVc23gSwxwL7JQqfkbJxLUJEttngBn72Ce4iQHRfxUdWwtTi9rs1zumb6sfyWbgmG5JphIQ";
	private final static String AUTHN_TOKEN_COOKIE_VALUE_INCORRECT = "eyAidHlwIjogIkpXVCIsICJhbGciOiAiUlMyNTYiLCAiY3R5IjogIkpXVCIsICJraWQiOiAiYzU0ZTk4M2YtMzg2NS00ZGYwLWEzNGEtNDdhOWVlMTZmYWM3IiB9.eyAidG9rZW5OYW1lIjogImlkX3Rva2VuIiwgImF6cCI6ICJ0b3Bqd3RjbGllbnQiLCAic3ViIjogInVzZXIuMTkiLCAiYXRfaGFzaCI6ICI2VDNhdTRjVThBTnZ4Z0Uyb2k4cVV3IiwgImlzcyI6ICJodHRwOi8vcmhlbDctYXV0aDIuaW50Lmtyb25vcy5jb206ODA4MC9vcGVuYW0vb2F1dGgyIiwgImlhdCI6IDE0NDIzODk5MDksICJhdXRoX3RpbWUiOiAxNDQyMzg5OTA5LCAiZXhwIjogMTQ0MjQ0OTkwOSwgInRva2VuVHlwZSI6ICJKV1RUb2tlbiIsICJyZWFsbSI6ICIvIiwgImF1ZCI6IFsgInRvcGp3dGNsaWVudCIgXSwgIm9wcyI6ICI1ODZlOTgxMS1iYzcxLTQ3ODQtOThlNy1mMTZiMTI1MzkwMjkiIH0.Sc56fldrgR0UB9hQwCkIoh9iaFE69GE3boG6O7-vjogHPxqCx4sHEiFR7NAwlDNVAvpdD6xgCclpdeW234EqxoSnNpQkidQcome8WPicfHgvBGXcbidccXaLEayiKqbVVYrJQXjPHMcCm2k7T9ThC5asltvHhDU_vOb3b6tZ7yOGTTtuw23bbz37bBrNbQYRxpw8FpNqk54gmIddIFIP6g3Z4Jq0v0i4cIX-v3nt6oJvZGJbA454YIVTC4u9u78U2R5ULKhmXOTIcVBIMUFyk3h2fO3stZTIqakpai41EncYPRAQnYM-h6uXrEn4Cyzc3FM_iMUHCUKzRs5p4k6F5N";
	//private final static String JWK_KEY_VALUE_CORRECT = "{\"keys\":[{\"kty\":\"RSA\",\"kid\":\"a52ad909-e5fd-4887-bf17-0b3f599150ae\",\"use\":\"sig\",\"alg\":\"RS256\",\"n\":\"AJ51bL-zyCb5eiUnUtqGojh8lru4WbEJCsewOrVLZGqvSeyuv72y75B76kusNyLRnFzdzhTQ36x0SmqXZ0z5nxl-rqcYvCP4tpSa2-sZGuWYhgEN-NUWxnoufCdEzrwKkndkO_v3jn9wIjeEcZLY_GIlle7aT5lKIhJyqkBuYKLPYl8sVFxxprb2iQwv0M-0zsI_iYXo5mu5bRLyw3cc0j8bxORB4dZyzMr5vdREheMfYDCQdBHmaj4NkrTV75nYL-7bI5bad-LvyASkevXB0TT8ugFvjRETRPdQeRJHCoWcosxqLkwut-XbzpW4wM1W4qFjtHWVMX8ljChlUKxtGTs\",\"e\":\"AQAB\"}]}";
	private final static String JWK_PAYLOAD = "{\"at_hash\": \"8wpSDxn2JAo8lJsDpUODzw\",\"sub\": \"amadmin\",\"tokenName\": \"id_token\",\"aud\": [\"kronos\"],\"ops\": \"c8857236-c8bc-4c50-b83b-a050b2c7baa1\",\"azp\": \"kronos\",\"auth_time\": 1448604406,\"realm\": \"/\",\"exp\": "+System.currentTimeMillis()/1000+",\"tokenType\": \"JWTToken\"}";
	private final static String JWK_PAYLOAD_TENANT = "{\"at_hash\": \"8wpSDxn2JAo8lJsDpUODzw\",\"sub\": \"SuperUser\",\"tokenName\": \"id_token\",\"aud\": [\"kronos\"],\"ops\": \"c8857236-c8bc-4c50-b83b-a050b2c7baa1\",\"azp\": \"kronos\",\"auth_time\": 1448604406,\"realm\": \"/tenant2\",\"exp\": "+System.currentTimeMillis()/1000+",\"tokenType\": \"JWTToken\"}";
    private static final boolean TRUE = true;
    private final static String AUTHN_LOGON_PROFILE = "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJodHRwOi8va2VuZzAxLWRldjAxLWluczAxLWF0aDAxLW9hbTAxLTE0ODcwNDY1MzkuZGV2Lm15a3Jvbm9zLmludGVybmFsOjgwODAiLCJpYXQiOjE0ODczMTIzMDgsImV4cCI6MTQ4NzMxOTUwOCwic3ViIjoiS2lvc2tVc2VyIiwibm9uY2UiOiI8RG4tMFM2X1d6QTJNaiIsInJlYWxtIjoiL2NvbWJpbmVkIn0.BEIeCe3ph8lUOWbP3PnovF2uY3q1p6sIpP5VcRhcHjAhmRcAzwTvZPLFY8P9JvnIXej8YaTMhaFtyaDUh63tfefp90hWw5pKKqHIQ7ttN4Q9g2xD5ZnKo83THgZ-pkhf2VnYdghR6qUrWW6Kt6xmf0-gDm-YdvRikEeTLcjlAjaMIfF4ORbxF9u6DgHI7_uvxMjf6u-T9nVN4tgKIt_ihG6nTfLA2NXQr9_J4WxOZ3_4xBRYEQNaSyjjv0xQ6pe239FnNmJgjKpEsGrLzuLsrGWLhvynbEffkga6hEhw77B6OtlaPfVBiaU2iqjlxjcvjASpvtv8jgfyXHR5rxebDg|bnRWakZkY2lUN2dmVUpqcEllc243eDlDVnNyUEtVS1J3RXpwdkJCNXAxRURiUFBhUlU4KzFhYTYzZFFtRkpHamJOdUc4WDVoajY0ZjFFMTlaYmV5emFKbThvUUpnRlNqSjZpMzk4M1BBcWh4OEJIVU85eGZJbXhkeDE0dHpwS0k1UlVWSnJkZHdoL1VCR3lCd3pXSG9BMytKZ1o5MHB5cnJIVkxnQWVBbEg2UDZ5SzMvMldRak5ueW5EeThiVG9KK1REZ1J6YVF4ZXI3amswbkpvVVFvRFU1K3ViSkRtR0dzZGdwZnlobUVkRWtxWlF6WUhXUnFGTHNzS2hwODdlUFVGdFB1Smc1VW1BTXV5NTVKRmpnaDhvd1ZNanpCcVF1OU5LcTJIR0FSM0ROY3dVYTBxYlR1cW1kZ2E2bWp1blh1eGRGMi9uK0QrYUIrTE9VbStaTkk4TktUb1hMdGtKV0tMdEpITy80b1hzdURRcGVORitOc1JmTzJWaVJ4ZVhkeVlVS1N6bU1LTDBoNklmVkIrVzdwbFJvTXJyVmZ4ZGwxQUdmbCtHWERWcVZKL2tFVUs0UHI4ejJtVUZUdWRxWXlic1M2V1F4a04rWTNDUUNnaVpmRUJUcDBaNFZ3Nk5BSjgxSVNyYXc3REhOQS9pSDNPZ0pNSkdyVjhTbFFudEJWdlJ6L0pyVTNYZmR2MkZ5RkpuTUFaVlZFWVN3WGVuMzBUb0lEZ1AzaWw0RE43OFdwNHMzcExXOXFyMFk4b1BFNEFKRDR4UjcvazAraUtGek1jYktuWG4rZ21KellGYzkvT1NZdXpoR2lrSS0=";
    private final static String JWK_PAYLOAD_LOGON_PROFILE = "{\"at_hash\": \"8wpSDxn2JAo8lJsDpUODzw\",\"sub\": \"KioskUser\",\"tokenName\": \"id_token\",\"aud\": [\"kronos\"],\"ops\": \"c8857236-c8bc-4c50-b83b-a050b2c7baa1\",\"azp\": \"kronos\",\"auth_time\": 1448604406,\"realm\": combined,\"exp\": "+System.currentTimeMillis()/1000+",\"tokenType\": \"JWTToken\"}";

	Cookie cookie2 = new Cookie(AUTHN_TOKEN, "AuthTokenValue");
	Cookie cookie3 = new Cookie(IPLANET_COOKIE, "iPlanetCookieValue");
	Cookie[] cookies2 = {cookie2, cookie3};
	Cookie[] cookies3 = {cookie2};
	
	String response = "session.time=30";
	private final static String DUMMY_URL = "http://someDummyURL.com:8080/openam";
	
	private final static String KEY_PASS = "key_password";
	private final static String KEY_PASS_VALUE = "$tr0ngKeY@123#56";
		
	@Before
	public void setup()
	{
		PowerMockito.mockStatic(PropertyFileHelper.class);
		Mockito.when(PropertyFileHelper.getOpenAMCookieName()).thenReturn(AUTHN_TOKEN);
	}
	
	@Test
    public void testGetAccessToken() throws Exception {
		Mockito.doReturn(new UserInfo("username", "tenantName")).when(authNTokenProviderImpl).getUserInfo(Mockito.any(Cookie[].class));
		PowerMockito.mockStatic(AuthUtil.class);
		AccessToken expectedValue = new AccessToken();
		expectedValue.setAccessToken("accessToken");
		expectedValue.setTokenType("tokenType");
		Mockito.when(AuthUtil.processAuthorizeRequest(Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString())).thenReturn(expectedValue);
		AccessToken accessToken = authNTokenProviderImpl.getAccessToken(request, "clientId");
		assertTrue(expectedValue.getTokenType().equals(accessToken.getTokenType()));
    }
	
	@Test
	public void testGetUserInfoTrue_HavingUserDetailsCookie() throws Exception {
		PowerMockito.mockStatic(AuthUtil.class);
		MockHttpServletRequest request = new MockHttpServletRequest();
		String allDetails = "eyAidHlwIjogIkpXVCIsICJraWQiOiAiMTI3ZjRmMjYtNmM2MS00Y2ZhLWExOGUtNmVmZDg5NjJjYTM2IiwgImN0eSI6ICJKV1QiLCAiYWxnIjogIlJTMjU2IiB9.eyAiYXRfaGFzaCI6ICI4d3BTRHhuMkpBbzhsSnNEcFVPRHp3IiwgInN1YiI6ICJmY2hpbiIsICJpc3MiOiAiaHR0cDovL3JoZWw3LWF1dGg5LmludC5rcm9ub3MuY29tOjgwODAvb3BlbmFtL29hdXRoMiIsICJ0b2tlbk5hbWUiOiAiaWRfdG9rZW4iLCAiYXVkIjogWyAia3Jvbm9zIiBdLCAib3BzIjogImM4ODU3MjM2LWM4YmMtNGM1MC1iODNiLWEwNTBiMmM3YmFhMSIsICJhenAiOiAia3Jvbm9zIiwgImF1dGhfdGltZSI6IDE0NDg2MDQ0MDYsICJyZWFsbSI6ICIvIiwgImV4cCI6IDIwNDg2MDQ0MDYsICJ0b2tlblR5cGUiOiAiSldUVG9rZW4iLCAiaWF0IjogMTQ0ODYwNDQwNiB9.Q6PduQp7kO_Ji1O0mR0uSNoTgzBunfp9qo0uIK-BqgmcBY21gTtMmfsL6LItVrgDkoafs59Ap13aVcaQ66PrdYipvsWg6XhJ1wqVhCL1Zzb-cO8XzpLhrHTofl1TlVY4nsZXkcy2mo4SUxYsH-CWtFcUEeDeV52EGgUM-DXjYFu0j6nH7eGn6sK3Tk2HkzqUjzElhHnoQQ23tHjzm_7BNAGxbHE0wlkAU3NBwgt-bZLQsB5M9n6PYJIT6C4nNd1nCfoGajy23XPADivXVc23gSwxwL7JQqfkbJxLUJEttngBn72Ce4iQHRfxUdWwtTi9rs1zumb6sfyWbgmG5JphIQ|ZllENzc3U3M3YjBBMC82bkdtQ0R2VVlDM2RXWG4xZlRwZ08raFNkMmZYOUI2RFlKRG0zQ1lBWllSKzE3T01LTGZ3QUZyTzBoK3o1RndCWnA2TWhUN1ZldGpVSE9UWHpSaGlIcVdBUXBoNEpXYjBkRXB5Q3NSVmFnV1NvaHlpYzZzNHZQdWxqeFdCUEtTQVlQSkdRcXNBLS0=";
		System.setProperty(KEY_PASS, KEY_PASS_VALUE);
		Cookie authNtokenCookie = createCookie(AUTHN_TOKEN, allDetails);
		Cookie iPlanetCookie = createCookie(IPLANET_COOKIE, "iplanetcookieValue");
		request.addCookie(authNtokenCookie);
		request.addCookie(iPlanetCookie);
		PowerMockito.mockStatic(JWTTokenProcessor.class);
		Mockito.when(JWTTokenProcessor.getJWTPayload(Mockito.anyString(), Mockito.anyString())).thenReturn(JWK_PAYLOAD);
		Mockito.when(JWTTokenProcessor.getJWTPayload(Mockito.anyString(), Mockito.anyString())).thenReturn(JWK_PAYLOAD);
	
		StringBuilder strMock = new StringBuilder();
		//setting up request Expiration time.
		strMock.append("exp=");
		strMock.append(System.currentTimeMillis()/1000);
		Mockito.when(AuthUtil.getResponseFromUrl(Mockito.any(),Mockito.anyString())).thenReturn(strMock);
		Mockito.when(AuthUtil.processAuthorizeRequest("authzUrl", "openAmCookieValue", "userName","clientId")).thenReturn(new AccessToken());
		
		PowerMockito.mockStatic(PropertyFileHelper.class);
		PowerMockito.mockStatic(CookieHelper.class);
		Mockito.when(PropertyFileHelper.getOpenAMServerURL()).thenReturn("http://dummyurl.com");
		Mockito.when(CookieHelper.getCookieValue(Mockito.any(HttpServletRequest.class), Mockito.anyString())).thenReturn("eyAidHlwIjogIkpXVCIsICJraWQiOiAiMTI3ZjRmMjYtNmM2MS00Y2ZhLWExOGUtNmVmZDg5NjJjYTM2IiwgImN0eSI6ICJKV1QiLCAiYWxnIjogIlJTMjU2IiB9.eyAiYXRfaGFzaCI6ICI4d3BTRHhuMkpBbzhsSnNEcFVPRHp3IiwgInN1YiI6ICJmY2hpbiIsICJpc3MiOiAiaHR0cDovL3JoZWw3LWF1dGg5LmludC5rcm9ub3MuY29tOjgwODAvb3BlbmFtL29hdXRoMiIsICJ0b2tlbk5hbWUiOiAiaWRfdG9rZW4iLCAiYXVkIjogWyAia3Jvbm9zIiBdLCAib3BzIjogImM4ODU3MjM2LWM4YmMtNGM1MC1iODNiLWEwNTBiMmM3YmFhMSIsICJhenAiOiAia3Jvbm9zIiwgImF1dGhfdGltZSI6IDE0NDg2MDQ0MDYsICJyZWFsbSI6ICIvIiwgImV4cCI6IDIwNDg2MDQ0MDYsICJ0b2tlblR5cGUiOiAiSldUVG9rZW4iLCAiaWF0IjogMTQ0ODYwNDQwNiB9.Q6PduQp7kO_Ji1O0mR0uSNoTgzBunfp9qo0uIK-BqgmcBY21gTtMmfsL6LItVrgDkoafs59Ap13aVcaQ66PrdYipvsWg6XhJ1wqVhCL1Zzb-cO8XzpLhrHTofl1TlVY4nsZXkcy2mo4SUxYsH-CWtFcUEeDeV52EGgUM-DXjYFu0j6nH7eGn6sK3Tk2HkzqUjzElhHnoQQ23tHjzm_7BNAGxbHE0wlkAU3NBwgt-bZLQsB5M9n6PYJIT6C4nNd1nCfoGajy23XPADivXVc23gSwxwL7JQqfkbJxLUJEttngBn72Ce4iQHRfxUdWwtTi9rs1zumb6sfyWbgmG5JphIQ|ZllENzc3U3M3YjBBMC82bkdtQ0R2VVlDM2RXWG4xZlRwZ08raFNkMmZYOUI2RFlKRG0zQ1lBWllSKzE3T01LTGZ3QUZyTzBoK3o1RndCWnA2TWhUN1ZldGpVSE9UWHpSaGlIcVdBUXBoNEpXYjBkRXB5Q3NSVmFnV1NvaHlpYzZzNHZQdWxqeFdCUEtTQVlQSkdRcXNBLS0=");
		
		UserInfo userInfo = authNTokenProviderImpl.getUserInfo(request);
		assertNotNull(userInfo.getFirstName());
		assertEquals("amadmin", userInfo.getUsername());
		
	}
	
	@Test
	public void testGetUserInfoTrue_HavingCorrectTenantId() throws Exception {
		MockHttpServletRequest request = new MockHttpServletRequest();
		String allDetails = "eyAidHlwIjogIkpXVCIsICJraWQiOiAiMjUzODJlZWUtYzA0MC00NWJiLWE1YTYtNDQ5ZDk3Nzg2ZjE4IiwgImN0eSI6ICJKV1QiLCAiYWxnIjogIlJTMjU2IiB9.eyAiYXRfaGFzaCI6ICJXUjFQRHVnRnRQUFAxTVk4Ti1EZWx3IiwgInN1YiI6ICJTdXBlclVzZXIiLCAiaXNzIjogImh0dHA6Ly9hdXRobnNlcnZlci5mYWxjb24ua3Jvbm9zLmNvbTo4MC9vcGVuYW0vb2F1dGgyL3RlbmFudDIiLCAidG9rZW5OYW1lIjogImlkX3Rva2VuIiwgIm5vbmNlIjogIjxEbi0wUzZfV3pBMk1qIiwgImF1ZCI6IFsgImtyb25vcyIgXSwgIm9wcyI6ICI0YjVlMTVhMS02MGEzLTQxZmEtYjEwYy0zNjI4OTNmMWJjYmIiLCAiYXpwIjogImtyb25vcyIsICJhdXRoX3RpbWUiOiAxNDYxOTE1NDQ0LCAicmVhbG0iOiAiL3RlbmFudDIiLCAiZXhwIjogMTQ2MTkxNjA0NCwgInRva2VuVHlwZSI6ICJKV1RUb2tlbiIsICJpYXQiOiAxNDYxOTE1NDQ0IH0.QYM3sbw851LGu-SAjN963a0gNvockjYXSzHIz5FiBmMZ5aGKll9C6ZhFyKw4Us20WiRI5BDzP-w7M1F_Ty_cHzJi02KQ1bBhE3NGqexuqVFy6oPfczQu5oea-k8HQa3u33w0gKp3V5c4MUVsKpeuyW3F2oAHwg2i4QmRt20WVqDLCVe86YkXbeTy49euZ5N74KW-lnuw5KdbfjtiKDj3aKuRP-X5IrlaU3kq8PyqPblmOx295m63WCmivdBDszMcgYP5Pz0IKznHxoEn8tQEY5DSwBSP9y8qKcxGVlF_fwAHZLQf0TZ_CFpX9b2eQ2vqyZwyxz-v9gwglLHwUiTIOg|QnVuc1lVdFZzKzR1UmtEM1lYNnZMQjlDVnNyUEtVS1J3RXpwdkJCNXAxRUt1M2hSeGwxRlNpWWI5dlNWeTdNYVhkSlF6WW90YkdqWkxPbndrTm5ieXM1UzhsTEFqMDNBMG5aTTNDbFpBUjgydEN0REN0bWhDTGIzRnNQcXg4bXdtQlRIdXppaEVwcE5UNzF1Lzc2eEs0eHcxSDBwUUY0SjVmbUtlYWZKQmNxQ0pzS2wxRklhY21QS0E2ZThNZ3FWRVMydlNGbHFyVWFxY1dydHA1NzczMlpHQk1SZmdyYWcwbm1qVUtSMFp3Z3V1cUlqQi9ZU3NwTE1lb25vbW0vSWg2T1J1dmxLMElFcjhnbmp4SDZtSnhQWGJ6cGxrRzY3eS9FQTJqcXBqK1FZWEdha1cvcEl3WFR5dTJld1BXMnlnbVlISG4ySGZDbHFsVHQ2UFo0dHRRLS0=";
		System.setProperty(KEY_PASS, KEY_PASS_VALUE);

		Cookie authNtokenCookie = createCookie(AUTHN_TOKEN, allDetails);
		request.addCookie(authNtokenCookie);
		request.setupAddParameter("tenantId", "tenant2");
		PowerMockito.mockStatic(JWTTokenProcessor.class);
		Mockito.when(JWTTokenProcessor.getJWTPayload(Mockito.anyString(), Mockito.anyString())).thenReturn(JWK_PAYLOAD_TENANT);
		Mockito.when(JWTTokenProcessor.getJWTPayload(Mockito.anyString(), Mockito.anyString())).thenReturn(JWK_PAYLOAD_TENANT);
		PowerMockito.mockStatic(AuthUtil.class);
		StringBuilder strMock = new StringBuilder();
		//setting up request Expiration time.
		strMock.append("exp=");
		strMock.append(System.currentTimeMillis()/1000);
		Mockito.when(AuthUtil.getResponseFromUrl(Mockito.any(),Mockito.anyString())).thenReturn(strMock);
		PowerMockito.mockStatic(CookieHelper.class);
		PowerMockito.mockStatic(PropertyFileHelper.class);
		Mockito.when(PropertyFileHelper.getOpenAMServerURL()).thenReturn("http://dummyurl.com");
		Mockito.when(CookieHelper.getCookieValue(Mockito.any(HttpServletRequest.class), Mockito.anyString())).thenReturn("eyAidHlwIjogIkpXVCIsICJraWQiOiAiMjUzODJlZWUtYzA0MC00NWJiLWE1YTYtNDQ5ZDk3Nzg2ZjE4IiwgImN0eSI6ICJKV1QiLCAiYWxnIjogIlJTMjU2IiB9.eyAiYXRfaGFzaCI6ICJXUjFQRHVnRnRQUFAxTVk4Ti1EZWx3IiwgInN1YiI6ICJTdXBlclVzZXIiLCAiaXNzIjogImh0dHA6Ly9hdXRobnNlcnZlci5mYWxjb24ua3Jvbm9zLmNvbTo4MC9vcGVuYW0vb2F1dGgyL3RlbmFudDIiLCAidG9rZW5OYW1lIjogImlkX3Rva2VuIiwgIm5vbmNlIjogIjxEbi0wUzZfV3pBMk1qIiwgImF1ZCI6IFsgImtyb25vcyIgXSwgIm9wcyI6ICI0YjVlMTVhMS02MGEzLTQxZmEtYjEwYy0zNjI4OTNmMWJjYmIiLCAiYXpwIjogImtyb25vcyIsICJhdXRoX3RpbWUiOiAxNDYxOTE1NDQ0LCAicmVhbG0iOiAiL3RlbmFudDIiLCAiZXhwIjogMTQ2MTkxNjA0NCwgInRva2VuVHlwZSI6ICJKV1RUb2tlbiIsICJpYXQiOiAxNDYxOTE1NDQ0IH0.QYM3sbw851LGu-SAjN963a0gNvockjYXSzHIz5FiBmMZ5aGKll9C6ZhFyKw4Us20WiRI5BDzP-w7M1F_Ty_cHzJi02KQ1bBhE3NGqexuqVFy6oPfczQu5oea-k8HQa3u33w0gKp3V5c4MUVsKpeuyW3F2oAHwg2i4QmRt20WVqDLCVe86YkXbeTy49euZ5N74KW-lnuw5KdbfjtiKDj3aKuRP-X5IrlaU3kq8PyqPblmOx295m63WCmivdBDszMcgYP5Pz0IKznHxoEn8tQEY5DSwBSP9y8qKcxGVlF_fwAHZLQf0TZ_CFpX9b2eQ2vqyZwyxz-v9gwglLHwUiTIOg|QnVuc1lVdFZzKzR1UmtEM1lYNnZMQjlDVnNyUEtVS1J3RXpwdkJCNXAxRUt1M2hSeGwxRlNpWWI5dlNWeTdNYVhkSlF6WW90YkdqWkxPbndrTm5ieXM1UzhsTEFqMDNBMG5aTTNDbFpBUjgydEN0REN0bWhDTGIzRnNQcXg4bXdtQlRIdXppaEVwcE5UNzF1Lzc2eEs0eHcxSDBwUUY0SjVmbUtlYWZKQmNxQ0pzS2wxRklhY21QS0E2ZThNZ3FWRVMydlNGbHFyVWFxY1dydHA1NzczMlpHQk1SZmdyYWcwbm1qVUtSMFp3Z3V1cUlqQi9ZU3NwTE1lb25vbW0vSWg2T1J1dmxLMElFcjhnbmp4SDZtSnhQWGJ6cGxrRzY3eS9FQTJqcXBqK1FZWEdha1cvcEl3WFR5dTJld1BXMnlnbVlISG4ySGZDbHFsVHQ2UFo0dHRRLS0=");
		UserInfo userInfo = authNTokenProviderImpl.getUserInfo(request);
		assertNotNull(userInfo.getFirstName());
		assertEquals("SuperUser", userInfo.getUsername());
		
	}
	
	@Test
	public void testGetUserInfoTrue_HavingDefaultTenantId() throws Exception {
		MockHttpServletRequest request = new MockHttpServletRequest();
		String allDetails = "eyAidHlwIjogIkpXVCIsICJraWQiOiAiMTI3ZjRmMjYtNmM2MS00Y2ZhLWExOGUtNmVmZDg5NjJjYTM2IiwgImN0eSI6ICJKV1QiLCAiYWxnIjogIlJTMjU2IiB9.eyAiYXRfaGFzaCI6ICI4d3BTRHhuMkpBbzhsSnNEcFVPRHp3IiwgInN1YiI6ICJmY2hpbiIsICJpc3MiOiAiaHR0cDovL3JoZWw3LWF1dGg5LmludC5rcm9ub3MuY29tOjgwODAvb3BlbmFtL29hdXRoMiIsICJ0b2tlbk5hbWUiOiAiaWRfdG9rZW4iLCAiYXVkIjogWyAia3Jvbm9zIiBdLCAib3BzIjogImM4ODU3MjM2LWM4YmMtNGM1MC1iODNiLWEwNTBiMmM3YmFhMSIsICJhenAiOiAia3Jvbm9zIiwgImF1dGhfdGltZSI6IDE0NDg2MDQ0MDYsICJyZWFsbSI6ICIvIiwgImV4cCI6IDIwNDg2MDQ0MDYsICJ0b2tlblR5cGUiOiAiSldUVG9rZW4iLCAiaWF0IjogMTQ0ODYwNDQwNiB9.Q6PduQp7kO_Ji1O0mR0uSNoTgzBunfp9qo0uIK-BqgmcBY21gTtMmfsL6LItVrgDkoafs59Ap13aVcaQ66PrdYipvsWg6XhJ1wqVhCL1Zzb-cO8XzpLhrHTofl1TlVY4nsZXkcy2mo4SUxYsH-CWtFcUEeDeV52EGgUM-DXjYFu0j6nH7eGn6sK3Tk2HkzqUjzElhHnoQQ23tHjzm_7BNAGxbHE0wlkAU3NBwgt-bZLQsB5M9n6PYJIT6C4nNd1nCfoGajy23XPADivXVc23gSwxwL7JQqfkbJxLUJEttngBn72Ce4iQHRfxUdWwtTi9rs1zumb6sfyWbgmG5JphIQ|ZllENzc3U3M3YjBBMC82bkdtQ0R2VVlDM2RXWG4xZlRwZ08raFNkMmZYOUI2RFlKRG0zQ1lBWllSKzE3T01LTGZ3QUZyTzBoK3o1RndCWnA2TWhUN1ZldGpVSE9UWHpSaGlIcVdBUXBoNEpXYjBkRXB5Q3NSVmFnV1NvaHlpYzZzNHZQdWxqeFdCUEtTQVlQSkdRcXNBLS0=";
		System.setProperty(KEY_PASS, KEY_PASS_VALUE);
		Cookie authNtokenCookie = createCookie(AUTHN_TOKEN, allDetails);
		request.addCookie(authNtokenCookie);
		request.setupAddParameter("tenantId", "DEFAULT");
		PowerMockito.mockStatic(JWTTokenProcessor.class);
		Mockito.when(JWTTokenProcessor.getJWTPayload(Mockito.anyString(), Mockito.anyString())).thenReturn(JWK_PAYLOAD);
		Mockito.when(JWTTokenProcessor.getJWTPayload(Mockito.anyString(), Mockito.anyString())).thenReturn(JWK_PAYLOAD);
		PowerMockito.mockStatic(AuthUtil.class);
		StringBuilder strMock = new StringBuilder();
		//setting up request Expiration time.
		strMock.append("exp=");
		strMock.append(System.currentTimeMillis()/1000);
		Mockito.when(AuthUtil.getResponseFromUrl(Mockito.any(),Mockito.anyString())).thenReturn(strMock);
		PowerMockito.mockStatic(PropertyFileHelper.class);
		PowerMockito.mockStatic(CookieHelper.class);
		Mockito.when(PropertyFileHelper.getOpenAMServerURL()).thenReturn("http://dummyurl.com");
		Mockito.when(CookieHelper.getCookieValue(Mockito.any(HttpServletRequest.class), Mockito.anyString())).thenReturn("eyAidHlwIjogIkpXVCIsICJraWQiOiAiMTI3ZjRmMjYtNmM2MS00Y2ZhLWExOGUtNmVmZDg5NjJjYTM2IiwgImN0eSI6ICJKV1QiLCAiYWxnIjogIlJTMjU2IiB9.eyAiYXRfaGFzaCI6ICI4d3BTRHhuMkpBbzhsSnNEcFVPRHp3IiwgInN1YiI6ICJmY2hpbiIsICJpc3MiOiAiaHR0cDovL3JoZWw3LWF1dGg5LmludC5rcm9ub3MuY29tOjgwODAvb3BlbmFtL29hdXRoMiIsICJ0b2tlbk5hbWUiOiAiaWRfdG9rZW4iLCAiYXVkIjogWyAia3Jvbm9zIiBdLCAib3BzIjogImM4ODU3MjM2LWM4YmMtNGM1MC1iODNiLWEwNTBiMmM3YmFhMSIsICJhenAiOiAia3Jvbm9zIiwgImF1dGhfdGltZSI6IDE0NDg2MDQ0MDYsICJyZWFsbSI6ICIvIiwgImV4cCI6IDIwNDg2MDQ0MDYsICJ0b2tlblR5cGUiOiAiSldUVG9rZW4iLCAiaWF0IjogMTQ0ODYwNDQwNiB9.Q6PduQp7kO_Ji1O0mR0uSNoTgzBunfp9qo0uIK-BqgmcBY21gTtMmfsL6LItVrgDkoafs59Ap13aVcaQ66PrdYipvsWg6XhJ1wqVhCL1Zzb-cO8XzpLhrHTofl1TlVY4nsZXkcy2mo4SUxYsH-CWtFcUEeDeV52EGgUM-DXjYFu0j6nH7eGn6sK3Tk2HkzqUjzElhHnoQQ23tHjzm_7BNAGxbHE0wlkAU3NBwgt-bZLQsB5M9n6PYJIT6C4nNd1nCfoGajy23XPADivXVc23gSwxwL7JQqfkbJxLUJEttngBn72Ce4iQHRfxUdWwtTi9rs1zumb6sfyWbgmG5JphIQ|ZllENzc3U3M3YjBBMC82bkdtQ0R2VVlDM2RXWG4xZlRwZ08raFNkMmZYOUI2RFlKRG0zQ1lBWllSKzE3T01LTGZ3QUZyTzBoK3o1RndCWnA2TWhUN1ZldGpVSE9UWHpSaGlIcVdBUXBoNEpXYjBkRXB5Q3NSVmFnV1NvaHlpYzZzNHZQdWxqeFdCUEtTQVlQSkdRcXNBLS0=");
		UserInfo userInfo = authNTokenProviderImpl.getUserInfo(request);
		assertNotNull(userInfo.getFirstName());
		assertEquals("amadmin", userInfo.getUsername());
		
	}

	@Test(expected=AuthNTokenPublicException.class)
	public void testGetUserInfoTrue_HavingInCorrectTenantId() throws Exception {
		MockHttpServletRequest request = new MockHttpServletRequest();
		String allDetails = "eyAidHlwIjogIkpXVCIsICJraWQiOiAiMjUzODJlZWUtYzA0MC00NWJiLWE1YTYtNDQ5ZDk3Nzg2ZjE4IiwgImN0eSI6ICJKV1QiLCAiYWxnIjogIlJTMjU2IiB9.eyAiYXRfaGFzaCI6ICJXUjFQRHVnRnRQUFAxTVk4Ti1EZWx3IiwgInN1YiI6ICJTdXBlclVzZXIiLCAiaXNzIjogImh0dHA6Ly9hdXRobnNlcnZlci5mYWxjb24ua3Jvbm9zLmNvbTo4MC9vcGVuYW0vb2F1dGgyL3RlbmFudDIiLCAidG9rZW5OYW1lIjogImlkX3Rva2VuIiwgIm5vbmNlIjogIjxEbi0wUzZfV3pBMk1qIiwgImF1ZCI6IFsgImtyb25vcyIgXSwgIm9wcyI6ICI0YjVlMTVhMS02MGEzLTQxZmEtYjEwYy0zNjI4OTNmMWJjYmIiLCAiYXpwIjogImtyb25vcyIsICJhdXRoX3RpbWUiOiAxNDYxOTE1NDQ0LCAicmVhbG0iOiAiL3RlbmFudDIiLCAiZXhwIjogMTQ2MTkxNjA0NCwgInRva2VuVHlwZSI6ICJKV1RUb2tlbiIsICJpYXQiOiAxNDYxOTE1NDQ0IH0.QYM3sbw851LGu-SAjN963a0gNvockjYXSzHIz5FiBmMZ5aGKll9C6ZhFyKw4Us20WiRI5BDzP-w7M1F_Ty_cHzJi02KQ1bBhE3NGqexuqVFy6oPfczQu5oea-k8HQa3u33w0gKp3V5c4MUVsKpeuyW3F2oAHwg2i4QmRt20WVqDLCVe86YkXbeTy49euZ5N74KW-lnuw5KdbfjtiKDj3aKuRP-X5IrlaU3kq8PyqPblmOx295m63WCmivdBDszMcgYP5Pz0IKznHxoEn8tQEY5DSwBSP9y8qKcxGVlF_fwAHZLQf0TZ_CFpX9b2eQ2vqyZwyxz-v9gwglLHwUiTIOg|QnVuc1lVdFZzKzR1UmtEM1lYNnZMQjlDVnNyUEtVS1J3RXpwdkJCNXAxRUt1M2hSeGwxRlNpWWI5dlNWeTdNYVhkSlF6WW90YkdqWkxPbndrTm5ieXM1UzhsTEFqMDNBMG5aTTNDbFpBUjgydEN0REN0bWhDTGIzRnNQcXg4bXdtQlRIdXppaEVwcE5UNzF1Lzc2eEs0eHcxSDBwUUY0SjVmbUtlYWZKQmNxQ0pzS2wxRklhY21QS0E2ZThNZ3FWRVMydlNGbHFyVWFxY1dydHA1NzczMlpHQk1SZmdyYWcwbm1qVUtSMFp3Z3V1cUlqQi9ZU3NwTE1lb25vbW0vSWg2T1J1dmxLMElFcjhnbmp4SDZtSnhQWGJ6cGxrRzY3eS9FQTJqcXBqK1FZWEdha1cvcEl3WFR5dTJld1BXMnlnbVlISG4ySGZDbHFsVHQ2UFo0dHRRLS0=";
		Cookie authNtokenCookie = createCookie(AUTHN_TOKEN, allDetails);
		request.addCookie(authNtokenCookie);
		request.setupAddParameter("tenantId", "tenantX");
		PowerMockito.mockStatic(JWTTokenProcessor.class);
		Mockito.when(JWTTokenProcessor.getJWTPayload(Mockito.anyString(), Mockito.anyString())).thenReturn(JWK_PAYLOAD_TENANT);
		Mockito.when(JWTTokenProcessor.getJWTPayload(Mockito.anyString(), Mockito.anyString())).thenReturn(JWK_PAYLOAD_TENANT);
		PowerMockito.mockStatic(AuthUtil.class);
		PowerMockito.mockStatic(PropertyFileHelper.class);
		PowerMockito.when(PropertyFileHelper.getOpenAMCookieName()).thenReturn(AUTHN_TOKEN);
		StringBuilder strMock = new StringBuilder();
		//setting up request Expiration time.
		strMock.append("exp=");
		strMock.append(System.currentTimeMillis()/1000);
		Mockito.when(AuthUtil.getResponseFromUrl(Mockito.any(),Mockito.anyString())).thenReturn(strMock);
		PowerMockito.mockStatic(FileStreamCreator.class);
		Properties returnedProps = new Properties();
		returnedProps.setProperty("skiptenantnamecheck", "false");
		PowerMockito.when(FileStreamCreator.getPropsInstance()).thenReturn(returnedProps);
		UserInfo userInfo = authNTokenProviderImpl.getUserInfo(request);
	}
	
	@Test
	public void testGetUserInfoTrue_NotHavingUserDetailsCookie() throws Exception {
		MockHttpServletRequest request = new MockHttpServletRequest();
		Cookie authNtokenCookie = createCookie(AUTHN_TOKEN, AUTHN_TOKEN_COOKIE_VALUE_CORRECT_WITHOUTUSERINFO);
		request.addCookie(authNtokenCookie);
		//AuthNTokenProvider authNTokenProvider = new AuthNTokenProviderImpl();
		PowerMockito.mockStatic(JWTTokenProcessor.class);
		Mockito.when(JWTTokenProcessor.getJWTPayload(Mockito.anyString(), Mockito.anyString())).thenReturn(JWK_PAYLOAD);
		Mockito.when(JWTTokenProcessor.getJWTPayload(Mockito.anyString(), Mockito.anyString())).thenReturn(JWK_PAYLOAD);
		PowerMockito.mockStatic(AuthUtil.class);
		PowerMockito.mockStatic(PropertyFileHelper.class);
		StringBuilder strMock = new StringBuilder();
		//setting up request Expiration time.
		strMock.append("exp=");
		strMock.append(System.currentTimeMillis()/1000);
		Mockito.when(AuthUtil.getResponseFromUrl(Mockito.any(),Mockito.anyString())).thenReturn(strMock);
		PowerMockito.when(PropertyFileHelper.getOpenAMServerURL()).thenReturn("http://somedummyURL.com");
		PowerMockito.when(PropertyFileHelper.getOpenAMCookieName()).thenReturn(AUTHN_TOKEN);
		UserInfo userInfo = authNTokenProviderImpl.getUserInfo(request);
		assertEquals("amadmin", userInfo.getUsername());
		assertNull(userInfo.getLastName());
		assertNull(userInfo.getFirstName());
		
	}
	
	
	@Test
	public void testGetUserInfoNull() throws Exception {
		MockHttpServletRequest request = new MockHttpServletRequest();
		Cookie authNtokenCookie = createCookie(AUTHN_TOKEN, AUTHN_TOKEN_COOKIE_VALUE_INCORRECT);
		request.addCookie(authNtokenCookie);
		AuthNTokenProvider authNTokenProvider = new AuthNTokenProviderImpl();
		PowerMockito.mockStatic(JWTTokenProcessor.class);
		Mockito.when(JWTTokenProcessor.getJWTPayload(Mockito.anyString(), Mockito.anyString())).thenReturn(null);

		//PowerMockito.mockStatic(EncryptionUtils.class);
		//Mockito.when(EncryptionUtils.decrypt(Mockito.anyString())).thenReturn(COOKIE_VALUE_INCORRECT);
		PowerMockito.mockStatic(PropertyFileHelper.class);
		PowerMockito.mockStatic(CookieHelper.class);
		Mockito.when(PropertyFileHelper.getOpenAMServerURL()).thenReturn("http://dummyurl.com");
		Mockito.when(CookieHelper.getCookieValue(request, AUTHN_TOKEN)).thenReturn("");
		assertNull(authNTokenProvider.getUserInfo(request));
	}
	
	@Test
	public void testGetUserInfoTrueCookieParam_HavingUserDetailsCookie() throws Exception {
		MockHttpServletRequest request = new MockHttpServletRequest();
		Cookie authNtokenCookie = createCookie(AUTHN_TOKEN, AUTHN_TOKEN_COOKIE_VALUE_CORRECT);
		System.setProperty(KEY_PASS, KEY_PASS_VALUE);
		request.addCookie(authNtokenCookie);
		//AuthNTokenProvider authNTokenProvider = new AuthNTokenProviderImpl();
		PowerMockito.mockStatic(JWTTokenProcessor.class);
		Mockito.when(JWTTokenProcessor.getJWTPayload(Mockito.anyString(), Mockito.anyString())).thenReturn(JWK_PAYLOAD);
		Mockito.when(JWTTokenProcessor.getJWTPayload(Mockito.anyString(), Mockito.anyString())).thenReturn(JWK_PAYLOAD);
		PowerMockito.mockStatic(AuthUtil.class);
		PowerMockito.mockStatic(PropertyFileHelper.class);
		PowerMockito.when(PropertyFileHelper.getOpenAMCookieName()).thenReturn(AUTHN_TOKEN);
		StringBuilder strMock = new StringBuilder();
		//setting up request Expiration time.
		strMock.append("exp=");
		strMock.append(System.currentTimeMillis()/1000);
		Mockito.when(PropertyFileHelper.getOpenAMServerURL()).thenReturn(null);
		Mockito.when(AuthUtil.getResponseFromUrl(Mockito.any(),Mockito.anyString())).thenReturn(strMock);
		UserInfo userInfo = authNTokenProviderImpl.getUserInfo(request.getCookies());
		assertEquals("amadmin", userInfo.getUsername());
		assertNotNull(userInfo);
	}

	@Test
	public void testGetUserInfoTrueCookieParam_NotHavingUserDetailsCookie() throws Exception {
		MockHttpServletRequest request = new MockHttpServletRequest();
		Cookie authNtokenCookie = createCookie(AUTHN_TOKEN, AUTHN_TOKEN_COOKIE_VALUE_CORRECT_WITHOUTUSERINFO);
		request.addCookie(authNtokenCookie);
		PowerMockito.mockStatic(JWTTokenProcessor.class);
		Mockito.when(JWTTokenProcessor.getJWTPayload(Mockito.anyString(), Mockito.anyString())).thenReturn(JWK_PAYLOAD);
		Mockito.when(JWTTokenProcessor.getJWTPayload(Mockito.anyString(), Mockito.anyString())).thenReturn(JWK_PAYLOAD);
		PowerMockito.mockStatic(AuthUtil.class);
		StringBuilder strMock = new StringBuilder();
		//setting up request Expiration time.
		strMock.append("exp=");
		strMock.append(System.currentTimeMillis()/1000);
		Mockito.when(AuthUtil.getResponseFromUrl(Mockito.any(),Mockito.anyString())).thenReturn(strMock);
		
		UserInfo userInfo = authNTokenProviderImpl.getUserInfo(request.getCookies());
		assertEquals("amadmin", userInfo.getUsername());
		assertNull(userInfo.getLastName());
		assertNull(userInfo.getFirstName());
		
	}
	
	@Test(expected=AuthNPublicException.class)
	//@PrepareForTest({HttpURLConnection.class,AuthUtil.class})
	public void testGetAuthNCookies_User_Blank() throws Exception
	{
		String expextedIPlanetValue = "AQIC5wM2LY4Sfcwh54pDXfoRTYwM7Diatg2JsksxGcNLyAo.*AAJTSQACMDMAAlNLABQtMzI1MjM2MTg3NTMwNTcyNTk0MAACUzEAAjAx*";
		String expectedReturn = "{\"tokenId\": "+expextedIPlanetValue+",\"successUrl\": \"/openam/console\"}";
		Map<String, List<String>> map = new HashMap<String, List<String>>();
		//setting up data for verification
		List<String> valSet = Arrays.asList("JWK_URI=http://someDummyURL.com:8080/openam/oauth2/connect/jwk_uri", "AUTHN_TOKEN=a.b.c-d-e-f|g");
        map.put("Set-Cookie", valSet);
        InputStream is = new ByteArrayInputStream(expectedReturn.getBytes());
        HttpURLConnection con = PowerMockito.mock(HttpURLConnection.class);
        PowerMockito.mockStatic(AuthUtil.class);
        PowerMockito.mockStatic(PropertyFileHelper.class);
		PowerMockito.when(PropertyFileHelper.getOpenAMCookieName()).thenReturn(AUTHN_TOKEN);
        PowerMockito.when(PropertyFileHelper.getOpenAMServerURL()).thenReturn("http://somedummyURL.com");
        PowerMockito.when(AuthUtil.getHttpConnection(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(con);
        PowerMockito.when(con.getHeaderFields()).thenReturn(map);
        PowerMockito.when(con.getInputStream()).thenReturn(is);
        Cookie [] cookies = authNTokenProviderImpl.getAuthNCookies("", "password");		
	}
	
	@Test(expected=AuthNPublicException.class)
	//@PrepareForTest({HttpURLConnection.class,AuthUtil.class})
	public void testGetAuthNCookies_Pass_Blank() throws Exception
	{
		String expextedIPlanetValue = "AQIC5wM2LY4Sfcwh54pDXfoRTYwM7Diatg2JsksxGcNLyAo.*AAJTSQACMDMAAlNLABQtMzI1MjM2MTg3NTMwNTcyNTk0MAACUzEAAjAx*";
		String expectedReturn = "{\"tokenId\": "+expextedIPlanetValue+",\"successUrl\": \"/openam/console\"}";
		Map<String, List<String>> map = new HashMap<String, List<String>>();
		//setting up data for verification
		List<String> valSet = Arrays.asList("JWK_URI=http://someDummyURL.com:8080/openam/oauth2/connect/jwk_uri", "AUTHN_TOKEN=a.b.c-d-e-f|g");
        map.put("Set-Cookie", valSet);
        InputStream is = new ByteArrayInputStream(expectedReturn.getBytes());
        HttpURLConnection con = PowerMockito.mock(HttpURLConnection.class);
        PowerMockito.mockStatic(AuthUtil.class);
        PowerMockito.mockStatic(PropertyFileHelper.class);
		PowerMockito.when(PropertyFileHelper.getOpenAMCookieName()).thenReturn(AUTHN_TOKEN);
        PowerMockito.when(PropertyFileHelper.getOpenAMServerURL()).thenReturn("http://somedummyURL.com");
        PowerMockito.when(AuthUtil.getHttpConnection(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(con);
        PowerMockito.when(con.getHeaderFields()).thenReturn(map);
        PowerMockito.when(con.getInputStream()).thenReturn(is);
        Cookie [] cookies = authNTokenProviderImpl.getAuthNCookies("username", "");		
	}



    @Test(expected=AuthNPublicException.class)
	public void testGetSystemUserAuthNCookies_User_Blank() throws Exception
	{
		Cookie [] cookies = authNTokenProviderImpl.getSystemUserAuthNCookies("", "password","tenantId", "onBehalfUser");
	}


    @Test(expected=AuthNPublicException.class)
	public void testGetSystemUserAuthNCookies_User_Null() throws Exception
	{
    	Cookie [] cookies = authNTokenProviderImpl.getSystemUserAuthNCookies(null, "password","tenantId", "onBehalfUser");
	}
	
    
    @Test(expected=AuthNPublicException.class)
	public void testGetSystemUserAuthNCookies_Pass_Null() throws Exception
	{
    	Cookie [] cookies = authNTokenProviderImpl.getSystemUserAuthNCookies("username", null,"tenantId", "onBehalfUser");
	}
	@Test(expected=AuthNPublicException.class)
	public void testGetSystemUserAuthNCookies_Pass_Blank() throws Exception
	{
		Cookie [] cookies = authNTokenProviderImpl.getSystemUserAuthNCookies("username", "","tenantId", "onBehalfUser");
	}
	
	
	@Test
	public void testGetUserInfoCookiesNull() throws Exception {
		MockHttpServletRequest request = new MockHttpServletRequest();
		Cookie authNtokenCookie = createCookie(AUTHN_TOKEN, AUTHN_TOKEN_COOKIE_VALUE_INCORRECT);
		request.addCookie(authNtokenCookie);
		AuthNTokenProvider authNTokenProvider = new AuthNTokenProviderImpl();
		PowerMockito.mockStatic(JWTTokenProcessor.class);
		Mockito.when(JWTTokenProcessor.getJWTPayload(Mockito.anyString(), Mockito.anyString())).thenReturn(null);
		assertNull(authNTokenProvider.getUserInfo(request.getCookies()));
	}
	
	
	private Cookie createCookie(String cookieName, String cookieValue) {
		Cookie cookie = new Cookie(cookieName, cookieValue);
		cookie.setMaxAge(100);
		cookie.setPath("/");
		cookie.setHttpOnly(TRUE);
		return cookie;
	}
	
	@Test
	//@PrepareForTest({HttpURLConnection.class,AuthUtil.class})
	public void testGetAuthNCookies() throws Exception
	{
		String expextedIPlanetValue = "AQIC5wM2LY4Sfcwh54pDXfoRTYwM7Diatg2JsksxGcNLyAo.*AAJTSQACMDMAAlNLABQtMzI1MjM2MTg3NTMwNTcyNTk0MAACUzEAAjAx*";
		String expectedReturn = "{\"tokenId\": "+expextedIPlanetValue+",\"successUrl\": \"/openam/console\"}";
		Map<String, List<String>> map = new HashMap<String, List<String>>();
		//setting up data for verification
		List<String> valSet = Arrays.asList("JWK_URI=http://someDummyURL.com:8080/openam/oauth2/connect/jwk_uri", "AUTHN_TOKEN=a.b.c-d-e-f|g");
        map.put("Set-Cookie", valSet);
        InputStream is = new ByteArrayInputStream(expectedReturn.getBytes());
        HttpURLConnection con = PowerMockito.mock(HttpURLConnection.class);
        PowerMockito.mockStatic(AuthUtil.class);
        PowerMockito.mockStatic(PropertyFileHelper.class);
		PowerMockito.when(PropertyFileHelper.getOpenAMCookieName()).thenReturn(AUTHN_TOKEN);
        PowerMockito.when(PropertyFileHelper.getOpenAMServerURL()).thenReturn("http://somedummyURL.com");
        PowerMockito.when(AuthUtil.getHttpConnection(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(con);
        PowerMockito.when(con.getHeaderFields()).thenReturn(map);
        PowerMockito.when(con.getInputStream()).thenReturn(is);
        Cookie [] cookies = authNTokenProviderImpl.getAuthNCookies("username", "password");
        //verifying set up data.
        assertNotNull(cookies);
        assertNotNull(cookies[0]);
        assertNotNull(cookies[1]);
        assertEquals("JWK_URI", cookies[0].getName());
        assertEquals("http://someDummyURL.com:8080/openam/oauth2/connect/jwk_uri", cookies[0].getValue());
        assertEquals("AUTHN_TOKEN", cookies[1].getName());
        assertEquals("a.b.c-d-e-f|g", cookies[1].getValue());
        assertEquals("iPlanetDirectoryPro", cookies[2].getName());
        assertEquals(expextedIPlanetValue, cookies[2].getValue());
		
	}

	@Test(expected=AuthNPublicException.class)
	@PrepareForTest({HttpURLConnection.class,AuthUtil.class,PropertyFileHelper.class})
	public void testGetAuthNCookiesWithException() throws Exception
	{
		Map<String, List<String>> map = new HashMap<String, List<String>>();
		List<String> valSet = Arrays.asList("JWK_URI=\"http://someDummyURL.com:8080/openam/oauth2/connect/jwk_uri\"", "AUTHN_TOKEN=a.b.c-d-e-f|g");
        map.put("Set-Cookie", valSet);
        PowerMockito.mockStatic(AuthUtil.class);
        PowerMockito.mockStatic(PropertyFileHelper.class);
        PowerMockito.when(PropertyFileHelper.getOpenAMServerURL()).thenReturn("http://somedummyURL.com");
        //throw exception
        PowerMockito.when(AuthUtil.getHttpConnection(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenThrow(new IOException());
        Cookie[] ck = authNTokenProviderImpl.getAuthNCookies("username", "password");
        // null will be returned due to explicitly throwing exception above.
        assertNull(ck);
        
	}
	
	@Test
	public void testGetAuthNCookiesWithTenantID() throws Exception
	{
		String expextedIPlanetValue = "AQIC5wM2LY4Sfcwh54pDXfoRTYwM7Diatg2JsksxGcNLyAo.*AAJTSQACMDMAAlNLABQtMzI1MjM2MTg3NTMwNTcyNTk0MAACUzEAAjAx*";
		String expectedReturn = "{\"tokenId\": "+expextedIPlanetValue+",\"successUrl\": \"/openam/console\"}";
		Map<String, List<String>> map = new HashMap<String, List<String>>();
		//setting up data for verification
		List<String> valSet = Arrays.asList("JWK_URI=http://someDummyURL.com:8080/openam/oauth2/connect/jwk_uri; Version=1.0, Domain=.com, Path=/", "AUTHN_TOKEN=a.b.c-d-e-f|g");
        map.put("Set-Cookie", valSet);
        InputStream is = new ByteArrayInputStream(expectedReturn.getBytes());
        HttpURLConnection con = PowerMockito.mock(HttpURLConnection.class);
        PowerMockito.mockStatic(AuthUtil.class);
        PowerMockito.mockStatic(PropertyFileHelper.class);
		PowerMockito.when(PropertyFileHelper.getOpenAMCookieName()).thenReturn(AUTHN_TOKEN);
        PowerMockito.when(PropertyFileHelper.getOpenAMServerURL()).thenReturn("http://somedummyURL.com");
        PowerMockito.when(AuthUtil.getHttpConnection(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(con);
        PowerMockito.when(con.getHeaderFields()).thenReturn(map);
        PowerMockito.when(con.getInputStream()).thenReturn(is);
        Cookie [] cookies = authNTokenProviderImpl.getAuthNCookies("username", "password","tenantId");
        //verifying set up data.
        assertNotNull(cookies);
        assertNotNull(cookies[0]); 
        assertNotNull(cookies[1]);
        assertEquals("JWK_URI", cookies[0].getName());
        assertEquals("http://someDummyURL.com:8080/openam/oauth2/connect/jwk_uri", cookies[0].getValue());
        assertEquals("AUTHN_TOKEN", cookies[1].getName());
        assertEquals("a.b.c-d-e-f|g", cookies[1].getValue());
        assertEquals("iPlanetDirectoryPro", cookies[2].getName());
        assertEquals(expextedIPlanetValue, cookies[2].getValue());
		
	}
	@Test
	public void testGetAuthNCookies_TenantID_null() throws Exception
	{
		String expextedIPlanetValue = "AQIC5wM2LY4Sfcwh54pDXfoRTYwM7Diatg2JsksxGcNLyAo.*AAJTSQACMDMAAlNLABQtMzI1MjM2MTg3NTMwNTcyNTk0MAACUzEAAjAx*";
		String expectedReturn = "{\"tokenId\": "+expextedIPlanetValue+",\"successUrl\": \"/openam/console\"}";
		Map<String, List<String>> map = new HashMap<String, List<String>>();
		List<String> valSet = Arrays.asList("JWK_URI=http://someDummyURL.com:8080/openam/oauth2/connect/jwk_uri", "AUTHN_TOKEN=a.b.c-d-e-f|g");
        map.put("Set-Cookie", valSet);
        InputStream is = new ByteArrayInputStream(expectedReturn.getBytes());
        HttpURLConnection con = PowerMockito.mock(HttpURLConnection.class);
        PowerMockito.mockStatic(AuthUtil.class);
        PowerMockito.mockStatic(PropertyFileHelper.class);
        PowerMockito.when(PropertyFileHelper.getOpenAMCookieName()).thenReturn("sdcf");
        PowerMockito.when(PropertyFileHelper.getOpenAMServerURL()).thenReturn("http://somedummyURL.com");
        PowerMockito.when(AuthUtil.getHttpConnection(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(con);
        PowerMockito.when(con.getHeaderFields()).thenReturn(map);
        PowerMockito.when(con.getInputStream()).thenReturn(is);
        Cookie [] cookies = authNTokenProviderImpl.getAuthNCookies("username", "password",null);
        //verifying that cookies are not null
        assertNotNull(cookies);		
	}
	@Test
	public void testGetAuthNCookies_TenantID_default() throws Exception
	{
		String expextedIPlanetValue = "AQIC5wM2LY4Sfcwh54pDXfoRTYwM7Diatg2JsksxGcNLyAo.*AAJTSQACMDMAAlNLABQtMzI1MjM2MTg3NTMwNTcyNTk0MAACUzEAAjAx*";
		String expectedReturn = "{\"tokenId\": "+expextedIPlanetValue+",\"successUrl\": \"/openam/console\"}";
		Map<String, List<String>> map = new HashMap<String, List<String>>();
		List<String> valSet = Arrays.asList("JWK_URI=http://someDummyURL.com:8080/openam/oauth2/connect/jwk_uri", "AUTHN_TOKEN=a.b.c-d-e-f|g");
        map.put("Set-Cookie", valSet);
        InputStream is = new ByteArrayInputStream(expectedReturn.getBytes());
        HttpURLConnection con = PowerMockito.mock(HttpURLConnection.class);
        PowerMockito.mockStatic(AuthUtil.class);
        PowerMockito.mockStatic(PropertyFileHelper.class);
        PowerMockito.when(PropertyFileHelper.getOpenAMCookieName()).thenReturn(AuthConstants.FALLBACK_AUTHN_TOKEN);
        PowerMockito.when(PropertyFileHelper.getOpenAMServerURL()).thenReturn("http://somedummyURL.com");
        PowerMockito.when(AuthUtil.getHttpConnection(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(con);
        PowerMockito.when(con.getHeaderFields()).thenReturn(map);
        PowerMockito.when(con.getInputStream()).thenReturn(is);
        Cookie [] cookies = authNTokenProviderImpl.getAuthNCookies("username", "password","Default");
        //verifying cookies are not null
        assertNotNull(cookies);		
	}

	@Test(expected=AuthNPublicException.class)
	@PrepareForTest({HttpURLConnection.class,AuthUtil.class,PropertyFileHelper.class})
	public void testGetAuthNCookiesWithTenantIdWithException() throws Exception
	{
		Map<String, List<String>> map = new HashMap<String, List<String>>();
		List<String> valSet = Arrays.asList("JWK_URI=\"http://someDummyURL.com:8080/openam/oauth2/connect/jwk_uri\"", "AUTHN_TOKEN=a.b.c-d-e-f|g");
        map.put("Set-Cookie", valSet);
        PowerMockito.mockStatic(AuthUtil.class);
        PowerMockito.mockStatic(PropertyFileHelper.class);
        PowerMockito.when(PropertyFileHelper.getOpenAMServerURL()).thenReturn("http://somedummyURL.com");
        //throw exception
        PowerMockito.when(AuthUtil.getHttpConnection(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenThrow(new IOException());
        Cookie[] ck = authNTokenProviderImpl.getAuthNCookies("username", "password","tenantId");
        // null will be returned as no connection is created so no cookies are set
        assertNull(ck);
        
	}

	@Test
	public void testGetSessionTimeOut() throws Exception
	{
		//setting up test data
		String expectedReturn = response;
		InputStream is = new ByteArrayInputStream(expectedReturn.getBytes());
		Mockito.when(request.getCookies()).thenReturn(cookies2);
		MockHttpServletRequest mockRequest = (MockHttpServletRequest)request;
		mockRequest.addCookie(cookie2);
		URL urlMock = PowerMockito.mock(URL.class);
		PowerMockito.whenNew(URL.class).withArguments(Mockito.anyString()).thenReturn(urlMock);
        HttpURLConnection con = PowerMockito.mock(HttpURLConnection.class);
        PowerMockito.when(urlMock.openConnection()).thenReturn(con);
		PowerMockito.when(con.getInputStream()).thenReturn(is);
		
		PowerMockito.when(con.getResponseCode()).thenReturn(200);
		OpenAmConfigAttrDTO sessionTimeResponse = authNTokenProviderImpl.getSessionTimeOut(request);
		//Extracting the timeout time from setup data;
		int startIndex = expectedReturn.lastIndexOf("=");
		String sessionTimeOutVal = expectedReturn.substring(startIndex + 1, expectedReturn.length());
		assertNotNull(sessionTimeResponse);
		assertEquals(sessionTimeOutVal,sessionTimeResponse.getSessionTimeout());
		
	}
	
	@Test(expected=AuthNPublicException.class)
	public void testGetSessionTimeoutThrowsException() throws Exception {
		InputStream is = new ByteArrayInputStream(response.getBytes());
		Mockito.when(request.getCookies()).thenReturn(cookies2);
		URL urlMock = PowerMockito.mock(URL.class);
		PowerMockito.whenNew(URL.class).withArguments(Mockito.anyString()).thenReturn(urlMock);
        HttpURLConnection con = PowerMockito.mock(HttpURLConnection.class);
        //throw exception
        PowerMockito.when(urlMock.openConnection()).thenThrow(IOException.class);
		PowerMockito.when(con.getInputStream()).thenReturn(is);
		authNTokenProviderImpl.getSessionTimeOut(request);
	}
	
	@Test(expected=AuthNPublicException.class)
	public void testGetSessionTimeoutWithNoCookies() throws Exception {
		InputStream is = new ByteArrayInputStream(response.getBytes());
		Mockito.when(request.getCookies()).thenReturn(null);
		URL urlMock = PowerMockito.mock(URL.class);
		PowerMockito.whenNew(URL.class).withArguments(Mockito.anyString()).thenReturn(urlMock);
        HttpURLConnection con = PowerMockito.mock(HttpURLConnection.class);
        PowerMockito.when(urlMock.openConnection()).thenReturn(con);
		PowerMockito.when(con.getInputStream()).thenReturn(is);
		OpenAmConfigAttrDTO sessionTimeResponse = authNTokenProviderImpl.getSessionTimeOut(request);
	}
	@Test//(expected=AuthNTokenPublicException.class)
	public void testGetUserInfoExpection() throws Exception {
		MockHttpServletRequest request = new MockHttpServletRequest();
		Cookie authNtokenCookie = createCookie(AUTHN_TOKEN, AUTHN_TOKEN_COOKIE_VALUE_INCORRECT);
		request.addCookie(authNtokenCookie);
        AuthNTokenProviderImpl authNTokenProvider = PowerMockito.spy(new AuthNTokenProviderImpl());
		PowerMockito.mockStatic(JWTTokenProcessor.class);
		PowerMockito.mockStatic(PropertyFileHelper.class);
		PowerMockito.mockStatic(CookieHelper.class);
		Mockito.when(PropertyFileHelper.getOpenAMServerURL()).thenReturn("http://dummyurl.com");
		Mockito.when(CookieHelper.getCookieValue(request, AUTHN_TOKEN)).thenReturn("");
        assertNull(authNTokenProviderImpl.getUserInfo(request));
		// Noting to assert as the test will generate exception which will be expected by @Test annotation
	}
	@Test(expected=AuthNPublicException.class)
	public void testGetUserInfoTrue_HavingUserDetailsCookieException() throws Exception {
		MockHttpServletRequest request = new MockHttpServletRequest();
		Cookie authNtokenCookie = createCookie(AUTHN_TOKEN, AUTHN_TOKEN_INCORRECT);
		request.addCookie(authNtokenCookie);
        AuthNTokenProviderImpl authNTokenProviderImpl = PowerMockito.spy(new AuthNTokenProviderImpl());
		PowerMockito.mockStatic(JWTTokenProcessor.class);
		Mockito.when(JWTTokenProcessor.getJWTPayload(Mockito.anyString(), Mockito.anyString())).thenReturn(JWK_PAYLOAD);
		Mockito.when(JWTTokenProcessor.getJWTPayload(Mockito.anyString(), Mockito.anyString())).thenReturn(JWK_PAYLOAD);
		//PowerMockito.whenNew(JSONObject.class).withParameterTypes(String.class).withArguments(Mockito.anyString()).thenThrow(new JSONException(""));
        authNTokenProviderImpl.getUserInfo(request);
		// Noting to assert as the test will generate exception which will be expected by @Test annotation
	}
	
	@Test()
	public void testGetSessionTimeOut_happy() throws Exception
	{
		Mockito.when(request.getCookies()).thenReturn(cookies2);
		MockHttpServletRequest mockRequest = (MockHttpServletRequest)request;
		mockRequest.addCookie(cookie2);
		// Setting up test data
		StringBuilder testData = new StringBuilder();
		String expectedReturn = "10000";
		testData.append("exp=");
		testData.append(expectedReturn);
		PowerMockito.mockStatic(AuthUtil.class);
		PowerMockito.when(AuthUtil.getResponseFromUrl(Mockito.any(), Mockito.anyString())).thenReturn(testData);
		OpenAmConfigAttrDTO sessionTimeResponse = authNTokenProviderImpl.getSessionTimeOut(request);
		//Extracting the timeout time from setup data;
		int startIndex = expectedReturn.lastIndexOf("=");
		String sessionTimeOutVal = expectedReturn.substring(startIndex + 1, expectedReturn.length());
		assertNotNull(sessionTimeResponse);
		assertEquals(sessionTimeOutVal,sessionTimeResponse.getSessionTimeout());
	}
	@Test
	public void TestgetOpenAMServerURL(){
		//data setup
		String expectedReturnUrl = DUMMY_URL;
		//mocking
		PowerMockito.mockStatic(PropertyFileHelper.class);
		PowerMockito.when(PropertyFileHelper.getOpenAMServerURL()).thenReturn(DUMMY_URL);
		String returnedURL = authNTokenProviderImpl.getOpenAMServerURL(cookies3);
		//verification
		assertNotNull(returnedURL);
		assertEquals(returnedURL, expectedReturnUrl);
	}
	
	@Test
	public void TestgetOpenAMServerURL_notNull(){
		//data setup
		String expectedReturnUrl = DUMMY_URL;
		//mocking
		PowerMockito.mockStatic(PropertyFileHelper.class);
		PowerMockito.when(PropertyFileHelper.getOpenAMServerURL()).thenReturn(expectedReturnUrl);
		String returnedURL = authNTokenProviderImpl.getOpenAMServerURL(cookies2);
		//verification
		assertNotNull(returnedURL);
		assertEquals(returnedURL, expectedReturnUrl);
	}
	@Test
	public void TestgetOpenAMServerURL_Null(){
		//mocking
		PowerMockito.mockStatic(PropertyFileHelper.class);
		PowerMockito.when(PropertyFileHelper.getOpenAMServerURL()).thenReturn(null);
		String returnedURL = authNTokenProviderImpl.getOpenAMServerURL(null);
		//verification
		assertNull(returnedURL);
	}
	@Test(expected = AuthNPublicException.class)
	public void testGetUserInfoTrueCookieParam_WrongExpTime() throws Exception {
		MockHttpServletRequest request = new MockHttpServletRequest();
		Cookie authNtokenCookie = createCookie(AUTHN_TOKEN, AUTHN_TOKEN_COOKIE_VALUE_CORRECT);
		request.addCookie(authNtokenCookie);
		//AuthNTokenProvider authNTokenProvider = new AuthNTokenProviderImpl();
		PowerMockito.mockStatic(JWTTokenProcessor.class);
		Mockito.when(JWTTokenProcessor.getJWTPayload(Mockito.anyString(), Mockito.anyString())).thenReturn(JWK_PAYLOAD);
		Mockito.when(JWTTokenProcessor.getJWTPayload(Mockito.anyString(), Mockito.anyString())).thenReturn(JWK_PAYLOAD);
		PowerMockito.mockStatic(AuthUtil.class);
		StringBuilder strMock = new StringBuilder();
		//setting up request Expiration time.
		strMock.append("exp=");
		strMock.append("wrongData");
		authNTokenProviderImpl.getUserInfo(request.getCookies());
		// assertion is handled by @Test expected = AuthNPublicException.class of this method.
	}
	@Test
	public void TestgetOpenAMServerURL_withEncodedString(){
		//data setup
		String expectedReturnUrl = DUMMY_URL;
		//mocking
		PowerMockito.mockStatic(PropertyFileHelper.class);
		PowerMockito.when(PropertyFileHelper.getOpenAMServerURL()).thenReturn(DUMMY_URL);
		String returnedURL = authNTokenProviderImpl.getOpenAMServerURL(cookies2);
		//verification
		assertNotNull(returnedURL);
		assertEquals(expectedReturnUrl,returnedURL);
	}
	
	@Test
	public void testGetOpenAMAuthenticationURL() throws Exception {
		String expectedReturnUrl = DUMMY_URL  + "/json/tenant1/authenticate";
		PowerMockito.mockStatic(PropertyFileHelper.class);
		PowerMockito.when(PropertyFileHelper.getOpenAMServerURL()).thenReturn(DUMMY_URL);
		String returnedURL = authNTokenProviderImpl.getOpenAMAuthenticationURL("tenant1");
		assertNotNull(returnedURL);
		assertEquals(returnedURL, expectedReturnUrl);
	}

	@Test(expected=AuthNPublicException.class)
	public void testGetOpenAMAuthenticationURL_OpenAMURL_NULL() throws Exception {
		PowerMockito.mockStatic(PropertyFileHelper.class);
		PowerMockito.when(PropertyFileHelper.getOpenAMServerURL()).thenReturn(null);
		String returnedURL = authNTokenProviderImpl.getOpenAMAuthenticationURL("tenant1");
		assertNull(returnedURL);
	}

	@Test
	public void testGetOpenAMAuthenticationURL_Tenant_NULL() throws Exception {
		String expectedReturnUrl = DUMMY_URL  + "/json/authenticate";
		PowerMockito.mockStatic(PropertyFileHelper.class);
		PowerMockito.when(PropertyFileHelper.getOpenAMServerURL()).thenReturn(DUMMY_URL);
		String returnedURL = authNTokenProviderImpl.getOpenAMAuthenticationURL(null);
		assertNotNull(returnedURL);
		assertEquals(returnedURL, expectedReturnUrl);
	}

	@Test
	public void testGetSystemUserAuthNCookies() throws Exception {
		String expextedIPlanetValue = "AQIC5wM2LY4Sfcwh54pDXfoRTYwM7Diatg2JsksxGcNLyAo.*AAJTSQACMDMAAlNLABQtMzI1MjM2MTg3NTMwNTcyNTk0MAACUzEAAjAx*";
		String expectedReturn = "{\"tokenId\": "+expextedIPlanetValue+",\"successUrl\": \"/openam/console\"}";
		Map<String, List<String>> map = new HashMap<String, List<String>>();
		//setting up data for verification
		List<String> valSet = Arrays.asList("JWK_URI=http://someDummyURL.com:8080/openam/oauth2/connect/jwk_uri", "AUTHN_TOKEN=a.b.c-d-e-f|g");
        map.put("Set-Cookie", valSet);
        InputStream is = new ByteArrayInputStream(expectedReturn.getBytes());
        HttpURLConnection con = PowerMockito.mock(HttpURLConnection.class);
        PowerMockito.mockStatic(AuthUtil.class);
        PowerMockito.mockStatic(PropertyFileHelper.class);
		PowerMockito.when(PropertyFileHelper.getOpenAMCookieName()).thenReturn(AUTHN_TOKEN);
        PowerMockito.when(PropertyFileHelper.getOpenAMServerURL()).thenReturn("http://somedummyURL.com");
        PowerMockito.when(AuthUtil.getSystemUserAuthHttpConnection(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(con);
        PowerMockito.when(con.getHeaderFields()).thenReturn(map);
        PowerMockito.when(con.getInputStream()).thenReturn(is);
        Cookie [] cookies = authNTokenProviderImpl.getSystemUserAuthNCookies("username", "password","tenantId", "onBehalfUser");
        //verifying set up data.
        assertNotNull(cookies);
        assertNotNull(cookies[0]); 
        assertNotNull(cookies[1]);
        assertEquals("JWK_URI", cookies[0].getName());
        assertEquals("http://someDummyURL.com:8080/openam/oauth2/connect/jwk_uri", cookies[0].getValue());
        assertEquals("AUTHN_TOKEN", cookies[1].getName());
        assertEquals("a.b.c-d-e-f|g", cookies[1].getValue());
        assertEquals("iPlanetDirectoryPro", cookies[2].getName());
        assertEquals(expextedIPlanetValue, cookies[2].getValue());	
	}
		
	@Test
	public void testGetNoImpersonationSystemUserAuthNCookies() throws Exception {
		String expextedIPlanetValue = "AQIC5wM2LY4Sfcwh54pDXfoRTYwM7Diatg2JsksxGcNLyAo.*AAJTSQACMDMAAlNLABQtMzI1MjM2MTg3NTMwNTcyNTk0MAACUzEAAjAx*";
		String expectedReturn = "{\"tokenId\": "+expextedIPlanetValue+",\"successUrl\": \"/openam/console\"}";
		Map<String, List<String>> map = new HashMap<String, List<String>>();
		//setting up data for verification
		List<String> valSet = Arrays.asList("JWK_URI=http://someDummyURL.com:8080/openam/oauth2/connect/jwk_uri", "AUTHN_TOKEN=a.b.c-d-e-f|g");
        map.put("Set-Cookie", valSet);
        InputStream is = new ByteArrayInputStream(expectedReturn.getBytes());
        HttpURLConnection con = PowerMockito.mock(HttpURLConnection.class);
        PowerMockito.mockStatic(AuthUtil.class);
        PowerMockito.mockStatic(PropertyFileHelper.class);
		PowerMockito.when(PropertyFileHelper.getOpenAMCookieName()).thenReturn(AUTHN_TOKEN);
        PowerMockito.when(PropertyFileHelper.getOpenAMServerURL()).thenReturn("http://somedummyURL.com");
        
        PowerMockito.when(AuthUtil.getSystemUserAuthConnection(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(con);
        
        PowerMockito.when(con.getHeaderFields()).thenReturn(map);
        PowerMockito.when(con.getInputStream()).thenReturn(is);
        Cookie [] cookies = authNTokenProviderImpl.getSystemUserAuthNCookies("username", "password","tenantId", "UserFname", "UserFname",null);
        //Cookie [] cookies = authNTokenProviderImpl.getSystemUserAuthNCookies("username", "password","tenantId", "onBehalfUser");
        //verifying set up data.
        assertNotNull(cookies);
        assertNotNull(cookies[0]); 
        assertNotNull(cookies[1]);
        assertEquals("JWK_URI", cookies[0].getName());
        assertEquals("http://someDummyURL.com:8080/openam/oauth2/connect/jwk_uri", cookies[0].getValue());
        assertEquals("AUTHN_TOKEN", cookies[1].getName());
        assertEquals("a.b.c-d-e-f|g", cookies[1].getValue());
        assertEquals("iPlanetDirectoryPro", cookies[2].getName());
        assertEquals(expextedIPlanetValue, cookies[2].getValue());	
	}
	
	@Test(expected=AuthNTokenPublicException.class)
	public void testGetNoImpersonationSystemUserAuthNCookies_Exception() throws Exception {
		String expextedIPlanetValue = "AQIC5wM2LY4Sfcwh54pDXfoRTYwM7Diatg2JsksxGcNLyAo.*AAJTSQACMDMAAlNLABQtMzI1MjM2MTg3NTMwNTcyNTk0MAACUzEAAjAx*";
		String expectedReturn = "{\"tokenId\": "+expextedIPlanetValue+",\"successUrl\": \"/openam/console\"}";
		Map<String, List<String>> map = new HashMap<String, List<String>>();
		//setting up data for verification
		List<String> valSet = Arrays.asList("JWK_URI=http://someDummyURL.com:8080/openam/oauth2/connect/jwk_uri", "AUTHN_TOKEN=a.b.c-d-e-f|g");
        map.put("Set-Cookie", valSet);
        InputStream is = new ByteArrayInputStream(expectedReturn.getBytes());
        HttpURLConnection con = PowerMockito.mock(HttpURLConnection.class);
        PowerMockito.mockStatic(AuthUtil.class);
        PowerMockito.mockStatic(PropertyFileHelper.class);
		PowerMockito.when(PropertyFileHelper.getOpenAMCookieName()).thenReturn(AUTHN_TOKEN);
        PowerMockito.when(PropertyFileHelper.getOpenAMServerURL()).thenReturn("http://somedummyURL.com");
        
		PowerMockito.when(AuthUtil.getSystemUserAuthConnection(Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenThrow(new IOException(""));
 
        PowerMockito.when(con.getHeaderFields()).thenReturn(map);
        PowerMockito.when(con.getInputStream()).thenReturn(is);
        Cookie [] cookies = authNTokenProviderImpl.getSystemUserAuthNCookies("username", "password","tenantId", "UserFname", "UserFname",null);
    }
    
    @Test
    public void testSetUserLocaleProfile() throws Exception {
    		
    		String userLocaleProfileJson = "{\"userLocaleProfile\" : {\"localeProfileId\":\"12345\",\"country\":\"US\",\"language\":\"EN\"}}";
    		UserInfo userInfo = new UserInfo("", "");
    		authNTokenProviderImpl.setUserLocaleProfile(userInfo, new JSONObject(userLocaleProfileJson));
    		assertEquals(userInfo.getUserLocaleProfile().getCountry(), "US");
    		assertEquals(userInfo.getUserLocaleProfile().getLanguage(), "EN");
    		assertEquals(userInfo.getUserLocaleProfile().getLocaleProfileId(), "12345");
    		
    }
    
	
    @Test
	public void testGetUserInfoTrueCookieParam_HavingUserDetailsCookie_logonProfile() throws Exception {
		MockHttpServletRequest request = new MockHttpServletRequest();
		Cookie authNtokenCookie = createCookie(AUTHN_TOKEN, AUTHN_LOGON_PROFILE);
		System.setProperty(KEY_PASS, KEY_PASS_VALUE);
		request.addCookie(authNtokenCookie);
		//AuthNTokenProvider authNTokenProvider = new AuthNTokenProviderImpl();
		PowerMockito.mockStatic(JWTTokenProcessor.class);
		Mockito.when(JWTTokenProcessor.getJWTPayload(Mockito.anyString(), Mockito.anyString())).thenReturn(JWK_PAYLOAD_LOGON_PROFILE);
		Mockito.when(JWTTokenProcessor.getJWTPayload(Mockito.anyString(), Mockito.anyString())).thenReturn(JWK_PAYLOAD_LOGON_PROFILE);
		PowerMockito.mockStatic(AuthUtil.class);
		PowerMockito.mockStatic(PropertyFileHelper.class);
		PowerMockito.when(PropertyFileHelper.getOpenAMCookieName()).thenReturn(AUTHN_TOKEN);
		StringBuilder strMock = new StringBuilder();
		//setting up request Expiration time.
		strMock.append("exp=");
		strMock.append(System.currentTimeMillis()/1000);
		Mockito.when(PropertyFileHelper.getOpenAMServerURL()).thenReturn(null);
		Mockito.when(AuthUtil.getResponseFromUrl(Mockito.any(),Mockito.anyString())).thenReturn(strMock);
		UserInfo userInfo = authNTokenProviderImpl.getUserInfo(request.getCookies());
		//assertEquals("amadmin", userInfo.getUsername());
		assertNotNull(userInfo);
	}

    public HttpURLConnection setupClearAuthNCookies(int resCode, boolean exception) throws Exception {
    	Cookie[] cookies = new Cookie[1];
		cookies[0] = new Cookie(AuthConstants.IPLANET_COOKIE, "somevalue");    		
    	PowerMockito.mockStatic(AuthUtil.class);
    	PowerMockito.mockStatic(PropertyFileHelper.class);
    	Mockito.when(PropertyFileHelper.getOpenAMServerURL()).thenReturn("someurl");
    	HttpURLConnection con = PowerMockito.mock(HttpURLConnection.class);
    	PowerMockito.doNothing().when(con).setRequestProperty(Mockito.anyString(), Mockito.anyString());
    	PowerMockito.when(AuthUtil.getHttpConnection(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(con);
    	if (exception) {
    		PowerMockito.doThrow(new IOException()).when(con).getResponseCode();
    	} else {
    		PowerMockito.doReturn(resCode).when(con).getResponseCode();
    	}
    	return con;
    }

    @Test
    public void testClearAuthNCookies() throws Exception {
    	HttpURLConnection con = setupClearAuthNCookies(200, false); 
    	authNTokenProvider.clearAuthNCookies(cookies2);
    	Mockito.verify(con, Mockito.times(1)).getResponseCode();
    }

    @Test(expected=AuthNPublicException.class)
    public void testClearAuthNCookies_404() throws Exception {
    	HttpURLConnection con = setupClearAuthNCookies(404, false); 
    	authNTokenProvider.clearAuthNCookies(cookies2);
    	Mockito.verify(con, Mockito.times(1)).getResponseCode();
    }

    @Test(expected=AuthNPublicException.class)
    public void testClearAuthNCookies_Exception() throws Exception {
    	HttpURLConnection con = setupClearAuthNCookies(200, true); 
    	authNTokenProvider.clearAuthNCookies(cookies2);
    	Mockito.verify(con, Mockito.times(1)).getResponseCode();
    }

    @Test(expected=AuthNPublicException.class)
    public void testClearAuthNCookies_OpenAM_url_null() throws Exception {
    	PowerMockito.mockStatic(AuthUtil.class);
    	PowerMockito.mockStatic(PropertyFileHelper.class);
    	Mockito.when(PropertyFileHelper.getOpenAMServerURL()).thenReturn(null);
    	authNTokenProvider.clearAuthNCookies(null);
    }
    
    private MockHttpServletRequest setUpForCheckSSOToken(int resCode, String reponse, boolean exception) throws Exception {
    	MockHttpServletRequest request = new MockHttpServletRequest();
    	Cookie[] cookies = {};
    	if (!exception) {
    		cookies = new Cookie[1];
    		cookies[0] = new Cookie(AuthConstants.IPLANET_COOKIE, "somevalue");    		
    	}
    	PowerMockito.mockStatic(AuthUtil.class);
    	PowerMockito.mockStatic(PropertyFileHelper.class);
    	PowerMockito.mockStatic(CookieHelper.class);
    	Mockito.when(PropertyFileHelper.getOpenAMServerURL()).thenReturn("someurl");
    	Mockito.when(CookieHelper.getCookieValue(request, AuthConstants.IPLANET_COOKIE)).thenReturn("somevalue");
    	HttpURLConnection con = PowerMockito.mock(HttpURLConnection.class);
    	if (exception) {
    		PowerMockito.when(AuthUtil.getResponseFromConn(Mockito.any(HttpURLConnection.class))).thenThrow(new IOException(""));
    	} else {
    		PowerMockito.doNothing().when(con).setRequestProperty(Mockito.anyString(), Mockito.anyString());
        	PowerMockito.when(AuthUtil.getHttpConnection(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(con);
        	StringBuilder str = reponse!= null ? new StringBuilder(reponse) : null;
    		PowerMockito.doReturn(resCode).when(con).getResponseCode();
    		PowerMockito.when(AuthUtil.getResponseFromConn(Mockito.any(HttpURLConnection.class))).thenReturn(str);
    	}
    	
    	PowerMockito.doReturn(cookies).when(authNTokenProviderImpl).getAuthNCookies(Mockito.anyString(), Mockito.anyString(), 
    			Mockito.anyString());
    	return request;
    }
    
    @Test
    public void testCheckSSOToken() throws Exception {
    	MockHttpServletRequest request = setUpForCheckSSOToken(200, "{ \"username\":\"LoginUser\" }", false);
    	boolean value = authNTokenProviderImpl.checkSSOToken(request);
		assertTrue(value);
    }
    
    @Test
    public void testCheckSSOToken_http_status_not_200() throws Exception {
    	MockHttpServletRequest request = setUpForCheckSSOToken(400, null, false);
    	boolean value = authNTokenProviderImpl.checkSSOToken(request);
		assertFalse(value);
    }
    
    @Test
    public void testCheckSSOToken_reponse_false() throws Exception {
    	MockHttpServletRequest request = setUpForCheckSSOToken(401, null, false);
    	boolean value = authNTokenProviderImpl.checkSSOToken(request);
    	assertFalse(value);
    }
    
    @Test(expected=AuthNPublicException.class)
    public void testCheckSSOToken_exception() throws Exception {
    	MockHttpServletRequest request = setUpForCheckSSOToken(200, "{ \"username\":\"LoginUser\" }" , true);
    	authNTokenProviderImpl.checkSSOToken(request);
    }
    
    @Test(expected=AuthNPublicException.class)
    public void testCheckSSOToken_OpenAM_url_null() throws Exception {
    	PowerMockito.mockStatic(AuthUtil.class);
    	PowerMockito.mockStatic(PropertyFileHelper.class);
    	Mockito.when(PropertyFileHelper.getOpenAMServerURL()).thenReturn(null);
    	authNTokenProvider.checkSSOToken(null);
    }
    
    @Test
    public void testGetOpenAMCookieName_Fallback() {
    	assertEquals(AuthConstants.FALLBACK_AUTHN_TOKEN, authNTokenProvider.getOpenAMCookieName());
    }
    
    @Test
    @PrepareForTest(PropertyFileHelper.class)
    public void testGetOpenAMCookieName() {
    	PowerMockito.mockStatic(PropertyFileHelper.class);
    	PowerMockito.when(PropertyFileHelper.getOpenAMCookieName()).thenReturn("TMS_AUTHN_TOKEN");
    	assertEquals("TMS_AUTHN_TOKEN", authNTokenProvider.getOpenAMCookieName());
    }
    
	@Test
	public void testGetSSOSessionInfo() throws Exception {
		MockHttpServletRequest request = setUpForCheckSSOToken(200, 
			"{ \"maxIdleExpirationTime\":\"2050-10-26T10:06:47Z\",  \"maxSessionExpirationTime\":\"2049-10-26T10:06:01Z\" }", false);
		SSOSessionInfo value = authNTokenProviderImpl.getSSOSessionInfo(request);
		assertNotNull(value);
	}

	@Test
	public void testGetSSOSessionInfo2() throws Exception {
		MockHttpServletRequest request = setUpForCheckSSOToken(200, 
			"{ \"maxIdleExpirationTime\":\"2049-10-26T10:06:47Z\",  \"maxSessionExpirationTime\":\"2050-10-26T10:06:47Z\" }", false);
		SSOSessionInfo value = authNTokenProviderImpl.getSSOSessionInfo(request);
		assertNotNull(value);
	}
	
    @Test(expected=AuthNPublicException.class)
	public void testGetSSOSessionInfo_Exception() throws Exception {
		MockHttpServletRequest request = setUpForCheckSSOToken(200, 
			"{ \"maxIdleExpirationTime\":\"2050-10-26T10:06:47Z\",  \"maxSessionExpirationTime\":\"2050-10-26T10:06:47Z\" }", true);
		authNTokenProviderImpl.getSSOSessionInfo(request);
    }
    
    @Test
    public void testGetSSOSessionInfo_reponse_null() throws Exception {
    	MockHttpServletRequest request = setUpForCheckSSOToken(401, null, false);
    	SSOSessionInfo value = authNTokenProviderImpl.getSSOSessionInfo(request);
    	assertNotNull(value);
    }
    
}
