package com.kronos.auth.clientlib.session;

import java.time.LocalDateTime;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.google.common.cache.RemovalCause;
import com.kronos.auth.clientlib.cache.AuthNCache;
import com.kronos.auth.clientlib.cache.AuthNCacheObject;
import com.kronos.auth.clientlib.util.AuthConstants;
import com.kronos.auth.clientlib.util.AuthUtil;
import com.kronos.auth.clientlib.util.CookieHelper;
import com.kronos.auth.clientlib.util.PropertyFileHelper;
import com.kronos.auth.redis.AuthNRedisConnectionPoolSvcResolver;
import com.kronos.auth.redis.AuthNRedisOperationResolver;
import com.kronos.auth.redis.impl.AuthNRedisOperationsImpl;

@PrepareForTest({ CookieHelper.class, AuthUtil.class, PropertyFileHelper.class, AuthNSessionTimeCache.class })
@RunWith(PowerMockRunner.class)
public class SessionOperationNotifierImplTest {

	private static final String SSO_TOKEN = "SSO_TOKEN_VALUE";
	private static final String AUTHN_TOKEN = "AUTHN_TOKEN_VALUE";

	private static final Cookie[] cookies = {};

	SessionOperationNotifierImpl notifierImpl;
	AuthNSessionTimeCache redis;
	HttpServletRequest httpServletRequest;
	HttpSession httpSession;
	AuthNRedisOperationResolver resolver;
	AuthNRedisConnectionPoolSvcResolver poolResolver;
	
	@Before
	public void setUp() throws Exception {
		PowerMockito.mockStatic(AuthNSessionTimeCache.class);
		PowerMockito.mockStatic(CookieHelper.class);
		PowerMockito.mockStatic(AuthUtil.class);

		httpSession = PowerMockito.mock(HttpSession.class);
		httpServletRequest = PowerMockito.mock(HttpServletRequest.class);
		Mockito.doReturn(httpSession).when(httpServletRequest).getSession(false);
		Mockito.doReturn(cookies).when(httpServletRequest).getCookies();
		Mockito.doReturn("JSessionID").when(httpSession).getId();

		AuthNRedisOperationsImpl redisOpImpl = Mockito.mock(AuthNRedisOperationsImpl.class);
		resolver = Mockito.mock(AuthNRedisOperationResolver.class);
		Mockito.doReturn(redisOpImpl).when(resolver).getAuthNRedisOperations();
		Mockito.doNothing().when(redisOpImpl).getSubscription(Mockito.anyString(), Mockito.any());
		poolResolver = Mockito.mock(AuthNRedisConnectionPoolSvcResolver.class);
		redisOpImpl.setAuthNRedisConnectionPoolSvcResolver(poolResolver);

		redis = Mockito.mock(AuthNSessionTimeCache.class);
		redis.redisOpResolver = resolver;
		Mockito.when(CookieHelper.getCookieValue(cookies, AuthConstants.IPLANET_COOKIE)).thenReturn(SSO_TOKEN);
		Mockito.when(CookieHelper.getCookieValue(cookies, AuthConstants.FALLBACK_AUTHN_TOKEN)).thenReturn(AUTHN_TOKEN);
		notifierImpl = new SessionOperationNotifierImpl();
		notifierImpl.authNRedis = redis;
		
		AuthNCache.getAuthNCache().removeKey(SSO_TOKEN);
	}

	@Test
	public void testSessionCreated() {
		Mockito.doNothing().when(redis).setSessionValidTime(Mockito.anyString(), Mockito.any(LocalDateTime.class));
		notifierImpl.sessionCreated(httpServletRequest);
		Assert.assertNotNull(AuthNCache.getAuthNCache().getValue(SSO_TOKEN));
	}

	@Test
	public void testSessionCreated_SSO_NULL() {
		Mockito.when(CookieHelper.getCookieValue(cookies, AuthConstants.IPLANET_COOKIE)).thenReturn(null);
		Mockito.doNothing().when(redis).setSessionValidTime(Mockito.anyString(), Mockito.any(LocalDateTime.class));
		notifierImpl.sessionCreated(httpServletRequest);
		Assert.assertNull(AuthNCache.getAuthNCache().getValue(SSO_TOKEN));
	}
	
	@Test
	public void testSessionCreated_Exception() {
		Mockito.when(CookieHelper.getCookieValue(cookies, AuthConstants.IPLANET_COOKIE)).thenThrow(new RuntimeException("error"));
		Mockito.doThrow(new RuntimeException("error")).when(redis).setSessionValidTime(Mockito.anyString(), Mockito.any(LocalDateTime.class));
		notifierImpl.sessionCreated(httpServletRequest);
	}
	
	@Test
	public void testSessionAccessed() {
		Mockito.doNothing().when(redis).setSessionValidTime(Mockito.anyString(), Mockito.any(LocalDateTime.class));
		notifierImpl.sessionAccessed(httpServletRequest);
		Assert.assertNull(AuthNCache.getAuthNCache().getValue(SSO_TOKEN));
		Mockito.verify(this.redis, Mockito.times(0)).setSessionValidTime(Mockito.anyString(), Mockito.anyObject());
	}

	@Test
	public void testSessionAccessed_SSO_NULL() {
		Mockito.when(CookieHelper.getCookieValue(cookies, AuthConstants.IPLANET_COOKIE)).thenReturn(null);
		Mockito.doThrow(new RuntimeException("error")).when(redis).setSessionValidTime(Mockito.anyString(), Mockito.any(LocalDateTime.class));
		notifierImpl.sessionAccessed(httpServletRequest);
	}

	@Test
	public void testSessionAccessed_Exception() {
		Mockito.when(CookieHelper.getCookieValue(cookies, AuthConstants.IPLANET_COOKIE)).thenThrow(new RuntimeException("error"));
		Mockito.doThrow(new RuntimeException("error")).when(redis).setSessionValidTime(Mockito.anyString(), Mockito.any(LocalDateTime.class));
		notifierImpl.sessionAccessed(httpServletRequest);
	}

	@Test
	public void testSessionAccessed_Valid_Cached_Object() {
		AuthNCacheObject object = new AuthNCacheObject(SSO_TOKEN, "JSessionId", AUTHN_TOKEN,
				LocalDateTime.of(2016, 11, 1, 1, 1));
		AuthNCache.getAuthNCache().putValue(SSO_TOKEN, object);
		Mockito.doNothing().when(redis).setSessionValidTime(Mockito.anyString(), Mockito.any(LocalDateTime.class));
		notifierImpl.sessionAccessed(httpServletRequest);
		Assert.assertNotNull(AuthNCache.getAuthNCache().getValue(SSO_TOKEN));
		Mockito.verify(this.redis, Mockito.times(1)).setSessionValidTime(Mockito.anyString(), Mockito.anyObject());
	}

	@Test
	public void testSessionLogout_SSO_NULL() {
		Mockito.when(CookieHelper.getCookieValue(cookies, AuthConstants.IPLANET_COOKIE)).thenReturn(null);
		Mockito.doNothing().when(redis).publishLogoutMessage(Mockito.anyString());
		notifierImpl.sessionLogout(httpServletRequest);
		Assert.assertNull(AuthNCache.getAuthNCache().getValue(SSO_TOKEN));
		Mockito.verify(this.redis, Mockito.times(0)).publishLogoutMessage(Mockito.anyString());
	}
	
	@Test
	public void testSessionLogout_OBJECT_NULL() {
		Mockito.doNothing().when(redis).publishLogoutMessage(Mockito.anyString());
		notifierImpl.sessionLogout(httpServletRequest);
		Assert.assertNull(AuthNCache.getAuthNCache().getValue(SSO_TOKEN));
		Mockito.verify(this.redis, Mockito.times(0)).publishLogoutMessage(Mockito.anyString());
	}

	@Test
	public void testSessionLogout_Exception() {
		Mockito.when(CookieHelper.getCookieValue(cookies, AuthConstants.IPLANET_COOKIE)).thenThrow(new RuntimeException("error"));
		AuthNCacheObject object = new AuthNCacheObject(SSO_TOKEN, "JSessionId", AUTHN_TOKEN,
				LocalDateTime.of(2016, 11, 1, 1, 1));
		object.setPublishMessage(true);
		AuthNCache.getAuthNCache().putValue(SSO_TOKEN, object);

		Mockito.doThrow(new RuntimeException("error")).when(redis).removeSessionValidTime(Mockito.anyString());
		notifierImpl.sessionLogout(httpServletRequest);
	}

	@Test
	public void testSessionLogout_String() {
		AuthNCacheObject object = new AuthNCacheObject(SSO_TOKEN, "JSessionId", AUTHN_TOKEN,
				LocalDateTime.of(2016, 11, 1, 1, 1));
		object.setPublishMessage(true);
		AuthNCache.getAuthNCache().putValue(SSO_TOKEN, object);

		Mockito.doNothing().when(redis).removeSessionValidTime(Mockito.anyString());
		Mockito.doNothing().when(redis).publishLogoutMessage(Mockito.anyString());
		notifierImpl.sessionLogout(httpServletRequest);
		Assert.assertNull(AuthNCache.getAuthNCache().getValue(SSO_TOKEN));
		Mockito.verify(this.redis, Mockito.times(1)).publishLogoutMessage(Mockito.anyString());		
	}
	
	@Test
	public void testHandleSessionLogout_Exception() {
		LocalDateTime loctime = LocalDateTime.of(2017, 11, 1, 1, 1);
		AuthNCacheObject object = new AuthNCacheObject(SSO_TOKEN, "JSessionId", AUTHN_TOKEN, loctime);
		AuthNCache.getAuthNCache().putValue(SSO_TOKEN, object);
		
		PowerMockito.doThrow(new RuntimeException("error")).when(AuthUtil.class);
		AuthUtil.notifySelf(Mockito.any(AuthNCacheObject.class), Mockito.any(Boolean.class));
		notifierImpl.handleSessionLogout(SSO_TOKEN);
	}
	
	@Test
	public void testHandleSessionLogout() {
		LocalDateTime loctime = LocalDateTime.of(2017, 11, 1, 1, 1);
		AuthNCacheObject object = new AuthNCacheObject(SSO_TOKEN, "JSessionId", AUTHN_TOKEN, loctime);
		AuthNCache.getAuthNCache().putValue(SSO_TOKEN, object);
		
		PowerMockito.doNothing().when(AuthUtil.class);
		AuthUtil.notifySelf(Mockito.any(AuthNCacheObject.class), Mockito.any(Boolean.class));
		notifierImpl.handleSessionLogout(SSO_TOKEN);
	}

	@Test
	public void testHandleOnRemoval() {
		LocalDateTime loctime = LocalDateTime.of(2017, 11, 1, 1, 1);
		AuthNCacheObject object = new AuthNCacheObject(SSO_TOKEN, "JSessionId", AUTHN_TOKEN, loctime);

		PowerMockito.doNothing().when(AuthUtil.class);
		AuthUtil.notifySelf(Mockito.any(AuthNCacheObject.class), Mockito.any(Boolean.class));

		Mockito.doReturn(loctime).when(redis).getSessionValidTime(Mockito.anyString());

		notifierImpl.handleOnRemoval(RemovalCause.EXPIRED, SSO_TOKEN, object);
	}

	@Test
	public void testHandleOnRemoval_Exception() {
		LocalDateTime loctime = LocalDateTime.of(2017, 11, 1, 1, 1);
		AuthNCacheObject object = new AuthNCacheObject(SSO_TOKEN, "JSessionId", AUTHN_TOKEN, loctime);

		PowerMockito.doNothing().when(AuthUtil.class);
		AuthUtil.notifySelf(Mockito.any(AuthNCacheObject.class), Mockito.any(Boolean.class));

		Mockito.doThrow(new RuntimeException("error")).when(redis).getSessionValidTime(Mockito.anyString());

		notifierImpl.handleOnRemoval(RemovalCause.EXPIRED, SSO_TOKEN, object);
	}
	
	@Test
	public void testHandleOnRemoval_NULL_Params() {
		LocalDateTime loctime = LocalDateTime.of(2017, 11, 1, 1, 1);
		AuthNCacheObject object = new AuthNCacheObject(SSO_TOKEN, "JSessionId", AUTHN_TOKEN, loctime);

		PowerMockito.doNothing().when(AuthUtil.class);
		AuthUtil.notifySelf(Mockito.any(AuthNCacheObject.class), Mockito.any(Boolean.class));

		Mockito.doReturn(loctime).when(redis).getSessionValidTime(Mockito.anyString());

		notifierImpl.handleOnRemoval(RemovalCause.EXPIRED, null, object);
		notifierImpl.handleOnRemoval(RemovalCause.EXPIRED, SSO_TOKEN, null);
		notifierImpl.handleOnRemoval(RemovalCause.COLLECTED, SSO_TOKEN, object);
	}
	
	@Test
	public void testOnMessage_NULLs() {
		notifierImpl.onMessage(null, "");
		notifierImpl.onMessage("LOGOUT_CHANNEL", "");
		notifierImpl.onMessage("CHANNEL_OTHER", "");
		notifierImpl.onMessage("LOGOUT_CHANNEL", null);
		notifierImpl.onMessage("LOGOUT_CHANNEL", "");
		notifierImpl.onMessage("LOGOUT_CHANNEL", "A");
	}
}
