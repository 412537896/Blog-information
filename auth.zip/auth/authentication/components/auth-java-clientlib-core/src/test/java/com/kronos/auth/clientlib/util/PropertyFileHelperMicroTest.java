package com.kronos.auth.clientlib.util;

import static org.junit.Assert.assertTrue;

import java.io.FileInputStream;
import java.util.Properties;
import java.util.Set;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.kronos.auth.clientlib.util.PropertyFileHelper;
import com.kronos.auth.clientlib.util.PropertyFileHelper.FileStreamCreator;

@RunWith(PowerMockRunner.class)
@PrepareForTest(FileStreamCreator.class)
public class PropertyFileHelperMicroTest {

	private static final String OPENAM_PORT_VALUE = "1111";
	private static final String OPENAM_SERVER_VALUE = "testopenamserver";
	private static final String OPENAM_CONTEXT_VALUE = "authn";
	private static final String OPENAM_SCHEME_VALUE = "http";
	private static final String SKIP_TENANT_NAME_VALUE = "true";
	private static final String APP_CONTEXT_VALUE = "myapp";
	private static final String APP_BASE_URL_VALUE = "localhost";
	private static final String FULL_URL = OPENAM_SCHEME_VALUE + AuthConstants.COLON_SLASH_SLASH + OPENAM_SERVER_VALUE
			+ AuthConstants.COLON + OPENAM_PORT_VALUE + AuthConstants.SLASH + OPENAM_CONTEXT_VALUE;
	private static final String OPENAM_URL = "http://testopenamserver:1111/authn";

	private static final String CONFIG_FILE = "anyConfigFile";
	private static final String OPENAM_COOKIE_VALUE = "AUTHN_TOKEN";

	private static final String REDIS_VALUE_STR = "server";
	private static final String REDIS_VALUE_NUM = "10";
	private static final String IPLANET_COOKIE_NAME_VALUE = "authn_ssid";
	
	Properties returnedProps;

	
	@Before
	public void setUp() {
		returnedProps = new Properties();
		returnedProps.setProperty(PropertyFileHelper.OPENAM_HOST, OPENAM_SERVER_VALUE);
		returnedProps.setProperty(PropertyFileHelper.OPENAM_PORT, OPENAM_PORT_VALUE);
		returnedProps.setProperty(PropertyFileHelper.OPENAM_CONTEXT, OPENAM_CONTEXT_VALUE);
		returnedProps.setProperty(PropertyFileHelper.OPENAM_SCHEME, OPENAM_SCHEME_VALUE);
		returnedProps.setProperty(PropertyFileHelper.OPENAM_COOKIENAME, OPENAM_COOKIE_VALUE);
		returnedProps.setProperty(PropertyFileHelper.SKIP_TENANT_NAME_CHECK_STR, SKIP_TENANT_NAME_VALUE);
		returnedProps.setProperty(PropertyFileHelper.APP_CONTEXT, APP_CONTEXT_VALUE);
		returnedProps.setProperty(PropertyFileHelper.APP_BASE_URL, APP_BASE_URL_VALUE);
		
		returnedProps.setProperty(PropertyFileHelper.REDIS_MASTER, REDIS_VALUE_STR);
		returnedProps.setProperty(PropertyFileHelper.REDIS_HOSTS_PORTS, REDIS_VALUE_STR);
		returnedProps.setProperty(PropertyFileHelper.REDIS_AUTH, REDIS_VALUE_STR);
		returnedProps.setProperty(PropertyFileHelper.REDIS_MAX_ACTIVE, REDIS_VALUE_NUM);
		returnedProps.setProperty(PropertyFileHelper.REDIS_TIMEOUT, REDIS_VALUE_NUM);
		returnedProps.setProperty(PropertyFileHelper.REDIS_KEY_TTL, REDIS_VALUE_NUM);
		returnedProps.setProperty(PropertyFileHelper.IPLANET_COOKIE_NAME, IPLANET_COOKIE_NAME_VALUE);
		PowerMockito.mockStatic(FileStreamCreator.class);
	}
	
	@After
	public void tearDown() {
		returnedProps = null;
	}

	@Test
	public void testGetOpenAMServerURL() throws Exception {
		final FileInputStream fileInputStreamMock = PowerMockito.mock(FileInputStream.class);
		PowerMockito.when(FileStreamCreator.getFileInputStream(Mockito.anyString()))
				.thenReturn(fileInputStreamMock);
		PowerMockito.when(FileStreamCreator.getPropsInstance()).thenReturn(returnedProps);
		PropertyFileHelper.initOpenAMConfig();
		String value = PropertyFileHelper.getOpenAMServerURL();
		Assert.assertEquals(FULL_URL, value);
	}

	@Test
	public void testReadConfig() throws Exception {
		final FileInputStream fileInputStreamMock = PowerMockito.mock(FileInputStream.class);
		PowerMockito.when(FileStreamCreator.getFileInputStream(Mockito.anyString()))
				.thenReturn(fileInputStreamMock);
		PowerMockito.when(FileStreamCreator.getPropsInstance()).thenReturn(returnedProps);

		PropertyFileHelper.readConfig(CONFIG_FILE);
		
	}

	@Test(expected=IllegalArgumentException.class)
	public void testInitOpenAMConfig() throws Exception {
		final FileInputStream fileInputStreamMock = PowerMockito.mock(FileInputStream.class);
		PowerMockito.when(FileStreamCreator.getFileInputStream(Mockito.anyString()))
				.thenReturn(fileInputStreamMock);
		PowerMockito.when(FileStreamCreator.getPropsInstance()).thenReturn(new Properties());
		PropertyFileHelper.initOpenAMConfig();
	}
	@Test
	public void testGetOpenAMServerURL_OPENAMURL_FOUND() throws Exception {
		returnedProps.setProperty(PropertyFileHelper.OPENAM_URL, OPENAM_URL);
		final FileInputStream fileInputStreamMock = PowerMockito.mock(FileInputStream.class);
		PowerMockito.when(FileStreamCreator.getFileInputStream(Mockito.anyString()))
				.thenReturn(fileInputStreamMock);
		PowerMockito.when(FileStreamCreator.getPropsInstance()).thenReturn(returnedProps);
		PropertyFileHelper.initOpenAMConfig();
		String value = PropertyFileHelper.getOpenAMServerURL();
		Assert.assertEquals(OPENAM_URL, value);
	}
	
	@Test
	public void testReadConfig_OPENAMURL_FOUND() throws Exception {
		returnedProps.setProperty(PropertyFileHelper.OPENAM_URL, OPENAM_URL);
		final FileInputStream fileInputStreamMock = PowerMockito.mock(FileInputStream.class);
		PowerMockito.when(FileStreamCreator.getFileInputStream(Mockito.anyString()))
				.thenReturn(fileInputStreamMock);
		PowerMockito.when(FileStreamCreator.getPropsInstance()).thenReturn(returnedProps);

		
	}
	
	@Test
	public void testGetOpenAMCookieName() throws Exception {
		final FileInputStream fileInputStreamMock = PowerMockito.mock(FileInputStream.class);
		PowerMockito.when(FileStreamCreator.getFileInputStream(Mockito.anyString()))
				.thenReturn(fileInputStreamMock);
		PowerMockito.when(FileStreamCreator.getPropsInstance()).thenReturn(returnedProps);
		PropertyFileHelper.initOpenAMConfig();
		String cookieName = PropertyFileHelper.getOpenAMCookieName();
		assertTrue(cookieName.equals(OPENAM_COOKIE_VALUE));
	}
	
	@Test
	public void testRedisProperties() throws Exception {
		final FileInputStream fileInputStreamMock = PowerMockito.mock(FileInputStream.class);
		PowerMockito.when(FileStreamCreator.getFileInputStream(Mockito.anyString()))
				.thenReturn(fileInputStreamMock);
		PowerMockito.when(FileStreamCreator.getPropsInstance()).thenReturn(returnedProps);
		PropertyFileHelper.initOpenAMConfig();
		String redisValue = PropertyFileHelper.getRedisAuth();
		assertTrue(redisValue.equals(REDIS_VALUE_STR));
		redisValue = PropertyFileHelper.getRedisMaster();
		assertTrue(redisValue.equals(REDIS_VALUE_STR));
		Set<String> value = PropertyFileHelper.getSentinelHostsAndPorts();
		assertTrue(value.size() > 0);
		redisValue = PropertyFileHelper.getRedisMaxActive();
		assertTrue(redisValue.equals(REDIS_VALUE_NUM));
		redisValue = PropertyFileHelper.getRedisTimeout();
		assertTrue(redisValue.equals(REDIS_VALUE_NUM));
		int intValue = PropertyFileHelper.getRedisKeyTTL();
		assertTrue(intValue > 0);
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void testReadConfig_Null() throws Exception {
		final FileInputStream fileInputStreamMock = PowerMockito.mock(FileInputStream.class);
		PowerMockito.when(FileStreamCreator.getFileInputStream(Mockito.anyString()))
				.thenReturn(fileInputStreamMock);
		Properties props = Mockito.mock(Properties.class);
		PowerMockito.when(FileStreamCreator.getPropsInstance()).thenReturn(props);
		Mockito.when(props.getProperty("openam_url")).thenReturn("");
		PropertyFileHelper.readConfig(CONFIG_FILE);
		
	}
	
}
