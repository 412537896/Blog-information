package com.kronos.auth.clientlib.impl;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.KeyFactory;
import java.security.PublicKey;
import java.security.spec.KeySpec;
import java.util.HashMap;
import java.util.Map;

import org.jose4j.jws.JsonWebSignature;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.kronos.auth.clientlib.exception.AuthNPublicException;
import com.kronos.auth.clientlib.util.AuthUtil;

import junit.framework.TestCase;

@PrepareForTest({URL.class,JsonWebSignature.class,AuthUtil.class,KeyFactory.class})
@RunWith(PowerMockRunner.class)
public class JWTTokenProcessorMicroTest extends TestCase{

	private final static String JWK_URI = "JWK_URI";
	private final static String JWK_URI_COOKIE_VALUE_CORRECT = "http://somedummyurl.com";
	String uri = "http://somedummyurl.com";
	private final static String AUTHN_TOKEN_COOKIE_VALUE_CORRECT = "eyAidHlwIjogIkpXVCIsICJraWQiOiAiMTI3ZjRmMjYtNmM2MS00Y2ZhLWExOGUtNmVmZDg5NjJjYTM2IiwgImN0eSI6ICJKV1QiLCAiYWxnIjogIlJTMjU2IiB9.eyAiYXRfaGFzaCI6ICI4d3BTRHhuMkpBbzhsSnNEcFVPRHp3IiwgInN1YiI6ICJmY2hpbiIsICJpc3MiOiAiaHR0cDovL3JoZWw3LWF1dGg5LmludC5rcm9ub3MuY29tOjgwODAvb3BlbmFtL29hdXRoMiIsICJ0b2tlbk5hbWUiOiAiaWRfdG9rZW4iLCAiYXVkIjogWyAia3Jvbm9zIiBdLCAib3BzIjogImM4ODU3MjM2LWM4YmMtNGM1MC1iODNiLWEwNTBiMmM3YmFhMSIsICJhenAiOiAia3Jvbm9zIiwgImF1dGhfdGltZSI6IDE0NDg2MDQ0MDYsICJyZWFsbSI6ICIvIiwgImV4cCI6IDIwNDg2MDQ0MDYsICJ0b2tlblR5cGUiOiAiSldUVG9rZW4iLCAiaWF0IjogMTQ0ODYwNDQwNiB9.Q6PduQp7kO_Ji1O0mR0uSNoTgzBunfp9qo0uIK-BqgmcBY21gTtMmfsL6LItVrgDkoafs59Ap13aVcaQ66PrdYipvsWg6XhJ1wqVhCL1Zzb-cO8XzpLhrHTofl1TlVY4nsZXkcy2mo4SUxYsH-CWtFcUEeDeV52EGgUM-DXjYFu0j6nH7eGn6sK3Tk2HkzqUjzElhHnoQQ23tHjzm_7BNAGxbHE0wlkAU3NBwgt-bZLQsB5M9n6PYJIT6C4nNd1nCfoGajy23XPADivXVc23gSwxwL7JQqfkbJxLUJEttngBn72Ce4iQHRfxUdWwtTi9rs1zumb6sfyWbgmG5JphIQ|ZllENzc3U3M3YjBBMC82bkdtQ0R2VVlDM2RXWG4xZlRwZ08raFNkMmZYOUI2RFlKRG0zQ1lBWllSKzE3T01LTGZ3QUZyTzBoK3o1RndCWnA2TWhUN1ZldGpVSE9UWHpSaGlIcVdBUXBoNEpXYjBkRXB5Q3NSVmFnV1NvaHlpYzZzNHZQdWxqeFdCUEtTQVlQSkdRcXNBLS0=";
	String response = "Hello";
	private final static String LONGKEY = "longkeyewwwwwqqqqqqqqqwwwwwsssssssslongkeyewwwwwqqqqqqqqqwwwwwsssssssslongkeyewwwwwqqqqqqqqqwwwwwsssssssslongkeyewwwwwqqqqqqqqqwwwwwsssssssslongkeyewwwwwqqqqqqqqqwwwwwsssssssslongkeyewwwwwqqqqqqqqqwwwwwsssssssslongkeyewwwwwqqqqqqqqqwwwwwsssssssslongkeyewwwwwqqqqqqqqqwwwwwssssssss";
	@Before
	public static void before(){
		PowerMockito.mockStatic(AuthUtil.class);
	}



	@Test
	public void testGetRequest() throws Exception
	{

		InputStream is = new ByteArrayInputStream(response.getBytes());
		//PowerMockito.mockStatic(AuthUtil.class);
		HttpURLConnection con = PowerMockito.mock(HttpURLConnection.class);
		PowerMockito.when(AuthUtil.getURLConnection(Mockito.anyString())).thenReturn(con);
		PowerMockito.when(con.getInputStream()).thenReturn(is);
		String getResponse = JWTTokenProcessor.getRequest(uri, "GET", null);
		assertNotNull(getResponse);
	}

	@Test(expected=AuthNPublicException.class)
	public void testGetRequestForException() throws Exception
	{
		// Exception case
		String malFormedUrl = "MalformedURL";
		PowerMockito.when(AuthUtil.getURLConnection(Mockito.anyString())).thenThrow(new IOException());
		JWTTokenProcessor.getRequest(malFormedUrl, "GET", null);
		// Noting to assert as the test will generate exception which will be expected by @Test annotation
	}

	@Test
	public void testGetRequestForSuccess() throws Exception
	{
		InputStream is = new ByteArrayInputStream(response.getBytes());
		//URL urlMock = new URL("http://www.google.com");
		HttpURLConnection con = PowerMockito.mock(HttpURLConnection.class);
		PowerMockito.when(AuthUtil.getURLConnection(Mockito.anyString())).thenReturn(con);
		Mockito.when(con.getInputStream()).thenReturn(is);
		String result = JWTTokenProcessor.getRequest(uri, "GET", null);
		// generic verification method used.
		assertNotNull(result);
		assertTrue(!result.isEmpty());
	}
	@Test
	public void testGetJWTPayloadSucessWithPayload() throws Exception{
		//setup test data
		String payloadTestData = "somePayload";
		PublicKey pk = PowerMockito.mock(PublicKey.class);
		JsonWebSignature jwsMock = PowerMockito.mock(JsonWebSignature.class);
		PowerMockito.mockStatic(KeyFactory.class);
		KeyFactory keyFactoryMock = PowerMockito.mock(KeyFactory.class);
		Map<String,String> map = new HashMap<String,String>();
		map.put(JWK_URI, JWK_URI_COOKIE_VALUE_CORRECT);
		String jsonRespTest = "{keys:[{use:sig,kty:RSA,n:"+LONGKEY+",e:"+LONGKEY+"}]}";
		InputStream is = new ByteArrayInputStream(jsonRespTest.getBytes());
		HttpURLConnection con = PowerMockito.mock(HttpURLConnection.class);
		PowerMockito.when(AuthUtil.getURLConnection(Mockito.anyString())).thenReturn(con);
		PowerMockito.when(con.getInputStream()).thenReturn(is);
		PowerMockito.when(KeyFactory.getInstance("RSA")).thenReturn(keyFactoryMock);
		PowerMockito.when(keyFactoryMock.generatePublic(Mockito.any(KeySpec.class))).thenReturn(pk);
		PowerMockito.when(AuthUtil.getJsonWebSignature()).thenReturn(jwsMock);
		PowerMockito.when(jwsMock.verifySignature()).thenReturn(true);
		//this will be returned by getJWTPayload call.
		PowerMockito.when(jwsMock.getPayload()).thenReturn(payloadTestData);
		String returnedPayload = JWTTokenProcessor.getJWTPayload(uri, AUTHN_TOKEN_COOKIE_VALUE_CORRECT);
		assertNotNull(returnedPayload);
		assertEquals(payloadTestData, returnedPayload);
	}
	@Test
	public void testGetJWTPayloadVerificationFailure() throws Exception{
		// test data
		String jsonRespTest = "{keys:[{use:sig,kty:RSA,n:"+LONGKEY+",e:"+LONGKEY+"}]}";
		PublicKey pk = PowerMockito.mock(PublicKey.class);
		JsonWebSignature jwsMock = PowerMockito.mock(JsonWebSignature.class);
		PowerMockito.mockStatic(KeyFactory.class);
		KeyFactory keyFactoryMock = PowerMockito.mock(KeyFactory.class);
		Map<String,String> map = new HashMap<String,String>();
		map.put(JWK_URI, JWK_URI_COOKIE_VALUE_CORRECT);
		InputStream is = new ByteArrayInputStream(jsonRespTest.getBytes());
		InputStream is1 = new ByteArrayInputStream(jsonRespTest.getBytes());
		HttpURLConnection con = PowerMockito.mock(HttpURLConnection.class);
		PowerMockito.when(AuthUtil.getURLConnection(Mockito.anyString())).thenReturn(con);
		PowerMockito.when(con.getInputStream()).thenReturn(is).thenReturn(is1);
		PowerMockito.when(KeyFactory.getInstance("RSA")).thenReturn(keyFactoryMock);
		PowerMockito.when(keyFactoryMock.generatePublic(Mockito.any(KeySpec.class))).thenReturn(pk);
		PowerMockito.when(AuthUtil.getJsonWebSignature()).thenReturn(jwsMock);
		String returnedPayload =JWTTokenProcessor.getJWTPayload(uri, AUTHN_TOKEN_COOKIE_VALUE_CORRECT);
		//verification
		assertNull(returnedPayload);
		Mockito.verify(jwsMock,Mockito.times(2)).verifySignature();
	}

	@Test
	public void testGetRequestWithPropSuccess() throws Exception
	{
		//setup test data.
		Map<String,String> map = new HashMap<String,String>();
		map.put(JWK_URI, JWK_URI_COOKIE_VALUE_CORRECT);
		InputStream is = new ByteArrayInputStream(response.getBytes());
		HttpURLConnection con = PowerMockito.mock(HttpURLConnection.class);
		PowerMockito.when(AuthUtil.getURLConnection(Mockito.anyString())).thenReturn(con);
		PowerMockito.when(con.getInputStream()).thenReturn(is);
		String result = JWTTokenProcessor.getRequest(uri, "GET", map);
		//closing the input stream
		is.close();
		// generic verification method used.
		assertNotNull(result);
		assertTrue(!result.isEmpty());
	}
}
