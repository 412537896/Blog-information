package com.kronos.auth.redis.impl;

import static org.junit.Assert.assertNotNull;

import java.util.HashSet;
import java.util.Set;

import org.apache.commons.pool2.impl.GenericObjectPoolConfig;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.core.classloader.annotations.SuppressStaticInitializationFor;
import org.powermock.modules.junit4.PowerMockRunner;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;

import com.kronos.auth.clientlib.util.AuthUtil;
import com.kronos.auth.clientlib.util.PropertyFileHelper;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ AuthUtil.class, PropertyFileHelper.class })
@SuppressStaticInitializationFor("com.kronos.auth.clientlib.util.PropertyFileHelper")
public class JedisConnPoolServiceMicroTest {
	private static JedisPool jedisPool = null;
	private static JedisPoolConfig jedisPoolConfig = null;
	private static Jedis jedis = null;

	/**
	 * prepare mocks before class is loaded
	 */
	@Before
	public void startUp() {
		PowerMockito.mockStatic(PropertyFileHelper.class);
		PowerMockito.doReturn("someHost:8080").when(PropertyFileHelper.class);
		PropertyFileHelper.getRedisMaster();
		Set<String> sentinals = new HashSet<>();
		PowerMockito.doReturn(sentinals).when(PropertyFileHelper.class);
		PropertyFileHelper.getSentinelHostsAndPorts();
		PowerMockito.doReturn("1000").when(PropertyFileHelper.class);
		PropertyFileHelper.getRedisTimeout();
		PowerMockito.doReturn("password").when(PropertyFileHelper.class);
		PropertyFileHelper.getRedisAuth();
		PowerMockito.doReturn("80").when(PropertyFileHelper.class);
		PropertyFileHelper.getRedisMaxActive();
		
		PowerMockito.mockStatic(AuthUtil.class);
		jedisPool = PowerMockito.mock(JedisPool.class);
		PowerMockito.doReturn(jedisPool).when(AuthUtil.class);
		AuthUtil.getJedisPool(Mockito.any(GenericObjectPoolConfig.class), Mockito.anyString(), Mockito.anyInt(),
				Mockito.anyInt(), Mockito.anyString());
		
		PowerMockito.doReturn(jedisPool).when(AuthUtil.class);
		AuthUtil.getJedisSentinelPool(Mockito.any(GenericObjectPoolConfig.class), Mockito.anyString(),
				Mockito.anyObject(), Mockito.anyInt(), Mockito.anyString());
		
		jedisPoolConfig = PowerMockito.mock(JedisPoolConfig.class);
		PowerMockito.doReturn(jedisPoolConfig).when(AuthUtil.class);
		AuthUtil.getJedisPoolConfig();
		jedis = PowerMockito.mock(Jedis.class);
		
			PowerMockito.mockStatic(PropertyFileHelper.class);
			Mockito.when(PropertyFileHelper.getOpenAMCookieName()).thenReturn("AUTHN_TOKEN");
	}
	

	/**
	 * test for constructor
	 */
	@Test
	public void testConstructor() {
		// actual test
		JedisConnectionPoolService inst = JedisConnectionPoolService.getInstance();
		// verification
		assertNotNull(inst);
	}
	
	

	@Test
	public void testReturnJedisConnection() {
		// actual test
		try{
			new AuthNRedisConnectionPoolServiceImpl().returnJedisConnection(jedis);
		}catch(Exception e){
			Assert.fail();
		}
	}

	@Test
	public void testConstructor_noop() {
		PowerMockito.mockStatic(PropertyFileHelper.class);
		PowerMockito.doReturn("someHost").when(PropertyFileHelper.class);
		PropertyFileHelper.getRedisMaster();
		// actual test
		JedisConnectionPoolService inst = new JedisConnectionPoolService();
		// verification
		assertNotNull(inst);
	}
	
	@Test
	public void testConstructor_sentinel() {
		PowerMockito.mockStatic(PropertyFileHelper.class);
		PowerMockito.doReturn("someHost").when(PropertyFileHelper.class);
		PropertyFileHelper.getRedisMaster();
		Set<String> sentinals = new HashSet<>();
		PowerMockito.doReturn(sentinals).when(PropertyFileHelper.class);
		PropertyFileHelper.getSentinelHostsAndPorts();
		PowerMockito.doReturn("1000").when(PropertyFileHelper.class);
		PropertyFileHelper.getRedisTimeout();
		PowerMockito.doReturn("password").when(PropertyFileHelper.class);
		PropertyFileHelper.getRedisAuth();
		PowerMockito.doReturn("80").when(PropertyFileHelper.class);
		PropertyFileHelper.getRedisMaxActive();

		PowerMockito.mockStatic(AuthUtil.class);
		jedisPool = PowerMockito.mock(JedisPool.class);
		
		PowerMockito.doReturn(jedisPool).when(AuthUtil.class);
		AuthUtil.getJedisSentinelPool(Mockito.any(GenericObjectPoolConfig.class), Mockito.anyString(),
				Mockito.anyObject(), Mockito.anyInt(), Mockito.anyString());
		
		jedisPoolConfig = PowerMockito.mock(JedisPoolConfig.class);
		PowerMockito.doReturn(jedisPoolConfig).when(AuthUtil.class);
		AuthUtil.getJedisPoolConfig();
		jedis = PowerMockito.mock(Jedis.class);
		
		// actual test
		JedisConnectionPoolService inst = new JedisConnectionPoolService();
		// verification
		assertNotNull(inst);
	}
}
