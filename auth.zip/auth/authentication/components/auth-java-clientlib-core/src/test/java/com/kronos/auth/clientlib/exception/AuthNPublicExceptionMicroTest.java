package com.kronos.auth.clientlib.exception;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

import com.kronos.auth.clientlib.util.AuthConstants;

import junit.framework.TestCase;

@RunWith(JUnit4.class)
public class AuthNPublicExceptionMicroTest {
	AuthNPublicException fixture = new AuthNPublicException();
	AuthNPublicException fixtureWithArg = new AuthNPublicException("TestMessage", AuthConstants.BAD_GATEWAY);
	AuthNPublicException fixtureWithMoreArg = new AuthNPublicException("TestMessage", AuthConstants.BAD_GATEWAY,new Throwable());
	@Test
	public void testGetStatus(){
		//Test data setup
		//verification
		TestCase.assertEquals(AuthConstants.INTERNAL_SERVER_ERROR,fixture.getStatus());
		TestCase.assertEquals(AuthConstants.BAD_GATEWAY,fixtureWithArg.getStatus());
		TestCase.assertEquals(AuthConstants.BAD_GATEWAY,fixtureWithMoreArg.getStatus());
	}

}
