package com.kronos.auth.redis.impl;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.kronos.auth.clientlib.util.AuthUtil;
import com.kronos.auth.clientlib.util.PropertyFileHelper;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPubSub;

@RunWith(PowerMockRunner.class)
@PrepareForTest({AuthUtil.class,PropertyFileHelper.class,AuthNRedisConnectionPoolServiceImpl.class})

public class NoOpJedisMicroTest {

	private static final String CHANNEL = "TEMP";
	
	@Test
	public void testNoOpJedisPool() {
		NoOpJedisPool pool = new NoOpJedisPool();
		Jedis jedis = pool.getResource();
		Assert.assertNotNull(jedis);
		pool.returnResourceObject(jedis);
		pool.close();
	}
	
	@Test
	public void testNoOpJedis() {
		Jedis jedis = new NoOpJedis();
		Assert.assertTrue(jedis.isConnected());
		
		JedisPubSub pubsub = new JedisPubSub() {
		};
		
		jedis.subscribe(pubsub, CHANNEL);
		Assert.assertTrue(jedis.publish(CHANNEL, NoOpJedis.REDIS_VALUE) == 0);
		
		jedis.set(NoOpJedis.REDIS_KEY, NoOpJedis.REDIS_VALUE);
		Assert.assertEquals(NoOpJedis.REDIS_VALUE, jedis.get(NoOpJedis.REDIS_KEY));
		Assert.assertTrue(jedis.expire(NoOpJedis.REDIS_KEY, 0) == 0);
		Assert.assertTrue(jedis.del(NoOpJedis.REDIS_KEY) == 0);
		
		jedis.close();
	}
}
