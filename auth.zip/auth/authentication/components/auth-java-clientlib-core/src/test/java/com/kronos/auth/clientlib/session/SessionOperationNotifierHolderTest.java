package com.kronos.auth.clientlib.session;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

/**
 * Unit tests
 * @author Sandeep.Agrrawal
 *
 */
public class SessionOperationNotifierHolderTest {

	SessionOperationNotifier notifier;
	
	@Before
	public void setUp() throws Exception {
		notifier = Mockito.mock(SessionOperationNotifierImpl.class);
	}
	
	@Test
	public void testSetSessionOperationNotifierImpl() {
		SessionOperationNotifierHolder holder = new SessionOperationNotifierHolder();
		holder.setSessionOperationNotifier(notifier);
		Assert.assertNotNull(SessionOperationNotifierHolder.getSessionOperationNotifierImpl());
	}

	@Test
	public void testSetSessionOperationNotifierImpl_null() {
		SessionOperationNotifierHolder holder = new SessionOperationNotifierHolder();
		holder.setSessionOperationNotifier(null);
		Assert.assertNull(SessionOperationNotifierHolder.getSessionOperationNotifierImpl());
	}
}
