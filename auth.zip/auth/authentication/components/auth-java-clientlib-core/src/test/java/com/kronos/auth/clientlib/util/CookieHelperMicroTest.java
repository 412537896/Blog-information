package com.kronos.auth.clientlib.util;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

@RunWith(PowerMockRunner.class)
@PrepareForTest(PropertyFileHelper.class)
public class CookieHelperMicroTest {

	@Before
	public void setUp() {
		PowerMockito.mockStatic(PropertyFileHelper.class);
		PowerMockito.doReturn("someurl").when(PropertyFileHelper.class);
		PropertyFileHelper.getApplicationURL();
	}
	
	@Test
	public void testDeleteCookie() throws Exception {
		HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
		HttpServletResponse response = Mockito.mock(HttpServletResponse.class);
		Cookie[] cookies = new Cookie[1];
		cookies[0] = new Cookie(AuthConstants.FALLBACK_AUTHN_TOKEN, "dummyValue");
		PowerMockito.doReturn(cookies).when(request).getCookies();
		PowerMockito.doNothing().when(response).addCookie(Mockito.anyObject());
		CookieHelper.deleteCookie(request, response, AuthConstants.FALLBACK_AUTHN_TOKEN);
		Mockito.verify(response,Mockito.times(1)).addCookie(Mockito.anyObject());
	}
	
	@Test
	public void testGetCookie() throws Exception {
		Cookie[] cookies = new Cookie[1];
		cookies[0] = new Cookie(AuthConstants.OPENAM_COOKIE_AUTHN_SSID, "somevalue");
		
		HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
		PowerMockito.doReturn(cookies).when(request).getCookies();
		
		Cookie value = CookieHelper.getCookie(request, AuthConstants.OPENAM_COOKIE_AUTHN_SSID);
		Assert.assertNotNull(value);
		Assert.assertEquals("somevalue", value.getValue());
	}
	
	@Test
	public void testGetCookieValue() throws Exception {
		Cookie[] cookies = new Cookie[1];
		cookies[0] = new Cookie(AuthConstants.OPENAM_COOKIE_AUTHN_SSID, "somevalue");
		
		HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
		PowerMockito.doReturn(cookies).when(request).getCookies();
		
		String value = CookieHelper.getCookieValue(request, AuthConstants.OPENAM_COOKIE_AUTHN_SSID);
		Assert.assertNotNull(value);
		Assert.assertEquals("somevalue", value);
		
		value = CookieHelper.getCookieValue(request, AuthConstants.IPLANET_COOKIE);
		Assert.assertNotNull(value);
		Assert.assertEquals("somevalue", value);
	}

	@Test
	public void testGetBaseUrl() throws Exception {
		HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
		PowerMockito.doReturn("http").when(request).getScheme();
		PowerMockito.doReturn("servername").when(request).getServerName();
		PowerMockito.doReturn(8080).when(request).getServerPort();
		PowerMockito.doReturn("/context").when(request).getContextPath();
		String value = CookieHelper.getBaseUrl(request);
		Assert.assertEquals("http://servername:8080/context", value);
	}

	@Test
	public void testGetNotificationURL_Refresh() throws Exception {
		String value = CookieHelper.getNotificationURL(true);
		Assert.assertEquals(PropertyFileHelper.getApplicationURL() + CookieHelper.REFRESH_API, value);
	}

	@Test
	public void testGetNotificationURL_Logout() throws Exception {
		String value = CookieHelper.getNotificationURL(false);
		Assert.assertEquals(PropertyFileHelper.getApplicationURL() + CookieHelper.LOGOUT_API, value);
	}
	
	@Test
	public void testGetCookie_No_Cookie() throws Exception {
		Cookie[] cookies = new Cookie[1];
		cookies[0] = new Cookie("InvalidCookie", "somevalue");
		
		HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
		PowerMockito.doReturn(cookies).when(request).getCookies();
		
		Cookie value = CookieHelper.getCookie(request, AuthConstants.OPENAM_COOKIE_AUTHN_SSID);
		Assert.assertNull(value);
	}
	
	@Test
	public void testGetCookie_Null_Cookie() throws Exception {
		HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
		PowerMockito.doReturn(null).when(request).getCookies();
		
		Cookie value = CookieHelper.getCookie(request, AuthConstants.OPENAM_COOKIE_AUTHN_SSID);
		Assert.assertNull(value);
	}

}
