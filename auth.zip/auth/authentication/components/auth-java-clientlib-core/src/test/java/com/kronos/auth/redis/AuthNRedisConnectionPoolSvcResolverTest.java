package com.kronos.auth.redis;

import java.util.Optional;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.modules.junit4.PowerMockRunner;

import com.kronos.auth.redis.api.AuthNRedisConnectionPoolService;

import redis.clients.jedis.Jedis;

/**
 * 
 * @author Sandeep.Agrrawal
 *
 */
@RunWith(PowerMockRunner.class)
public class AuthNRedisConnectionPoolSvcResolverTest {

	private CustomAuthNRedisConnectionPoolServiceTestImpl customRedisPoolSvcMock;

	private AuthNRedisConnectionPoolSvcResolver resolver;
	
	@Before
	public void startUp() {
		customRedisPoolSvcMock = new CustomAuthNRedisConnectionPoolServiceTestImpl();
		
		resolver = new AuthNRedisConnectionPoolSvcResolver();
		resolver.cleanUp();
	}

	@Test
	public void testGetAuthNRedisConnectionPoolService_ALL_NULL() {
		resolver.defaultRedisConnPoolSvc = customRedisPoolSvcMock;
		AuthNRedisConnectionPoolService redisPoolSvc = resolver.getAuthNRedisConnectionPoolService();
		resolver.logStatus();
		Assert.assertNotNull(redisPoolSvc);
	}

	@Test
	public void testGetAuthNRedisConnectionPoolService_CUSTOM() {
		resolver.customRedisConnPoolSvc = Optional.of(customRedisPoolSvcMock);
		AuthNRedisConnectionPoolService redisPoolSvc = resolver.getAuthNRedisConnectionPoolService();
		resolver.logStatus();
		Assert.assertEquals(customRedisPoolSvcMock, redisPoolSvc);
	}

	@Test
	public void testGetAuthNRedisConnectionPoolService_CUSTOM_EMPTY() {
		resolver.customRedisConnPoolSvc = Optional.empty();
		AuthNRedisConnectionPoolService redisPoolSvc = resolver.getAuthNRedisConnectionPoolService();
		resolver.logStatus();
		Assert.assertNotNull(redisPoolSvc);
	}
	
	@Test
	public void testGetAuthNRedisConnectionPoolService_CUSTOM_NULL() {
		resolver.customRedisConnPoolSvc = null;
		AuthNRedisConnectionPoolService redisPoolSvc = resolver.getAuthNRedisConnectionPoolService();
		resolver.logStatus();
		Assert.assertNotNull(redisPoolSvc);
	}
	
	private class CustomAuthNRedisConnectionPoolServiceTestImpl implements AuthNRedisConnectionPoolService {
		@Override
		public Jedis getJedisConnection() {
			return null;
		}

		@Override
		public void returnJedisConnection(Jedis jedis) {

		}

		@Override
		public boolean isEnvironmentRedis() {
			return true;
		}
	}

}
