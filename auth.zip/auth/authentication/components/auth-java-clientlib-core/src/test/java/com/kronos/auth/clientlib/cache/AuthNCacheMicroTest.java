package com.kronos.auth.clientlib.cache;

import java.time.LocalDateTime;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

import com.google.common.cache.RemovalListener;
import com.google.common.cache.RemovalNotification;

/**
 * Unit Test for AuthNCache
 * @author Sandeep.Agrrawal
 *
 */
@RunWith(JUnit4.class)
public class AuthNCacheMicroTest implements RemovalListener<String, AuthNCacheObject> {
	
	private static final String TEST_KEY = "TESTKEY";
	private static final String TOKEN = "SSO Token";
	private static final String SESSIONID = "JSessionId";
	private static final String AUTHN_TOKEN = "AUTHN TOKEN";
	
	private AuthNCache authNCache;
	private AuthNCacheObject object;
	
	@Before
	public void setUp() {
		AuthNCache.createAuthNCache(this);
		this.authNCache = AuthNCache.getAuthNCache();
		this.object = new AuthNCacheObject(TOKEN, SESSIONID, AUTHN_TOKEN, LocalDateTime.now());
	}
	
	@Test
	public void testCreateAuthNCache(){
		AuthNCache.createAuthNCache(this);
		Assert.assertNotNull(AuthNCache.getAuthNCache());
	}

	@Test
	public void testGetValue() {
		authNCache.putValue(TEST_KEY, this.object);
		Assert.assertEquals(TOKEN, authNCache.getValue(TEST_KEY).getSsoToken());
	}
	@Test
	public void testGetValue_NULL() {
		authNCache.removeKey(TEST_KEY);
		Assert.assertNull(authNCache.getValue(TEST_KEY));
	}
	
	@Test
	public void testPutValue_NULL() {
		boolean value = authNCache.putValue(TEST_KEY, null);
		Assert.assertFalse(value);
	}

	@Test
	public void testRemoveKey() {
		authNCache.putValue(TEST_KEY, this.object);
		authNCache.removeKey(TEST_KEY);
		Assert.assertNull(authNCache.getValue(TEST_KEY));
	}

	@Test
	public void checkKey() {
		authNCache.putValue(TEST_KEY, this.object);
		Assert.assertNotNull(authNCache.getValue(TEST_KEY));
	}
	
	@Override
	public void onRemoval(RemovalNotification<String, AuthNCacheObject> arg0) {
		// TODO Auto-generated method stub
		
	}
}
