package com.kronos.auth.redis;

import java.util.Optional;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.modules.junit4.PowerMockRunner;

import com.kronos.auth.redis.api.AuthNRedisOperations;

/**
 * 
 * @author Sandeep.Agrrawal
 *
 */
@RunWith(PowerMockRunner.class)
public class AuthNRedisOperationResolverTest {

	private AuthNRedisOperations customRedisOperations;

	private AuthNRedisOperationResolver resolver;

	@Before
	public void setUp() {
		customRedisOperations = Mockito.mock(AuthNRedisOperations.class);
		resolver = new AuthNRedisOperationResolver();
		resolver.cleanUp();
	}

	@Test
	public void testGetAuthNRedisOperations_ALL_NULL() {
		resolver.customRedisOperations = null;
		resolver.authnRedisOperations = customRedisOperations;
		AuthNRedisOperations redisOps = resolver.getAuthNRedisOperations();
		resolver.logStatus();
		Assert.assertNotNull(redisOps);
	}

	@Test
	public void testGetAuthNRedisOperations_CUSTOM() {
		PowerMockito.doReturn(true).when(customRedisOperations).isEnvironmentRedis();
		resolver.customRedisOperations = Optional.of(customRedisOperations);
		AuthNRedisOperations redisOps = resolver.getAuthNRedisOperations();
		resolver.logStatus();
		Assert.assertEquals(customRedisOperations, redisOps);
	}

	@Test
	public void testGetAuthNRedisOperations_CUSTOM_ENV_RADIS_FALSE() {
		PowerMockito.doReturn(false).when(customRedisOperations).isEnvironmentRedis();
		resolver.customRedisOperations = Optional.of(customRedisOperations);
		AuthNRedisOperations redisOps = resolver.getAuthNRedisOperations();
		resolver.logStatus();
		Assert.assertNotNull(redisOps);
	}

	@Test
	public void testGetAuthNRedisOperations_CUSTOM_EMPTY() {
		resolver.customRedisOperations = Optional.empty();
		AuthNRedisOperations redisOps = resolver.getAuthNRedisOperations();
		resolver.logStatus();
		Assert.assertNotNull(redisOps);
	}

	@Test
	public void testGetAuthNRedisOperations_CUSTOM_NULL() {
		resolver.customRedisOperations = null;
		AuthNRedisOperations redisOps = resolver.getAuthNRedisOperations();
		resolver.logStatus();
		Assert.assertNotNull(redisOps);
	}
}
