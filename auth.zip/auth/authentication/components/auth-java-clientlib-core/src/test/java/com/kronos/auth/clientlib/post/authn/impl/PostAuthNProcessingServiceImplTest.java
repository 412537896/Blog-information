package com.kronos.auth.clientlib.post.authn.impl;

import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.kronos.auth.clientlib.api.AuthNTokenProvider;
import com.kronos.auth.clientlib.impl.AuthNTokenProviderImpl;
import com.kronos.auth.clientlib.post.authn.api.AuthzAccessValidator;
import com.kronos.auth.clientlib.post.authn.api.PostAuthNProcessor;
import com.kronos.auth.clientlib.post.authn.impl.PostAuthNProcessingServiceImpl;
import com.kronos.auth.clientlib.util.AuthConstants;
import com.kronos.auth.clientlib.util.AuthUtil;
import com.kronos.auth.clientlib.util.CookieHelper;
import com.kronos.auth.domain.UserInfo;
import com.mockrunner.mock.web.MockHttpServletRequest;
import com.mockrunner.mock.web.MockHttpServletResponse;


@RunWith(PowerMockRunner.class)
@PrepareForTest({ PostAuthNProcessor.class})
public class PostAuthNProcessingServiceImplTest {
	
	
	@Mock
	PostAuthNProcessor postAuthnProcessrorMock = PowerMockito.mock(PostAuthNProcessor.class);
	
	
	@InjectMocks
    PostAuthNProcessingServiceImpl postAuthNService  = new PostAuthNProcessingServiceImpl();

	@Mock
    AuthNTokenProvider authNTokenProvider = PowerMockito.mock(AuthNTokenProviderImpl.class);
	
    @Mock
    private HttpServletRequest request = PowerMockito.mock(MockHttpServletRequest.class);
    
    @Mock
    private HttpServletResponse response = PowerMockito.mock(MockHttpServletResponse.class);
    
    @Mock 
    PostAuthNProcessor postAuthNProcessorMock = PowerMockito.mock(PostAuthNProcessor.class);
    
    @Mock 
    AuthzAccessValidator authzAccessValidatorMock = PowerMockito.mock(AuthzAccessValidator.class);
    
    
	@Test
	public void testSetCustomCookies_Authorized() throws Exception {
		UserInfo userInfo = new UserInfo("user", "tenant");
		PowerMockito.when(authNTokenProvider.getUserInfo(request)).thenReturn(userInfo);
		PowerMockito.doNothing().when(postAuthnProcessrorMock).setSessionCookies(request, response);
		
		String setCustomCookies = postAuthNService.performPostAuthNInitializeSession(request,response);
		System.out.println(setCustomCookies);
		Assert.assertEquals(setCustomCookies, AuthConstants.ACCEPTED);
	}
	
	@Test
	public void testSetCustomCookies_UnAuthorized_NotValidToken() throws Exception {
		PowerMockito.when(authNTokenProvider.getUserInfo(request)).thenReturn(null);
		PowerMockito.doNothing().when(postAuthnProcessrorMock).setSessionCookies(request, response);
		String setCustomCookies = postAuthNService.performPostAuthNInitializeSession(request,response);
		System.out.println(setCustomCookies);
		Assert.assertEquals(setCustomCookies, AuthConstants.UNAUTHORIZED);
	}
	
	@Test
	public void testSetCustomCookies_UnAuthorized_Exception() throws Exception {
		PowerMockito.when(authNTokenProvider.getUserInfo(request)).thenThrow(new RuntimeException());
		String setCustomCookies = postAuthNService.performPostAuthNInitializeSession(request,response);
		Assert.assertEquals(setCustomCookies, AuthConstants.UNAUTHORIZED);
	}
	
	@Test
	@PrepareForTest({CookieHelper.class})
	public void testSetCustomCookies_Authorized_Not_Null_PostAuthNProcessor() throws Exception {
		postAuthNService.postAuthNProcessorExists=Optional.of(postAuthNProcessorMock);
		UserInfo userInfo = new UserInfo("user", "tenant");
		PowerMockito.when(authNTokenProvider.getUserInfo(request)).thenReturn(userInfo);
		PowerMockito.doNothing().when(postAuthnProcessrorMock).setSessionCookies(request, response);
		
		String setCustomCookies = postAuthNService.performPostAuthNInitializeSession(request,response);
		Assert.assertEquals(setCustomCookies, AuthConstants.ACCEPTED);
	}
	
	@Test
	@PrepareForTest({CookieHelper.class})
	public void testSetCustomCookies_Authorized_Not_Null_AuthzAccessValidator() throws Exception {
		postAuthNService.accessValidator=Optional.of(authzAccessValidatorMock);
		UserInfo userInfo = new UserInfo("user", "tenant");
		PowerMockito.when(authNTokenProvider.getUserInfo(request)).thenReturn(userInfo);
		PowerMockito.doNothing().when(postAuthnProcessrorMock).setSessionCookies(request, response);
		
		String setCustomCookies = postAuthNService.performPostAuthNInitializeSession(request,response);
		Assert.assertEquals(setCustomCookies, AuthConstants.ACCEPTED);
	}
	
}
