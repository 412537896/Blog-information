package com.kronos.auth.clientlib.exception;

import org.junit.Test;

import com.kronos.auth.clientlib.util.AuthConstants;

import junit.framework.TestCase;

public class AuthNTokenPublicExceptionMicroTest {

	AuthNTokenPublicException fixture = new AuthNTokenPublicException();
	AuthNTokenPublicException fixtureWithArgs = new AuthNTokenPublicException("TestMessage", AuthConstants.BAD_GATEWAY);
	@Test
	public void testGetStatus(){
		//verification
		TestCase.assertEquals(AuthConstants.INTERNAL_SERVER_ERROR,fixture.getStatus());
		TestCase.assertEquals(AuthConstants.BAD_GATEWAY,fixtureWithArgs.getStatus());
	}
}
