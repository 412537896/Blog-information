package com.kronos.auth.clientlib.cache;

import java.time.LocalDateTime;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

/**
 * Unit Test for  AuthNCacheObject
 * @author Sandeep.Agrrawal
 *
 */
@RunWith(JUnit4.class)
public class AuthNCacheObjectMicroTest {
	 
	@Test
	public void testAuthCacheObject() {
		String token = "test-token";
		String sid = "jSessionId";
		String authn = "AuthNToken";
		
		LocalDateTime datetime = LocalDateTime.of(2015, 1, 1, 1, 1);
		AuthNCacheObject object = new AuthNCacheObject(token, sid, authn, datetime);
		object.setPublishMessage(true);
		Assert.assertEquals(token, object.getSsoToken());
		Assert.assertEquals(sid, object.getjSessionId());
		Assert.assertEquals(authn, object.getAuthNToken());
		Assert.assertTrue(LocalDateTime.now().isAfter(object.getLocalDateTime()));
		Assert.assertTrue(object.isPublishMessage());
	}
}
