package com.kronos.auth.encryption.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.security.spec.KeySpec;
import java.util.Properties;

import javax.crypto.spec.PBEKeySpec;

/**
 * Util class to get Instances
 * 
 * @author Sumit.Sharma
 *
 */
public class InstanceUtil {

	/**
	 * Private constructor just to make single design
	 */
	private InstanceUtil() {
	}

	/**
	 * Used to getInstance of FileInputStream
	 * 
	 * @param confFile
	 * @return
	 * @throws FileNotFoundException
	 */
	protected static FileInputStream getInputStream(String confFile) throws FileNotFoundException {
		FileInputStream inputStream;
		inputStream = new FileInputStream(confFile);
		return inputStream;
	}

	/**
	 * Used to getInstance of Properties
	 * 
	 * @return Properties
	 */
	protected static Properties getProperties() {
		return new Properties();
	}

	/**
	 * Used to getInstance of File
	 * 
	 * @param confFile
	 * @return
	 * @throws FileNotFoundException
	 */
	protected static File getFileInstance(String confFile){
		return new File(confFile);
	}

}