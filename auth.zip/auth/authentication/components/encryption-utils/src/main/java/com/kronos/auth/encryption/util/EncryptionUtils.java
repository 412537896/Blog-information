package com.kronos.auth.encryption.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.security.Key;
import java.util.Base64;
import java.util.Properties;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kronos.auth.encryption.constants.AppConstants;
import com.kronos.auth.encryption.exception.EncryptionException;

/**
 * Helper class which provides convenience methods for Encrypting/Decrypting
 * Cookie Values
 * 
 * No need to instantiate this class as all members and methods are static
 * 
 * 
 */
/**
 * @author Sumit.Sharma
 *
 */
public class EncryptionUtils {
	/**
	 * No need to instantiate this class as all members and methods are static
	 */
	private EncryptionUtils() {

	}

	private static Logger xlogger = LoggerFactory.getLogger(EncryptionUtils.class);
	private static boolean openAMParamsInitialized = false;
	private static String TOMCAT_CONFIG = null;
	private static final String CATALINA_BASE = "catalina.base";
	private static final String PASS_KEY = "key_password";
	private static String encryptionKey;
	private static final String REASON = ",Reason [";
	private static String defaultPass = "$tr0ngKeY@123#56";

	/**
	 * Encrypts the plain text passed in as parameter. The encrypted value is
	 * Base64 encoded
	 * 
	 * @param data
	 * @return encryptedValue
	 * @throws EncryptionException
	 * 
	 */
	public static String encrypt(String data) throws EncryptionException {
		if (data == null) {
			return null;
		}
		try {
			Key key = generateKey();
			String encryptedValue = null;
			if (null != key) {
				Cipher c = Cipher.getInstance(AppConstants.ALGORITHM_AES);
				c.init(Cipher.ENCRYPT_MODE, key);
				byte[] encVal = c.doFinal(data.getBytes());
				encryptedValue = new String(Base64.getEncoder().encode(encVal));
				encryptedValue = encryptedValue.replaceAll("=", "-");
			}
			return encryptedValue;
		} catch (Exception e) {
			throw getEncryptionException("Exception occured during encryption" + REASON + e.getMessage() + "]", e);
		}
	}

	/**
	 * Decrypts the ciphertext passed in as parameter.
	 * 
	 * @param encryptedDatas
	 * @return originalData
	 * @throws EncryptionException
	 *
	 */
	public static String decrypt(String encryptedData) throws EncryptionException {
		String encryData = encryptedData;
		String originalData = null;
		if (encryData == null) {
			return null;
		}
		encryData = encryData.replaceAll("-", "=");
		try {
			Key key = generateKey();
			if (null != key) {
				Cipher c = Cipher.getInstance(AppConstants.ALGORITHM_AES);
				c.init(Cipher.DECRYPT_MODE, key);
				byte[] decordedValue = Base64.getDecoder().decode(encryData);
				byte[] decValue = c.doFinal(decordedValue);
				originalData=new String(decValue);
			}
			return originalData;
		} catch (Exception e) {
			throw getEncryptionException("Exception occured during decryption" + REASON + e.getMessage() + "]", e);
		}
	}

	/**
	 * Generates the key
	 * 
	 * @return key
	 * @throws EncryptionException
	 */
	public static Key generateKey() throws EncryptionException {
		if (!openAMParamsInitialized || null == encryptionKey) {
			initOpenAMConfig();
		}
		if (encryptionKey == null || encryptionKey.trim().isEmpty()) {
			throw getEncryptionException("Encryption Key password value can't be null", null);
		}
		xlogger.debug("getOpenAMServerURL() : paramsInitialized [{}]", openAMParamsInitialized);
		try {
			return new SecretKeySpec(encryptionKey.getBytes(), AppConstants.ALGORITHM_AES);
		} catch (Exception e) {
			xlogger.error("Error Generating encryption key. Reason={}, Exception Details= {}", e.getMessage(), e);
			throw getEncryptionException("SecretKeySpec key generation Error found" + REASON + e.getMessage() + "]", e);
		}
	}

	/**
	 * for setting default value of encryptionKey
	 */
	public static synchronized void setDefaultEncryptionKey(String value) {
		encryptionKey = value;
	}

	/**
	 * for setting default value of encryptionpassValue
	 */
	public static synchronized void setDefaultEncryptionKeyPass(String value) {
		defaultPass = value;
	}

	/**
	 * Intialize password value using system property/openAm.properties
	 * This method is marked as synchronized as it will be only called on initialization.
	 * 
	 * @throws EncryptionException
	 */
	public static synchronized void initOpenAMConfig() throws EncryptionException {
		openAMParamsInitialized = false;
		xlogger.info("initOpenAMConfig() : Start");
		if (null != System.getProperty(PASS_KEY)) {
			openAMParamsInitialized = true;
			encryptionKey = System.getProperty(PASS_KEY);
		} else {
			TOMCAT_CONFIG = System.getProperty(CATALINA_BASE) + "/conf/openam.properties";
			xlogger.debug("readConfig : TOMCAT_CONFIG - {}", TOMCAT_CONFIG);
			if (readConfig(TOMCAT_CONFIG)) {
				openAMParamsInitialized = true;
			}
		}
		xlogger.info("initOpenAMConfig() : End");
	}

	/**
	 * Reads the OpenAM config file
	 * 
	 * @param: configFile
	 * @return: true/false
	 * @throws EncryptionException
	 * This method is marked as synchronized as it will be only called on initialization.
	 */
	public static synchronized boolean readConfig(String configFile) throws EncryptionException {
		xlogger.info("readConfig() : Start");
		Properties openAMProps = InstanceUtil.getProperties();
		boolean initConfigDone = false;
		xlogger.debug("readConfig : configFile - [{}]", configFile);
		File file = InstanceUtil.getFileInstance(configFile);
		if (configFile != null && file.exists()) {
			initConfigDone = readFromFile(configFile, openAMProps);
		} else {
			xlogger.warn("openam.properties file doesn't not exist.");
			encryptionKey = defaultPass;
		}

		return initConfigDone;
	}

	/**
	 * Used to read property from file
	 * 
	 * @param configFile
	 * @param openAMProps
	 * @param initConfigDone
	 * @return
	 * @throws EncryptionException
	 * This method is marked as synchronized as it will be only called on initialization.
	 */
	private static synchronized boolean readFromFile(String configFile, Properties openAMProps) throws EncryptionException {
		FileInputStream inputStream = null;
		try {
			boolean initConfig = false;
			inputStream = InstanceUtil.getInputStream(configFile);
			openAMProps.load(inputStream);
			encryptionKey = openAMProps.getProperty(PASS_KEY);
			initConfig = encryptionKey != null;
			if (!initConfig) {
				xlogger.warn("Encryption key was not provided in openam.properties.");
				// TODO needs to be removed when key will be fully property
				encryptionKey = defaultPass;
				initConfig = true;
			}
			return initConfig;
		} catch (IOException ioe) {
			xlogger.error("Input/output exception occured during password read from OpenAm Properties. Reason={}, Exception Details= {}",ioe.getMessage(), ioe);
			throw getEncryptionException("Input/output exception occured during password read from OpenAm Properties"+ REASON + ioe.getMessage() + "]", ioe);
		} finally {
			if (inputStream != null) {
				try {
					inputStream.close();
				} catch (IOException ex) {
					xlogger.error("Unable to close inputStream. Reason={}, Exception Details= {}", ex.getMessage(), ex);
				}
			}
		}
	}

	/**
	 * Used to generate custom exception
	 * 
	 * @param errorMessage
	 * @param t
	 * @return
	 */
	public static EncryptionException getEncryptionException(String errorMessage, Throwable t) {
		String message = " : " + errorMessage;
		xlogger.error(message, t);
		String rootCause = "";
		if (t != null && t.getStackTrace() != null && t.getStackTrace().length > 0) {
			rootCause = t.getStackTrace()[0].getClassName();
			if (rootCause == null)
				rootCause = "";
			else
				rootCause = rootCause + "  :  ";
		}
		EncryptionException ex = new EncryptionException(rootCause + errorMessage, AppConstants.ENCRYPTION_EXCEPTION);
		return ex;
	}

}