package com.kronos.auth.encryption.exception;

/**
 * Custom Exception class for Encryption Util
 * 
 * @author Sumit.Sharma
 *
 */
public class EncryptionException extends Exception {

	private static final long serialVersionUID = 1L;

	private final String errorCode;
	private final String reason;

	public EncryptionException(String s, String errorCode) {
		reason = s;
		this.errorCode = errorCode;
	}

	public EncryptionException(String s, String errorCode, Throwable t) {
		super(s, t);
		reason = s;
		this.errorCode = errorCode;
	}

	/**
	 * @return the errorCode
	 */
	public String getErrorCode() {
		return errorCode;
	}

	public String getReason() {
		return reason;
	}

	

}
