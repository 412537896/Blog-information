package com.kronos.auth.encryption.constants;

/**
 * All constants related to encryption utils
 * @author Sumit.Sharma
 *
 */
public interface AppConstants {
	
	public static final String IV_VALUE = "RandomInitVector";
	public static final String BASE64 = "BASE64";
	public static final String ALGORITHM_AES = "AES";
	public static final String EMPTY_STRING = "";
	public static final String UTF_8 = "UTF-8";
	public static final String ENCRYPTION_EXCEPTION = "encryption_exception_occured";
	
}
