package com.kronos.auth.encryption.exception;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;
import junit.framework.TestCase;

@RunWith(JUnit4.class)
public class EncryptionExceptionMicroTest {
	
	@Test
	public void testGetStatus(){
		//Test data setup
		EncryptionException encryptExWithArgCode = new EncryptionException("TestMessage","Error-0002");
		EncryptionException encryptExWithArgThree = new EncryptionException("TestMessage","Error-0002",new Throwable());
		//verification
		TestCase.assertEquals("TestMessage",encryptExWithArgThree.getReason());
		TestCase.assertEquals("Error-0002",encryptExWithArgThree.getErrorCode());
		TestCase.assertEquals("TestMessage",encryptExWithArgCode.getReason());
		TestCase.assertEquals("Error-0002",encryptExWithArgCode.getErrorCode());
	}

}
