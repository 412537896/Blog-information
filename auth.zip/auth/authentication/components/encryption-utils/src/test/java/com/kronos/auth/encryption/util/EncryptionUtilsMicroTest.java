package com.kronos.auth.encryption.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import junit.framework.TestCase;

@RunWith(PowerMockRunner.class)
@PowerMockIgnore({"javax.crypto.*" })
public class EncryptionUtilsMicroTest extends TestCase {

	private static final String PLAINTEXT = "kronos";

	private static final String PLAINTEXT_ENCRYPTED = "JwJbghU373pscTK2T9K4kA--";

	@Before
	public void setup() {
		EncryptionUtils.setDefaultEncryptionKey(null);
		EncryptionUtils.setDefaultEncryptionKeyPass(null);
	}

	/**
	 * Ensures encryption is done correctly and there are no algorithm or key
	 * changes.
	 * 
	 * @throws Exception
	 */

	public void testEncryptWithKey() throws Exception {
		String encryptedValue = null;
		System.setProperty("key_password", "$tr0ngKeY@123#56");
		encryptedValue = EncryptionUtils.encrypt(PLAINTEXT);
		assertNotNull(encryptedValue);
		assertEquals(PLAINTEXT_ENCRYPTED, encryptedValue);

	}

	/**
	 * Ensures encryption is done correctly and there are no algorithm or key
	 * changes.
	 */
	public void testEncrypt() {
		String encryptedValue = null;
		boolean exceptionThrown = false;
		try {
			System.clearProperty("key_password");
			EncryptionUtils.setDefaultEncryptionKey(null);
			EncryptionUtils.setDefaultEncryptionKeyPass(null);
			encryptedValue = EncryptionUtils.encrypt(PLAINTEXT);
		} catch (Exception e) {
			exceptionThrown = true;
		}
		assertNull(encryptedValue);
		assertEquals(Boolean.TRUE.booleanValue(), exceptionThrown);
	}

	/**
	 * Ensures the cipher text is decrypted properly.
	 */
	public void testDecryptValidCipher() {
		String decryptedValue = null;
		try {
			System.setProperty("key_password", "$tr0ngKeY@123#56");
			decryptedValue = EncryptionUtils.decrypt(PLAINTEXT_ENCRYPTED);
		} catch (Exception e) {

		}
		//assertNotNull(decryptedValue);
		//assertEquals(PLAINTEXT, decryptedValue);
	}

	/**
	 * Ensures any incorrect text results in exception being thrown
	 */
	public void testDecryptInvalidCipher() {
		boolean exceptionThrown = false;
		String decryptedValue = null;
		try {
			System.setProperty("key_password", "$tr0ngKeY@123#565");
			decryptedValue = EncryptionUtils.decrypt("randomData");
		} catch (Exception e) {
			exceptionThrown = true;
		}
		assertEquals(Boolean.TRUE.booleanValue(), exceptionThrown);
		assertNull(decryptedValue);
	}

	/**
	 * Ensures the cipher text is decrypted properly.
	 */

	public void testDecryptNullData() {
		String decryptedValue = null;
		try {
			decryptedValue = EncryptionUtils.decrypt(null);
		} catch (Exception e) {
		}
		assertNull(decryptedValue);
	}

	/**
	 * Ensures the cipher text is decrypted properly.
	 */

	public void testEncryptNullData() {
		String encryptedValue = null;
		try {
			encryptedValue = EncryptionUtils.encrypt(null);
		} catch (Exception e) {
		}
		assertNull(encryptedValue);
	}

	@Test
	@PrepareForTest({ FileInputStream.class, Properties.class, InstanceUtil.class, File.class })
	public void testEncryptedUsingProp() throws Exception {
		System.clearProperty("key_password");
		EncryptionUtils.setDefaultEncryptionKey(null);
		FileInputStream mockInputStream = PowerMockito.mock(FileInputStream.class);
		File mockFile = PowerMockito.mock(File.class);
		PowerMockito.mockStatic(InstanceUtil.class);
		PowerMockito.when(InstanceUtil.getFileInstance(Mockito.anyString())).thenReturn(mockFile);
		PowerMockito.when(mockFile.exists()).thenReturn(true);
		PowerMockito.when(InstanceUtil.getInputStream(Mockito.anyString())).thenReturn(mockInputStream);
		Properties mockProperties = PowerMockito.mock(Properties.class);
		PowerMockito.when(InstanceUtil.getProperties()).thenReturn(mockProperties);
		PowerMockito.doNothing().when(mockProperties).load(mockInputStream);
		PowerMockito.when(mockProperties.getProperty(Mockito.anyString())).thenReturn("$tr0ngKeY@123#565");
		EncryptionUtils.initOpenAMConfig();
	}

	@Test(expected = Exception.class)
	@PrepareForTest({ FileInputStream.class, Properties.class, InstanceUtil.class, File.class })
	public void testGenKeyWithNullPass() throws Exception {
		FileInputStream mockInputStream = PowerMockito.mock(FileInputStream.class);
		File mockFile = PowerMockito.mock(File.class);
		PowerMockito.mockStatic(InstanceUtil.class);
		PowerMockito.when(InstanceUtil.getFileInstance(Mockito.anyString())).thenReturn(mockFile);
		PowerMockito.when(mockFile.exists()).thenReturn(true);
		PowerMockito.when(InstanceUtil.getInputStream(Mockito.anyString())).thenReturn(mockInputStream);
		Properties mockProperties = PowerMockito.mock(Properties.class);
		PowerMockito.when(InstanceUtil.getProperties()).thenReturn(mockProperties);
		PowerMockito.doNothing().when(mockProperties).load(mockInputStream);
		PowerMockito.when(mockProperties.getProperty(Mockito.anyString())).thenReturn(null);
		System.clearProperty("key_password");
		EncryptionUtils.setDefaultEncryptionKey(null);
		EncryptionUtils.setDefaultEncryptionKeyPass(null);
		EncryptionUtils.generateKey();
	}

	@Test
	@PrepareForTest({ FileInputStream.class, Properties.class, InstanceUtil.class, File.class })
	public void testReadConfigWithStreamError() throws Exception {
		FileInputStream mockInputStream = PowerMockito.mock(FileInputStream.class);
		File mockFile = PowerMockito.mock(File.class);
		PowerMockito.mockStatic(InstanceUtil.class);
		PowerMockito.when(InstanceUtil.getFileInstance(Mockito.anyString())).thenReturn(mockFile);
		PowerMockito.when(mockFile.exists()).thenReturn(true);
		PowerMockito.when(InstanceUtil.getInputStream(Mockito.anyString())).thenReturn(mockInputStream);
		Properties mockProperties = PowerMockito.mock(Properties.class);
		PowerMockito.when(InstanceUtil.getProperties()).thenReturn(mockProperties);
		PowerMockito.doNothing().when(mockProperties).load(mockInputStream);
		PowerMockito.when(mockProperties.getProperty(Mockito.anyString())).thenReturn("$tr0ngKeY@123#565");
		PowerMockito.doThrow(new IOException()).when(mockInputStream).close();
		EncryptionUtils.readConfig("openam.properties");
	}

	@Test
	@PrepareForTest({ FileInputStream.class, Properties.class, InstanceUtil.class, File.class })
	public void testReadConfigFileNotExist() throws Exception {
		File mockFile = PowerMockito.mock(File.class);
		PowerMockito.mockStatic(InstanceUtil.class);
		PowerMockito.when(InstanceUtil.getFileInstance(Mockito.anyString())).thenReturn(mockFile);
		PowerMockito.when(mockFile.exists()).thenReturn(false);
		EncryptionUtils.readConfig("openam.properties");

	}

	@Test(expected = Exception.class)
	@PrepareForTest({ FileInputStream.class, Properties.class, InstanceUtil.class, File.class })
	public void testReadConfigInvalidStream() throws Exception {
		FileInputStream mockInputStream = PowerMockito.mock(FileInputStream.class);
		File mockFile = PowerMockito.mock(File.class);
		PowerMockito.mockStatic(InstanceUtil.class);
		PowerMockito.when(InstanceUtil.getFileInstance(Mockito.anyString())).thenReturn(mockFile);
		PowerMockito.when(mockFile.exists()).thenReturn(true);
		PowerMockito.when(InstanceUtil.getInputStream(Mockito.anyString())).thenReturn(mockInputStream);
		Properties mockProperties = PowerMockito.mock(Properties.class);
		PowerMockito.when(InstanceUtil.getProperties()).thenReturn(mockProperties);
		PowerMockito.doThrow(new IOException()).when(mockProperties).load(mockInputStream);
		PowerMockito.doThrow(new IOException()).when(mockInputStream).close();
		EncryptionUtils.readConfig("openam.properties");
	}

}
