package com.kronos.auth.ldap.api;

/**
 * This interface defines the modify operation. 
 * 
 */
public interface LdapModify {
	/**
	 * This method modifies (add, update, delete) attributes on existing DN
	 * @return
	 * @throws LdapOperationException
	 */
	boolean executeModifyAttribute() throws LdapOperationException;

	/**
	 * This method will work on LDAP Entry and add that into store
	 * @return
	 * @throws LdapOperationException
	 */
	boolean executeAddEntry() throws LdapOperationException;

	/**
	 * This will take a DN and will delete all the sub-tree of it.
	 * @return
	 * @throws LdapOperationException
	 */
	boolean executeDeleteSubTree() throws LdapOperationException;

	/**
	 * This will modify the DN which is unique identifier in the system
	 * @return
	 * @throws LdapOperationException
	 */
	boolean executeModifyIdentifier() throws LdapOperationException;
}
