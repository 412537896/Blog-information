package com.kronos.auth.ldap.api;

import java.util.List;
import java.util.Map;

public interface LdapSearchResponse {

	public String getLdifasString();

	public String getAttributeValue(String outerMapKey, String ldifKey);

	List<Map<String, List<String>>> getLdifResult();
	
	public List<String> getSearchResultNameList();
}
