package com.kronos.auth.ldap.api;

public class LdapOperationException extends Exception {
	private static final long serialVersionUID = 1L;
	private String errorCode;
	private String reason;

	public LdapOperationException(String reason, String errorCode,Throwable arg1) {
		super(reason, arg1);
		this.reason = reason;
		this.errorCode=errorCode;
	}
	public LdapOperationException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		reason = arg0;
	}
	public LdapOperationException(String arg0,String errorCode) {
		super(arg0);
		reason = arg0;
		this.errorCode = errorCode;
	}
	public LdapOperationException(String arg0) {
		super(arg0);
		reason = arg0;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}


}
