package com.kronos.auth.ldap.api;

/**
 * 
 * This provides LDAP search functionality
 *
 */
@FunctionalInterface
public interface LdapSearch {
	/**
	 * Method which will provide search against LDAP
	 * @return
	 * @throws LdapOperationException
	 */
	public LdapSearchResponse executeSearch() throws LdapOperationException;
}
