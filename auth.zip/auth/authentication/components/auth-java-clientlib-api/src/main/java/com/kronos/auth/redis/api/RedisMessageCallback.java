package com.kronos.auth.redis.api;

/**
 * Interface that should be implemented to get Redis events
 * 
 * @author Sandeep.Agrrawal
 *
 */
@FunctionalInterface
public interface RedisMessageCallback {
	public void onMessage(String channel, String message);
}
