package com.kronos.auth.redis.api;

import java.lang.annotation.RetentionPolicy;

/**
 * Annotation to specify the default implementation of
 * AuthNRedisConnectionPoolService. It is provided by AuthN library itself. It
 * should not be used by other components. Other components should use
 * <code>CustomAuthNRedisPoolSvc</code>
 * 
 * @author Sandeep.Agrrawal
 *
 */
@java.lang.annotation.Documented
@java.lang.annotation.Retention(RetentionPolicy.RUNTIME)
@javax.inject.Qualifier
public @interface AuthNRedisPoolSvc {
}