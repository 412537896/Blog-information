package com.kronos.auth.redis.api;

import redis.clients.jedis.Jedis;

/**
 * Interface to work with Redis Connection. It should be implmented by
 * components which have Redis connection management and should be used in AuthN
 * library.
 * 
 * @author Sandeep.Agrrawal
 *
 */
public interface AuthNRedisConnectionPoolService {
	/**
	 * Returns Jedis connection which can be used for Redis Operations
	 * @return
	 */
	public Jedis getJedisConnection();

	/**
	 * Return given Jedis connection to pool
	 * @param jedis
	 */
	public void returnJedisConnection(Jedis jedis);

	/**
	 * Specifies if Redis used is running as Environment Service or not
	 * @return
	 */
	default public boolean isEnvironmentRedis() {
		return false;
	}
}
