package com.kronos.auth.redis.api;

import java.lang.annotation.RetentionPolicy;

/**
 * Annotation to specify the implementation of AuthNRedisConnectionPoolService.
 * Other components should use this annotation should specify which bean should
 * be used for injection.
 * 
 * @author Sandeep.Agrrawal
 *
 */
@java.lang.annotation.Documented
@java.lang.annotation.Retention(RetentionPolicy.RUNTIME)
@javax.inject.Qualifier
public @interface CustomAuthNRedisPoolSvc {
}
