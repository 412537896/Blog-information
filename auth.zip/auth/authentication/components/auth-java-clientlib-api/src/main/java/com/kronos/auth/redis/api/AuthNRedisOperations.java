package com.kronos.auth.redis.api;

/**
 * It defines all the operations that can be performed against Redis. Should be
 * implemented by components which already have Redis implementation and can be
 * reused by AuthN.
 * 
 * @author Sandeep.Agrrawal
 *
 */
public interface AuthNRedisOperations {
	/**
	 * Add Given Key Value pair to data store
	 * 
	 * @param key
	 * @param value
	 */
	public void add(String key, String value);

	/**
	 * Remove the given key from data store
	 * 
	 * @param key
	 */
	public void remove(String key);

	/**
	 * Return value for the given key as present in data store
	 * 
	 * @param key
	 * @return
	 */
	public String getValue(String key);

	/**
	 * Set the expiration time for given key to expire immediately
	 * 
	 * @param key
	 */
	public void expire(String key);

	/**
	 * Create subscription which can listen for messages on given channel and
	 * call the given callback for those messages
	 * 
	 * @param channel
	 * @param impl
	 */
	public void getSubscription(String channel, RedisMessageCallback impl);

	/**
	 * Publish the given message on given channel
	 * 
	 * @param channel
	 * @param message
	 */
	public void publish(String channel, String message);

	/**
	 * Specifies if Redis used is running as Environment Service or not
	 * 
	 * @return
	 */
	public boolean isEnvironmentRedis();
}