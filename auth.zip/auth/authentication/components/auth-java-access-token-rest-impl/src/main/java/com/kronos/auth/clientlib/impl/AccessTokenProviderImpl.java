package com.kronos.auth.clientlib.impl;

import java.net.URI;
import java.net.URISyntaxException;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.kronos.auth.clientlib.api.AccessTokenProvider;
import com.kronos.auth.clientlib.exception.AuthNPublicException;
import com.kronos.auth.clientlib.util.LoggerHelper;
import com.kronos.commonapp.kronosproperties.impl.KPropertiesImpl;

@Component
public class AccessTokenProviderImpl implements AccessTokenProvider {

	private static final String TARGET_DOMAIN_KEY = "global.oAuthToken.redirection.domain.whiteList";

	@Context 
	private HttpServletRequest request;
	
	public static final Logger LOGGER = LoggerFactory.getLogger(AuthNTokenProviderImpl.class);
	
	@Override
	public Response getAccessToken(String clientId, String targetUrl){
		LoggerHelper.info(LOGGER,"getAccessToken called for clientId : " , clientId);
		if(clientId == null || clientId.equals("") ) {
			LoggerHelper.error(LOGGER,"client id is null or blank");
			return sendErrorResponse();
		}
		AuthNTokenProviderImpl authNTokenProviderImpl = getAuthnTokenProviderImpl();
		try {
			if(!validateTargetUrl(targetUrl)) {
				LoggerHelper.error(LOGGER,"invalid target URL: " , targetUrl);
				return sendErrorResponse();
			}
			LoggerHelper.info(LOGGER,"getAccessToken called for clientId :{}, and targetURl; {} " , clientId, targetUrl);
			return Response.ok(authNTokenProviderImpl.getAccessToken(request,clientId)).build();
		}catch (URISyntaxException e) {
			LoggerHelper.error(LOGGER,"Target URL syntax invalid. targetURL : [{}]" ,targetUrl, e);
			return sendErrorResponse();
		} catch (AuthNPublicException e) {
			LoggerHelper.error(LOGGER,"getAccessToken failed with exception: " , e);
			return sendErrorResponse();
		}
	}
	
	protected AuthNTokenProviderImpl getAuthnTokenProviderImpl() {
		return new AuthNTokenProviderImpl();
	}


	private Response sendErrorResponse() {
		return Response.status(Response.Status.BAD_REQUEST).type(MediaType.TEXT_HTML).entity("Invalid Request").build();
	}

	protected boolean validateTargetUrl(String targetUrl) throws URISyntaxException {
		boolean isTargetUrlValid = false;
		URI uri = new URI(targetUrl);
		String domain = uri.getHost();
		KPropertiesImpl kPropertiesImpl = getKProperties();
		String domainWhiteListString = kPropertiesImpl.get(TARGET_DOMAIN_KEY,"");
		if(domainWhiteListString != null  && !"".equals(domainWhiteListString) && targetUrl != null && !"".equals(targetUrl)) {
		String[] domainWhiteList = domainWhiteListString.split(",");
			for (String allowedDomain : domainWhiteList) {
				if(domain.endsWith(allowedDomain)) {
					isTargetUrlValid = true;
					break;
				}
			}
		}
		
		return isTargetUrlValid;
	}

	protected KPropertiesImpl getKProperties() {
		return new KPropertiesImpl();
		 
	}
}
