package com.kronos.auth.clientlib.impl;

import java.net.URISyntaxException;

import javax.servlet.http.HttpServletRequest;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.kronos.auth.clientlib.api.AuthNTokenProvider;
import com.kronos.auth.clientlib.exception.AuthNPublicException;
import com.kronos.commonapp.kronosproperties.impl.KPropertiesImpl;
import com.mockrunner.mock.web.MockHttpServletRequest;

import junit.framework.TestCase;

@RunWith(PowerMockRunner.class)
@PrepareForTest(KPropertiesImpl.class)
public class AccessTokenProviderImplTest extends TestCase{
	@Mock
    private HttpServletRequest request = PowerMockito.mock(MockHttpServletRequest.class);
	
	@Mock 
	private KPropertiesImpl kProperties= PowerMockito.mock(KPropertiesImpl.class);
	
	@Mock
    AuthNTokenProvider authNTokenProvider = PowerMockito.spy(new AuthNTokenProviderImpl());
	
	@InjectMocks
	AccessTokenProviderImpl accessTokenProviderImpl = PowerMockito.spy(new AccessTokenProviderImpl());
	
	@Test
	public void testGetAccessToken() throws AuthNPublicException, URISyntaxException {
		Mockito.doReturn(new AccessToken()).when(authNTokenProvider).getAccessToken(request,"clientId");
		Mockito.doReturn(true).when(accessTokenProviderImpl).validateTargetUrl("targetUrl");
		
		Mockito.doReturn(authNTokenProvider).when(accessTokenProviderImpl).getAuthnTokenProviderImpl();
		Mockito.doReturn(kProperties).when(accessTokenProviderImpl).getKProperties();
		accessTokenProviderImpl.getAccessToken("clientId","targetUrl");
		Mockito.verify(authNTokenProvider,Mockito.times(1)).getAccessToken(Mockito.any(),Mockito.any());
	}
	
	@Test
	public void testGetAccessTokenInvalidTarget() throws AuthNPublicException, URISyntaxException {
		Mockito.doReturn(new AccessToken()).when(authNTokenProvider).getAccessToken(request,"clientId");
		Mockito.doReturn(false).when(accessTokenProviderImpl).validateTargetUrl("targetUrl");
		
		Mockito.doReturn(authNTokenProvider).when(accessTokenProviderImpl).getAuthnTokenProviderImpl();
		Mockito.doReturn(kProperties).when(accessTokenProviderImpl).getKProperties();
		accessTokenProviderImpl.getAccessToken("clientId","targetUrl");
		Mockito.verify(authNTokenProvider,Mockito.times(0)).getAccessToken(Mockito.any(),Mockito.any());
	}
	
}
