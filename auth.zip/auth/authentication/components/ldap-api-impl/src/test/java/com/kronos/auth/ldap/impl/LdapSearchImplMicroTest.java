package com.kronos.auth.ldap.impl;

import java.io.IOException;

import org.apache.directory.api.ldap.model.cursor.CursorException;
import org.apache.directory.api.ldap.model.cursor.SearchCursor;
import org.apache.directory.api.ldap.model.exception.LdapException;
import org.apache.directory.api.ldap.model.message.SearchRequest;
import org.apache.directory.api.ldap.model.message.SearchResultEntry;
import org.apache.directory.api.ldap.model.message.SearchScope;
import org.apache.directory.api.ldap.model.name.Dn;
import org.apache.directory.ldap.client.api.LdapNetworkConnection;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.kronos.auth.ldap.api.LdapOperationException;
import com.kronos.auth.ldap.impl.LdapSearchRequest.SCOPE;

@RunWith(PowerMockRunner.class)
@PrepareForTest(LdapConnectionMgr.class)
public class LdapSearchImplMicroTest {
	
	LdapDetails details;
	LdapSearchRequest searchRequest;
	SearchResponseParser parser;

	LdapSearchImpl spy;
	LdapNetworkConnection mockConnection;
	Dn mockDn;
	SearchCursor mockSearchCursor;
	SearchResultEntry mockEntiry;
	LdapSearchRequest mockLdapSearchRequest;
	LdapConnectionMgr mockConnMgr;
	
	@Before
	public void setUp() throws Exception {
		this.details = new LdapDetails("someHost", 1111, "dummyUser", "dontKnow");
		this.searchRequest = new LdapSearchRequest("Some base DN");
		this.parser = new SearchResponseParser();
		this.mockDn = PowerMockito.mock(Dn.class);
		this.mockSearchCursor = PowerMockito.mock(SearchCursor.class);
		this.mockEntiry = PowerMockito.mock(SearchResultEntry.class);
		this.mockLdapSearchRequest = PowerMockito.mock(LdapSearchRequest.class);
		mockConnMgr = PowerMockito.spy(LdapConnectionMgr.initLdapConnectionMgr(details));
		PowerMockito.doReturn(mockConnection).when(mockConnMgr).getLdapNetworkConnection(Mockito.anyString(),
				Mockito.anyInt());
		PowerMockito.mockStatic(LdapConnectionMgr.class);
		Mockito.when(LdapConnectionMgr.getLdapConnectionMgr()).thenReturn(mockConnMgr);
		this.spy = PowerMockito.spy(new LdapSearchImpl(searchRequest, parser));
		this.mockConnection = PowerMockito.mock(LdapNetworkConnection.class);
		
	}
	
	@Test
	public void testExecuteSearch_Happy() throws LdapException, LdapOperationException, CursorException{
		//data
		Answer<Boolean> ans = new Answer<Boolean>() {
			private int count = 0;
			@Override
			public Boolean answer(InvocationOnMock invocation) throws Throwable {
				if (++count == 1){
					return true;
				}
				return false;
			}
		}; 
		//mocks
		//prepare connection
		PowerMockito.doReturn(mockConnection).when(mockConnMgr).getConnection();
		PowerMockito.doReturn(mockConnection).when(mockConnMgr).getLdapNetworkConnection(Mockito.anyString(), Mockito.anyInt());
		PowerMockito.doNothing().when(mockConnection).bind(Mockito.anyString(),Mockito.anyString());
		//getLdapSearchResponse
		PowerMockito.doReturn(mockSearchCursor).when(mockConnection).search(Mockito.any(SearchRequest.class));
		PowerMockito.doAnswer(ans).when(mockSearchCursor).next();
		PowerMockito.doReturn(mockEntiry).when(mockSearchCursor).get();
		Mockito.when(mockSearchCursor.isReferral()).thenReturn(false);
		//setAttributesForSearchRequest
		PowerMockito.doReturn(mockDn).when(spy).createNewDn();
		spy.getResultMap();
		spy.getLdapSearchRequest();
		spy.setLdapSearchRequest(searchRequest);
		spy.executeSearch();
		//verification
		Mockito.verify(mockSearchCursor,Mockito.timeout(1)).get();
	}
	
	@Test(expected = LdapOperationException.class)
	public void testExecuteSearch_LdapException() throws LdapException, LdapOperationException, CursorException{
		//mocks
		//prepare connection
		PowerMockito.doReturn(mockConnection).when(mockConnMgr).getLdapNetworkConnection(Mockito.anyString(), Mockito.anyInt());
		PowerMockito.doThrow(new LdapException("some error")).when(mockConnection).bind(Mockito.anyString(),Mockito.anyString());
		//Test
		spy.executeSearch();
	}
	
	@Test(expected=LdapOperationException.class)
	public void testExecuteSearch_CursorException() throws LdapException, LdapOperationException, CursorException{
		//mocks
		//prepare connection
		PowerMockito.doReturn(mockConnection).when(mockConnMgr).getLdapNetworkConnection(Mockito.anyString(), Mockito.anyInt());
		//getLdapSearchResponse
		//setAttributesForSearchRequest
		PowerMockito.doReturn(mockConnection).when(mockConnMgr).getConnection();
		PowerMockito.doReturn(mockDn).when(spy).createNewDn();
		PowerMockito.doReturn(mockSearchCursor).when(mockConnection).search(Mockito.any(SearchRequest.class));
		PowerMockito.doThrow(new CursorException("error")).when(mockSearchCursor).next();

		//Test
		spy.executeSearch();
		//verification
		Mockito.verify(mockSearchCursor,Mockito.timeout(1)).get();
	}
		
	@Test(expected = LdapOperationException.class)
	public void testExecuteSearch_LdapExceptionInCloseConnection() throws LdapOperationException, IOException
	{
		//mocks
		//prepare connection
		PowerMockito.doReturn(mockConnection).when(mockConnMgr).getLdapNetworkConnection(Mockito.anyString(), Mockito.anyInt());
		PowerMockito.doThrow(new IOException()).when(mockConnection).close();
		//Test
		spy.executeSearch();
	}
	
	@Test
	public void testExecuteSearch_Happy_scope_BASE() throws LdapException, LdapOperationException, CursorException{
		//data
		Answer<Boolean> ans = new Answer<Boolean>() {
			private int count = 0;
			@Override
			public Boolean answer(InvocationOnMock invocation) throws Throwable {
				if (++count == 1){
					return true;
				}
				return false;
			}
		}; 
		//mocks
		//prepare connection
		PowerMockito.doReturn(mockConnection).when(mockConnMgr).getConnection();
		PowerMockito.doReturn(mockConnection).when(mockConnMgr).getLdapNetworkConnection(Mockito.anyString(), Mockito.anyInt());
		PowerMockito.doNothing().when(mockConnection).bind(Mockito.anyString(),Mockito.anyString());
		//getLdapSearchResponse
		PowerMockito.doReturn(mockSearchCursor).when(mockConnection).search(Mockito.any(SearchRequest.class));
		PowerMockito.doAnswer(ans).when(mockSearchCursor).next();
		PowerMockito.doReturn(mockEntiry).when(mockSearchCursor).get();
		Mockito.when(mockSearchCursor.isReferral()).thenReturn(false);
		//setAttributesForSearchRequest
		PowerMockito.doReturn(mockDn).when(spy).createNewDn();
		spy.getResultMap();
		spy.getLdapSearchRequest();
		searchRequest.setScope(SCOPE.BASE);
		spy.setLdapSearchRequest(searchRequest);
		spy.executeSearch();
		//verification
		Mockito.verify(mockSearchCursor,Mockito.timeout(1)).get();
	}
	
	@Test
	public void testExecuteSearch_Happy_scope_SUBORDINATE() throws LdapException, LdapOperationException, CursorException{
		//data
		Answer<Boolean> ans = new Answer<Boolean>() {
			private int count = 0;
			@Override
			public Boolean answer(InvocationOnMock invocation) throws Throwable {
				if (++count == 1){
					return true;
				}
				return false;
			}
		}; 
		//mocks
		//prepare connection
		PowerMockito.doReturn(mockConnection).when(mockConnMgr).getConnection();
		PowerMockito.doReturn(mockConnection).when(mockConnMgr).getLdapNetworkConnection(Mockito.anyString(), Mockito.anyInt());
		PowerMockito.doNothing().when(mockConnection).bind(Mockito.anyString(),Mockito.anyString());
		//getLdapSearchResponse
		PowerMockito.doReturn(mockSearchCursor).when(mockConnection).search(Mockito.any(SearchRequest.class));
		PowerMockito.doAnswer(ans).when(mockSearchCursor).next();
		PowerMockito.doReturn(mockEntiry).when(mockSearchCursor).get();
		Mockito.when(mockSearchCursor.isReferral()).thenReturn(false);
		//setAttributesForSearchRequest
		PowerMockito.doReturn(mockDn).when(spy).createNewDn();
		spy.getResultMap();
		spy.getLdapSearchRequest();
		searchRequest.setScope(SCOPE.SUBORDINATE);
		spy.setLdapSearchRequest(searchRequest);
		spy.executeSearch();
		//verification
		Mockito.verify(mockSearchCursor,Mockito.timeout(1)).get();
	}
	
	@Test
	public void testExecuteSearch_Happy_scope_null() throws LdapException, LdapOperationException, CursorException{
		//data
		Answer<Boolean> ans = new Answer<Boolean>() {
			private int count = 0;
			@Override
			public Boolean answer(InvocationOnMock invocation) throws Throwable {
				if (++count == 1){
					return true;
				}
				return false;
			}
		}; 
		//mocks
		//prepare connection
		PowerMockito.doReturn(mockConnection).when(mockConnMgr).getConnection();
		PowerMockito.doReturn(mockConnection).when(mockConnMgr).getLdapNetworkConnection(Mockito.anyString(), Mockito.anyInt());
		PowerMockito.doNothing().when(mockConnection).bind(Mockito.anyString(),Mockito.anyString());
		//getLdapSearchResponse
		PowerMockito.doReturn(mockSearchCursor).when(mockConnection).search(Mockito.any(SearchRequest.class));
		PowerMockito.doAnswer(ans).when(mockSearchCursor).next();
		PowerMockito.doReturn(mockEntiry).when(mockSearchCursor).get();
		Mockito.when(mockSearchCursor.isReferral()).thenReturn(false);
		//setAttributesForSearchRequest
		PowerMockito.doReturn(mockDn).when(spy).createNewDn();
		spy.getResultMap();
		spy.getLdapSearchRequest();
		searchRequest.setScope(null);
		spy.setLdapSearchRequest(searchRequest);
		spy.executeSearch();
		//verification
		Mockito.verify(mockSearchCursor,Mockito.timeout(1)).get();
	}
	
}


