package com.kronos.auth.ldap.impl;

import java.io.IOException;

import org.apache.directory.api.ldap.model.entry.DefaultModification;
import org.apache.directory.api.ldap.model.entry.Entry;
import org.apache.directory.api.ldap.model.exception.LdapException;
import org.apache.directory.api.ldap.model.message.DeleteRequest;
import org.apache.directory.api.ldap.model.message.LdapResult;
import org.apache.directory.api.ldap.model.message.ModifyDnRequest;
import org.apache.directory.api.ldap.model.message.ModifyDnResponse;
import org.apache.directory.api.ldap.model.message.ResultCodeEnum;
import org.apache.directory.api.ldap.model.name.Dn;
import org.apache.directory.ldap.client.api.LdapNetworkConnection;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

import com.kronos.auth.ldap.api.LdapOperationException;

import junit.framework.TestCase;

@RunWith(PowerMockRunner.class)
@PrepareForTest(LdapConnectionMgr.class)
public class LdapModifyImplMicroTest extends TestCase {

	String dnStr = "ou=dummyRealm,dc=kronos,dc=com";
	LdapDetails details = new LdapDetails("someHost", 1111, "dummyUser", "dontKnow");
	LdapModifyRequest modifyRequest;
	
	LdapModifyImpl spy;
	LdapNetworkConnection mockConnection;
	LdapConnectionMgr mockConnMgr;
	
	@Before
	public void setUp() throws Exception {
		modifyRequest = new LdapModifyRequest(dnStr, "SomeKey", "SomeValue");
		mockConnMgr = PowerMockito.spy(LdapConnectionMgr.initLdapConnectionMgr(details));
		PowerMockito.mockStatic(LdapConnectionMgr.class);
		Mockito.when(LdapConnectionMgr.getLdapConnectionMgr()).thenReturn(mockConnMgr);
		LdapConnectionMgr.getLdapConnectionMgr();
		PowerMockito.doReturn(mockConnection).when(mockConnMgr).getLdapNetworkConnection(Mockito.anyString(),
				Mockito.anyInt());
		spy = PowerMockito.spy(new LdapModifyImpl(modifyRequest));

		mockConnection = PowerMockito.mock(LdapNetworkConnection.class);
	}
	
	@Test
	public void testExecuteModify() throws LdapOperationException, LdapException
	{
		//mocks
		//prepare connection
		mockConnection = PowerMockito.mock(LdapNetworkConnection.class);
		PowerMockito.doReturn(mockConnection).when(mockConnMgr).getLdapNetworkConnection(Mockito.anyString(), Mockito.anyInt());
		PowerMockito.doReturn(mockConnection).when(mockConnMgr).getConnection();
		PowerMockito.doNothing().when(mockConnection).bind(Mockito.anyString(),Mockito.anyString());
		
		Boolean result = spy.executeModifyAttribute();
		assertNotNull(result);
	}
	
	@Test
	public void testExecuteAdd() throws LdapOperationException, LdapException
	{
		Entry en = PowerMockito.mock(Entry.class);
		modifyRequest.addEntry(en);	
		modifyRequest.addEntry(en);	
		//mocks
		//prepare connection
		PowerMockito.doReturn(mockConnection).when(mockConnMgr).getLdapNetworkConnection(Mockito.anyString(), Mockito.anyInt());
		PowerMockito.doReturn(mockConnection).when(mockConnMgr).getConnection();
		PowerMockito.doNothing().when(mockConnection).bind(Mockito.anyString(),Mockito.anyString());
		Boolean result = spy.executeAddEntry();
		assertNotNull(result);
	}
	
	@Test(expected = LdapOperationException.class)
	public void testExecuteAdd_LdapExceptionInPrepareConnection() throws LdapException, LdapOperationException
	{
		Entry en = PowerMockito.mock(Entry.class);
		modifyRequest.addEntry(en);	
		modifyRequest.addEntry(en);	
		//mocks
		//prepare connection
		PowerMockito.doReturn(mockConnection).when(mockConnMgr).getLdapNetworkConnection(Mockito.anyString(), Mockito.anyInt());
		//PowerMockito.doNothing().when(mockConnMgr).getConnection();
		PowerMockito.doReturn(mockConnection).when(mockConnMgr).getConnection();
		PowerMockito.doThrow(new LdapException("some error")).when(mockConnection).add(Mockito.any(Entry.class));
		//Test
		//No verification required,It will throw LDAPSearchException
		//spy.ldapConnectionMgr =mockConnMgr;
		spy.executeAddEntry(); 
	}
	@Test
	public void testExecuteDelete() throws LdapOperationException, LdapException
	{
		Entry en = PowerMockito.mock(Entry.class);
		modifyRequest.addEntry(en);	
		modifyRequest.addEntry(en);	
		//mocks
		//prepare connection
		PowerMockito.doReturn(mockConnection).when(mockConnMgr).getLdapNetworkConnection(Mockito.anyString(), Mockito.anyInt());
		PowerMockito.doReturn(mockConnection).when(mockConnMgr).getConnection();
		//spy.ldapConnectionMgr =mockConnMgr;
		Boolean result = spy.executeDeleteSubTree();
		assertNotNull(result);
	}
	@Test(expected = LdapOperationException.class)
	public void testExecuteDelete_LdapExceptionInPrepareConnection() throws LdapException, LdapOperationException
	{
		//mocks
		//prepare connection
		PowerMockito.doReturn(mockConnection).when(mockConnMgr).getLdapNetworkConnection(Mockito.anyString(), Mockito.anyInt());
		PowerMockito.doReturn(mockConnection).when(mockConnMgr).getConnection();
		PowerMockito.doThrow(new LdapException("some error")).when(mockConnection).delete(Mockito.any(DeleteRequest.class));
		//Test
		//No verification required,It will throw LDAPSearchException
		//spy.ldapConnectionMgr =mockConnMgr;
		spy.executeDeleteSubTree();
	}
	@Test(expected = LdapOperationException.class)
	public void testExecuteModify_LdapExceptionInPrepareConnection() throws LdapException, LdapOperationException
	{
		//mocks
		//prepare connection
		PowerMockito.doReturn(mockConnection).when(mockConnMgr).getLdapNetworkConnection(Mockito.anyString(), Mockito.anyInt());
		PowerMockito.doReturn(mockConnection).when(mockConnMgr).getConnection();
		PowerMockito.doThrow(new LdapException("some error")).when(mockConnection).modify(Mockito.any(Dn.class),Mockito.any());
		//Test
		//No verification required,It will throw LDAPSearchException
		//spy.ldapConnectionMgr =mockConnMgr;
		spy.executeModifyAttribute(); 
	}
	
	@Test
	public void testExecuteModify_LdapExceptionInCloseConnection() throws LdapOperationException, IOException, LdapException
	{
		//mocks
		//prepare connection
		PowerMockito.doReturn(mockConnection).when(mockConnMgr).getLdapNetworkConnection(Mockito.anyString(), Mockito.anyInt());
		PowerMockito.doReturn(mockConnection).when(mockConnMgr).getConnection();
		PowerMockito.doReturn(true).when(mockConnection).isConnected();
		PowerMockito.doThrow(new IOException()).when(mockConnection).close();
		//Test
		//spy.ldapConnectionMgr =mockConnMgr;
		spy.executeModifyAttribute();
	}
	
	@Test
	public void testExecuteModifyIdentifier() throws LdapOperationException, LdapException
	{
		Entry en = PowerMockito.mock(Entry.class);
		modifyRequest.addEntry(en);	
		modifyRequest.addEntry(en);	
		//mocks
		//prepare connection
		PowerMockito.doReturn(mockConnection).when(mockConnMgr).getLdapNetworkConnection(Mockito.anyString(), Mockito.anyInt());
		PowerMockito.doReturn(mockConnection).when(mockConnMgr).getConnection();
		ModifyDnResponse res = PowerMockito.mock(ModifyDnResponse.class);
		LdapResult lRes = PowerMockito.mock(LdapResult.class);
		PowerMockito.doReturn(lRes).when(res).getLdapResult();
		PowerMockito.doReturn(ResultCodeEnum.SUCCESS).when(lRes).getResultCode();
		PowerMockito.doReturn(res).when(mockConnection).modifyDn(Mockito.any(ModifyDnRequest.class));
		//spy.ldapConnectionMgr =mockConnMgr;
		Boolean result = spy.executeModifyIdentifier();
		Mockito.verify(mockConnection,Mockito.times(1)).modifyDn(Mockito.any(ModifyDnRequest.class));
		assertTrue(result);
	}
	
	@Test(expected=LdapOperationException.class)
	public void testExecuteModifyIdentifier_Exception() throws LdapOperationException, LdapException
	{
		Entry en = PowerMockito.mock(Entry.class);
		modifyRequest.addEntry(en);	
		modifyRequest.addEntry(en);	
		//mocks
		//prepare connection
		PowerMockito.doReturn(mockConnection).when(mockConnMgr).getLdapNetworkConnection(Mockito.anyString(), Mockito.anyInt());
		PowerMockito.doReturn(mockConnection).when(mockConnMgr).getConnection();
		PowerMockito.doThrow(new LdapException()).when(mockConnection).modifyDn(Mockito.any(ModifyDnRequest.class));
		//spy.ldapConnectionMgr =mockConnMgr;
		Boolean result = spy.executeModifyIdentifier();
		assertTrue(result);
	}
	
	@Test(expected=LdapOperationException.class)
	public void testExecuteModifyIdentifier_resultcode_not_success() throws LdapOperationException, LdapException
	{
		Entry en = PowerMockito.mock(Entry.class);
		modifyRequest.addEntry(en);	
		modifyRequest.addEntry(en);	
		//mocks
		//prepare connection
		PowerMockito.doReturn(mockConnection).when(mockConnMgr).getLdapNetworkConnection(Mockito.anyString(), Mockito.anyInt());
		PowerMockito.doReturn(mockConnection).when(mockConnMgr).getConnection();
		ModifyDnResponse res = PowerMockito.mock(ModifyDnResponse.class);
		LdapResult lRes = PowerMockito.mock(LdapResult.class);
		PowerMockito.doReturn(lRes).when(res).getLdapResult();
		PowerMockito.doReturn(ResultCodeEnum.COMPARE_FALSE).when(lRes).getResultCode();
		PowerMockito.doReturn(res).when(mockConnection).modifyDn(Mockito.any(ModifyDnRequest.class));
		spy.executeModifyIdentifier();
	}
	
	@Test
	public void testExecuteModify_null_request() throws LdapOperationException, LdapException
	{
		//mocks
		//prepare connection
		modifyRequest = null;
		mockConnection = PowerMockito.mock(LdapNetworkConnection.class);
		PowerMockito.doReturn(mockConnection).when(mockConnMgr).getLdapNetworkConnection(Mockito.anyString(), Mockito.anyInt());
		PowerMockito.doReturn(mockConnection).when(mockConnMgr).getConnection();
		PowerMockito.doNothing().when(mockConnection).bind(Mockito.anyString(),Mockito.anyString());
		spy = PowerMockito.spy(new LdapModifyImpl(modifyRequest));
		Boolean result = spy.executeModifyAttribute();
		assertNotNull(result);
	}
	
	@Test
	public void testExecuteAdd_null_request() throws LdapOperationException, LdapException
	{
		Entry en = PowerMockito.mock(Entry.class);
		modifyRequest.addEntry(en);	
		modifyRequest.addEntry(en);	
		modifyRequest = null;
		//mocks
		//prepare connection
		PowerMockito.doReturn(mockConnection).when(mockConnMgr).getLdapNetworkConnection(Mockito.anyString(), Mockito.anyInt());
		PowerMockito.doReturn(mockConnection).when(mockConnMgr).getConnection();
		PowerMockito.doNothing().when(mockConnection).bind(Mockito.anyString(),Mockito.anyString());
		spy = PowerMockito.spy(new LdapModifyImpl(modifyRequest));
		Boolean result = spy.executeAddEntry();
		assertNotNull(result);
	}
	
	@Test
	public void testExecuteAdd_null_add_entries() throws LdapOperationException, LdapException
	{
		modifyRequest.setEntriesToModify(null);
		//mocks
		//prepare connection
		PowerMockito.doReturn(mockConnection).when(mockConnMgr).getLdapNetworkConnection(Mockito.anyString(), Mockito.anyInt());
		PowerMockito.doReturn(mockConnection).when(mockConnMgr).getConnection();
		PowerMockito.doNothing().when(mockConnection).bind(Mockito.anyString(),Mockito.anyString());
		spy = PowerMockito.spy(new LdapModifyImpl(modifyRequest));
		Boolean result = spy.executeAddEntry();
		assertNotNull(result);
	}
}
