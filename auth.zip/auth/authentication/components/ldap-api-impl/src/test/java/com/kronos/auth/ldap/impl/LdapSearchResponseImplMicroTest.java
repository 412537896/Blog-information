package com.kronos.auth.ldap.impl;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.directory.api.ldap.model.entry.Attribute;
import org.apache.directory.api.ldap.model.entry.DefaultAttribute;
import org.apache.directory.api.ldap.model.entry.DefaultEntry;
import org.apache.directory.api.ldap.model.entry.Entry;
import org.apache.directory.api.ldap.model.entry.StringValue;
import org.apache.directory.api.ldap.model.exception.LdapException;
import org.apache.directory.api.ldap.model.exception.LdapInvalidAttributeValueException;
import org.apache.directory.api.ldap.model.message.SearchResultEntry;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;

public class LdapSearchResponseImplMicroTest {
	SearchResultEntry searchEntiry;
	Entry entry;
	SearchResponseParser parser = new SearchResponseParser();
	LdapSearchResponseImpl spy = PowerMockito.spy(new LdapSearchResponseImpl(parser));

	@Before
	public void beforeTest() throws LdapException{
		searchEntiry = PowerMockito.mock(SearchResultEntry.class);
		entry = new DefaultEntry();
		Attribute attr1 = new DefaultAttribute("testAttr1");
		attr1.add(":someId1=someId1");
		attr1.add(new StringValue("value1=value2"));
		Attribute attr2 = new DefaultAttribute("testAttr2");
		attr2.add("someId2=someId1");
		attr2.add(new StringValue("value2=value2"));
		entry.add(attr1);
		entry.add(attr2);
		searchEntiry.setEntry(entry);
		ArrayList<SearchResultEntry> list = new ArrayList<>();
		list.add(searchEntiry);
		parser.setResponse(list);
	}
	@Test
	public void testGetLdifasString(){
		spy.setEntry(searchEntiry);
		PowerMockito.doReturn(entry).when(searchEntiry).getEntry();
		String result = spy.getLdifasString();
		System.out.println(result);
		Assert.assertNotNull(result);
		Assert.assertTrue(result.length()>0);
		Mockito.verify(searchEntiry, Mockito.times(1)).getEntry();
	}
	@Test
	public void testGetLdifResult(){
		spy.setEntry(searchEntiry);
		PowerMockito.doReturn(entry).when(searchEntiry).getEntry();
		List<Map<String, List<String>>> result = spy.getLdifResult();
		Assert.assertNotNull(result);
		Assert.assertTrue(result.size()>0);
		Mockito.verify(searchEntiry, Mockito.times(1)).getEntry();
	}
	
	@Test
	public void testGetLdifResult_Non_Null_ldifAsString()
			throws InstantiationException, IllegalAccessException, NoSuchFieldException, SecurityException {
		SearchResponseParser  parser = new SearchResponseParser();
		LdapSearchResponseImpl spy = PowerMockito.spy(new LdapSearchResponseImpl(parser));
		Field f1 = parser.getClass().getDeclaredField("ldifAsString"); // listOfLdif
		f1.setAccessible(true);
		f1.set(parser, "[dn:cn=test]");
		spy.setEntry(searchEntiry);
		PowerMockito.doReturn(entry).when(searchEntiry).getEntry();
		List<Map<String, List<String>>> result = spy.getLdifResult();
		Assert.assertNotNull(result);
		Assert.assertTrue(result.size() > 0);
		Mockito.verify(searchEntiry, Mockito.times(1)).getEntry();
	}
	
	@Test
	public void testGetLdifResult_Not_null_listOfLdif()
			throws InstantiationException, IllegalAccessException, NoSuchFieldException, SecurityException {
		SearchResponseParser  parser = new SearchResponseParser();
		LdapSearchResponseImpl spy = PowerMockito.spy(new LdapSearchResponseImpl(parser));
		List<String> ldifList = new ArrayList<>();
		ldifList.add("lidf1");
		Field f1 = parser.getClass().getDeclaredField("listOfLdif"); // listOfLdif
		f1.setAccessible(true);
		f1.set(parser, ldifList);
		spy.setEntry(searchEntiry);
		PowerMockito.doReturn(entry).when(searchEntiry).getEntry();
		List<Map<String, List<String>>> result = spy.getLdifResult();
		Assert.assertNotNull(result);
		Assert.assertTrue(result.size() > 0);
	}
	
	@Test
	public void getSearchResultNameList_Null()
			throws InstantiationException, IllegalAccessException, NoSuchFieldException, SecurityException, LdapException {
		ArrayList<SearchResultEntry> list = new ArrayList<>();
		parser.setResponse(list);
		PowerMockito.doReturn(entry).when(searchEntiry).getEntry();
		List<String> result = spy.getSearchResultNameList();
		Assert.assertTrue(result.size() == 0);
	}
	
	@Test
	public void testAddLdif_Null_ldifAsString()
			throws InstantiationException, IllegalAccessException, NoSuchFieldException, SecurityException, LdapException {
		parser.addLdif(null);
		Field f1 = parser.getClass().getDeclaredField("listOfLdif"); // listOfLdif
		f1.setAccessible(true);
		Assert.assertNull(f1.get(parser));
	}
}
