package com.kronos.auth.ldap.util;

import org.junit.Test;

import junit.framework.TestCase;

public class LdapUtilsTest extends TestCase {

	@Test
	public void testSplit_stringToSplit_Empty() {

		String stringToSplit = null;
		String key = "testkey";
		boolean isconsiderFirstOccurrence = true;
		String[] result = LdapUtils.split(stringToSplit, key, isconsiderFirstOccurrence);
		assertEquals(0, result.length);
	}

	@Test
	public void testSplit_isconsiderFirstOccurrence_false() {
		String stringToSplit = "startkeyend";
		String key = "key";
		boolean isconsiderFirstOccurrence = false;
		String[] result = LdapUtils.split(stringToSplit, key, isconsiderFirstOccurrence);
		assertEquals("start", result[0]);
		assertEquals("end", result[1]);
	}

	@Test
	public void testSplit_key_missing() {
		String stringToSplit = "startkeyend";
		String key = "missingkey";
		boolean isconsiderFirstOccurrence = true;
		String[] result = LdapUtils.split(stringToSplit, key, isconsiderFirstOccurrence);
		assertEquals(0, result.length);
	}
	
	@Test
	public void testIsEmpty_true() {
		String input = "";
		boolean result = LdapUtils.isEmpty(input);
		assertEquals(true, result);
	}
	
	@Test
	public void testIsEmpty_false() {
		String input = "test";
		boolean result = LdapUtils.isEmpty(input);
		assertEquals(false, result);
	}

}
