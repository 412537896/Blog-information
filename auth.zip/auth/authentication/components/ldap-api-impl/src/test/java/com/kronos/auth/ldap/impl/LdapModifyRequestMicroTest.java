package com.kronos.auth.ldap.impl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.directory.api.ldap.model.entry.Entry;
import org.apache.directory.api.ldap.model.ldif.LdapLdifException;
import org.apache.directory.api.ldap.model.ldif.LdifEntry;
import org.apache.directory.api.ldap.model.ldif.LdifReader;
import org.apache.directory.api.ldap.model.name.Dn;
import org.junit.Assert;
import org.junit.Test;
import org.mockito.Mockito;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.powermock.api.mockito.PowerMockito;

import com.kronos.auth.ldap.api.LdapOperationException;

public class LdapModifyRequestMicroTest {
	LdapModifyLdifRequest spy = PowerMockito.spy(new LdapModifyLdifRequest(PowerMockito.mock(Dn.class)));
	LdifReader mockReader = PowerMockito.mock(LdifReader.class);
	LdifEntry mockLdifEntry = PowerMockito.mock(LdifEntry.class);
	Entry mockEntry = PowerMockito.mock(Entry.class);
	@Test
	public void testAddAttrToModify(){
		spy.addAttrToModify("someKey", "someValue");
		Assert.assertTrue(spy.getDm().get(0).toString().contains("someKey"));
	}
	
	@Test
	public void testAddAttrToDelete(){
		spy.addAttrToDelete("someKey", "someValue");
		Assert.assertTrue(spy.getDm().get(0).toString().contains("someKey"));
	}
	
	@Test
	public void testAddLdif() throws LdapLdifException{
		Answer<Boolean> ans = new Answer<Boolean>() {
			int count;
			@Override
			public Boolean answer(InvocationOnMock invocation) throws Throwable {
				count++;
				if(count>1){
					return false;
				}
				// TODO Auto-generated method stub
				return true;
			}
		};
		String ldifName = "someLdifFilePath";
		PowerMockito.doReturn(mockReader).when(spy).getLdifReader(Mockito.anyString());
		PowerMockito.doAnswer(ans).when(mockReader).hasNext();
		PowerMockito.doReturn(mockLdifEntry).when(mockReader).next();
		PowerMockito.doReturn(mockEntry).when(mockLdifEntry).getEntry();
		spy.addLdif(ldifName);
		Mockito.verify(mockLdifEntry, Mockito.timeout(1)).getEntry();
	}
	@Test(expected=LdapLdifException.class)
	public void testAddLdif_LdapLdifException() throws LdapLdifException{
		String ldifName = "someLdifFilePath";
		PowerMockito.doThrow(new LdapLdifException("Ldif error occourred")).when(spy).getLdifReader(Mockito.anyString());
		spy.addLdif(ldifName);
	}
	@Test(expected=LdapLdifException.class)
	public void testAddLdif_IOException() throws LdapLdifException, IOException{
		String ldifName = "someLdifFilePath";
		PowerMockito.doReturn(mockReader).when(spy).getLdifReader(Mockito.anyString());
		PowerMockito.doThrow(new IOException("Ldif error occourred")).when(mockReader).close();
		spy.addLdif(ldifName);
	}
	@Test
	public void testAddAttr(){
		spy.addAttr("someKey", "someValue");
		Assert.assertTrue(spy.getDm().get(0).toString().contains("someKey"));
	}
	@Test
	public void testAddAttr_null_key_and_value(){
		spy.addAttr("", "");
		Assert.assertTrue(spy.getDm().size()==0);
	}
	
	@Test
	public void testAddAttrToDelete_null_key_and_value(){
		spy.addAttrToDelete("", "");
		Assert.assertTrue(spy.getDm().size()==0);
	}
	
	@Test
	public void testAddAttrToModify_null_key_and_value(){
		spy.addAttrToModify("", "");
		Assert.assertTrue(spy.getDm().size()==0);
	}
	

	@Test
	public void testAddAttr_null_key() throws LdapOperationException{
		Map<String, Object> attributes  = new HashMap<String, Object>();
		List<String> attrList =  new ArrayList<>();
		attrList.add("attr1");
		attributes.put("testKey", attrList);
		spy.addEntry(attributes);
		Assert.assertTrue(spy.getEntriesToModify().size()!=0);
	}
}
