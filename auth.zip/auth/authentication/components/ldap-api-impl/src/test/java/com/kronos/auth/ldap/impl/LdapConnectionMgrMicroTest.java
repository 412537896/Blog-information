package com.kronos.auth.ldap.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.io.IOException;

import org.apache.directory.api.ldap.model.exception.LdapException;
import org.apache.directory.ldap.client.api.LdapConnection;
import org.apache.directory.ldap.client.api.LdapConnectionPool;
import org.apache.directory.ldap.client.api.LdapNetworkConnection;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;

import com.kronos.auth.ldap.api.LdapOperationException;

public class LdapConnectionMgrMicroTest {

	LdapDetails details;
	LdapConnectionMgr mockConnMgr;
	LdapNetworkConnection mockConnection;
	LdapConnectionPool mockPool;

	@Before
	public void setUp() throws Exception {
		this.details = new LdapDetails("someHost", 1111, "dummyUser", "dontKnow");
		this.mockConnMgr =PowerMockito.spy(LdapConnectionMgr.initLdapConnectionMgr(details));
		this.mockConnection = PowerMockito.mock(LdapNetworkConnection.class);
		this.mockPool= Mockito.mock(LdapConnectionPool.class);
		PowerMockito.doReturn(mockConnection).when(mockConnMgr).getLdapNetworkConnection(Mockito.anyString(),
				Mockito.anyInt());
		mockConnMgr.pool=this.mockPool;
		
	}

	@Test
	public void testGetLdapNetworkConnection() {
		LdapNetworkConnection connection = mockConnMgr.getLdapNetworkConnection(Mockito.anyString(), Mockito.anyInt());
		assertNotNull(connection);
	}

	@Test
	public void testCloseConnection() throws Exception
	{
		PowerMockito.doNothing().when(mockConnection).bind(Mockito.anyString(),Mockito.anyString());
		PowerMockito.doReturn(true).when(mockConnection).isConnected();
		PowerMockito.doReturn(mockConnection).when(mockConnMgr).getConnection();
		LdapConnection connection =mockConnMgr.getConnection();
		mockConnMgr.closeConnection(connection);
		Mockito.verify(mockPool, Mockito.times(1)).releaseConnection(connection);
	}

	@Test(expected = LdapException.class)
	public void testLdapExceptionExceptionInGetConnection() throws LdapOperationException, IOException, LdapException
	{
		PowerMockito.doThrow(new LdapException()).when(mockPool).getConnection();
		PowerMockito.doReturn(true).when(mockConnection).isConnected();
		mockConnMgr.getConnection();
	}
	
	@Test
	public void testGetConnection() throws LdapOperationException, LdapException {
		PowerMockito.doReturn(mockConnection).when(mockPool).getConnection();
		LdapConnection connection = mockConnMgr.getConnection();
		assertNotNull(connection);
	}
	@Test
	public void testInitLdapConnectionMgr() throws LdapOperationException, LdapException {
		PowerMockito.doReturn(mockConnection).when(mockConnMgr).getConnection();
		LdapConnectionMgr connectionMgr = LdapConnectionMgr.initLdapConnectionMgr(details);
		assertEquals(details.getHostName(), connectionMgr.ldapDetails.getHostName());
		assertEquals(details.getPort(), connectionMgr.ldapDetails.getPort());
	}
	
	@Test
	public void testCloseConnection__Null_Connection() throws Exception
	{
		PowerMockito.doNothing().when(mockConnection).bind(Mockito.anyString(),Mockito.anyString());
		PowerMockito.doReturn(true).when(mockConnection).isConnected();
		PowerMockito.doReturn(null).when(mockConnMgr).getConnection();
		LdapConnection connection =mockConnMgr.getConnection();
		mockConnMgr.closeConnection(connection);
	}
	
	@Test
	public void testCloseConnection_Connection_Not_Connected() throws Exception
	{
		PowerMockito.doNothing().when(mockConnection).bind(Mockito.anyString(),Mockito.anyString());
		PowerMockito.doReturn(false).when(mockConnection).isConnected();
		PowerMockito.doReturn(mockConnection).when(mockPool).getConnection();
		LdapConnection connection =mockConnMgr.getConnection();
		mockConnMgr.closeConnection(connection);
	}
		
	@Test
	public void testGetLdapConnectionMgr() throws Exception
	{
		LdapConnectionMgr mgr = LdapConnectionMgr.getLdapConnectionMgr();
		assertNotNull(mgr);
	}
}
