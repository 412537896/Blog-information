package com.kronos.auth.ldap.impl;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.directory.api.ldap.model.cursor.CursorException;
import org.apache.directory.api.ldap.model.cursor.SearchCursor;
import org.apache.directory.api.ldap.model.exception.LdapException;
import org.apache.directory.api.ldap.model.exception.LdapInvalidDnException;
import org.apache.directory.api.ldap.model.message.Response;
import org.apache.directory.api.ldap.model.message.SearchRequest;
import org.apache.directory.api.ldap.model.message.SearchRequestImpl;
import org.apache.directory.api.ldap.model.message.SearchResultEntry;
import org.apache.directory.api.ldap.model.message.SearchScope;
import org.apache.directory.api.ldap.model.name.Dn;
import org.apache.directory.ldap.client.api.LdapConnection;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kronos.auth.ldap.api.LdapSearch;
import com.kronos.auth.ldap.api.LdapOperationException;
import com.kronos.auth.ldap.api.LdapSearchResponse;
import com.kronos.auth.ldap.impl.LdapSearchRequest.SCOPE;

public class LdapSearchImpl implements LdapSearch {

	private static final Logger xlogger = LoggerFactory.getLogger(LdapSearchResponseImpl.class);
	private LdapSearchRequest ldapSearchRequest;
	private LdapConnectionMgr ldapConnectionMgr;
	SearchResponseParser respParser;

	private Map<String, String> resultMap = new HashMap<>();

	public LdapSearchImpl( LdapSearchRequest ldapSearchRequest, SearchResponseParser parser) {
		super();
		this.ldapSearchRequest = ldapSearchRequest;
		this.respParser = parser;
		this.ldapConnectionMgr =LdapConnectionMgr.getLdapConnectionMgr();
	}

	public Map<String, String> getResultMap() {
		return resultMap;
	}

	/**
	 * @return the ldapSearchRequest
	 */
	public LdapSearchRequest getLdapSearchRequest() {
		return ldapSearchRequest;
	}

	/**
	 * @param ldapSearchRequest
	 *            the ldapSearchRequest to set
	 */
	public void setLdapSearchRequest(LdapSearchRequest ldapSearchRequest) {
		this.ldapSearchRequest = ldapSearchRequest;
	}

	/**
	 * @return
	 * @throws IOException
	 * @throws Exception
	 */
	@Override
	public LdapSearchResponse executeSearch() throws LdapOperationException {
		return getLdapSearchResponse();
	}

	private LdapSearchResponse getLdapSearchResponse() throws LdapOperationException {
		LdapSearchResponseImpl resp = new LdapSearchResponseImpl(respParser);
		SearchRequest req = setAttributesForSearchRequest();
		SearchCursor searchCursor = null;
		LdapConnection connection =null;
		try {
			connection = ldapConnectionMgr.getConnection();
			searchCursor = connection.search(req);

			while (searchCursor.next()) {
				Response response = searchCursor.get();
				if (response instanceof SearchResultEntry && !searchCursor.isReferral()) {
					SearchResultEntry resultEntry = (SearchResultEntry) response;
					resp.setEntry(resultEntry);
				}
			}
		} catch (LdapException | CursorException e) {
			xlogger.debug("Problem while Searching request [" + req + "] Error [" + e.getMessage() + "]", e);
			throw new LdapOperationException(
					"Problem while Searching request [" + req + "] Error [" + e.getMessage() + "]", e);
		} finally {
			ldapConnectionMgr.closeConnection(connection);
		}
		return resp;
	}

	private SearchRequest setAttributesForSearchRequest() throws LdapOperationException {
		SearchRequest req = new SearchRequestImpl();
		req.addAttributes(ldapSearchRequest.getAttributes());
		req.setTimeLimit(0);
		req.setScope(getSearchScope(ldapSearchRequest.getScope()));

		try {
			req.setBase(createNewDn());
		} catch (LdapInvalidDnException e) {
			throw new LdapOperationException(
					"Invalid DN found for base DN [" + ldapSearchRequest.getBaseDN() + "] [" + e.getMessage() + "]", e);
		}
		try {
			req.setFilter(ldapSearchRequest.getFilter());
		} catch (LdapException e) {
			throw new LdapOperationException("Problem while setting filter [" + ldapSearchRequest.getFilter()
					+ "] for search [" + e.getMessage() + "]", e);
		}
		return req;
	}

	Dn createNewDn() throws LdapInvalidDnException {
		return new Dn(ldapSearchRequest.getBaseDN());
	}

	private SearchScope getSearchScope(SCOPE scope) {
		SearchScope apacheScope = SearchScope.ONELEVEL;
		if (scope != null) {
			switch (scope) {
			case BASE:
				apacheScope = SearchScope.OBJECT;
				break;
			case SINGLE:
				apacheScope = SearchScope.ONELEVEL;
				break;
			case SUBORDINATE:
			case WHOLE_SUBTREE:
				apacheScope = SearchScope.SUBTREE;
				break;
			default:
				break;
			}

		}
		return apacheScope;
	}
}
