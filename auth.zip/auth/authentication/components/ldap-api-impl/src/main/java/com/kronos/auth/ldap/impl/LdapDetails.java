package com.kronos.auth.ldap.impl;

/**
 * Class to keep connection details for a LDAP server
 *
 */
public class LdapDetails {

	private String hostName;

	private int portNumber;

	private String userName;

	private String password;

	/**
	 * Creates ldap details object
	 * @param hostName
	 * @param port
	 * @param userName
	 * @param password
	 */
	public LdapDetails(String hostName, int port, String userName, String password) {
		super();
		this.hostName = hostName;
		this.portNumber = port;
		this.userName = userName;
		this.password = password;
	}

	/**
	 * @return hostName of LDAP server
	 */
	public String getHostName() {
		return hostName;
	}

	/**
	 * @return port of LDAP server
	 */
	public int getPort() {
		return portNumber;
	}

	/**
	 * @return userName of LDAP server
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * @return password of LDAP server for given user
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @param sets hostName of LDAP server
	 */
	public void setHostName(String hostName) {
		this.hostName = hostName;
	}

	/**
	 * @param sets the port of LDAP server
	 */
	public void setPort(int port) {
		this.portNumber = port;
	}
	/**
	 * @param sets userName of LDAP server
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}


	/**
	 * @param sets password of LDAP server for given user
	 */
	public void setPassword(String password) {
		this.password = password;
	}

}
