package com.kronos.auth.ldap.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.directory.api.ldap.model.message.SearchResultEntry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kronos.auth.ldap.api.LdapSearchResponse;

/**
 *@author Geeta.Chaudhari
 * 
 */
public class LdapSearchResponseImpl implements LdapSearchResponse {

	private static final Logger xlogger = LoggerFactory.getLogger(LdapSearchResponseImpl.class);

	private List<SearchResultEntry> entry = new ArrayList<>();

	private SearchResponseParser responseParser;

	public LdapSearchResponseImpl(SearchResponseParser parser) {
		this.responseParser = parser;
		this.responseParser.setResponse(entry);
	}
	
	public void setEntry(SearchResultEntry entry) {
		this.entry.add(entry);
	}
	
	public List<String> getSearchResultNameList() {
		 return responseParser.getResultList() ;
	}

	/**
	 * returns search result LDIF as {@link String}
	 * 
	 * @return
	 */
	@Override
	public String getLdifasString() {
		xlogger.debug(".getLdifasString() : Start");
		return responseParser.getLdifasString();
	}

	@Override
	public String getAttributeValue(String outerMapKey, String ldifKey) {
		return null;
	}

	/**
	 * returns search result as List of maps containing parsed LDIF to key pair
	 * value
	 */
	@Override
	public List<Map<String, List<String>>> getLdifResult() {
		return responseParser.populateldifMap();
	}
}
