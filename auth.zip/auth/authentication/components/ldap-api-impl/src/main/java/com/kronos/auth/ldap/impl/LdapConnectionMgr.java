package com.kronos.auth.ldap.impl;

import org.apache.directory.api.ldap.codec.api.LdapApiService;
import org.apache.directory.api.ldap.model.exception.LdapException;
import org.apache.directory.ldap.client.api.LdapConnection;
import org.apache.directory.ldap.client.api.LdapConnectionConfig;
import org.apache.directory.ldap.client.api.LdapConnectionPool;
import org.apache.directory.ldap.client.api.LdapNetworkConnection;
import org.apache.directory.ldap.client.api.ValidatingPoolableLdapConnectionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kronos.auth.ldap.api.LdapOperationException;
/**
 * This class is responsible for creation/management of connections to OpenDJ. The LDAP APIs 
 * used by client applications use this class internally for getting connection.
 * @author Manish.Sharma
 *
 */
public class LdapConnectionMgr {
	private static final Logger xlogger = LoggerFactory.getLogger(LdapConnectionMgr.class);
	private static String CONNECTION_POOL_INITIALIZATION_EXCEPTION = "Could not initialize the connection pool";

    LdapConnectionPool pool;
	static LdapConnectionMgr mgr;
	static long TIMEOUT = 300000;
	LdapDetails ldapDetails;

	private LdapConnectionMgr(LdapDetails ldapDetails) {
		this.ldapDetails = ldapDetails;
		createPool(ldapDetails.getHostName(), ldapDetails.getPort(),ldapDetails.getUserName(),ldapDetails.getPassword());
	}

	public LdapConnection getConnection() throws LdapOperationException, LdapException {
		xlogger.info("entering  getConnection");
		LdapConnection connection = pool.getConnection();
		xlogger.info("got connection successfully from the pool");
		return connection;
	}

	/**
	 * Initialize the Connection Manager
	 * @param ldapDetails details for creating connection
	 * @return
	 */
	public static synchronized LdapConnectionMgr initLdapConnectionMgr(LdapDetails ldapDetails) {
				try {
					mgr = new LdapConnectionMgr(ldapDetails);
				} catch (Exception e) {
					xlogger.error(CONNECTION_POOL_INITIALIZATION_EXCEPTION, e);
				}
		   return mgr;
	}
	
	/**
	 * Returns the connection manager instance
	 * @return
	 */
	public static LdapConnectionMgr getLdapConnectionMgr() {
				if(mgr == null)
				xlogger.error("could not get connection as connection pool is not yet initialized");
		return mgr;
	}

	/**
	 * Releases the connection and puts it back in pool.
	 * @param connection
	 */
	public void closeConnection(LdapConnection connection) {
		try {
			if (connection != null && connection.isConnected())
				pool.releaseConnection(connection);
		} catch (LdapException e) {
			xlogger.warn("Could not close ldap connection [{}]", e.getMessage(), e);
		}
	}

	/**
	 * Creates a connection pool with provided details.
	 * @param server
	 * @param port
	 * @param username
	 * @param password
	 */
	private void createPool(String server, int port, String username, String password) {
		xlogger.info("entering  createPool");
		LdapConnectionConfig config = new LdapConnectionConfig();
		config.setLdapHost(server);
		config.setLdapPort(port);
		config.setName(username);
		config.setCredentials(password);
		ValidatingPoolableLdapConnectionFactory factory = new ValidatingPoolableLdapConnectionFactory(config);
		LdapApiService apiService = factory.getLdapApiService();
		pool = new LdapConnectionPool(config, apiService, TIMEOUT);
		pool.setTestOnBorrow(true);
		pool.setTimeBetweenEvictionRunsMillis(TIMEOUT);
		pool.setTestWhileIdle(true);
		pool.setWhenExhaustedAction(LdapConnectionPool.WHEN_EXHAUSTED_GROW);
		xlogger.info("connection Pool created");
	}

	LdapNetworkConnection getLdapNetworkConnection(String server, int port) {
		return new LdapNetworkConnection(server, port);
	}
}
