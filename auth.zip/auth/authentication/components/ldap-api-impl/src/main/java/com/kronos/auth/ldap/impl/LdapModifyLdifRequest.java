package com.kronos.auth.ldap.impl;

import java.io.File;
import java.io.IOException;

import org.apache.directory.api.ldap.model.entry.Entry;
import org.apache.directory.api.ldap.model.ldif.LdapLdifException;
import org.apache.directory.api.ldap.model.ldif.LdifEntry;
import org.apache.directory.api.ldap.model.ldif.LdifReader;
import org.apache.directory.api.ldap.model.name.Dn;

import com.kronos.auth.ldap.api.LdapOperationException;

public class LdapModifyLdifRequest extends LdapModifyRequest {

	/**
	 * @deprecated
	 * @param dn
	 */
	@Deprecated
	public LdapModifyLdifRequest(Dn dn) {
		super(dn);
	}

	public LdapModifyLdifRequest(String dn) throws LdapOperationException {
		super(dn);
	}

	/**
	 * Parse given LDIF file and adds it to Entry list.
	 * 
	 * @param fileName
	 * @throws LdapLdifException
	 */
	public void addLdif(String fileName) throws LdapLdifException {
		try (LdifReader r = getLdifReader(fileName)) {
			while (r.hasNext()) {
				LdifEntry entity = r.next();
				Entry en = entity.getEntry();
				this.addEntry(en);
			}
		} catch (LdapLdifException e) {
			throw e;
		} catch (IOException e1) {
			throw new LdapLdifException("Could not close connection", e1);
		}
	}

	LdifReader getLdifReader(String fileName) throws LdapLdifException {
		return new LdifReader(new File(fileName));
	}

}
