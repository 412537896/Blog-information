package com.kronos.auth.ldap.impl;

import org.apache.directory.api.ldap.model.entry.DefaultModification;
import org.apache.directory.api.ldap.model.entry.Entry;
import org.apache.directory.api.ldap.model.exception.LdapException;
import org.apache.directory.api.ldap.model.message.Control;
import org.apache.directory.api.ldap.model.message.DeleteRequest;
import org.apache.directory.api.ldap.model.message.DeleteRequestImpl;
import org.apache.directory.api.ldap.model.message.ModifyDnRequest;
import org.apache.directory.api.ldap.model.message.ModifyDnRequestImpl;
import org.apache.directory.api.ldap.model.message.ModifyDnResponse;
import org.apache.directory.api.ldap.model.message.ResultCodeEnum;
import org.apache.directory.api.ldap.model.message.controls.OpaqueControl;
import org.apache.directory.ldap.client.api.LdapConnection;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kronos.auth.ldap.api.LdapModify;
import com.kronos.auth.ldap.api.LdapOperationException;

public class LdapModifyImpl implements LdapModify {
	private static final Logger xlogger = LoggerFactory.getLogger(LdapSearchResponseImpl.class);
	LdapModifyRequest modifyRequest;
	private LdapConnectionMgr ldapConnectionMgr;
	private LdapConnection connection = null;
	public LdapModifyImpl( LdapModifyRequest modifyRequest) {
		super();
		this.modifyRequest = modifyRequest;
		this.ldapConnectionMgr =LdapConnectionMgr.getLdapConnectionMgr();
	}

	@Override
	public boolean executeModifyAttribute() throws LdapOperationException {
		try {
			 modifyAttribute();
		} catch (LdapException e) {
			xlogger.error(".executeModify() : [{}]", e.getMessage());
			throw new LdapOperationException(e.getMessage(), e);
		} finally {
			ldapConnectionMgr.closeConnection(connection);
		}
		return true;
	}

	@Override
	public boolean executeAddEntry() throws LdapOperationException {
		try {
			xlogger.info("executeAddEntry : [{}]");
			addEntry();
			xlogger.info("executeAddEntry end");
		} catch (LdapException e) {
			xlogger.error(".executeAdd() : [{}]", e.getMessage());
			throw new LdapOperationException(e.getMessage(), e);
		} finally {
			ldapConnectionMgr.closeConnection(connection);
		}
		return true;
	}

	/**
	 * deletes all sub entries as well
	 */
	@Override
	public boolean executeDeleteSubTree() throws LdapOperationException {
		try {
			DeleteRequest deleteRequest = new DeleteRequestImpl();
			deleteRequest.setName(modifyRequest.getDn());
			// delete all sub tree
			Control deleteTreeControl = new OpaqueControl("1.2.840.113556.1.4.805");
			deleteRequest.addControl(deleteTreeControl);
		    connection = ldapConnectionMgr.getConnection();
		    connection.delete(deleteRequest);
		} catch (LdapException e) {
			xlogger.error(".executeDeleteSubTree() : [{}]", e.getMessage());
			throw new LdapOperationException(e.getMessage(), e);
		} finally {
			ldapConnectionMgr.closeConnection(connection);
		}
		return true;
	}

	/**
	 * Updates the DN itself
	 */
	@Override
	public boolean executeModifyIdentifier() throws LdapOperationException {
		try {
		    connection = ldapConnectionMgr.getConnection();
			ModifyDnRequest modDnReq = new ModifyDnRequestImpl();
			modDnReq.setName(modifyRequest.getDn());
			modDnReq.setNewRdn(modifyRequest.getRdn());
			modDnReq.setDeleteOldRdn(true);
			ModifyDnResponse res = connection.modifyDn(modDnReq);
			ResultCodeEnum resCode = res.getLdapResult().getResultCode();
			if (resCode != ResultCodeEnum.SUCCESS) {
				xlogger.error(".executeModifyIdentifier() : [{}]", res.toString());
				throw new LdapOperationException(res.getLdapResult().getDiagnosticMessage(),resCode.toString());
			}
		} catch (LdapException e) {
			xlogger.error(".executeModifyIdentifier() : [{}]", e.getMessage());
			throw new LdapOperationException(e.getMessage(), e);
		} finally {
			ldapConnectionMgr.closeConnection(connection);
		}
		return true;
	}

	private void modifyAttribute() throws LdapException, LdapOperationException {
		connection = ldapConnectionMgr.getConnection();
		if (modifyRequest != null && !modifyRequest.getDm().isEmpty()) {
			connection.modify(modifyRequest.dn, modifyRequest.getDm().toArray(new DefaultModification[] {}));
		}
	}

	private void addEntry() throws LdapException, LdapOperationException {
		xlogger.info("entering addEntry()");
		 connection = ldapConnectionMgr.getConnection();
		xlogger.info("connection get successful");
		if (modifyRequest != null && modifyRequest.getEntriesToModify() != null
				&& !modifyRequest.getEntriesToModify().isEmpty()) {
			for (Entry element : modifyRequest.getEntriesToModify()) {
				connection.add(element);
			}
		}
	}
}
