package com.kronos.auth.ldap.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.directory.api.ldap.model.entry.Entry;
import org.apache.directory.api.ldap.model.exception.LdapException;
import org.apache.directory.api.ldap.model.ldif.LdifUtils;
import org.apache.directory.api.ldap.model.message.SearchResultEntry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kronos.auth.ldap.util.LdapUtils;

public class SearchResponseParser {

	private static final Logger xlogger = LoggerFactory.getLogger(SearchResponseParser.class);

	private List<SearchResultEntry> entry = new ArrayList<>();

	private List<String> listOfLdif;
	private List<Map<String, List<String>>> ldifResultMap;
	private String ldifAsString;


	public List<SearchResultEntry> getEntry() {
		return entry;
	}

	public void addEntry(SearchResultEntry item){
		entry.add(item);
	}
	public void addLdif(String ldifAsString){
		if(this.listOfLdif!=null)
			this.listOfLdif.add(ldifAsString);
	}
	public void setResponse(List<SearchResultEntry> entryList) {
		this.entry = entryList;
	}
	/**
	 * returns search result LDIF as {@link String}
	 * 
	 * @return
	 */
	public String getLdifasString() {
		xlogger.debug(".getLdifasString() : Start");
		StringBuilder sb = new StringBuilder();
		if (this.ldifAsString == null || this.listOfLdif == null) {
			this.listOfLdif = new ArrayList<>();
			for (SearchResultEntry searchEntity : this.entry) {
				String eachResultAsLdif = getEntryAsString(searchEntity);
				if(eachResultAsLdif!=null){
					sb.append(eachResultAsLdif);
					sb.append("\n");
					addLdif(eachResultAsLdif);
				}
			}
			this.ldifAsString = sb.toString();
		}
		return this.ldifAsString;
	}
	/**
	 * convert Entry to LDIF String
	 * @param searchEntity
	 * @return
	 */
	private String getEntryAsString(SearchResultEntry searchEntity){
		Entry entity = searchEntity.getEntry();
		filterEntry(entity);
		try {
			return LdifUtils.convertToLdif(entity,Integer.MAX_VALUE);
		} catch (LdapException e) {
			xlogger.error("Could not Convert Search result to LDIF [{}]", e.getMessage(), e);
		}
		return null;
	}
	/**
	 * Override this method to add custom logic in case specific handle is required as to what comes out as LDIF i.e if you want to add/remove some attribute from ldif.
	 * this method will be invoked for every entry
	 * @param searchEntity
	 * @return
	 */
	protected void filterEntry(Entry entity){
		// hook
	}

	/**
	 * Parses LDIF into key pair value where key is left side of separator ":"
	 * and value as Right side of separator ":".
	 */
	private Map<String, List<String>> parseLdifToMap(String ldif) {
		Map<String, List<String>> result = new HashMap<>();
		if (ldif == null) {
			return null;
		}
		if (!LdapUtils.isEmpty(ldif)) {
			String[] temp = ldif.split("\n");
			for (String string : temp) {
				String[] value = LdapUtils.split(string, ":", true);
				addResult(result, value);
			}
		}
		return result;
	}

	private void addResult(Map<String, List<String>> result, String[] value) {
		List<String> values = new ArrayList<>();
		if (value.length == 2) {
			String key = value[0].trim();
			String finalValue = value[1];
			if (!LdapUtils.isEmpty(finalValue)) {
				finalValue = finalValue.trim();
			} else {
				finalValue = "";
			}
			if (result.containsKey(key)) {
				result.get(key).add(finalValue);
			} else {
				values.add(finalValue);
				result.put(key, values);
			}
		} else if (value.length > 2) {
			populateResultMap(result, value, values);
		}
	}

	private void populateResultMap(Map<String, List<String>> result, String[] value, List<String> values) {
		String key = value[0];
		String finalValue = value[value.length - 1];
		if (!LdapUtils.isEmpty(finalValue)) {
			finalValue = finalValue.trim();
		} else {
			finalValue = "";
		}
		if (result.containsKey(key)) {
			result.get(key).add(finalValue);
		} else {
			values.add(finalValue);
			result.put(key, values);
		}
	}

	/**
	 * populates {@link LdapSearchResponseImpl.ldifResultMap} only once.
	 */
	public List<Map<String, List<String>>> populateldifMap() {
		xlogger.debug(".populateldifMap() : Start");
		if (this.listOfLdif == null) {
			getLdifasString();
			populateldifMap();
		} else if (this.ldifResultMap == null) {
			this.ldifResultMap = new ArrayList<>();
			for (String ldif : this.listOfLdif) {
				Map<String, List<String>> temp = parseLdifToMap(ldif);
				if (!LdapUtils.isEmpty(temp)) {
					this.ldifResultMap.add(temp);
				}
			}
		}
		xlogger.debug(".populateldifMap() : End");
		return this.ldifResultMap;
	}
	
	public List<String> getResultList() {
		List<String> resultString = new ArrayList<>();
		for(SearchResultEntry resultEntry :entry ){
			resultString.add(resultEntry.getObjectName().getName());
		}
		return resultString;
	}
}
