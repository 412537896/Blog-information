package com.kronos.auth.ldap.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.directory.api.ldap.model.entry.DefaultEntry;
import org.apache.directory.api.ldap.model.entry.DefaultModification;
import org.apache.directory.api.ldap.model.entry.Entry;
import org.apache.directory.api.ldap.model.entry.ModificationOperation;
import org.apache.directory.api.ldap.model.exception.LdapException;
import org.apache.directory.api.ldap.model.exception.LdapInvalidDnException;
import org.apache.directory.api.ldap.model.name.Dn;
import org.apache.directory.api.ldap.model.name.Rdn;

import com.kronos.auth.ldap.api.LdapOperationException;
import com.kronos.auth.ldap.util.LdapUtils;

/**
 * This class is responsible for modify operations (such as operations on
 * attributes or creating a new entry)
 * 
 */
public class LdapModifyRequest {
	public static final ModificationOperation OPERA_REPLACE = ModificationOperation.REPLACE_ATTRIBUTE;
	public static final ModificationOperation OPERA_ADD = ModificationOperation.ADD_ATTRIBUTE;
	public static final ModificationOperation OPERA_REMOVE = ModificationOperation.REMOVE_ATTRIBUTE;

	Dn dn;
	Rdn rdn;

	List<Entry> entriesToModify = new ArrayList<>();
	private final List<DefaultModification> dm = new ArrayList<>();

	/**
	 * Constructor which takes existing DN string and attribute to work on.
	 * 
	 * @param dnStr
	 *            String pointing to Existing DN
	 * @param key
	 *            Attribute Key
	 * @param value
	 *            Attribute Value
	 * @throws LdapOperationException
	 */
	public LdapModifyRequest(String dnStr, String key, String value) throws LdapOperationException {
		super();
		try {
			this.dn = new Dn(dnStr);
			dm.add(new DefaultModification(OPERA_REPLACE, key, value));
		} catch (LdapInvalidDnException ex) {
			throw new LdapOperationException(ex.getMessage(), ex);
		}
	}
	

	/**
	 * Constructor which will takes DN string to work on, attribute with
	 * operation can be added later.
	 * 
	 * @param dnStr
	 * @throws LdapOperationException
	 */
	public LdapModifyRequest(String dnStr) throws LdapOperationException {
		super();
		try {
			this.dn = new Dn(dnStr);
		} catch (LdapInvalidDnException ex) {
			throw new LdapOperationException(ex.getMessage(), ex);
		}
	}

	/**
	 * Constructor which takes new RDN String to which DN String will converted
	 * to.
	 * 
	 * @param dnStr
	 * @param newRdnStr
	 * @throws LdapOperationException
	 */
	public LdapModifyRequest(String dnStr, String newRdnStr) throws LdapOperationException {
		super();
		try {
			this.dn = new Dn(dnStr);
			this.rdn = new Rdn(newRdnStr);
		} catch (LdapInvalidDnException ex) {
			throw new LdapOperationException(ex.getMessage(), ex);
		}
	}

	/**
	 * Constructor which will takes DN to work on, attribute with operation can be added later.
	 * @deprecated
	 * @param dn
	 */
	@Deprecated
	public LdapModifyRequest(Dn dn) {
		super();
		this.dn = dn;
	}

	@SuppressWarnings("unchecked")
	public void addEntry(Map<String, Object> attributes) throws LdapOperationException {
		try {		
			Entry de = new DefaultEntry();
			de.setDn(this.dn);
			for (Map.Entry<String, Object> entry : attributes.entrySet()) {
				List<Object> value = (List<Object>) entry.getValue();
				for (Object object : value) {
					de.add(entry.getKey(), (String) object);					
				}
			}
			this.addEntry(de);
		} catch (LdapException ex) {
			throw new LdapOperationException(ex.getMessage(), ex);
		}
	}

	void addEntry(Entry entry) {
		if (null != entry) {
			entriesToModify.add(entry);
		}
	}

	void setEntriesToModify(List<Entry> entriesToModify) {
		this.entriesToModify = entriesToModify;
	}

	List<Entry> getEntriesToModify() {
		return entriesToModify;
	}

	Dn getDn() {
		return dn;
	}

	Rdn getRdn() {
		return this.rdn;
	}

	List<DefaultModification> getDm() {
		return dm;
	}

	public void addAttrToModify(String key, String value) {
		if (!LdapUtils.isEmpty(key) && !LdapUtils.isEmpty(value)) {
			dm.add(new DefaultModification(OPERA_REPLACE, key, value));
		}
	}

	public void addAttrToDelete(String key, String value) {
		if (!LdapUtils.isEmpty(key) && !LdapUtils.isEmpty(value)) {
			dm.add(new DefaultModification(OPERA_REMOVE, key, value));
		}
	}
	
	public void addAttr(String key, String value) {
		if (!LdapUtils.isEmpty(key) && !LdapUtils.isEmpty(value)) {
			dm.add(new DefaultModification(OPERA_ADD, key, value));
		}
	}

}
