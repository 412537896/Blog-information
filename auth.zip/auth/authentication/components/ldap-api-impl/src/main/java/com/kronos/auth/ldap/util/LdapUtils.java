package com.kronos.auth.ldap.util;

/**
 * Contains utility methods that can be used across application
 * 
 * @author Sandeep.Agrrawal
 *
 */
public class LdapUtils {
	
	private LdapUtils(){
		
	}
	
	/**
	 * Splits the given string based on given key
	 * 
	 * @param stringToSplit
	 * @param key
	 * @param isconsiderFirstOccurrence
	 * @return
	 */
	public static String[] split(String stringToSplit, String key, boolean isconsiderFirstOccurrence) {
		if (isEmpty(stringToSplit)) {
			return new String[] {};
		}
		if (!isconsiderFirstOccurrence) {
			return stringToSplit.split(key);
		} else {
			int index = stringToSplit.indexOf(key);
			String firstIndexValue;
			String secondIndexValue;
			if (index > -1) {
				firstIndexValue = stringToSplit.substring(0, index);
				secondIndexValue = stringToSplit.substring(index + 1);
				return new String[] { firstIndexValue, secondIndexValue };
			}
		}
		return new String[] {};
	}

	/**
	 * Checks if given object is empty or not
	 * 
	 * @param str
	 * @return
	 */
	public static boolean isEmpty(Object str) {
		return (str == null || "".equals(str));
	}
}
