package com.kronos.auth.ldap.impl;

public class LdapSearchRequest {

	public enum SCOPE {
		SINGLE("one"), BASE("bae"), SUBORDINATE("subordinates"), WHOLE_SUBTREE("sub");

		private final String value;

		SCOPE(String value) {
			this.value = value;
		}

		public String getValue() {
			return value;
		}

	}

	private String baseDN = "";

	private SCOPE scope = SCOPE.SINGLE;

	private String filter = "(objectClass=*)";

	private String[] attributes;

	public LdapSearchRequest(String baseDN) {
		this.baseDN = baseDN;
		this.scope = SCOPE.SINGLE;
		this.filter = "(objectClass=*)";
		this.attributes = new String[0];
	}

	/**
	 * @return the baseDN
	 */
	public String getBaseDN() {
		return baseDN;
	}

	/**
	 * @param baseDN
	 *            the baseDN to set
	 */
	public void setBaseDN(String baseDN) {
		this.baseDN = baseDN;
	}

	/**
	 * @return the scope
	 */
	public SCOPE getScope() {
		return scope;
	}

	/**
	 * @param scope
	 *            the scope to set
	 */
	public void setScope(SCOPE scope) {
		this.scope = scope;
	}

	/**
	 * @return the filter
	 */
	public String getFilter() {
		return filter;
	}

	/**
	 * @param filter
	 *            the filter to set
	 */
	public void setFilter(String filter) {
		this.filter = filter;
	}

	/**
	 * @return the attributes
	 */
	public String[] getAttributes() {
		return attributes;
	}

	/**
	 * @param attributes
	 *            the attributes to set
	 */
	public void setAttributes(String[] attributes) {
		this.attributes = attributes;
	}

}
