package com.kronos.auth.clientlib.post.authn.impl;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Lazy;

import com.kronos.auth.clientlib.exception.AuthNPublicException;
import com.kronos.auth.clientlib.post.authn.api.PostRefreshProcessingAPIService;
import com.kronos.auth.clientlib.post.authn.api.PostRefreshProcessingService;
import com.kronos.auth.clientlib.util.AuthConstants;
import com.kronos.auth.clientlib.util.LoggerHelper;

@Named("PostRefreshProcessingServiceClientLibRestImpl")
public class PostRefreshProcessingRestServiceImpl implements PostRefreshProcessingAPIService {

	@Context
	private HttpServletRequest httpReq;
	@Context
	private HttpServletResponse httpResp;

	static final Logger LOGGER = LoggerFactory.getLogger(PostRefreshProcessingRestServiceImpl.class);

	@Inject @Lazy
	PostRefreshProcessingService postRefreshProcessingService;

	@Override
	public Response performRefresh() {
		LoggerHelper.info(LOGGER, ".performRefresh : Start");
		Response res = null;
		try {
			String status = postRefreshProcessingService.performPostRefresh(httpReq, httpResp);

			if (status.equalsIgnoreCase(AuthConstants.UNAUTHORIZED)) {
				res = Response.status(Status.UNAUTHORIZED).entity(AuthConstants.SSO_TOKEN_VALIDATON_FAILED).build();
			} else if (status.equalsIgnoreCase(AuthConstants.ACCEPTED)) {
				res = Response.accepted().build();
			}
		} catch (AuthNPublicException ex) {
			// eating exception as the interface does not throw this exception.
			LOGGER.error(".performRefresh : " + ex.getMessage(), ex);
		}
		LoggerHelper.info(LOGGER, ".performRefresh : End");
		LoggerHelper.debug(LOGGER, ".performRefresh : returing Response [{}]", res);
		return res;
	}

}
