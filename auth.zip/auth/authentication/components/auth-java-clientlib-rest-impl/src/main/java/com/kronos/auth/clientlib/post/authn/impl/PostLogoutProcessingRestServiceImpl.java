package com.kronos.auth.clientlib.post.authn.impl;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Lazy;

import com.kronos.auth.clientlib.exception.AuthNPublicException;
import com.kronos.auth.clientlib.post.authn.api.PostLogoutProcessingAPIService;
import com.kronos.auth.clientlib.post.authn.api.PostLogoutProcessingService;
import com.kronos.auth.clientlib.util.AuthConstants;
import com.kronos.auth.clientlib.util.LoggerHelper;

@Named("PostLogoutProcessingServiceClientLibRestImpl")
public class PostLogoutProcessingRestServiceImpl implements PostLogoutProcessingAPIService {

	@Context
	private HttpServletRequest httpReq;
	@Context
	private HttpServletResponse httpResp;

	static final Logger LOGGER = LoggerFactory.getLogger(PostLogoutProcessingRestServiceImpl.class);

	@Inject @Lazy
	PostLogoutProcessingService postLogoutProcessingService;

	@Override
	public Response performLogout() {
		LoggerHelper.info(LOGGER, ".performLogout : Start");
		Response res = null;
		try {
			String status = postLogoutProcessingService.performPostLogout(httpReq, httpResp);

			if (status.equalsIgnoreCase(AuthConstants.UNAUTHORIZED)) {
				res = Response.status(Status.UNAUTHORIZED).entity(AuthConstants.SSO_TOKEN_VALIDATON_FAILED).build();
			} else if (status.equalsIgnoreCase(AuthConstants.ACCEPTED)) {
				res = Response.accepted().header(HttpHeaders.CONTENT_TYPE, MediaType.TEXT_HTML).build();
			}
		} catch (AuthNPublicException ex) {
			// eating exception as the interface does not throw this exception.
			LOGGER.error(".performLogout : " + ex.getMessage(), ex);
		}
		LoggerHelper.info(LOGGER, ".performLogout : End");
		LoggerHelper.debug(LOGGER, ".performLogout : returing Response [{}]", res);
		return res;
	}

}
