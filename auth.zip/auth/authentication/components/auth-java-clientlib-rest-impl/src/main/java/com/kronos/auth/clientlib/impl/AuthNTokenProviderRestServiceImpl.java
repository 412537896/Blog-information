package com.kronos.auth.clientlib.impl;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.springframework.context.annotation.Lazy;

import com.kronos.auth.clientlib.api.AuthNTokenProvider;
import com.kronos.auth.clientlib.api.AuthNTokenProviderAPIService;
import com.kronos.auth.clientlib.exception.AuthNPublicException;
import com.kronos.auth.clientlib.util.AuthConstants;
import com.kronos.auth.domain.OpenAmConfigAttrDTO;
import com.kronos.auth.domain.SSOSessionInfo;
import com.kronos.auth.domain.UserInfo;

@Named("AuthNTokenProviderImplClientLibRestImpl")
public class AuthNTokenProviderRestServiceImpl implements AuthNTokenProviderAPIService { 

	@Context private HttpServletRequest httpReq;
	private static final String RESPONSE = "{\"message\":\"Success\"}";

	@Inject @Lazy
	AuthNTokenProvider authNTokenProvider;

	/**
	 *  Will return login and validated UserInfo
	 * @throws AuthNPublicException 
	 */
	@Override
	public UserInfo getUserInfo() throws AuthNPublicException{
		return authNTokenProvider.getUserInfo(httpReq);
	}

	/**
	 * Will return true if SSO Token is valid
	 * @throws AuthNPublicException 
	 */
	@Override
 	public boolean isSSOSessionValid() throws AuthNPublicException {
		return authNTokenProvider.checkSSOToken(httpReq);
	}
	
	/**
	 * Will return SSO session information
	 */
	@Override
	public SSOSessionInfo getSSOSessionInfo() throws AuthNPublicException {
		return authNTokenProvider.getSSOSessionInfo(httpReq);
	}
	
	/**
	 * Will return user sessionTimeout info
	 * @throws AuthNPublicException 
	 */
	@Override
	public Response getSessionTimeOut() throws AuthNPublicException {

		try {
			OpenAmConfigAttrDTO attrDTO = authNTokenProvider.getSessionTimeOut(httpReq);
			return Response.ok(attrDTO).build();
		} catch (AuthNPublicException ex) {
			return Response.status(Status.UNAUTHORIZED).entity(AuthConstants.NOT_AUTHORIZED).build();
		}
	}
		
		/**
		 * Will return success if call is received at backend
		 */
		@Override
		public Response extendSession() throws AuthNPublicException {
			return Response.ok(RESPONSE).build();
		}
}
