package com.kronos.auth.clientlib.post.authn.impl;

import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Lazy;

import com.kronos.auth.clientlib.exception.AuthNPublicException;
import com.kronos.auth.clientlib.post.authn.api.PostAuthNProcessingAPIService;
import com.kronos.auth.clientlib.post.authn.api.PostAuthNProcessingService;
import com.kronos.auth.clientlib.util.AuthConstants;
import com.kronos.auth.clientlib.util.LoggerHelper;


@Named("PostAuthNProcessingServiceClientLibRestImpl")
public class PostAuthNProcessingRestServiceImpl implements PostAuthNProcessingAPIService{

	@Context private HttpServletRequest httpReq;
	@Context private HttpServletResponse httpResp;
	
	static final Logger LOGGER = LoggerFactory.getLogger(PostAuthNProcessingRestServiceImpl.class);
	
	@Inject @Lazy
	PostAuthNProcessingService postAuthNProcessingService;
	/**
	 * public no-arg constructor
	 */
	public PostAuthNProcessingRestServiceImpl() {
		//constructor
	}

	/**
	 * validates User token and set session Cookies.
	 * This method can return null.
	 * @return Response
	 */

	@Override
	public Response performPostAuthNInitializeSession() {
		LoggerHelper.info(LOGGER,".performPostAuthNInitializeSession : Start");
		Response res = null;
		try {
			String status = postAuthNProcessingService.performPostAuthNInitializeSession(httpReq,httpResp);
			
			if(status.equalsIgnoreCase(AuthConstants.UNAUTHORIZED)) {
				res = Response.status(Status.UNAUTHORIZED).entity(AuthConstants.SSO_TOKEN_VALIDATON_FAILED).build();
			} else if (status.equalsIgnoreCase(AuthConstants.ACCEPTED)) {
				res = Response.accepted().build();
			}
		}  catch (AuthNPublicException ex) {
			// eating exception as the interface does not throw this exception.
			LOGGER.error(".performPostAuthNInitializeSession : "+ex.getMessage(),ex);
		}
		LoggerHelper.info(LOGGER,".performPostAuthNInitializeSession : End");
		LoggerHelper.debug(LOGGER, ".performPostAuthNInitializeSession : returing Response [{}]",res);
		return res;
	}

}
