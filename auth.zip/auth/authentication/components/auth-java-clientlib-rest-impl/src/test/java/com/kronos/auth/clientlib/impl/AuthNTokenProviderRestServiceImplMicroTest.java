package com.kronos.auth.clientlib.impl;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Response;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PowerMockIgnore;
import org.powermock.modules.junit4.PowerMockRunner;

import com.kronos.auth.clientlib.api.AuthNTokenProvider;
import com.kronos.auth.domain.OpenAmConfigAttrDTO;
import com.kronos.auth.domain.SSOSessionInfo;
import com.kronos.auth.domain.UserInfo;
import com.mockrunner.mock.web.MockHttpServletRequest;

import junit.framework.TestCase;

//@PrepareForTest({AuthNTokenProviderImpl.class, JWTTokenProcessor.class })
@RunWith(PowerMockRunner.class)
@PowerMockIgnore({"javax.crypto.*" })
public class AuthNTokenProviderRestServiceImplMicroTest extends TestCase {
	
	@Mock
    private HttpServletRequest request = PowerMockito.mock(MockHttpServletRequest.class);
	
	@Mock
    AuthNTokenProvider authNTokenProvider = PowerMockito.spy(new AuthNTokenProviderImpl());
	
	@InjectMocks
	AuthNTokenProviderRestServiceImpl authNTokenProviderRestServiceImpl = new AuthNTokenProviderRestServiceImpl();
	
	String response = "session.time=30";
	
	@Test
	public void testGetUserInfo_RestCall() throws Exception {
		PowerMockito.doReturn(new UserInfo("user", "tenant")).when(authNTokenProvider).getUserInfo(request);
		UserInfo userinfo = authNTokenProviderRestServiceImpl.getUserInfo();
		assertEquals("user", userinfo.getUsername());
		
	}

	@Test
	public void testisSSOSessionValid() throws Exception {
		PowerMockito.doReturn(true).when(authNTokenProvider).checkSSOToken(request);
		boolean value = authNTokenProviderRestServiceImpl.isSSOSessionValid();
		assertTrue(value);
	}

	@Test
	public void testGetSSOSessionInfo() throws Exception {
		SSOSessionInfo info = new SSOSessionInfo();
		info.setIdleTtl(-1);
		PowerMockito.doReturn(info).when(authNTokenProvider).getSSOSessionInfo(request);
		PowerMockito.doReturn(true).when(authNTokenProvider).checkSSOToken(request);
		SSOSessionInfo value = authNTokenProviderRestServiceImpl.getSSOSessionInfo();
		assertNotNull(value);
		assertTrue(value.getIdleTtl() == -1);
	}

	@Test
	public void testGetSessionTimeOut() throws Exception
	{
		OpenAmConfigAttrDTO attr = new OpenAmConfigAttrDTO();
		PowerMockito.doReturn(attr).when(authNTokenProvider).getSessionTimeOut(request);
		Response sessionTimeOut = authNTokenProviderRestServiceImpl.getSessionTimeOut();
		assertNotNull(sessionTimeOut);
		assertEquals(sessionTimeOut.getEntity(),attr);
	}
	
	@Test
	public void testExtendSession() throws Exception
	{
		Response message = authNTokenProviderRestServiceImpl.extendSession();
		assertNotNull(message);
	}
	
	
	
}
