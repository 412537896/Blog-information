package com.kronos.auth.clientlib.component.processing.impl;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import junit.framework.TestCase;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;

import com.kronos.auth.clientlib.post.authn.api.PostAuthNProcessingService;
import com.kronos.auth.clientlib.post.authn.impl.PostAuthNProcessingRestServiceImpl;
import com.kronos.auth.clientlib.post.authn.impl.PostAuthNProcessingServiceImpl;
import com.kronos.auth.clientlib.util.AuthConstants;
import com.mockrunner.mock.web.MockHttpServletRequest;
import com.mockrunner.mock.web.MockHttpServletResponse;


@RunWith(MockitoJUnitRunner.class)
@PrepareForTest({ PostAuthNProcessingRestServiceImpl.class })
public class PostAuthNProcessingRestServiceImplMicroTest extends TestCase{
	
	
	@InjectMocks
	PostAuthNProcessingRestServiceImpl postauthNRestservice = new PostAuthNProcessingRestServiceImpl();

	@Mock
	PostAuthNProcessingService postAuthNservice = PowerMockito.mock(PostAuthNProcessingServiceImpl.class);
	
    @Mock
    private HttpServletRequest request = PowerMockito.mock(MockHttpServletRequest.class);
    
    @Mock
    private HttpServletResponse response = PowerMockito.mock(MockHttpServletResponse.class);

	@Test
	public void testSetCustomCookies_Authorized() throws Exception {
		PowerMockito.doReturn(AuthConstants.ACCEPTED).when(postAuthNservice).performPostAuthNInitializeSession(request, response);
		Response setCustomCookies = postauthNRestservice.performPostAuthNInitializeSession();
		assertEquals(setCustomCookies.getStatus(), Status.ACCEPTED.getStatusCode());
	}
	
	@Test
	public void testSetCustomCookies_UnAuthorized() throws Exception {
		PowerMockito.doReturn(AuthConstants.UNAUTHORIZED).when(postAuthNservice).performPostAuthNInitializeSession(request, response);
		Response setCustomCookies = postauthNRestservice.performPostAuthNInitializeSession();
		assertEquals(setCustomCookies.getStatus(), Status.UNAUTHORIZED.getStatusCode());
	}
	
}
