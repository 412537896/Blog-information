package com.kronos.auth.clientlib.component.processing.impl;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;

import com.kronos.auth.clientlib.exception.AuthNPublicException;
import com.kronos.auth.clientlib.post.authn.api.PostLogoutProcessingService;
import com.kronos.auth.clientlib.post.authn.impl.PostLogoutProcessingRestServiceImpl;
import com.kronos.auth.clientlib.post.authn.impl.PostLogoutProcessingServiceImpl;
import com.kronos.auth.clientlib.util.AuthConstants;
import com.mockrunner.mock.web.MockHttpServletRequest;
import com.mockrunner.mock.web.MockHttpServletResponse;

import junit.framework.TestCase;

@RunWith(MockitoJUnitRunner.class)
@PrepareForTest({ PostLogoutProcessingRestServiceImpl.class })
public class PostLogoutProcessingRestServiceImplMicroTest extends TestCase{

	@InjectMocks
	PostLogoutProcessingRestServiceImpl postLogoutRestservice = new PostLogoutProcessingRestServiceImpl();

	@Mock
	PostLogoutProcessingService postLogoutservice = PowerMockito.mock(PostLogoutProcessingServiceImpl.class);
	
    @Mock
    private HttpServletRequest request = PowerMockito.mock(MockHttpServletRequest.class);
    
    @Mock
    private HttpServletResponse response = PowerMockito.mock(MockHttpServletResponse.class);

	@Test
	public void testSetCustomCookies_Authorized() throws Exception {
		PowerMockito.doReturn(AuthConstants.ACCEPTED).when(postLogoutservice).performPostLogout(request, response);
		Response setCustomCookies = postLogoutRestservice.performLogout();
		assertEquals(setCustomCookies.getStatus(), Status.ACCEPTED.getStatusCode());
	}
	
	@Test
	public void testSetCustomCookies_UnAuthorized() throws Exception {
		PowerMockito.doReturn(AuthConstants.UNAUTHORIZED).when(postLogoutservice).performPostLogout(request, response);
		Response setCustomCookies = postLogoutRestservice.performLogout();
		assertEquals(setCustomCookies.getStatus(), Status.UNAUTHORIZED.getStatusCode());
	}
	
	@Test
	public void testSetCustomCookies_Exception() throws Exception {
		PowerMockito.doThrow(new AuthNPublicException()).when(postLogoutservice).performPostLogout(request, response);
		Response setCustomCookies = postLogoutRestservice.performLogout();
		assertNull(setCustomCookies);
	}
}