package com.kronos.ALM;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import org.apache.log4j.Logger;
import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.response.Header;
import com.jayway.restassured.response.Headers;
import com.jayway.restassured.response.Response;
import com.kronos.logging.KronosLogger;

public class ALMAuthN {
	protected final static Logger logger = Logger.getLogger(ALMAuthN.class);
	public static final String BREAK_LINE = "</br>";
	public static final String REST_CLIENT = "REST Client";
	public static final int TIMEOUT = 60;

	/**
	 * Login function
	 * 
	 * @param apiOps: APIOperation
	 * @param userName: String
	 * @param password: String
	 * @param loginEndpoint: String
	 * @return cookie: String
	 */
	private static String getALMLoginPayload(String userName, String password){
		KronosLogger.traceEnter();
		String payload="";
		try{
		payload="<alm-authentication>"
				+ "<user>"
				+ userName
				+ "</user>"
				+ "<password>"
				+ password
				+ "</password>"
				+ "</alm-authentication>";
		}catch(Exception e){		
			logger.error(e.getMessage());
		}
	
		return payload;
	}	
	
	
	/**
	 * Login function
	 * 
	 * @param apiOps: APIOperation
	 * @param userName: String
	 * @param password: String
	 * @param loginEndpoint: String
	 * @return cookie: String
	 */
	public static String doALMLogin(APIOperations apiOps,String userName, String password, String loginEndpoint, String sessionEndpoint){
		KronosLogger.traceEnter();
		Response res=null;
		 String infoMessage="Logged in to ALM with username :"+ userName+BREAK_LINE+ " Password : *********"+BREAK_LINE+" Login endpoint as : "+ loginEndpoint ;
		try{
			res=apiOps.postWithFormParameters(getALMLoginPayload(userName, password), loginEndpoint, ContentType.XML);
			logger.info(infoMessage);
		}catch(Exception e){		
			logger.error(infoMessage,e);
		}
		KronosLogger.traceLeave();
		return generateCookie(apiOps,res,sessionEndpoint);
		
	}	
	
	/**
	 * Generate cookie via ALM login response and create a valid session
	 * 
	 * @param loginResponse: Response
	 * @param apiOps: APIOperations
	 * @param sessionEndpoint: String
	 * @return cookie in String
	 */
	private static String generateCookie(APIOperations apiOps,Response loginResponse, String sessionEndpoint) {
		KronosLogger.traceEnter();
		String cookie="";
		String PATH=";Path=/";
		try{
		cookie="LWSSO_COOKIE_KEY="+loginResponse.getHeader("Set-Cookie").split("[=]")[1].split("[;]")[0]+PATH;
		
		Map<String, String> headerParameters=new HashMap<String , String>();
		headerParameters.put("Cookie", cookie);
		
		Response res= apiOps.postWithFormParameters(cookie,generatePayLoadForSession(),sessionEndpoint, ContentType.XML);
		
		Headers headers= res.getHeaders();
		
		String cookie1="";
		Iterator<Header> it= headers.iterator();	   
		  while(it.hasNext()){
		   Header h= (Header) it.next();
		   if(h.getName().equalsIgnoreCase("Set-Cookie") && h.getValue().contains("QCSession")){
		   cookie1=cookie1+h.getValue().split("[;]")[0];	    
		   }		   
		  }
		  cookie=cookie+";"+cookie1+PATH;		
		
		logger.info("Generated ALM cookie is : "+ cookie);
		}catch(Exception e){
			logger.error("Exception occured while generating ALM cookie .  Exception occured is due to : "+e.getMessage());

		}
		   KronosLogger.traceLeave();
		   return cookie;
	}


	private static String generatePayLoadForSession() {
		String payLoad = "<session-parameters>"
				+ "<client-type>"
				+ 	REST_CLIENT
				+ "</client-type>"
				+ "<timeout>"
				+ 	TIMEOUT
				+ "</timeout>"
				+ "</session-parameters>";
		return payLoad;
	}
	
	
}
