package com.kronos.ALM;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.jayway.restassured.RestAssured;
import org.apache.commons.codec.binary.Base64;
import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.path.json.JsonPath;
import com.jayway.restassured.response.Response;
import com.kronos.api.rest.exception.KronosCoreAPIException;
import com.kronos.exception.KronosCoreCommonException;
import com.kronos.logging.KronosLogger;
import com.relevantcodes.extentreports.LogStatus;

public class ALMDriver{
	static Report reporter= null;
	private static File folder =new File("");
	private static List <String> listOfFiles=new ArrayList<String>();
	private static APIOperations apiOps= new APIOperations();
	private static Map<String,String> params=null;
	private static String ALM_BASE_URL="";
	private static String GOLOBAL_ALM_COOKIE= "";
	private static String TESTSET_ID="";
	private static String TEST_APP_BUILD="";
	private static String TEST_BUILD_LEVEL="";
	private static String ALM_TESTCASE_OWNER=""; 
	private static String ALM_LOGIN_PASSWORD = "RmFsY29uVDAwTCQ=";
	private static String ALM_LOGIN_USER = "svchpalm1";
	private static String JSON_FILE_LOC="";
	
	
	private static String BASE_RESOURSE=""; 
	private static String REST="";
	private static String DOMAIN=""; 
	private static String PROJECTS=""; 
	
	private static String TEST_INSTANCE="";
	private static String PAGE_SIZE="1000";
	private static String RUNS="";
	private static String SESSION="";
	private static String LOGIN_ENDPOINT="";
	private static String LOGOUT="";
	private static String temp = "";
	
	@BeforeSuite(alwaysRun=true)
	public void almSetUP(ITestContext context) throws KronosCoreCommonException{		
			KronosLogger.traceEnter();
			try {
				params = context.getCurrentXmlTest().getAllParameters();
				
			} catch (Exception e) {
				String errorMsg = "excution before suite fail!";
				throw new KronosCoreCommonException(errorMsg,e);
			}
			KronosLogger.traceLeave();
	
		ALM_BASE_URL=params.get("ALM_BASE_URL");		
		TESTSET_ID=params.get("ALM_TEST_SET_ID");
		ALM_TESTCASE_OWNER=params.get("ALM_USER_NAME");
		JSON_FILE_LOC=params.get("JSON_FILE_LOC");
		folder = new File(JSON_FILE_LOC);
		
		BASE_RESOURSE="/qcbin/"; 
		REST="rest/";
		DOMAIN="domains/"+params.get("ALM_DOMAIN"); 
		PROJECTS="/projects/"+params.get("ALM_PROJECT"); 
		
		TEST_INSTANCE=REST+DOMAIN+PROJECTS+"/test-instances";
		RUNS=REST+DOMAIN+PROJECTS+"/runs/";
		SESSION=REST+"site-session";
		LOGIN_ENDPOINT="authentication-point/alm-authenticate";
		LOGOUT="authentication-point/logout";		
		
		reporter= new Report(params.get("REPORT_LOC"));
	}	
	
	@BeforeClass
	public static void almSetup(){
		KronosLogger.traceEnter();
		// set the ALM base url
		setALMBaseURI(ALM_BASE_URL);
		byte[] user_pwd = Base64.decodeBase64(ALM_LOGIN_PASSWORD.getBytes());
		String decoded_pwd = new String(user_pwd);
		// login to ALM and generate the cookies
		GOLOBAL_ALM_COOKIE = ALMAuthN.doALMLogin(apiOps, ALM_LOGIN_USER,  decoded_pwd, LOGIN_ENDPOINT, SESSION);
		KronosLogger.traceLeave();
	}

	/**
	 * This method sets the ALM Base URL 
	 * 
	 * @param ALMBaseURI: String
	 *
	 */
	private static void setALMBaseURI(String ALMBaseURI){
		KronosLogger.traceEnter();
		RestAssured.baseURI=ALMBaseURI;
		RestAssured.basePath=BASE_RESOURSE;
		KronosLogger.traceLeave();
	}
	
	/**
	 * This method updates the status of the newly create Run from Not Completed to actual status in the JSON file
	 * 
	 * @param testInstanceId: String
	 * @param testCaseId: String
	 * @param status: String
	 * @throws KronosCoreAPIException
	 */
	private void createRun(String testInstanceId,String testCaseId,String status) throws KronosCoreAPIException{
		KronosLogger.traceEnter(); 
		String runID = createRunwithStatusNotCompleted(testInstanceId,testCaseId,"Not Completed");
		String URI = RUNS + runID;
		Response res = apiOps.putWithFormParameters(GOLOBAL_ALM_COOKIE, getUpdateRunPayload(status), URI, ContentType.XML);
		if(checkAuthFailure(res.asString())){
			almSetup();
			res = apiOps.putWithFormParameters(GOLOBAL_ALM_COOKIE, getUpdateRunPayload(status), URI, ContentType.XML);
		}
		KronosLogger.traceLeave();
	}
	
	
	/**
	 * This method is used to create a new run under a a test Instance with status as Not Completed
	 * 
	 * @param testInstanceId: String
	 * @param testCaseId: String
	 * @param status: String
	 * @return runId: String
	 * @throws KronosCoreAPIException
	 */
	private String createRunwithStatusNotCompleted(String testInstanceId,String testCaseId,String status) throws KronosCoreAPIException{
		KronosLogger.traceEnter(); 
		String runId = "";		
		Response res = apiOps.postWithFormParameters(GOLOBAL_ALM_COOKIE, getCreateRunPayload(testInstanceId,testCaseId,status), RUNS, ContentType.XML);
		if(checkAuthFailure(res.asString())){
			almSetup();
			res = apiOps.postWithFormParameters(GOLOBAL_ALM_COOKIE, getCreateRunPayload(testInstanceId,testCaseId,status), RUNS, ContentType.XML);
		}
		String run = res.asString();
		runId = JsonPath.with(run).get("Fields.find {fields -> fields.Name=='id'}.values[0].value");
		
		KronosLogger.traceLeave();
		return runId;
	}
	
	/**
	 * This method is used to logout from ALM
	 */	
	private static void logout() throws KronosCoreAPIException{
		KronosLogger.traceEnter();
		 apiOps.getWithNoParameters("", LOGOUT);
		 KronosLogger.traceLeave();
	}
	
	/**
	 * This method is used to create a payload for new run under a testInstance
	 * 
	 * @param testInstanceId: String
	 * @param testCaseId: String
	 * @param status: String
	 */
	private static String getCreateRunPayload(String testInstanceId,String testCaseId,String status){
		KronosLogger.traceEnter();
		String runXml="<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
	 			+"<Entity Type=\"run\">"
	 			+"<Fields>"
	 			+"<Field Name=\"name\"><Value>Run_Automation</Value>"
	 			+"</Field><Field Name=\"test-instance\"><Value>1</Value>"
	 			+"</Field><Field Name=\"testcycl-id\"><Value>"+testInstanceId+"</Value>"    // this is your test instance id
	 			+"</Field><Field Name=\"cycle-id\"><Value>"+TESTSET_ID+"</Value>"     // test set id
	 			+"</Field><Field Name=\"test-id\"><Value>"+testCaseId+"</Value>"       // test case
	 			+"</Field><Field Name=\"subtype-id\"><Value>hp.qc.run.MANUAL</Value>"
	 			+"</Field><Field Name=\"status\"><Value>"+status+"</Value>"
	 			+"</Field><Field Name=\"user-01\"><Value>"+ALM_LOGIN_USER+"</Value>"
	 			+"</Field><Field Name=\"owner\"><Value>"+ALM_TESTCASE_OWNER+"</Value>"
	 			+"</Field><Field Name=\"user-template-01\"><Value>"+TEST_APP_BUILD+"</Value>"
	 			+"</Field><Field Name=\"user-template-07\"><Value>"+TEST_BUILD_LEVEL+"</Value>"
	 			+"</Field>"
	 			+"</Fields>"
	 			+"<RelatedEntities/>"
	 			+"</Entity>";
		KronosLogger.traceLeave();
		return runXml;
		
	}
	
	/**
	 * This method is used to create a payload for new run under a testInstance
	 * 
	 * @param testInstanceId: String
	 * @param testCaseId: String
	 * @param status: String
	 */
	private static String getUpdateRunPayload(String status){
		KronosLogger.traceEnter();
		String runXml="<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
	 			+"<Entity Type=\"run\">"
	 			+"<Fields>"
	 			+"<Field Name=\"status\"><Value>"+status+"</Value></Field>"
	 			+"</Fields>"
	 			+"<RelatedEntities/>"
	 			+"</Entity>";
		KronosLogger.traceLeave();
		return runXml;
		
	}
	
	@DataProvider
	public static Object[][] getFiles(){			
	    listFilesForFolder(folder);
	    int noOfFiles= listOfFiles.size();
	    Object[][] jsonFiles= new Object[noOfFiles][1];
	    Iterator<String> it= listOfFiles.iterator();    
	    for(int i=0;i<noOfFiles;i++){
	    	String filePath= it.next();
	    	jsonFiles[i][0]=filePath;
	    }
	    	return jsonFiles; 
	}
	
	public static void listFilesForFolder(final File folder) {

	    for (final File fileEntry : folder.listFiles()) {
	      if (fileEntry.isDirectory()) {
	        listFilesForFolder(fileEntry);
	      } else {
	        if (fileEntry.isFile()) {
	          temp = fileEntry.getName();
	          if ((temp.substring(temp.lastIndexOf('.') + 1, temp.length()).toLowerCase()).equals("json"))
	        	  listOfFiles.add(folder.getAbsolutePath()+ "/" + fileEntry.getName());
	        }
	      }
	    }
	  }
	/**
	 * This method is used to generates a map with the mapping between test case and test instance and returns the map with test instance and their status 
	 * 
	 * @param testSetId: String
	 * @return Map
	 * @throws KronosCoreAPIException
	 */
	private static Map<String,String> getTestInstanceToTestCaseMap(String testSetId) throws KronosCoreAPIException{
		KronosLogger.traceEnter();
		Map<String, String> params= new HashMap<String,String>();		
		params.put("query", "{cycle-id["+testSetId+"]}"); 
		params.put("page-size", PAGE_SIZE);
		params.put("fields", "test-id,id");
		Response res= apiOps.getWithQueryparameters(GOLOBAL_ALM_COOKIE, params, TEST_INSTANCE);
		String response = res.asString();
		if(checkAuthFailure(response)){
			almSetup();
			res = apiOps.getWithQueryparameters(GOLOBAL_ALM_COOKIE, params, TEST_INSTANCE);
		}
		response = res.asString();
		int totalResults = JsonPath.with(response).get("TotalResults");
		if(totalResults == 0){
			udpateExtentReport();
			return null;
		}
		
		HashMap<String,String> testInstanceToTestCaseMap= new HashMap<String,String>();
		
		List testCasesInTestSet = JsonPath.with(response).get("entities.Fields");
		
		for(int i=0;i<testCasesInTestSet.size();i++){
			String testInstance = JsonPath.with(response).get("entities[" + i + "].Fields.find {fields -> fields.Name=='id'}.values[0].value");
			String testCaseId = JsonPath.with(response).get("entities[" + i + "].Fields.find {fields -> fields.Name=='test-id'}.values[0].value");
			testInstanceToTestCaseMap.put(testInstance, testCaseId);
		}
 		KronosLogger.traceLeave();
 		return testInstanceToTestCaseMap;		
	}
	
	/**
	 * This method is used to create 
	 * a map with all test instances and their status to be updated  (statues will be only available for the tests executed ie if they were automated) 
	 * ie. 
	 *  case 1 - there might be tests cases automated but are not part of the test set, so will not get a test instance related to that test case in test set
	 *  case 2 - there might be test instance for which there is no test case automated yet, so do not have the execution status for this test instance.
	 * 
	 * @param testSetId: String
	 * @param testExecutionMap: Map
	 * @return Map
	 * @throws KronosCoreAPIException
	 */
	private void updateTests(Map<String,String> testInstanceTotestCaseMap, Map<String,String> testExecutionMap) throws KronosCoreAPIException{
		KronosLogger.traceEnter();
		if(testInstanceTotestCaseMap==null)
			return;
		//	List contains the test instances that are to be updated to ALM
		ArrayList<String> testInstancesToBeUpdated = new ArrayList<>();
		//	List contains the test instances that are not to be updated to ALM
		ArrayList<String> testInstancesNotToBeUpdated = new ArrayList<>();
		
		for(String testInstance : testInstanceTotestCaseMap.keySet()){
			String testCaseId = testInstanceTotestCaseMap.get(testInstance);
			if(testExecutionMap.containsKey(testCaseId))
				testInstancesToBeUpdated.add(testInstance);
			else
				testInstancesNotToBeUpdated.add(testInstance);
		}
		
		//	Updating results in ALM
		for(String udpateInstance : testInstancesToBeUpdated)
			createRun(udpateInstance,testInstanceTotestCaseMap.get(udpateInstance),testExecutionMap.get(testInstanceTotestCaseMap.get(udpateInstance)));
		
		//	Publish Extent report 
		udpateExtentReport(testInstancesToBeUpdated,testInstancesNotToBeUpdated,testInstanceTotestCaseMap);
		
 		KronosLogger.traceLeave();
	}
	
	private static void udpateExtentReport(ArrayList<String> testInstancesToBeUpdated,
			ArrayList<String> testInstancesNotToBeUpdated,Map<String,String> testInstanceTotestCaseMap) {
		KronosLogger.traceEnter();
		
		String updatedTestCases="",notUpdatedTestCase="";
		reporter.reportStep("Number of test cases present in the ALM test set: " + (testInstancesToBeUpdated.size() + testInstancesNotToBeUpdated.size()));
 		reporter.reportStep("Number of test cases for which we have results in JSON file: " + testInstancesToBeUpdated.size());
 		if(testInstancesNotToBeUpdated.size()==0)
 			reporter.reportStep("Number of test cases present in ALM but not in JSON file: " + testInstancesNotToBeUpdated.size());
			
 		else
 			reporter.reportStep(LogStatus.WARNING,"Number of test cases present in ALM but not in JSON file: " + testInstancesNotToBeUpdated.size());

 		//	Print test cases that are updated in ALM
 		if(testInstancesToBeUpdated.size()==0)
 			reporter.reportStep(LogStatus.WARNING,"Test cases present in ALM test set that are updated: None");
 		else{
 			for(String testInstances : testInstancesToBeUpdated)
 				updatedTestCases += testInstanceTotestCaseMap.get(testInstances) + ", ";
 			reporter.reportStep("Test cases present in ALM test set that are updated: " + updatedTestCases.substring(0,updatedTestCases.length()-2));
 		}
 		
 		// 	Print test cases that are not updated in ALM
 		if(testInstancesNotToBeUpdated.size()==0)
 			reporter.reportStep("Test cases present in ALM testset but not updated: None");
 		else{
 			for(String testInstances : testInstancesNotToBeUpdated)
 				notUpdatedTestCase += testInstanceTotestCaseMap.get(testInstances) + ", ";
 			reporter.reportStep(LogStatus.WARNING,"Test cases present in ALM testset but not updated: " + notUpdatedTestCase.substring(0,notUpdatedTestCase.length()-2));
 		}
 		KronosLogger.traceLeave();
	}


	private static void udpateExtentReport() {
		reporter.reportStep(LogStatus.WARNING, "The testSetId either does not exist or has no test cases");		
	}
	
	/**
	 * 
	 * @param response: Takes the response of API and checks for authentication failure
	 * @return true if authentication fails else return false
	 */
	private static boolean checkAuthFailure(String response) {
		KronosLogger.traceEnter();
		if(response.toLowerCase().contains("error 401 authentication failed"))
			return true;
		KronosLogger.traceLeave();
		return false;	
	}
	
	/**
	 * This method is used to convert a json to map
	 * @param json: JSONObject
	 * @return Map
	 * @throws JSONException
	 */
	private static Map<String, String> jsonToMap(JSONObject json) throws JSONException {
        Map<String, String> retMap = new HashMap<String, String>();
        if(json != JSONObject.NULL) {
            retMap = toMap(json);
        }
        return retMap;
    }

	/**
	 * This method is used to convert a json to map
	 * @param json: JSONObject
	 * @return Map
	 * @throws JSONException
	 */
    private static Map<String, String> toMap(JSONObject object) throws JSONException {
        Map<String, String> map = new HashMap<String, String>();

        Iterator<String> keysItr = object.keys();
        while(keysItr.hasNext()) {
            String key = keysItr.next();
            Object value = object.get(key);

            if(value instanceof JSONArray) {
                value = toList((JSONArray) value);
            }

            else if(value instanceof JSONObject) {
                value = toMap((JSONObject) value);
            }
            map.put(key, value.toString());
        }
        return map;
    }
    
   
    public static <T> Set<T> difference(Set<T> setA, Set<T> setB) {
        Set<T> tmp = new TreeSet<T>(setA);
        tmp.removeAll(setB);
        return tmp;
      }
     

    /**
	 * This method is used to convert a json array to list
	 * @param array: JSONArray
	 * @return List
	 * @throws JSONException
	 */
    private static List<Object> toList(JSONArray array) throws JSONException {
        List<Object> list = new ArrayList<Object>();
        for(int i = 0; i < array.length(); i++) {
            Object value = array.get(i);
            if(value instanceof JSONArray) {
                value = toList((JSONArray) value);
            }

            else if(value instanceof JSONObject) {
                value = toMap((JSONObject) value);
            }
            list.add(value);
        }
        return list;
    }
    
	/*
	 * 
	 * Driver script which updates all the testinstances for a given test set id
	 */
    @Test(dataProvider="getFiles",description="Update the test cases in ALM if the flag PUBLISH_RESULTS_TO_ALM is set to true.")    
	public void _ALMupdate(String filepath) throws KronosCoreAPIException{
    	
    	reporter.startTest("_ALMupdate", "Update ALM test results");    	
    	reporter.reportStep("Updating for file : "+ filepath);
    	reporter.reportStep("Summary : ");
    	
    	KronosLogger.traceEnter();
    	try{
        BufferedReader br = null;
        String sCurrentLine;
        String sCurrentLine1="";
		try {
			br = new BufferedReader(new FileReader(filepath));
			while ((sCurrentLine = br.readLine()) != null) {
				sCurrentLine1=sCurrentLine1+sCurrentLine;
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (br != null)br.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}        
        JSONObject json= new JSONObject(sCurrentLine1);		
        if(json.has("Build"))
        	TEST_APP_BUILD = json.getString("Build");
        if(json.has("Build_Level"))
        	TEST_BUILD_LEVEL = json.getString("Build_Level");
		List testSetIds= toList((JSONArray) json.get("TestSetId"));		
		Iterator it = testSetIds.iterator();
		reporter.reportStep("Updating the tests for Test Set Ids : "+ testSetIds);
		
		
		Map<String, String> testResultsMap= jsonToMap(json.getJSONObject("TestCases"));
		while(it.hasNext()){
			TESTSET_ID= it.next().toString();			
			reporter.reportStep("Updating the tests for Test Set Id : "+ TESTSET_ID);
			System.out.println("Updating the tests for Test Set Id : "+ TESTSET_ID);
			updateTests(getTestInstanceToTestCaseMap(TESTSET_ID), testResultsMap);				
		}			
		logout();
		KronosLogger.traceLeave();
    }catch(Exception e){
    	System.out.println("Error occured: " + e);
    	reporter.reportStep(LogStatus.ERROR, "Error occured while update alm status: " + e.getMessage());
	}
    	reporter.endTest();
		reporter.writeToReports();
    }
}
