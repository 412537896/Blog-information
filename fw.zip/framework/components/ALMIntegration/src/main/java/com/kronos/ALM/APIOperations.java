package com.kronos.ALM;

import static com.jayway.restassured.RestAssured.given;

import java.util.Map;

import org.testng.log4testng.Logger;

import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;
import com.kronos.api.rest.exception.KronosCoreAPIException;
import com.kronos.logging.KronosLogger;

public class APIOperations {

	final static Logger logger = Logger.getLogger(APIOperations.class);

	
	/**
	 * This method is for setting cookie in the headers
	 * 
	 * @param cookie: String
	 * @return cookie
	 */
	
	public RequestSpecification setAuthToken(String cookie) {
		return given().headers("Cookie", cookie);
	}
	
	/**
	 * This method is used to perform POST operation with json request body and with the cookies set in the headers
	 * perform a POST request to URI. Mostly can be used for XML based payloads.
	 * 
	 * @param authToken: String
	 * @param formParametersJson: String
	 * @param URI
	 *            : String
	 * @param contentType: String
	 * @return res:response
	 */
	
	
	public Response postWithFormParameters(String authToken, String formParametersJson, String URI, ContentType contentType)
			throws KronosCoreAPIException {
		KronosLogger.traceEnter();
		Response res = null;
		try {
			res = setAuthToken(authToken).contentType(contentType)
					.body(formParametersJson).accept(ContentType.JSON).when().post(URI);

			String infoMessage = "postWithFormParameters: \" post from parameters using json " + formParametersJson
					+ " using authToken  " + authToken + " using URI " + URI + " with contentType " + contentType
					+ " and received response is " + res;
			logger.info(infoMessage);
		} catch (Exception e) {
			String errMsg = "postWithFormParameters: \" post from parameters using json " + formParametersJson
					+ " using authToken " + authToken + " using URI " + URI + " with contentType " + contentType
					+ " failed and received response is " + res;
			logger.error(errMsg, e);
			throw new KronosCoreAPIException(errMsg, e);
		}
		KronosLogger.traceLeave();
		return res;

	}
	
	/**
	 * This method is used to update newly created Run with actual Status present in the JSON file
	 * 
	 * @param authToken: String
	 * @param formParametersJson: String
	 * @param URI
	 *            : String
	 * @param contentType: String
	 * @return res:response
	 */
	public Response putWithFormParameters(String authToken, String formParametersJson, String URI, ContentType contentType)
			throws KronosCoreAPIException {
		KronosLogger.traceEnter();
		Response res = null;
		try {
			res = setAuthToken(authToken).contentType(contentType)
					.body(formParametersJson).accept(ContentType.JSON).when().put(URI);

			String infoMessage = "putWithFormParameters: \" post from parameters using json " + formParametersJson
					+ " using authToken  " + authToken + " using URI " + URI + " with contentType " + contentType
					+ " and received response is " + res;
			logger.info(infoMessage);
		} catch (Exception e) {
			String errMsg = "putWithFormParameters: \" post from parameters using json " + formParametersJson
					+ " using authToken " + authToken + " using URI " + URI + " with contentType " + contentType
					+ " failed and received response is " + res;
			logger.error(errMsg, e);
			throw new KronosCoreAPIException(errMsg, e);
		}
		KronosLogger.traceLeave();
		return res;

	}
	
	/**
	 * This method is used to perform POST operation with json request body and with the cookies set in the headers
	 * perform a POST request to URI. 
	 * 
	 * @param authToken: String
	 * @param formParametersJson: String
	 * @param URI
	 *            : String
	 * @param contentType: String
	 * @return res:response
	 */
	
	public Response postWithFormParameters(String payload, String URI, ContentType contentType)
			throws KronosCoreAPIException {
		KronosLogger.traceEnter();
		Response res = null;
		try {
			res = given().contentType(contentType).accept(contentType)
					.body(payload).when().post(URI);

			String infoMessage = "postWithFormParameters: \" post from parameters using json " + payload
					+ " using URI " + URI + " with contentType " + contentType
					+ " and received response is " + res;
			logger.info(infoMessage);
		} catch (Exception e) {
			String errMsg = "postWithFormParameters: \" post from parameters using json " + payload
					+" using URI " + URI + " with contentType " + contentType
					+ " failed and received response is " + res;
			logger.error(errMsg, e);
			throw new KronosCoreAPIException(errMsg, e);
		}
		KronosLogger.traceLeave();
		return res;

	}
	
	/**
	 * This method is used to perform GET operation with no parameters and with the cookies set in the headers
	 * 
	 * @param authToken: String
	 * @param URI
	 *            : String
	 * @return response
	 */
	public Response getWithNoParameters(String authToken, String URI) throws KronosCoreAPIException {
		KronosLogger.traceEnter();
		Response res = null;
		try {
			res = setAuthToken(authToken).get(URI);
			String infoMessage = "getWithNoParameters: \" with authToken as " + authToken + " and URI " + URI
					+ " and received response as " + res.asString();
			logger.info(infoMessage);
		} catch (Exception e) {
			String errMsg = "getWithNoParameters: \" with no parameters " + " using authToken " + authToken
					+ " and URI " + URI + " failed with received response as " + res.asString();
			logger.error(errMsg, e);
			throw new KronosCoreAPIException(errMsg, e);
		}
		KronosLogger.traceLeave();
		return res;
	}
	
	/**
	 * This method is used to perform GET operation with query parameters and with the cookies set in the headers
	 * perform a GET request to URI.
	 * 
	 * @param authToken: String
	 * @param queryParameters
	 *            :HashMap
	 * @param URI
	 *            : String
	 * @return response
	 */
	
	public Response getWithQueryparameters(String authToken, Map<String, ?> queryParameters, String URI)
			throws KronosCoreAPIException {
		KronosLogger.traceEnter();
		Response res = null;
		try {
			res = setAuthToken(authToken).parameters(queryParameters).accept(ContentType.JSON).when().get(URI);
			String infoMessage = "getWithQueryparameters: \" queryParameters as " + queryParameters
					+ " using authToken " + authToken + " and URI " + URI + " and received response is " + res.asString();
			logger.info(infoMessage);
		} catch (Exception e) {
			String errMsg = "getWithQueryparameters: \" queryParameters as " + queryParameters + " using authToken "
					+ authToken + " and URI " + URI + " failed and received response is " + res.asString();
			logger.error(errMsg, e);
			throw new KronosCoreAPIException(errMsg, e);
		}
		KronosLogger.traceLeave();
		return res;

	}
	
	/**
	 * This method takes Headers parameters with method type post.
	 * 
	 * @param headerParameters
	 *            :Map
	 * 
	 * @param URI
	 *            :endpoint
	 * @return response
	 */
	
	public Response postWithHeaderParameters(Map<String, ?> headerParameters, String URI)
			throws KronosCoreAPIException {
		KronosLogger.traceEnter();
		Response res = null;
		try {
			res = given()
				    .headers(headerParameters)					 
				    .accept(ContentType.JSON)
				    .contentType(ContentType.JSON)
				    .post(URI)
				    ;
			String infoMessage = "postWithHeaderParameters: \"  URI is " + URI + " with Header parameters "
					+ headerParameters +  "  response received as " + res.asString();
			logger.info(infoMessage);
		} catch (Exception e) {
			String errMsg = "postWithHeaderParameters: \"  URI is " + URI + " with Header parameters " + headerParameters
					+ " failed and response received as " + res.asString();
			logger.error(errMsg, e);
			throw new KronosCoreAPIException(errMsg, e);
		}
		KronosLogger.traceLeave();
		return res;
	}
	
}
