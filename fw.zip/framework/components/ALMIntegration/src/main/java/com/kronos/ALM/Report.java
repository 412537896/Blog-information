package com.kronos.ALM;

import java.text.SimpleDateFormat;
import java.util.Date;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class Report {

	private static final String timeStamp = new SimpleDateFormat("yyyy_MM_dd_HHmmss").format(new Date());
	ExtentReports extent = null;
	
	ExtentTest test=null;
	
	public Report(String ReportsPath){
		extent = new ExtentReports(System.getProperty("user.dir")+"/reports/"+"ALM_Report_"+timeStamp+ ".html", false);
		extent = new ExtentReports(ReportsPath+"/ALM Reports/"+"ALM_Report_"+timeStamp+ ".html", false);
	}
	
	void startTest(String testStep, String description){
		test=extent.startTest(testStep, description);
	}
	

	public void reportStep(LogStatus status,String stepName) {
		test.log(status, stepName);
	}
	
	public void reportStep(String description) {
		test.log(LogStatus.INFO, description);
	}
	
	void endTest(){
		extent.endTest(test);
	}
	
	void writeToReports(){
		extent.flush();		
	}
}
