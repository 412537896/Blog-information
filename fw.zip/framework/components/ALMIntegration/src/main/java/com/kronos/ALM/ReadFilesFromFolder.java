package com.kronos.ALM;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;


public class ReadFilesFromFolder {
  public static File folder = new File("C:\\Reports\\ALM\\");
  static String temp = "";
  static List <String> listOfFiles=new ArrayList<String>();

  public static void main(String[] args) {
	  
	  
	  System.out.println("*******************************************************");
	  
	  String alm="test_ALM12345_CreateRegularShift";
	  System.out.println(alm.split("(ALM)")[1].split("_")[0]);
	  
	  System.out.println("*********************************************************");
    System.out.println("Reading files under the folder "+ folder.getAbsolutePath());
    listFilesForFolder(folder);
    System.out.println(listOfFiles);
    Iterator<String> it= listOfFiles.iterator();
    
    while(it.hasNext()){
    	String filePath= it.next();
    	 BufferedReader br = null;
    	    String sCurrentLine;
    	    String sCurrentLine1="";
    		try {
    			br = new BufferedReader(new FileReader(filePath));
    			while ((sCurrentLine = br.readLine()) != null) {
    				sCurrentLine1=sCurrentLine1+sCurrentLine;
    			}
    			
    			System.out.println(sCurrentLine1);
    		} catch (IOException e) {
    			e.printStackTrace();
    		} finally {
    			try {
    				if (br != null)br.close();
    			} catch (IOException ex) {
    				ex.printStackTrace();
    			}
    		}     
    }
   
  }

  public static void listFilesForFolder(final File folder) {

    for (final File fileEntry : folder.listFiles()) {
      if (fileEntry.isDirectory()) {
        listFilesForFolder(fileEntry);
      } else {
        if (fileEntry.isFile()) {
          temp = fileEntry.getName();
          if ((temp.substring(temp.lastIndexOf('.') + 1, temp.length()).toLowerCase()).equals("json"))
            //System.out.println("File= " + folder.getAbsolutePath()+ "\\" + fileEntry.getName());
          listOfFiles.add(folder.getAbsolutePath()+ "\\" + fileEntry.getName());
        }

      }
    }
  }
}