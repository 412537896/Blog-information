package com.kronos.dataseed.generator.jsonschema;

import java.io.BufferedWriter;
import com.fasterxml.jackson.databind.introspect.JacksonAnnotationIntrospector; 
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.AnnotationIntrospector;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.jsonschema.JsonSchema;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.databind.type.TypeFactory;
import com.fasterxml.jackson.module.jaxb.JaxbAnnotationIntrospector;
import com.kronos.dataseed.generator.DataSeedingGeneratorException;
import com.kronos.dataseed.generator.config.GeneratorConstants;
import com.kronos.dataseed.generator.config.PropertiesHandler;
import com.kronos.dataseed.generator.swagger.SchemaGen;

public class JsonSchemaGenerator{

	public static final Logger log = LoggerFactory.getLogger(JsonSchemaGenerator.class);

	/**
	 * Main method to create JSON schemas from pojos available
	 * 
	 * @param args Main method arguments. 
	 * @throws DataSeedingGeneratorException Application specific exception thrown to the JVM.
	 */
	public static void main(String[] args) throws DataSeedingGeneratorException { 

		log.info("Generating JSON Schemas from the pojos... ");

		JsonSchemaGenerator jsonSchemaGenerator = new JsonSchemaGenerator();
		PropertiesHandler properties = new PropertiesHandler();
		properties.loadProperties(GeneratorConstants.GENERATOR_CONFIG_FILE_NAME);

		Map<String, String> classes = jsonSchemaGenerator.getSetupElements();
		final ObjectMapper objectMapper = jsonSchemaGenerator.createJaxbObjectMapper();

		Iterator iterator = classes.entrySet().iterator();
		while (iterator.hasNext()) {
			Map.Entry<String, String> entry = (Map.Entry<String, String>)iterator.next();
			String setupElement = entry.getKey();
			String className = entry.getValue();
			log.info("JSONSchema for "+setupElement+" is : "+jsonSchemaGenerator.writeToStandardOutputWithDeprecatedJsonSchema(objectMapper, setupElement, className, properties));
			iterator.remove();
		}
	}


	/**
	 * @return list of fully qualified class names
	 * @throws DataSeedingGeneratorException Application specific exception ducked to the 
	 * 		calling method.
	 */
	public Map<String, String> getSetupElements() throws DataSeedingGeneratorException {

		Map<String, String> classes = new HashMap<>();

		try {
			PropertiesHandler properties = new PropertiesHandler();
			properties.loadProperties(GeneratorConstants.MAPPING_CONFIG_FILE_NAME);

			for (Entry<Object, Object> pojo : properties.entrySet()){
				classes.put((String) pojo.getKey(),(String) pojo.getValue());
			}

		} catch (DataSeedingGeneratorException e) {
			log.error("Error while generating json schemas from pojos.");
			throw new DataSeedingGeneratorException(e);
		}

		return classes;
	}
	
	/**
	 * Write out JSON Schema based upon Java source code in class whose fully qualified package and class name have
	 * been provided.
	 * 
	 * @param mapper Instance of ObjectMapper from which to
	 *     invoke JSON schema generation.
	 * @param setupName Name of the JSON File
	 * @param fullyQualifiedClass Name of Java class upon
	 *    which JSON Schema will be extracted
	 * @param properties Location of JSON files and CSV file as key/value pair
	 * @return jsonSchemaStr Content of JSON file in String format
	 * @throws DataSeedingGeneratorException Application specific exception ducked to the 
	 * 		calling method
	 */
	@SuppressWarnings("deprecation")
	public String writeToStandardOutputWithDeprecatedJsonSchema (ObjectMapper mapper, String setupName, String fullyQualifiedClassName, PropertiesHandler properties) throws DataSeedingGeneratorException
	{
		String jsonSchemaStr = null;
		BufferedWriter output = null;		
		try{
			JsonSchema jsonSchema = mapper.generateJsonSchema(Class.forName(fullyQualifiedClassName));
			ObjectNode node = mapper.getNodeFactory().objectNode();
			node.put(setupName, jsonSchema.getSchemaNode());
			File f = new File(getDirectory(properties), setupName + GeneratorConstants.JSON_EXTENSION);
			output = new BufferedWriter(new FileWriter(f.getAbsoluteFile()));
			jsonSchemaStr = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(node);
			output.write(jsonSchemaStr);
			log.debug("JSON Schema for "+ setupName + " setup element is : "+ GeneratorConstants.LINE_SEPARATOR + jsonSchemaStr);
		} catch (ClassNotFoundException e){
			log.error("Unable to find class " + fullyQualifiedClassName);
			throw new DataSeedingGeneratorException(e);
		} catch (IOException e) {
			log.error("Error while processing the pojos/schemas : " + e);
			throw new DataSeedingGeneratorException(e);
		} finally {
				try {
					if(output!=null)
						output.close();
				} catch (IOException e) {
					log.error("Error while closing the output."+e);
				}
		}
		return jsonSchemaStr;
	}
	
	/**
	 * Generate all the JSON Schema based on a swagger file whose file name is provided.
	 * 
	 * @param swagerFileName Name of the Swagger file to 
	 * 		generate the JSON Schema from.
	 * @return List<String> List of all the JSON file name
	 * 		generated from the swagger.json file.
	 * @throws DataSeedingGeneratorException
	 */
	public List<String> generateJsonSchemaFromSwagger(PropertiesHandler properties,String swagerFileName) throws DataSeedingGeneratorException{
		// Write code to generate JSON Schema
		List<String> jsonFileNames = new ArrayList<String>();
		
		try {
			SchemaGen schemaGenObj = new SchemaGen();
			jsonFileNames = schemaGenObj.getSchemaFromPath(swagerFileName,properties);
		} catch (JsonProcessingException e) {
			System.out.println("Json Parsing Exception Occured While parsing swager file.");
			e.printStackTrace();
		} catch (IOException e) {
			System.out.println("IO exception occured while reading swager file.");
			e.printStackTrace();
		}
		
		return jsonFileNames; 
	}    
	
	/**
	 * Read the content of JSON file whose name(setupName) is provided.
	 * 
	 * @param setupName Name of the json file whose content is to be read. 
	 * @return jsonSchemaStr Content of the JSON file in String format.
	 * @throws DataSeedingGeneratorException
	 */
	public String getJsonSchema(String setupName, PropertiesHandler properties) throws DataSeedingGeneratorException{
		String jsonSchemaStr = null;
		try{
			File file = new File(getDirectory(properties), setupName + GeneratorConstants.JSON_EXTENSION);
	    	jsonSchemaStr = FileUtils.readFileToString(file);
		}catch(IOException e){
			log.error("Error while processing the JSON schemas : " + e);
			throw new DataSeedingGeneratorException(e);
		} 
		return jsonSchemaStr;
	}
	
	/**
	 * Returns list of all the json File from a directory. 
	 * 
	 * @return List<File> List of JSON file on a predefined directory.
	 */
	public List<File> getAllGeneratedJSONFile(PropertiesHandler properties) {
		String[] extensions = new String[] { "json" };
		File dir = new File(getDirectory(properties));
		List<File> files = (List<File>) FileUtils.listFiles(dir, extensions, true);
		return files;
	}


	/**
	 * @param properties
	 * @return 
	 */
	private String getDirectory(PropertiesHandler properties) {
		String jsonSchemaDirectory = properties.getProperty(GeneratorConstants.JSON_SCHEMA_DIR_LOCATION);
		URL jsonSchemaDir = this.getClass().getResource(jsonSchemaDirectory);
		jsonSchemaDirectory = jsonSchemaDir.getPath();
		return jsonSchemaDirectory;
	}
	

	/**
	 * Get the object mapper with JaxbAnnotationIntrospector
	 * @return ObjectMapper
	 */
	public ObjectMapper createJaxbObjectMapper() {
		final ObjectMapper objectMapper = new ObjectMapper();
		SimpleModule module = new SimpleModule();
		module.addSerializer(LocalDateTime.class, new LocalDateTimeSerialiser());
		objectMapper.registerModule(module);

		final TypeFactory typeFactory = TypeFactory.defaultInstance();
		objectMapper.setAnnotationIntrospector(AnnotationIntrospector.pair(new JacksonAnnotationIntrospector(),
				new JaxbAnnotationIntrospector(typeFactory)));

		return objectMapper;
	}
	
	
}



