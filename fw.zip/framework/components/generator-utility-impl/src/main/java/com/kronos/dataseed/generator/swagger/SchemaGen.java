package com.kronos.dataseed.generator.swagger;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import com.fasterxml.jackson.core.JsonPointer;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.kronos.dataseed.generator.config.GeneratorConstants;
import com.kronos.dataseed.generator.config.PropertiesHandler;

public class SchemaGen {
	static Logger log = Logger.getLogger(SchemaGen.class);

	public static final String SCHEMA_EXTENSION = ".json";
	public static JsonNode allSchema;
	public static Map<String, JsonNode> resolved_schema = new HashMap<String, JsonNode>();
	public static PropertiesHandler properties = new PropertiesHandler();
	public static String SWAGGER_DEFINITION_NODE = "definitions";

	/*
	 * This is a utility program which generates json schema of API from the
	 * swagger file and returns the list of generated json schema.
	 * 
	 * @param file It refers the Swagger file.
	 * 
	 * @param properties Properties encapsulate the directory path for the
	 * generation of schema.
	 * 
	 * @return List<String> returns List of json Schema.
	 */
	public List<String> getSchemaFromPath(String file, PropertiesHandler properties)
			throws JsonProcessingException, IOException {
		log.info("Parsing Swagger json : ");
		String SWAGGER_PATH_NODE = "paths";
		String RESOURCE_PATH = this.getDirectory(properties) + "/";
		File schemaFile = null;
		InputStream in = SchemaGen.class.getClassLoader().getResourceAsStream(file);
		ObjectMapper mapper = new ObjectMapper();
		JsonNode rootNode = mapper.readTree(in);
		JsonNode allPathSchema;
		JsonNode apiSchema;
		allSchema = rootNode.get(SWAGGER_DEFINITION_NODE);

		allPathSchema = rootNode.get(SWAGGER_PATH_NODE);
		List<String> blackListApi = new ArrayList<String>();
		Iterator<String> pathIterator = allPathSchema.fieldNames();
		List<String> listOfJsonFiles = new ArrayList<String>();
		List<String> uniqueApiList = new ArrayList<String>();
		Set<String> notFoundApiList = new HashSet<>();

		while (pathIterator.hasNext()) {

			String entryKey = pathIterator.next().toString();
			JsonNode pathEntry = allPathSchema.get(entryKey);

			String fileName = "";
			String tagName = "";
			
			// loop through all the methods
			Iterator methodItr = pathEntry.fieldNames();
			while (methodItr.hasNext()) {
				try {

					String methodKey = methodItr.next().toString();
					JsonNode methodValue = (JsonNode) pathEntry.get(methodKey);
					JsonNode modifiedSchemaReference = null;

					if ((methodValue.isContainerNode()) && (methodValue.toString().toLowerCase().contains("tags"))) {

						tagName = getElementFromArray(methodValue.get("tags"));
						tagName = tagName.replace("/", "-");

						SchemaDetail schemadetail = getSchemaReference(methodValue);
						String schemaReference = schemadetail.name;
						String schemaType = schemadetail.type;

						if (schemaReference != null) {
							schemaReference = schemadetail.name.replace("#/definitions/", "");
							

							if (schemaType.equals("Object")) {
								fileName = schemaReference.replace("/", "-");
								modifiedSchemaReference = rootNode
										.at(JsonPointer.compile("/definitions/" + schemaReference));
							} else {
								fileName = schemaReference.replace("/", "-").concat("_Array");
								modifiedSchemaReference = schemadetail.node;
								ObjectNode modifiedObjectIncaseOfArray = (ObjectNode) modifiedSchemaReference;
								((ObjectNode) modifiedObjectIncaseOfArray.get("items")).remove("$ref");
								((ObjectNode) modifiedObjectIncaseOfArray.get("items")).put(schemaReference,
										rootNode.at(JsonPointer.compile("/definitions/" + schemaReference)));
								modifiedSchemaReference = (JsonNode) modifiedObjectIncaseOfArray;
							}

							if (rootNode.at(JsonPointer.compile("/definitions/" + schemaReference)).size() > 0) {
								if (!uniqueApiList.contains(fileName)) {
									uniqueApiList.add(fileName);

									try {
										apiSchema = transformSchema(modifiedSchemaReference,new GenericTree(schemaReference, null));
										schemaFile = new File(RESOURCE_PATH + fileName + SCHEMA_EXTENSION);
										
										if (schemaType.equals("Object"))
											FileUtils.writeStringToFile(schemaFile,
													"{\"" + fileName + "\":" + apiSchema.toString() + "}");
										else
											FileUtils.writeStringToFile(schemaFile, apiSchema.toString());
										listOfJsonFiles.add(fileName);
										
									} catch (StackOverflowError t) {
										blackListApi.add(schemaReference);
									}
								}
							} else {
								notFoundApiList.add(schemaReference);
							}

						}
					}
				} catch (Exception e) {
					log.info("Exception found for :"+fileName);
				}

			}
		}

		FileWriter writer = new FileWriter("BlackListAPI.txt");
		for (String str : blackListApi) {

			writer.write(str);
			writer.write(",");
		}
		writer.close();
		log.info("BlackListed Api :"+blackListApi);
		log.info("Reference Not Found In Defination :" + notFoundApiList);
		log.info("api generated :" + listOfJsonFiles.size());
		return listOfJsonFiles;
	}

	private String getElementFromArray(JsonNode element) {
		for (int i = 0; i < element.size(); i++) {
			String currentElement = element.get(i).asText();
			if (!currentElement.equals("") && !(currentElement == "") && !currentElement.equals(null)) {
				return currentElement;
			}

		}

		return null;
	}


	private SchemaDetail getSchemaReference(JsonNode methodValue) {
		JsonNode tempNode = methodValue.get("parameters");
		JsonNode referenceName = null;
		SchemaDetail schemadetail = new SchemaDetail(null, null);
		if (tempNode.isArray()) {
			JsonNode currentNode = tempNode;
			for (int i = 0; i < tempNode.size(); i++) {
				currentNode = tempNode.get(i);

				Iterator<String> paramItr = currentNode.fieldNames();
				boolean flag = false;
				while (paramItr.hasNext() && !flag) {
					String filedName = paramItr.next().toString();
					String body = currentNode.get(filedName).asText();
					if (currentNode.get("in") != null && "body".equals(currentNode.get("in").asText())) {
						if (currentNode.get("schema").get("$ref") != null) {
							referenceName = currentNode.get("schema").get("$ref");
							flag = true;
							schemadetail.name = referenceName.asText();
							schemadetail.type = "Object";
						} else if ("array".equalsIgnoreCase(currentNode.get("schema").get("type").asText())
								&& (currentNode.get("schema").get("items") != null)) {
							referenceName = currentNode.get("schema").get("items").get("$ref");
							flag = true;
							schemadetail.type = "Array";
							schemadetail.name = referenceName.asText();
							schemadetail.node = currentNode.get("schema");
						}

					}
				}

			}

		}

		if (referenceName == null)
			return new SchemaDetail(null, null);

		return schemadetail;
	}


	public JsonNode transformSchema(JsonNode schemaIp,GenericTree parentTree) throws IOException {
		String schmaString = schemaIp.toString();
		ObjectMapper mappernew = new ObjectMapper();
		JsonNode schema=mappernew.readTree(new ByteArrayInputStream(schmaString.getBytes()));
		
		Iterator<Map.Entry<String, JsonNode>> fieldsIterator = schema.fields();
		while (fieldsIterator.hasNext()) {
			Map.Entry<String, JsonNode> field = fieldsIterator.next();
			final String key = field.getKey();
			 JsonNode value = field.getValue();
			if ((value.isContainerNode()) && (value.toString().toLowerCase().contains("$ref")))
			{
				value =transformSchema(value,parentTree); // RECURSIVE CALL
				((ObjectNode)schema).set(key, value);
			}
			else if (key.equalsIgnoreCase("$ref")) {
				log.info("Value: " + value);

				String childSchemaNodeValue = value.toString().replaceAll("#/definitions/", "");
				childSchemaNodeValue = childSchemaNodeValue.substring(1, childSchemaNodeValue.length() - 1);
				log.info("childSchemaNodeValue: " + childSchemaNodeValue);
				
				// adding child
				GenericTree childnode = new GenericTree(childSchemaNodeValue, parentTree);
				parentTree.addChild(childnode);

				ObjectNode object = (ObjectNode) schema;
				object.remove("$ref");

				if (childnode.isCycleFound()) {
					ObjectMapper mapper = new ObjectMapper();
					String childschemavalue = allSchema.get(childSchemaNodeValue).toString();
					JsonNode childNode = mapper.readTree(new ByteArrayInputStream(childschemavalue.getBytes()));
					JsonNode newNode = makePropertyNull(childNode);
					
					Iterator<Map.Entry<String, JsonNode>> childNodeIterator = newNode.fields();
					while (childNodeIterator.hasNext()) {
						Map.Entry<String, JsonNode> childField = childNodeIterator.next();
						object.set(childField.getKey(), childField.getValue());
					}
				} else {
					if (childSchemaNodeValue.equalsIgnoreCase("localtime")) {
						object.put("type", "String");
					} else {
						JsonNode childSchemaNode = null;
							JsonNode childValue = allSchema.get(childSchemaNodeValue);
							childSchemaNode = transformSchema(childValue,childnode);
							resolved_schema.put(childSchemaNodeValue, childSchemaNode);
						Iterator<Map.Entry<String, JsonNode>> childNodeIterator = childSchemaNode.fields();
						while (childNodeIterator.hasNext()) {
							Map.Entry<String, JsonNode> childField = childNodeIterator.next();
							object.set(childField.getKey(), childField.getValue());
						}
					}
				}

			}
		}
		return schema;
	}
	private JsonNode makePropertyNull(JsonNode tempNode) throws JsonProcessingException, IOException {
		Iterator<String> itr = tempNode.fieldNames();
		while(itr.hasNext()){
			String key = itr.next();
			if("properties".contains(key)){
				JsonNode propNode = tempNode.get("properties");
				ObjectNode objectnode = (ObjectNode)propNode;
				objectnode.removeAll();
			}
		}
		return tempNode;
	}

	/** Find the directory in property and returns the path where json schema will be generated.
	 * @param properties
	 * @return String
	 */
	private String getDirectory(PropertiesHandler properties) {
		String jsonSchemaDirectory = properties.getProperty(GeneratorConstants.JSON_SCHEMA_DIR_LOCATION);
		URL jsonSchemaDir = this.getClass().getResource(jsonSchemaDirectory);
		jsonSchemaDirectory = jsonSchemaDir.getPath();
		return jsonSchemaDirectory;
	}


	private class SchemaDetail {
		public SchemaDetail(String type, String name) {
			this.type = type;
			this.name = name;
		}

		String type;
		String name;
		JsonNode node;
	}
	
	private class GenericTree{
		String nodeVal;
		ArrayList<GenericTree> childNodes ;
		GenericTree parent;
		
		public GenericTree(String nodeValue,GenericTree parent){
			this.nodeVal=nodeValue;
			this.childNodes=new ArrayList();
			this.parent=parent;
		}
		public void addChild(GenericTree child){
			this.childNodes.add(child);
		}
		
		public GenericTree getParent(){
			return this.parent;
		}
		
		public boolean isCycleFound(){
			GenericTree nextParent = this.parent;
			while(nextParent!=null){
				
				if(this.nodeVal.equals(nextParent.nodeVal)){
					return true;
				}
				nextParent = nextParent.parent;
			}
			
			return false;
		}
	}
	
}
