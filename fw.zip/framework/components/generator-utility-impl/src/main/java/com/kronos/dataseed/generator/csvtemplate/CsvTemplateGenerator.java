package com.kronos.dataseed.generator.csvtemplate;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;
import java.util.regex.Pattern;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kronos.dataseed.generator.DataSeedingGeneratorException;
import com.kronos.dataseed.generator.config.GeneratorConstants;
import com.univocity.parsers.csv.CsvWriter;
import com.univocity.parsers.csv.CsvWriterSettings;

/**
 * This class convert JSON Schemas to CSV Templates
 * @author Rajesh.Lohani
 *
 */
public class CsvTemplateGenerator{
	
	final static List<String> dataTypes = new ArrayList<String>(Arrays.asList(
		    GeneratorConstants.JSON_SCHEMA_TYPE_BOOLEAN,
		    GeneratorConstants.JSON_SCHEMA_TYPE_INTEGER,
		    GeneratorConstants.JSON_SCHEMA_TYPE_STRING,
		    GeneratorConstants.JSON_SCHEMA_TYPE_NUMBER,
		    GeneratorConstants.JSON_SCHEMA_TYPE_ANY
		));

	private static final Logger log = LoggerFactory.getLogger(CsvTemplateGenerator.class);

	private static String csvDirectory;
	private String parentName;
	private boolean checkDuplicateComplexArrayType;
	private Map<String, String> complextArrayParentNameMap;
	private LinkedHashMap<String, String> duplicateEntityMap;
	private File propFile;
	private  String propertyFileName;
	private  boolean isPropertyFilePresent = false;

	/**
	 * Parameterized constructor to set the csv template directories
	 * @param csvDir location of generated CSV directory.
	 */
	public CsvTemplateGenerator(String csvDir) {
		super();
		csvDirectory = csvDir;	
	}	

	/**
	 * This method will fetch the root node of json schema file and pass it to createCSV method, 
	 * 	if no node is present it will throw DataSeedingGeneratorException
	 * 
	 * @param jsonSchema :String representation of the content of the intended JSON file
	 * @param setupName: String Name of the JSON file for which CSV is to be generated
	 * @throws DataSeedingGeneratorException Application specific exception ducked to the calling method
	 */
	public void parseSchema(String jsonSchema, String setupName) throws DataSeedingGeneratorException {
		log.info("Parsing json schema for : "+setupName);
		ObjectMapper mapper = new ObjectMapper();		 
		JsonNode rootNode;
		JsonNode newNode = null;
		try {
			rootNode = mapper.readTree(jsonSchema);
			// check if root node is of array type.
			if ((rootNode.has("type")) && (rootNode.get("type").toString().equalsIgnoreCase("\"array\"")))
			{
				Iterator<String> nodeIterator = rootNode.fieldNames();
				while (nodeIterator.hasNext()){
					String fieldName = nodeIterator.next();
					if (!fieldName.equalsIgnoreCase("type"))
						rootNode = rootNode.get(fieldName);	
				}
			}
			
			// check for complex array type
			complextArrayParentNameMap = new HashMap<String, String>();
			duplicateEntityMap = new LinkedHashMap<String, String>();
			checkDuplicateComplexArrayType = true;
			createCSV(jsonSchema, rootNode, false);
			
			// create CSVs
			checkDuplicateComplexArrayType = false;
			parentName = setupName;
			if(setupName != null && !setupName.trim().isEmpty()) {
				this.deleteFilesInDirectory(csvDirectory + GeneratorConstants.FILE_SEPARATOR + parentName);
				propertyFileName = setupName;
				createCSV(setupName , rootNode, false);
			}else{
				throw new DataSeedingGeneratorException("JSON schema is invalid. JSON schema root must be an entity.");
			}
		} catch (DataSeedingGeneratorException e) {
			log.error("Error while reading json schema :"+jsonSchema);
			throw new DataSeedingGeneratorException(e);
		} catch (JsonProcessingException e) {
			log.error("JSON schema processing exception :"+jsonSchema);
			throw new DataSeedingGeneratorException(e);
		} catch (IOException e) {
			log.error("Error while reading/writing the file :"+jsonSchema);
			throw new DataSeedingGeneratorException(e);
		}
	}

	/**
	 * This method will generate csv template based on the input root node
	 * 
	 * @param entityName: String Name of used for naming the generated CSVs
	 * @param rootNode : JSON node currently participating in the CSV creation process
	 * @param isArray: boolean Whether the root node passed is of array type. 
	 * @throws DataSeedingGeneratorException Application specific exception ducked to the 
	 * 		calling method
	 */
	public void createCSV(String entityName , JsonNode rootNode, boolean isArray) throws DataSeedingGeneratorException {
		log.info("Getting parent node of json schema.");
		String csvName = entityName;
		String headers = GeneratorConstants.KEY_STRING + GeneratorConstants.COMMA_DELIMITER +  GeneratorConstants.PARENT_STRING;		
		String nodeType = null;
		// get properties of rootNode
		JsonNode nextNode = null;
		try {
			Iterator<Entry<String, JsonNode>> fields = rootNode.fields();
			while(fields.hasNext()) {
				Entry<String, JsonNode> entry = fields.next();
				if(isArray){
					nextNode = rootNode;
					nodeType = nextNode.get(GeneratorConstants.JSON_SCHEMA_PROPERTY_TYPE).asText();
					break;
				}
				else{
					nextNode = entry.getValue();
					nodeType = nextNode.get(GeneratorConstants.JSON_SCHEMA_PROPERTY_TYPE).asText();
				}
			}
			headers = checkForTypes(headers, nextNode, null, entityName,nodeType, true);
			if(!checkDuplicateComplexArrayType)
				writeValues(csvName, headers);
		} catch (DataSeedingGeneratorException e) {
			throw new DataSeedingGeneratorException(e);
		} catch (IOException e) {
			throw new DataSeedingGeneratorException(e);
		}
	}

	/**
	 * This method will check the type of next node , if type is object it will parse the properties of that object, 
	 * elseif array then it will check for the complex type array
	 * else the value will be appended with the headers value string and return back
	 * 
	 * @param headers: String
	 * @param nextNode : JsonNode
	 * @param entityName : String
	 * @param nodeType : String
	 * @return
	 * @throws DataSeedingGeneratorException
	 */
	private String checkForTypes(String headers, JsonNode nextNode,
			String prependValue, String entityName, String nodeType, boolean isParentType) throws DataSeedingGeneratorException {
		String itemName = "";
		String csvHeaders = headers;
		if(GeneratorConstants.JSON_SCHEMA_PROPERTY_OBJECT.equalsIgnoreCase(nodeType)) {
			if(!isParentType)
				if(!prependValue.isEmpty())
					itemName = prependValue + GeneratorConstants.HYPHEN_IDENTIFIER + entityName;
				else
					itemName = entityName;
			csvHeaders = parseProperties(nextNode, csvHeaders, isParentType, itemName);
		} else if(GeneratorConstants.JSON_SCHEMA_PROPERTY_ARRAY.equalsIgnoreCase(nodeType)) {
			JsonNode itemsNode = nextNode.get(GeneratorConstants.JSON_SCHEMA_PROPERTY_ITEMS);
			String simpleLeafProp = hasSingleSimpleLeaf(isParentType, prependValue, entityName, itemsNode);			
			if (simpleLeafProp != null && !simpleLeafProp.isEmpty())		
				csvHeaders = csvHeaders + GeneratorConstants.COMMA_DELIMITER + simpleLeafProp;
			else{
				if(checkDuplicateComplexArrayType)
					checkDuplicateEntity(prependValue, entityName);
				else
					createCSV(entityName, itemsNode, true);
			}

		} 

		return csvHeaders;
	}

	/**
	 * This method will parse the properties of each of the node
	 * 
	 * @param rootNode : JsonNode
	 * @param headers : String
	 * @param isParentType  : boolean
	 * @param parentType :String
	 * @return
	 * @throws DataSeedingGeneratorException
	 */
	private String parseProperties(JsonNode rootNode,
			String headers, boolean isParentType, String parentName) throws DataSeedingGeneratorException {
		String csvHeaders = headers;
		JsonNode propertiesNode = rootNode.get(GeneratorConstants.JSON_SCHEMA_PROPERTY_PROPERTIES);
		if(propertiesNode != null) {
			Iterator<Entry<String, JsonNode>> fields = propertiesNode.fields();
			while(fields.hasNext()) {
				Entry<String, JsonNode> entry = fields.next();
				JsonNode nextNode = entry.getValue();
				String entityName = entry.getKey();
				String nodeType = nextNode.get(GeneratorConstants.JSON_SCHEMA_PROPERTY_TYPE).asText();
				if(isLeafNodeType(nodeType)){
					if(isParentType)
						csvHeaders = csvHeaders + GeneratorConstants.COMMA_DELIMITER + entityName;
					else
						csvHeaders = csvHeaders + GeneratorConstants.COMMA_DELIMITER + parentName + GeneratorConstants.HYPHEN_IDENTIFIER + entityName;
					continue;
				} else
					csvHeaders = checkForTypes(csvHeaders, nextNode, parentName, entityName, nodeType, false);
			}
		}
		return csvHeaders;
	}
	
	/**
	 * Whether array has single simple leaf node or not
	 * @param entityName : String
	 * @param node : JsonNode
	 * @return
	 */
	private static String hasSingleSimpleLeaf(boolean isParentType, String parentName, String entityName, JsonNode node) {

		String itemChildType = node.get(GeneratorConstants.JSON_SCHEMA_PROPERTY_TYPE) != null ? node.get(GeneratorConstants.JSON_SCHEMA_PROPERTY_TYPE).asText() : null;

		if(isLeafNodeType(itemChildType)) {
			if(!isParentType && !parentName.isEmpty())
				return parentName + GeneratorConstants.HYPHEN_IDENTIFIER + entityName;
			else
				return entityName;
		} else if (GeneratorConstants.JSON_SCHEMA_PROPERTY_OBJECT.equalsIgnoreCase(itemChildType)) {
			JsonNode propertiesNode = node.get(GeneratorConstants.JSON_SCHEMA_PROPERTY_PROPERTIES);
			int noOfProperties = propertiesNode.size();
			if (noOfProperties == 1) {
				String propName = propertiesNode.fields().next().getKey();
				JsonNode propChildNode = propertiesNode.get(propName);
				return hasSingleSimpleLeaf(false, parentName + GeneratorConstants.HYPHEN_IDENTIFIER + entityName, propName, propChildNode);
			}
		}
		return null;
	}

	/**
	 * Check the leaf node type
	 * @param nodeType
	 * @return
	 */
	private static boolean isLeafNodeType(String nodeType) {
		for(String dataType : dataTypes){
	        if(dataType.equalsIgnoreCase(nodeType))
	            return true;
	    }
	    return false;
	}

	/**
	 * This method will take headers string as input and write these value in to the cvs created using univocity csv writer
	 * @param entityName : String
	 * @param headers : String
	 * @throws DataSeedingGeneratorException
	 */
	private void writeValues(String entityName, String headers) throws DataSeedingGeneratorException,IOException {
		FileWriter fileWriter = null;
		CsvWriter csvFileWriter = null;
		String entityNameString = entityName;
		try {
			// is duplicate entry present in map : handled for identical complex array in two different childs
			if(duplicateEntityMap.size()>0)
				entityNameString = getDuplicateEntityMapKey(entityName);
				 
			log.info("CSV name is: "+entityNameString+" and headers are :"+headers);
			Collection<Object[]> headersList = new ArrayList<>();
			headersList.add(headers.split(GeneratorConstants.COMMA_DELIMITER));
			// create parent directory if not present

			String directoryName = csvDirectory + GeneratorConstants.FILE_SEPARATOR + parentName;
			File dir = new File(directoryName);
			if(!dir.exists()) {
				dir.mkdirs();
			}
			// create file inside directory
			fileWriter = new FileWriter(new File(directoryName + GeneratorConstants.FILE_SEPARATOR + entityNameString + GeneratorConstants.CSV_EXTENSION));
			csvFileWriter = new CsvWriter(fileWriter, new CsvWriterSettings());
			csvFileWriter.writeRowsAndClose(headersList);
		} catch (IOException e) {
			log.error("Error in CsvFileWriter !!!");
			throw new DataSeedingGeneratorException(e);
		} finally {
			if(fileWriter != null)
				fileWriter.close();
		}
	}	

/** This methods checks whether EntityName is duplicate or not.In case it is duplicate it adds the parent name as suffix.
 * 
 * @param prependValue : String 
 * @param entityName  : String 
 */
	private void checkDuplicateEntity(String prependValue, String entityName){

		if (complextArrayParentNameMap.containsValue(entityName)) {
			log.info("Duplicate value for entityName=" + entityName + " exists!!!");
			final String dupEntityNameFound = entityName;
			complextArrayParentNameMap.entrySet().forEach(entry -> {
				String csvName = ((Entry<String, String>) entry).getKey();
				String duplicateEntityName = ((Entry<String, String>) entry).getValue();
				if(duplicateEntityName.equals(dupEntityNameFound)) {
					duplicateEntityMap.put(csvName , duplicateEntityName);
				}
			});

			duplicateEntityMap.put(prependValue + GeneratorConstants.HYPHEN_IDENTIFIER + entityName , entityName);

		}

		complextArrayParentNameMap.put(prependValue + GeneratorConstants.HYPHEN_IDENTIFIER + entityName , entityName);
	}
	
	/** This method return the fully qualified entity name (prefix as parent) in case it is found duplicate.In case the fully qualified node name is found more then 100 characters 
	 * node name renamed as nodename_counter (counter keeps on increasing) and inserted in property file.
	 * @param entityName : String
	 */

	private String getDuplicateEntityMapKey(String entityName) throws DataSeedingGeneratorException {
		String fileName = entityName;
		String key = "";
		String value = "";

		if (duplicateEntityMap.containsValue(entityName)) {
			for (Map.Entry<String, String> entry : duplicateEntityMap.entrySet()) {
				key = ((Entry<String, String>) entry).getKey();
				value = ((Entry<String, String>) entry).getValue();
				if (value.equals(entityName)) {
					if (key.length() > GeneratorConstants.MAXCSVLENGTH)
						fileName = makeEntryInProperty(key, value);
					else
						fileName = key;
					break;
				}
			}
			duplicateEntityMap.remove(key);
		}
		return fileName;
	}

	
	/** This method checks the next counter for the entityName and append in property file.
	 * Key as - fully qualified entity name
	 * value as - entityName_counter (for counter definition look at the doc of getnextCounterofvalue())
	 * 
	 * @param csvName : String
	 * @param entityName : String
	 */
	private String makeEntryInProperty(String csvName, String entityName) throws DataSeedingGeneratorException{

		int nextCounter = 0;
		if(!isPropertyFilePresent){
			createProperty(propertyFileName);
		}
		
		if(propFile != null){
			try {
				Properties prop = new Properties();
				OutputStream output = new FileOutputStream(propFile, true);
				
				nextCounter=getnextCounterofvalue(entityName);
				String newCsvname =  entityName+"_"+nextCounter;
				prop.setProperty(csvName,newCsvname);
				prop.store(output, "");
				output.flush();
				output.close();
				
				return newCsvname;
			} catch (Exception ex) {
				log.error("File Write error in property file :"+propFile.getAbsolutePath());
				throw new DataSeedingGeneratorException(ex);
			}
		}
		return null;
	}

	/** This method creates a regular expression with entityName and checks the matching values in property file.It finds the next counter value to be appended with the entityName and returns.
	 *  @param entityName: String
	 */
	private int getnextCounterofvalue(String entityName) throws  DataSeedingGeneratorException{
		Properties prop = new Properties();
		try {
			InputStream inStream = new FileInputStream(propFile);
			prop.load(inStream);
		} catch (Exception ex) {
			log.error("File read error for property file: " + propFile.getAbsolutePath());
			throw new DataSeedingGeneratorException(ex);
		}
		
		String regex = entityName+"_[0-9]{1,}";
		Pattern pattern = Pattern.compile(regex);
		int maxCounter = 0;
		int currCounter = 0;
		
		Set<Entry<Object, Object>> propset = prop.entrySet();
		Iterator<Entry<Object,Object>> itr= propset.iterator();
		while(itr.hasNext()){
			String value = (String)((Entry)itr.next()).getValue();
			if(pattern.matcher(value).matches()){
				currCounter= Integer.parseInt(value.substring(value.lastIndexOf("_")+1));
				if(currCounter > maxCounter){
					maxCounter = currCounter;
				}
			}
		}
		
		return (maxCounter+1);
	}

	/** Creates the property file with the setUpname .
	 *  @param setupname: String
	 */
	private void createProperty(String fileName) throws DataSeedingGeneratorException{
		String directoryName = csvDirectory + GeneratorConstants.FILE_SEPARATOR + parentName;
		File dir = new File(directoryName);
		if(!dir.exists()) {
			dir.mkdirs();
		}
		 propFile = new File(directoryName+ GeneratorConstants.FILE_SEPARATOR +fileName+ ".properties");
		 try {
			propFile.delete();
			propFile.createNewFile();
			isPropertyFilePresent = true;
			
		} catch (Exception ex) {
			log.error("Error in property file creation for:"+fileName);
			throw new DataSeedingGeneratorException(ex);
		}
		
	}

	/** This method deletes all files inside directory
	 * 
	 * @param directoryName : String
	 */
		private void deleteFilesInDirectory(String directoryName){
			File dir = new File(directoryName);
			if(dir.exists()) {
				for(File file:dir.listFiles()){
					if(file.isFile())
						file.delete();
				}
			}
		}

}
