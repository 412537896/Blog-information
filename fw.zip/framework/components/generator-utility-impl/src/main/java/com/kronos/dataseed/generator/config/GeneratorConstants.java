package com.kronos.dataseed.generator.config;

/**
 * Class having all the constants used in generator utility
 * @author Rajesh.Lohani
 */
public class GeneratorConstants {
	
	private GeneratorConstants(){
	}
	
	public static final String JSON_SCHEMA_DIR_LOCATION = "JsonSchemaFilesLocation";
	public static final String CSV_TEMPLATE_DIR_LOCATION = "CSVTemplatesFilesLocation";
	public static final String SETUP_ELEMENTS_NAMES = "SetupConfigurationNames";
	public static final String GENERATOR_CONFIG_FILE_NAME = "GeneratorConfig.properties";
	public static final String MAPPING_CONFIG_FILE_NAME = "SetupElementsMapping.properties";
	public static final String LINE_SEPARATOR = System.getProperty("line.separator");
	public static final String FILE_SEPARATOR = System.getProperty("file.separator");
	public static final String SCHEMA_NODE = "schemaNode";	
	public static final String CSV_EXTENSION = ".csv";
	public static final String JSON_EXTENSION = ".json";
	public static final String EMPTY_STRING = "";
	public static final String COMMA_DELIMITER = ",";
	public static final String HYPHEN_IDENTIFIER = "-";
	public static final String KEY_STRING = "Key";
	public static final String PARENT_STRING = "Parent";
	public static final String JSON_SCHEMA_PROPERTY_ITEMS = "items";
	public static final String JSON_SCHEMA_PROPERTY_ARRAY = "array";
	public static final String JSON_SCHEMA_PROPERTY_PROPERTIES = "properties";
	public static final String JSON_SCHEMA_PROPERTY_OBJECT = "object";
	public static final String JSON_SCHEMA_PROPERTY_TYPE = "type";
	public static final String JSON_SCHEMA_TYPE_INTEGER = "integer";
	public static final String JSON_SCHEMA_TYPE_BOOLEAN = "boolean";
	public static final String JSON_SCHEMA_TYPE_STRING = "string";
	public static final String JSON_SCHEMA_TYPE_ANY = "any";
	public static final String JSON_SCHEMA_TYPE_NUMBER = "number";
	public static final int MAXCSVLENGTH = 100;
	
}
