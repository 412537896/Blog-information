package com.kronos.dataseed.generator.csv.diff;

public enum ChangeEnum {

	ADDED, REMOVED, MODIFIED
}
