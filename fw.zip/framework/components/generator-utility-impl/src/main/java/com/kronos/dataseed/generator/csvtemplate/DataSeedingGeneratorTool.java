package com.kronos.dataseed.generator.csvtemplate;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Scanner;
import java.util.Set;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.kronos.dataseed.generator.DataSeedingGeneratorException;
import com.kronos.dataseed.generator.config.GeneratorConstants;
import com.kronos.dataseed.generator.config.PropertiesHandler;
import com.kronos.dataseed.generator.csv.diff.CsvDiffUtils;
import com.kronos.dataseed.generator.jsonschema.JsonSchemaGenerator;

/**
 * 
 * This class is the driving class for the data seeding generator tool (JSON Schema and csv template generation).
 * @author Rajesh.Lohani
 *
 */
public class DataSeedingGeneratorTool {

	private static final Logger log = LoggerFactory.getLogger(DataSeedingGeneratorTool.class);

	private static String jsonSchemaDirectory;
	private static String csvDirectory;
	private static Scanner scanner;

	public static void main(String[] args) throws DataSeedingGeneratorException{
		

		try {
			DataSeedingGeneratorTool dataSeedingGeneratorTool = new DataSeedingGeneratorTool();
			PropertiesHandler properties = new PropertiesHandler();
			properties.loadProperties(GeneratorConstants.GENERATOR_CONFIG_FILE_NAME);
			dataSeedingGeneratorTool.setDirectoryLocations(properties);
			JsonSchemaGenerator generator = new JsonSchemaGenerator();
			
			String option = null;
			if(args.length > 0){
				option = args[0];
			}else{
				scanner = new Scanner(System.in);
				System.out.println("Please press 1 and then Enter key if you want to generate JSON schema and CSV from POJO");
				System.out.println("Please press 2 and then Enter key if you want to generate JSON schema CSV from Swagger");
				System.out.println("Please press 3 and then Enter key if you want to generate CSV from already generated JSON schema");
				option = scanner.nextLine();
			}
			
	        switch (option) {
		        case "1":
			        // Get setup elements
			        Map<String, String> setupElements = generator.getSetupElements();
			        // generate JSON Schemas
			        final ObjectMapper objectMapper = generator.createJaxbObjectMapper();
			        Iterator iterator = setupElements.entrySet().iterator();
			        while (iterator.hasNext()) {
			        	Map.Entry<String, String> entry = (Map.Entry<String, String>)iterator.next();
			        	String jsonSchema = generator.writeToStandardOutputWithDeprecatedJsonSchema(objectMapper, entry.getKey(), entry.getValue(), properties);
			        	// parse json schema to create csv templates
			        	dataSeedingGeneratorTool.parseJsonSchema(jsonSchema, entry.getKey());
			        	iterator.remove();
			        }
			        
		    		System.out.println("Json Schema Generated At :"+DataSeedingGeneratorTool.class.getResource(properties.getProperty(GeneratorConstants.JSON_SCHEMA_DIR_LOCATION)));
		    		System.out.println("CSV Template Generated At :"+DataSeedingGeneratorTool.class.getResource(properties.getProperty(GeneratorConstants.CSV_TEMPLATE_DIR_LOCATION)));

			        break;
			        
		        case "2":
		        	String jsonSchema = null;
		        	String swagerFileName="swagger.json";
		        	// generate JSON Schemas from swagger
	        		List<String> jsonFileNames = generator.generateJsonSchemaFromSwagger(properties,swagerFileName);
	        		Set<String> jsonFileSet = new HashSet<>();
	        		jsonFileSet.addAll(jsonFileNames);
	        		for (String setupName : jsonFileSet) {
		    			

		    			try{
		        			jsonSchema = generator.getJsonSchema(setupName, properties);
			    			dataSeedingGeneratorTool.parseJsonSchema(jsonSchema, setupName);
		    			}catch(DataSeedingGeneratorException e){
		    				log.error("Data seeding exception in generation of --"+setupName);
		    			}catch(Exception e){
		    				log.error("Data seeding exception in generation of --"+setupName);
		    			}

		    		}

		    		System.out.println("Json Schema Generated At :"+DataSeedingGeneratorTool.class.getResource(properties.getProperty(GeneratorConstants.JSON_SCHEMA_DIR_LOCATION)));
		    		System.out.println("CSV Template Generated At :"+DataSeedingGeneratorTool.class.getResource(properties.getProperty(GeneratorConstants.CSV_TEMPLATE_DIR_LOCATION)));

	        		break;
	        		
		        case "3":
		        	jsonSchema = null;
		        	// Get all existing JSON Schemas
		        	List<File> files = generator.getAllGeneratedJSONFile(properties);
		        	//System.out.println("Compared Report Published As :csv-diff-report.html"+DataSeedingGeneratorTool.class.getClassLoader().getResource("csv-diff-report.html").getFile());
		        		
		    		for (File file : files) {
			        	try{
		    			String setupName = FilenameUtils.removeExtension(file.getName());
		    			jsonSchema = generator.getJsonSchema(setupName, properties);
		    			dataSeedingGeneratorTool.parseJsonSchema(jsonSchema, setupName);
			        	}
			    		catch(Exception e){
		    				log.error("Data seeding exception in generation of --"+jsonSchema);
		    			}
		    		}
		    		System.out.println("CSV Template Generated At :"+DataSeedingGeneratorTool.class.getResource(properties.getProperty(GeneratorConstants.CSV_TEMPLATE_DIR_LOCATION)));
		    		break;
	        }
			dataSeedingGeneratorTool.compareCsvDiff();
		} catch (DataSeedingGeneratorException e) {
			log.error("Error while parsing json schemas and converting them to csv templates.");
			throw new DataSeedingGeneratorException(e);
		} catch (IOException e) {
			log.error("Error while parsing json schemas and converting them to csv templates.");
			throw new DataSeedingGeneratorException(e);
		}
	}

	private void compareCsvDiff() throws DataSeedingGeneratorException{
		String comparisonSwitch = "N";
		try{
			scanner = new Scanner(System.in);
			System.out.println("do you want to compare old csv templates with newly generated templates? Y/N");
			comparisonSwitch = scanner.nextLine();
			if("Y".equalsIgnoreCase(comparisonSwitch)){
				System.out.println("please provide directory location of old csv templates");
				String oldCsvLocation = scanner.nextLine();
				if(StringUtils.isEmpty(oldCsvLocation)){
					throw new DataSeedingGeneratorException("invalid old csv directory");
				}
				File oldCsvDirectory = new File(oldCsvLocation);
				File newCsvDirectory = new File(csvDirectory);
				CsvDiffUtils.findDifference(oldCsvDirectory, newCsvDirectory);
				
				System.out.println("Compared Report Published As :"+DataSeedingGeneratorTool.class.getClassLoader().getResource("csv-diff-report.html").getFile());
			}
		} catch(NoSuchElementException e){
			log.warn("This utility is probabely running from data-seeding build", e);
		}
	}

	
	
	/**
	 * This method will parse the json schemas and convert them into csv templates
	 * @param jsonSchema String representation of the content of the intended JSON file
	 * @param setupName Name of the JSON file for which CSV is to be generated
	 * @throws DataSeedingGeneratorException Application specific exception ducked to the calling method
	 * @throws IOException Thrown when error occurs while reading/writing the file
	 */
	public void  parseJsonSchema(String jsonSchema, String setupName) throws DataSeedingGeneratorException, IOException {

		log.info("Json schema to csv template conversion started...");
		try {
			CsvTemplateGenerator jsonSchemaToCSV = new CsvTemplateGenerator(csvDirectory);
			jsonSchemaToCSV.parseSchema(jsonSchema, setupName); 
		} catch (DataSeedingGeneratorException e) {
			log.error("Error while reading json schemas.");
			throw new DataSeedingGeneratorException(e);
		}
	}

	/**
	 * Set the directory locations of json schemas and csv template files
	 * @param properties Folder Location of JSON files and CSV files as key/value pair
	 */
	public void setDirectoryLocations(PropertiesHandler properties) {

		jsonSchemaDirectory = properties.getProperty(GeneratorConstants.JSON_SCHEMA_DIR_LOCATION);
		csvDirectory = properties.getProperty(GeneratorConstants.CSV_TEMPLATE_DIR_LOCATION);

		URL jsonSchemaDir = this.getClass().getResource(jsonSchemaDirectory);
		URL csvTemplateDir = this.getClass().getResource(csvDirectory);

		jsonSchemaDirectory = jsonSchemaDir.getPath();
		csvDirectory = csvTemplateDir.getPath();

		log.info("JSON Schemas are present at " +jsonSchemaDirectory+ " and csv templates will be generated at " +csvDirectory);
	}

	public String getJsonSchemaDirectory() {
		return jsonSchemaDirectory;
	}

	public void setJsonSchemaDirectory(String jsonSchemaDirectory) {
		this.jsonSchemaDirectory = jsonSchemaDirectory;
	}

	public String getCsvDirectory() {
		return csvDirectory;
	}

	public void setCsvDirectory(String csvDirectory) {
		this.csvDirectory = csvDirectory;
	}
}
