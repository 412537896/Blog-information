package com.kronos.dataseed.generator.config;

import java.io.IOException;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.kronos.dataseed.generator.DataSeedingGeneratorException;

/**
 * This class loads the GeneratorConfig.properties and provides apis to read the
 * properties.
 * 
 * @author Rajesh.Lohani
 *
 */
public class PropertiesHandler extends Properties {

	private static final long serialVersionUID = 1L;
	private static final Logger log = LoggerFactory.getLogger(PropertiesHandler.class);

	/**
	 * This method loads the GeneratorConfig.properties properties file from
	 * 	classpath
	 * @param configFile Name of the properties file to read the key value pair from.
	 * @throws DataSeedingGeneratorException Throws exception when the properties file 
	 * 	is not present in class path
	 */
	public void loadProperties(String configFile) throws DataSeedingGeneratorException {
		try {
			load(this.getClass().getClassLoader().getResourceAsStream(configFile));
		} catch (IOException e) {
			log.error("Error Reading configuration file:" + configFile
					+ ". Please ensure the configuration file is in classpath.");
			throw new DataSeedingGeneratorException("Error Reading configuration file:" + configFile
					+ ". Please ensure the configuration file is in classpath.", e);

		}

	}
}
