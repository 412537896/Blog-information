package com.kronos.dataseed.generator;

public class DataSeedingGeneratorException extends Exception{
	
	private static final long serialVersionUID = 1L;

	/**
	 * Constructor with string message.
	 * 
	 * @param message User friendly message for the explanation of exception
	 *  thrown from the application.
	 */
	public DataSeedingGeneratorException(String message) {
		super(message);
	}

	/**
	 * Constructor with exception.
	 * 
	 * @param ex Exception thrown from the application
	 */
	public DataSeedingGeneratorException(Exception ex) {
		super(ex);
	}
	
	public DataSeedingGeneratorException(String message, Throwable throwable) {
		super(message, throwable);
	}

}
