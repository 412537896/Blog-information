package com.kronos.dataseed.generator.csv.diff;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * This is a utility program to find out differences in csv directory/files.
 * @author Abhishek.Omar
 *
 */
public class CsvDiffUtils {
	
	private static final Map<String,File> oldDirFilesMap = new HashMap<>();
	private static final Map<String,File> newDirFilesMap = new HashMap<>();
	private static final Logger LOG = LoggerFactory.getLogger(CsvDiffUtils.class);
	/**
	 * @param oldCsvDirectory Directory location of old CSVs to compare with. 
	 * @param newCsvDirectory	Directory location of new CSVs to compare with.
	 */
	public static void findDifference(File oldCsvDirectory, File newCsvDirectory){
		if (!oldCsvDirectory.isDirectory() || !newCsvDirectory.isDirectory()) {
			LOG.error("either {} or {} is not a valid directory", oldCsvDirectory, newCsvDirectory);
			return;
		}
		mapSetupItemDirectoriesByName(oldCsvDirectory, newCsvDirectory);
		if(oldDirFilesMap.isEmpty() || newDirFilesMap.isEmpty()){
			LOG.error("either {} or {} has invalid directory structure", oldCsvDirectory, newCsvDirectory);
			LOG.info("Input directory structure should be like: /csv/<setup items dir>/<csv files>");
			return;
		}
		StringBuilder dirDifferencesHtmlString = findDifferenceInDirectories(oldCsvDirectory,newCsvDirectory, new StringBuilder(), false);
		StringBuilder setupItemDifferencesHtmlString = findDifferenceInSetUpItemDirectories(oldCsvDirectory, newCsvDirectory);
		String csvDifferencesHtmlString = generateReportStringForCSVHeadersDifferences(newCsvDirectory, oldCsvDirectory);
		setupItemDifferencesHtmlString.append(csvDifferencesHtmlString);
		generateReport(dirDifferencesHtmlString.toString(), setupItemDifferencesHtmlString.toString());
	}
	
	private static String generateReportStringForCSVHeadersDifferences(File newCsvDirectory, File oldCsvDirectory){
		StringBuilder reportBuilder = new StringBuilder();
		findDifferenceInSetupItemsCsvHeaders(oldCsvDirectory, newCsvDirectory, reportBuilder);
		return  reportBuilder.toString();
	}
	
	private static void generateReport(String setupItemDifferencesHtmlString, String csvDifferencesHtmlString) {
		InputStream inputStream = CsvDiffUtils.class.getClassLoader().getResourceAsStream("template.html");
		String htmlString;
		try {
			htmlString = IOUtils.toString(inputStream, "UTF-8");
		htmlString = htmlString.replace("$setUpItemDirectoryDiffData", setupItemDifferencesHtmlString);
		htmlString = htmlString.replace("$setUpItemCSVDiffData", csvDifferencesHtmlString);
		File newHtmlFile = new File("csv-diff-report.html");
		FileUtils.writeStringToFile(newHtmlFile, htmlString);
		} catch (Exception e) {
			LOG.warn("error occured while generating the report. Please check the logs", e);
		}
	}

	private static StringBuilder findDifferenceInDirectories(final File oldDirectory, final File newDirectory, StringBuilder reportBuilder, boolean isSetupItemDirectory){
		String[]   oldSetUpItemsDirArr = oldDirectory.list();
		String[]   newSetUpItemsDirArr = newDirectory.list();
		return difference(oldSetUpItemsDirArr, newSetUpItemsDirArr, newDirectory.getName(), reportBuilder, isSetupItemDirectory);
	}
	
	private static StringBuilder findDifferenceInSetUpItemDirectories(final File oldCsvDirectory, final File newCsvDirectory){
		StringBuilder reportBuilder = new StringBuilder();
		oldDirFilesMap.forEach((key,value) -> {
			if(newDirFilesMap.containsKey(key)){
				findDifferenceInDirectories(value,newDirFilesMap.get(key), reportBuilder, true);
			}
		});
		return reportBuilder;
	}
	
	private static void findDifferenceInSetupItemsCsvHeaders(final File oldCsvDirectory, final File newCsvDirectory, StringBuilder reportBuilder){
		oldDirFilesMap.forEach((key,oldSetUpItemDirectory) -> {
			if(newDirFilesMap.containsKey(key)){
				List<File> oldCsvFilesForSetupItem = Arrays.asList(oldSetUpItemDirectory.listFiles());
				List<File> newCsvFilesForSetupItem = Arrays.asList(newDirFilesMap.get(key).listFiles());
				Map<String,File> oldCsvFilesMapForSetupItem = new HashMap<>();
				oldCsvFilesForSetupItem.stream().filter(oldCsvFile ->!oldCsvFile.isDirectory()).forEachOrdered(oldCsvFile ->{
					oldCsvFilesMapForSetupItem.put(oldCsvFile.getName(), oldCsvFile);
				});
				Map<String,File> newCsvFilesMapForSetupItem = new HashMap<>();
				newCsvFilesForSetupItem.stream().filter(newCsvFile ->!newCsvFile.isDirectory()).forEachOrdered(newCsvFile ->{
					newCsvFilesMapForSetupItem.put(newCsvFile.getName(), newCsvFile);
				});
				oldCsvFilesMapForSetupItem.forEach((oldCsvFileName, oldCsvFile) -> {
					if(newCsvFilesMapForSetupItem.containsKey(oldCsvFileName)){
						compareCsv(oldSetUpItemDirectory.getName(),oldCsvFile,newCsvFilesMapForSetupItem.get(oldCsvFileName),reportBuilder );
					}
				});
			}
		});
	}
	
	
	private static void compareCsv(String setupItemName, File oldCsvFile, File newCsvFile, StringBuilder reportBuilder) {
		if(oldCsvFile.isFile() && newCsvFile.isFile()){
			try (InputStream sourceStream = new FileInputStream(oldCsvFile);
					InputStream targetStream = new FileInputStream(newCsvFile);
					BufferedReader reader = new BufferedReader(new InputStreamReader(sourceStream));) {
				String sourceHeaders = reader.readLine();
				String target = IOUtils.toString(targetStream);
				if(areHeadersDifferent(sourceHeaders, target)){
					reportBuilder.append("<tr>");
					reportBuilder.append("<td> " + setupItemName + " </td>");
					reportBuilder.append("<td> " + oldCsvFile.getName() + " </td>");
					reportBuilder.append("<td> " + ChangeEnum.MODIFIED.name() + " </td>");
					reportBuilder.append("<td> " + sourceHeaders + " </td>");
					reportBuilder.append("<td> " + target + " </td>");
					reportBuilder.append("</tr>");
					LOG.info(" Headers in {}/{} have changed", setupItemName,
							oldCsvFile.getName());
					LOG.info("Old Headers: "+sourceHeaders);
					LOG.info("New Headers: "+target);
				}
			} catch (Exception ex) {
				LOG.warn("error occured while processing csv:"+ex);
			}
		}
	}
	
	private static StringBuilder difference(String[] oldArray, String [] newArray, String newDirName, StringBuilder reportBuilder, boolean isSetupItemDirectory){
		List<String> oldItemsList = Arrays.asList(oldArray);
		List<String> newItemsList = Arrays.asList(newArray);
		List<String> itemsDeletedList = oldItemsList.stream().filter(oldItem -> !newItemsList.contains(oldItem)).collect(Collectors.toList());
		List<String> itemsInsertedList = newItemsList.stream().filter(newItem -> !oldItemsList.contains(newItem)).collect(Collectors.toList());
		if(!itemsDeletedList.isEmpty()){
			itemsDeletedList.stream().forEachOrdered(deletedItem ->{
				addItemInTable(reportBuilder, deletedItem, newDirName, isSetupItemDirectory, ChangeEnum.REMOVED);
			});
		}
		if(!itemsInsertedList.isEmpty()){
			itemsInsertedList.stream().forEachOrdered(insertedItem ->{
				addItemInTable(reportBuilder, insertedItem, newDirName, isSetupItemDirectory, ChangeEnum.ADDED);
			});
		}
		LOG.info("List of Items Deleted from {} are : {}", newDirName, itemsDeletedList);
		LOG.info("List of Items Inserted in {} are : {}", newDirName, itemsInsertedList);
		return reportBuilder;
	}
	
	private static boolean areHeadersDifferent(String source, String target) {
		String formattedSource = source.replace("\n", "").replace("\r", "");
		String formattedTarget = target.replace("\n", "").replace("\r", "");
		Predicate<String> allTargetHeadersInSourcepredicate = targetHeader -> !Arrays.asList(StringUtils.split(formattedSource, ",")).contains(targetHeader);
		Predicate<String> allSourceHeadersInTargetpredicate = sourceHeader -> !Arrays.asList(StringUtils.split(formattedTarget, ",")).contains(sourceHeader);
		boolean resultAllTargetHeadersInSource=  Arrays.asList(StringUtils.split(formattedTarget, ",")).stream().anyMatch(allTargetHeadersInSourcepredicate);
		boolean resultAllSourceHeadersInTarget=  Arrays.asList(StringUtils.split(formattedSource, ",")).stream().anyMatch(allSourceHeadersInTargetpredicate);
		return resultAllTargetHeadersInSource || resultAllSourceHeadersInTarget;
	}
	
	private static void addItemInTable(StringBuilder reportBuilder, String item, String dirName, boolean isSetupItemDirectory, ChangeEnum change){
		reportBuilder.append("<tr>");
		if(isSetupItemDirectory){
			reportBuilder.append("<td> " + dirName + " </td>");
		}
		reportBuilder.append("<td> " + item + " </td>");
		reportBuilder.append("<td> " + change.name() + " </td>");
		reportBuilder.append("</tr>");
	}

	private static void mapSetupItemDirectoriesByName(
			final File oldCsvDirectory, final File newCsvDirectory) {
		List<File> oldSetUpItemsDirList = Arrays.asList(oldCsvDirectory
				.listFiles());
		oldSetUpItemsDirList
				.stream()
				.filter(oldSetUpItemsDirectory -> oldSetUpItemsDirectory
						.isDirectory())
				.forEachOrdered(
						oldSetUpItemsDirectory -> {
							if(validateDirectoryStructure(oldSetUpItemsDirectory)){
								oldDirFilesMap.put(
										oldSetUpItemsDirectory.getName(),
										oldSetUpItemsDirectory);
							}
						});
		List<File> newSetUpItemsDirList = Arrays.asList(newCsvDirectory
				.listFiles());
		newSetUpItemsDirList
				.stream()
				.filter(newSetUpItemsDirectory -> newSetUpItemsDirectory
						.isDirectory())
				.forEachOrdered(
						newSetUpItemsDirectory -> {
							if(validateDirectoryStructure(newSetUpItemsDirectory)){
								newDirFilesMap.put(
										newSetUpItemsDirectory.getName(),
										newSetUpItemsDirectory);
							}
						});
	}

	private static boolean validateDirectoryStructure(
			File directory) {
		List<File> filesInDirectory = Arrays.asList(directory.listFiles()).stream().filter(file -> file.isFile()).collect(Collectors.toList());
		return !filesInDirectory.isEmpty();
	}
	
	/**
	 * method to clear class level data.
	 */
	protected static void clearCachedData(){
		oldDirFilesMap.clear();
		newDirFilesMap.clear();
	}
}
