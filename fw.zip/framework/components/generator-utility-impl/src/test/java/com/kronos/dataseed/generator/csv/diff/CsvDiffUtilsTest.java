package com.kronos.dataseed.generator.csv.diff;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.junit.Assert;
import org.junit.Test;

public class CsvDiffUtilsTest {

	@Test
	public void shouldFindDifference() throws IOException{
		CsvDiffUtils.clearCachedData();
		File oldCsvDirectory = new File("src/test/resources/old-csv");
		File newCsvDirectory = new File("src/test/resources/new-csv");
		CsvDiffUtils.findDifference(oldCsvDirectory, newCsvDirectory);
		File file = new File("csv-diff-report.html");
		Assert.assertTrue(file.exists());
		FileUtils.forceDelete(file);
	}
	
	@Test
	public void shouldNotFindDifferenceWhenOldPathIsNotDirectory(){
		CsvDiffUtils.clearCachedData();
		File oldCsvDirectory = new File("src/test/resources/old-csv/CurrencyPolicy/CurrencyPolicy.csv");
		File newCsvDirectory = new File("src/test/resources/new-csv");
		CsvDiffUtils.findDifference(oldCsvDirectory, newCsvDirectory);
		File file = new File("csv-diff-report.html");
		Assert.assertFalse(file.exists());
	}
	
	@Test
	public void shouldNotFindDifferenceWhenNewPathIsNotDirectory(){
		CsvDiffUtils.clearCachedData();
		File oldCsvDirectory = new File("src/test/resources/old-csv");
		File newCsvDirectory = new File("src/test/resources/new-csv/CurrencyPolicy/CurrencyPolicy.csv");
		CsvDiffUtils.findDifference(oldCsvDirectory, newCsvDirectory);
		File file = new File("csv-diff-report.html");
		Assert.assertFalse(file.exists());
	}
}
