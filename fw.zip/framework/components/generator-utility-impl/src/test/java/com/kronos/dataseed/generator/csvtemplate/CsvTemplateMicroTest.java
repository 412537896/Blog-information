package com.kronos.dataseed.generator.csvtemplate;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kronos.dataseed.generator.DataSeedingGeneratorException;

public class CsvTemplateMicroTest {

	public String jsonSchema;
	public String jsonSchemaDirectory;
	public String csvDirectory;

	@Before
	public void setUp() throws IOException {
		jsonSchema = "{\"WSAPayCodeDAPType\":{\"type\":\"object\",\"properties\":"
				+ "{\"AllowAll\":{\"type\":\"boolean\"},\"Description\":{\"type\":\"string\"},\"Name\":"
				+ "{\"type\":\"string\"},\"ProfileItems\":{\"type\":\"object\",\"properties\":"
				+ "{\"WSAPayCodeProfileItem\":{\"type\":\"array\",\"items\":"
				+ "{\"type\":\"object\",\"properties\":{\"Name\":{\"type\":\"string\"}}}}}}}}}";
		csvDirectory = System.getProperty("java.io.tmpdir");
	}

	@Test
	public void testParseSchema() {
		CsvTemplateGenerator jsonSchemaToCSV = new CsvTemplateGenerator(csvDirectory);
		boolean flag = false;
		try {
			jsonSchemaToCSV.parseSchema(jsonSchema, "WSAPayCodeDAPType");
			flag = true;
		} catch (DataSeedingGeneratorException e) {
			Assert.assertTrue("ERROR", flag);
		}

		Assert.assertTrue("CSV template created successfully.", flag);
	}

	@Test
	public void testParseSchemaError() {

		CsvTemplateGenerator jsonSchemaToCSV = new CsvTemplateGenerator(csvDirectory);
		boolean flag = false;
		try {
			jsonSchema = "{\"\":{\"type\":\"object\",\"properties\":"
					+ "{\"AllowAll\":{\"type\":\"boolean\"},\"Description\":{\"type\":\"string\"},\"Name\":"
					+ "{\"type\":\"string\"},\"ProfileItems\":{\"type\":\"object\",\"properties\":"
					+ "{\"WSAPayCodeProfileItem\":{\"type\":\"array\",\"items\":"
					+ "{\"type\":\"object\",\"properties\":{\"Name\":{\"type\":\"string\"}}}}}}}}}";
			jsonSchemaToCSV.parseSchema(jsonSchema, "");
			flag = true;
		} catch (DataSeedingGeneratorException e) {
			flag = false;
		}

		Assert.assertFalse("CSV template created successfully.", flag);
	}

	@Test
	public void testParseSchemaFileComplexType() {

		CsvTemplateGenerator jsonSchemaToCSV = new CsvTemplateGenerator(csvDirectory);
		boolean flag = false;
		try {
			jsonSchema = "{\"LeaveProfileType\":{\"type\":\"object\",\"properties\":"
					+ "{\"Description\":{\"type\":\"string\"},\"IsActive\":{\"type\":\"boolean\"},"
					+ "\"Name\":{\"type\":\"string\",\"required\":true},\"ProfileCategoryAssignments\":"
					+ "{\"type\":\"object\",\"properties\":{\"LeaveProfileCategory\":{\"type\":\"array\",\"items\":"
					+ "{\"type\":\"object\",\"properties\":{\"Category\":{\"type\":\"string\",\"required\":true},\"ProfileCategoryCustomDataAssignments\":"
					+ "{\"type\":\"object\",\"properties\":{\"LeaveProfileCategoryCustomData\":{\"type\":\"array\",\"items\":"
					+ "{\"type\":\"object\",\"properties\":{\"CustomData\":{\"type\":\"string\"}}}}}},\"ProfileCategoryRuleAssignments\":"
					+ "{\"type\":\"object\",\"properties\":{\"LeaveProfileCategoryRule\":{\"type\":\"array\",\"items\":{\"type\":\"object\",\"properties\":"
					+ "{\"LeaveRule\":{\"type\":\"string\",\"required\":true}}}}}},\"ProfileCategoryTypeAssignments\":{\"type\":\"object\",\"properties\":"
					+ "{\"LeaveProfileCategoryType\":{\"type\":\"array\",\"items\":{\"type\":\"object\",\"properties\":{\"EligibilityRequirement\":"
					+ "{\"type\":\"string\"},\"LeaveType\":{\"type\":\"string\",\"required\":true}}}}}}}}}}},\"LeaveType\":{\"type\":\"string\",\"required\":true}}}}";
			jsonSchemaToCSV.parseSchema(jsonSchema, "LeaveProfileType");
			flag = true;
		} catch (DataSeedingGeneratorException e) {
			flag = false;
		}

		Assert.assertTrue("CSV template created successfully.", flag);
	}

	@Test
	public void testParseSchemaFileArrayType() {

		CsvTemplateGenerator jsonSchemaToCSV = new CsvTemplateGenerator(csvDirectory);
		boolean flag = false;
		try {
			jsonSchema = "{\"type\":\"array\",\"items\":{\"Workload\":{\"type\":\"object\",\"properties\":"
					+ "{\"jobRef\":{\"type\":\"object\",\"properties\":{\"id\":{\"type\":\"integer\",\"format\":"
					+ "\"int64\",\"readOnly\":true},\"qualifier\":{\"type\":\"string\"}}},\"workloadTypeRef\":{\"type\":"
					+ "\"object\",\"properties\":{\"id\":{\"type\":\"integer\",\"format\":\"int64\",\"readOnly\":"
					+ "true},\"qualifier\":{\"type\":\"string\"}}},\"startDateTime\":{\"type\":\"string\",\"format\":"
					+ "\"date-time\"},\"endDateTime\":{\"type\":\"string\",\"format\":\"date-time\"},\"workloadHeadCounts\":"
					+ "{\"type\":\"array\",\"items\":{\"type\":\"object\",\"properties\":{\"startDateTime\":{\"type\":"
					+ "\"string\",\"format\":\"date-time\"},\"endDateTime\":{\"type\":\"string\",\"format\":"
					+ "\"date-time\"},\"headCount\":{\"type\":\"integer\",\"format\":\"int64\"}}}}}}}}";

			jsonSchemaToCSV.parseSchema(jsonSchema, "WorkLoad_Array");
			flag = true;
		} catch (DataSeedingGeneratorException e) {
			flag = false;
		}

		Assert.assertTrue("CSV template created successfully.", flag);
	}

	@Test
	public void testCreateCSV() {
		CsvTemplateGenerator jsonSchemaToCSV = new CsvTemplateGenerator(csvDirectory);
		boolean flag = false;
		try {
			String jsonSchema = "{\"LeaveProfile\":{\"type\":\"object\",\"properties\":"
					+ "{\"Description\":{\"type\":\"string\"},\"IsActive\":{\"type\":\"boolean\"},"
					+ "\"Name\":{\"type\":\"string\",\"required\":true},\"ProfileCategoryAssignments\":"
					+ "{\"type\":\"object\",\"properties\":{\"LeaveProfileCategory\":{\"type\":\"array\",\"items\":"
					+ "{\"type\":\"object\",\"properties\":{\"Category\":{\"type\":\"string\",\"required\":true},\"ProfileCategoryCustomDataAssignments\":"
					+ "{\"type\":\"object\",\"properties\":{\"LeaveProfileCategoryCustomData\":{\"type\":\"array\",\"items\":"
					+ "{\"type\":\"object\",\"properties\":{\"CustomData\":{\"type\":\"string\"}}}}}},\"ProfileCategoryRuleAssignments\":"
					+ "{\"type\":\"object\",\"properties\":{\"LeaveProfileCategoryRule\":{\"type\":\"array\",\"items\":{\"type\":\"object\",\"properties\":"
					+ "{\"LeaveRule\":{\"type\":\"string\",\"required\":true}}}}}},\"ProfileCategoryTypeAssignments\":{\"type\":\"object\",\"properties\":"
					+ "{\"LeaveProfileCategoryType\":{\"type\":\"array\",\"items\":{\"type\":\"object\",\"properties\":{\"EligibilityRequirement\":"
					+ "{\"type\":\"string\"},\"LeaveType\":{\"type\":\"string\",\"required\":true}}}}}}}}}}},\"LeaveType\":{\"type\":\"string\",\"required\":true}}}}";
			ObjectMapper objMapper = new ObjectMapper();
			JsonNode rootNode = objMapper.readTree(jsonSchema);
			jsonSchemaToCSV.createCSV("LeaveProfile", rootNode, true);
			flag = true;
		} catch (Exception e) {
			flag = false;
		}

		// Assert.assertTrue("CSV template created successfully.", flag);
	}

	/*@Test
	public void testParseSchema_LongCSVNames() {
		String setupname = "LongNameCSV";
		int expectedCountOfEntriesInProperty = 1;
		int actualCountOfEntriesInProperty = 0;
		int actualNoOfFiles = 0;

		CsvTemplateGenerator jsonSchemaToCSV = new CsvTemplateGenerator(csvDirectory);
		String jsonSchema = "{\"duplicateCSV\": {\"type\": \"object\",\"properties\": {\"A\": {\"type\": \"object\",\"properties\": {\"A1\": {\"type\":"
				+ " \"string\"},\"A2\": {\"type\": \"number\"},\"zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz\": {\"type\": "
				+ "\"object\",\"properties\": {\"B1\": {\"type\": \"boolean\"},\"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\":"
				+ " {\"type\": \"array\",\"items\": {\"type\": \"object\",\"properties\": {\"C1\": {\"type\": \"string\"},\"C2\": {\"type\": \"boolean\"}}}}}},"
				+ "\"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\": {\"type\":\"array\",\"items\": {\"type\": \"object\",\"properties\": "
				+ "{\"C1\": {\"type\": \"string\"},\"C2\": {\"type\": \"boolean\"},\"zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz\": "
				+ "{\"type\": \"object\",\"properties\": {\"B1\": {\"type\": \"boolean\"},\"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\": "
				+ "{\"type\": \"array\",\"items\": {\"type\": \"object\",\"properties\": {\"C1\": {\"type\": \"string\"},\"C2\": {\"type\": \"boolean\"}}}}}}}}}}}}}}";

		try {
			jsonSchemaToCSV.parseSchema(jsonSchema, setupname);
			File propFile = new File(csvDirectory + "\\" + setupname);
			actualNoOfFiles = propFile.listFiles().length;

			for (File file : propFile.listFiles()) {
				BufferedInputStream buf = null;
				if (file.getAbsolutePath().contains(".properties")) {
					try {
						Properties prop = new Properties();
						buf = new BufferedInputStream(new FileInputStream(file));
						prop.load(buf);
						actualCountOfEntriesInProperty = prop.size();
						break;
					} finally {
						buf.close();
					}
				}
			}
			// delete setup folder
			for (File file : propFile.listFiles()) {
				file.delete();
			}
			propFile.delete();

		} catch (Exception e) {
			e.printStackTrace();
			actualCountOfEntriesInProperty =0;
			actualNoOfFiles = 0;
		}

		Assert.assertEquals(expectedCountOfEntriesInProperty, actualCountOfEntriesInProperty);
		Assert.assertEquals(5, actualNoOfFiles);
	}*/
}
