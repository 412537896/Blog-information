package com.kronos.dataseed.generator.jsonschema;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.kronos.dataseed.generator.DataSeedingGeneratorException;
import com.kronos.dataseed.generator.config.PropertiesHandler;
import com.kronos.dataseed.generator.csvtemplate.DataSeedingGeneratorTool;

public class JsonSchemaGeneratorMicroTest{

	JsonSchemaGenerator jsonSchemaGenerator;

	@Before
	public void setUp() throws IOException {
		jsonSchemaGenerator = new JsonSchemaGenerator();
	}

	@Test
	public void testMain(){
		boolean flag = false;
		String[] args = null;
		try {
			JsonSchemaGenerator.main(args);
			flag = true;
		} catch (DataSeedingGeneratorException e) {
			flag = false;
		}

		Assert.assertTrue("success",flag);
	}

	@Test
	public void testJsonSchemaGeneratorException(){
		String setupName = "";
		String className = "";
		boolean flag = false;
		DataSeedingGeneratorTool dataSeedingGeneratorTool = new DataSeedingGeneratorTool();
		try {
			// set properties
			PropertiesHandler properties = new PropertiesHandler();
			properties.loadProperties("GeneratorConfig.properties");
			dataSeedingGeneratorTool.setDirectoryLocations(properties);

			JsonSchemaGenerator generator = new JsonSchemaGenerator();
			Map<String, String> setupElements = generator.getSetupElements();

			// generate JSON Schemas
			final ObjectMapper objectMapper = generator.createJaxbObjectMapper();
			Iterator iterator = setupElements.entrySet().iterator();
			while (iterator.hasNext()) {
				Map.Entry<String, String> entry = (Map.Entry<String, String>)iterator.next();
				setupName = entry.getKey();
				className = entry.getValue();
				generator.writeToStandardOutputWithDeprecatedJsonSchema(objectMapper, setupName, className+ "Append garbage *&^%$#", properties);
				iterator.remove();
			}
			flag = true;
		} catch (DataSeedingGeneratorException e) {
			flag = false;
		} 

		Assert.assertFalse("failure :",flag);
	}
	
	@Test
	public void testGenerateJsonSchemaFromSwagger(){
		
		boolean flag = false;
		String swagerFileName = "swagger.json";
		DataSeedingGeneratorTool dataSeedingGeneratorTool = new DataSeedingGeneratorTool();
		List<String> schemaFromSwaggerList;
		try {
			// set properties
			PropertiesHandler properties = new PropertiesHandler();
			properties.loadProperties("GeneratorConfig.properties");
			dataSeedingGeneratorTool.setDirectoryLocations(properties);
			schemaFromSwaggerList = jsonSchemaGenerator.generateJsonSchemaFromSwagger(properties, swagerFileName );
			flag = true;
			Assert.assertNotNull(schemaFromSwaggerList);
			Assert.assertTrue(schemaFromSwaggerList.size()>0);
		}catch(DataSeedingGeneratorException e){
			flag = false;
		}
		Assert.assertTrue("success :",flag);
	}
	
	@Test
	public void testGetJsonSchema(){
		
		boolean flag = false;
		String setupName = "SampleJsonSchema";
		
		try {
			URL resource = this.getClass().getResource("/" + setupName + ".json");
			File file = new File(resource.toURI());
			URL destination = this.getClass().getResource("/output/jsonSchemas");
			FileUtils.copyFileToDirectory(file, new File(destination.toURI()));
			PropertiesHandler properties = new PropertiesHandler();
			properties.loadProperties("GeneratorConfig.properties");
			String fileContentExpected = "{\"type\":\"array\",\"items\":{\"ObjectRef\":"
					+ "{\"type\":\"object\",\"properties\":{\"id\":{\"type\":\"integer\",\"format\":"
					+ "\"int64\",\"readOnly\":true},\"qualifier\":{\"type\":\"string\"}}}}}";
			String fileContentReturned = jsonSchemaGenerator.getJsonSchema(setupName, properties);
			flag = true;
			Assert.assertEquals(fileContentExpected, fileContentReturned);
		}catch(Exception e){
			e.printStackTrace();
			flag = false;
		}
		Assert.assertTrue("success :",flag);
	}
	
	@Test
	public void testGetAllGeneratedJSONFile(){
		boolean flag = false;
		try {
			PropertiesHandler properties = new PropertiesHandler();
			properties.loadProperties("GeneratorConfig.properties");
			DataSeedingGeneratorTool dataSeedingGeneratorTool = new DataSeedingGeneratorTool();
			dataSeedingGeneratorTool.setDirectoryLocations(properties);
			jsonSchemaGenerator.getAllGeneratedJSONFile(properties);
			flag = true;
		} catch (DataSeedingGeneratorException e) {
			flag = false;
		}
		Assert.assertTrue("success :",flag);
	}
	
	@Test
	public void testGetSetupElements(){
		boolean flag = false;
		try {
			jsonSchemaGenerator.getSetupElements();
			flag = true;
		} catch (DataSeedingGeneratorException e) {
			flag = false;
		}
		Assert.assertTrue("success :",flag);
	}
}