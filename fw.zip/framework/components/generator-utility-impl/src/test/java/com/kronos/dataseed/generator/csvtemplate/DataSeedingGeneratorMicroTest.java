package com.kronos.dataseed.generator.csvtemplate;

import java.io.File;
import java.io.IOException;
import java.net.URL;

import org.junit.Before;
import org.junit.Test;

import com.kronos.dataseed.generator.DataSeedingGeneratorException;

public class DataSeedingGeneratorMicroTest {
	
	DataSeedingGeneratorTool dataSeedingGenerator;
	
	@Before
	public void setUp() throws IOException {
		dataSeedingGenerator = new DataSeedingGeneratorTool();
		URL resource = this.getClass().getResource("/output/csv");
		dataSeedingGenerator.setCsvDirectory(resource.getPath());
		resource = this.getClass().getResource("/output/jsonSchemas");
		dataSeedingGenerator.setJsonSchemaDirectory(resource.getPath());
		deleteFiles();
	}

	@Test
	public void testMain() throws DataSeedingGeneratorException{
		String[] args =  new String[1];
		for (int i = 1 ; i <= 3; i++) {
			args[0] = new Integer(i).toString();
			DataSeedingGeneratorTool.main(args);
		}
	}
	
	/**
	 * Delete the files already present in the folders
	 */
	public void deleteFiles() {
		File folder = new File(dataSeedingGenerator.getCsvDirectory());
		File[] listOfFiles = folder.listFiles();
		if(listOfFiles.length>0){
			for (File file : listOfFiles) {
				delete(file);
			}
		}
	}
	
	/**
	 * Delete a file/folder (empty or non-empty) from a 
	 * location passed as parameter.
	 * 
	 * @param directory Take a folder location to be deleted.
	 */
	void delete(File directory) {
	    File[] files = directory.listFiles();
	    if (files != null) {
	        for (File f : files) {
	            delete(f);
	        }
	    }
	    directory.delete();
	}
	
	
}
