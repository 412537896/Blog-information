package com.kronos.requestgenerator.reader.csv;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

import com.kronos.requestgenerator.reader.csv.CSVColumnDataProcessor;
import com.kronos.facade.DateParser;

public class CSVColumnDataProcessor {
	
	private static final Logger log = Logger.getLogger(CSVColumnDataProcessor.class);
	private static final String DateTypeStartWith="{{{";
	private static final String DateTypeEndWith="}}}";
	private static final String isDateTypePattern="(\\{{3})(.*)(\\}{3})";
	private static final DateParser dateParser = new DateParser();
	/**
	 * Replace two vertical line with comma.
	 * @param value String
	 * @return String 
	 */
	public static String replaceTwoVerticalLineToComma(String value) {
		return value.replaceAll("\\|\\|", ",");
	}
	
	private static String getInnnerDateExpresssion(String columnValue) {

		Pattern datePattern = Pattern.compile(isDateTypePattern);

		Matcher matcher = datePattern.matcher(columnValue);

		matcher.find();

		return matcher.group(2).replaceAll(" ", "");

	}
	
	public static boolean isDatePattern(String columnValue) {

		int from = columnValue.indexOf(DateTypeStartWith);
		int to = columnValue.indexOf(DateTypeEndWith);

		return (from >= 0) && (to > from);
	}
	
	public static String evalDate(String columnValue)
	{
		try
		{
			String innerDateExp = getInnnerDateExpresssion(columnValue);
			columnValue= columnValue.replace(DateTypeStartWith + innerDateExp + DateTypeEndWith , dateParser.parseDatePattern(innerDateExp));
		}
		catch(Exception E)
		{
			log.error("Error while parsing date");
		}
		return columnValue;
	}
}
