package com.kronos.requestgenerator.transformer.csv;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import com.fasterxml.jackson.databind.JsonNode;
import com.kronos.requestgenerator.transformer.csv.CSVDataSeedingTransformer;
import com.kronos.requestgenerator.transformer.csv.CSVDataSeedingTrnsUtils;
import com.kronos.requestgenerator.transformer.csv.EntityJSONProcessData;
import com.kronos.requestgenerator.api.reader.DataSeedingReader;
import com.kronos.requestgenerator.api.reader.DataSeedingReaderException;
import com.kronos.requestgenerator.api.reader.SeedingDataEntity;
import com.kronos.requestgenerator.api.reader.SeedingDataRecord;
import com.kronos.requestgenerator.api.transformer.DataSeedingTransformerException;
import com.kronos.requestgenerator.constants.AppConstants;
import com.kronos.requestgenerator.reader.csv.CSVDataSeedingReader;

public class CSVDataSeedingTrnsUtils {
	private static CSVDataSeedingTrnsUtils utils = null;
	
	
	public static CSVDataSeedingTrnsUtils getInstance() {
		if(utils == null)
			utils = new CSVDataSeedingTrnsUtils();
		return utils;
	}

	private static final Logger log = Logger
			.getLogger(CSVDataSeedingTrnsUtils.class);

	/**
	 * This method identifies if a tool name is a legacy entity or not.
	 * @param toolConfig 
	 * 
	 * @param toolName
	 * @return
	 */
	/*
	public boolean isLegacyEntity(ToolConfig toolConfig, String toolName) {
		Boolean isLegacyProp = (Boolean) toolConfig.getToolConfigProperty(toolName,
				CSVDataSeedingTransformer.APP_CONFIG_TOOL_PROPERTY_IS_LEGACY);
		return isLegacyProp != null ? isLegacyProp : false;
	}*/
	/**
	 * If the entity is a legacy entity, the leaf property of the json is
	 * required to be prepended with @. This method identifies if the json is of
	 * leaf node and if yes prepends @ to the json property name.
	 * 
	 * @param propertyNameKey:  Property Name
	 * @param propertyJson: Json object
	 * @param isLegacyEntity : If legacy entity
	 * @return String
	 */
	
	public String getPropertyNameForJson(String propertyNameKey, Object propertyJson, boolean isLegacyEntity) {
		String propNameForJSON = propertyNameKey;
		if ((propertyJson instanceof String) || (propertyJson instanceof Boolean)
				|| (propertyJson instanceof Number)) {
			//propNameForJSON = isLegacyEntity ? CSVDataSeedingTransformer.LEGACY_PROPERTY_PRE_STRING + propNameForJSON : propNameForJSON;
			propNameForJSON = isLegacyEntity ? propNameForJSON : propNameForJSON;
		}
		return propNameForJSON;
	}
	/**
	 * This method reads the csv data for the entity @param entityName.
	 * 
	 * @param entityName
	 *            The name of the entity for which the csv file data is
	 *            required.
	 * @param configDataDirectory: Config data directory
	 * @return SeedingDataEntity
	 */
	public SeedingDataEntity readEntityCSV(String entityName, String configDataDirectory) {
		DataSeedingReader reader = new CSVDataSeedingReader();
		SeedingDataEntity seedingDataEntity = null;
		String csvAbsPath = configDataDirectory + AppConstants.FILE_SEPARATOR + entityName + CSVDataSeedingTransformer.CSV_FILE_EXTENSION;
		try {
			log.debug("Reading csv data: " + csvAbsPath);
			seedingDataEntity = reader.readData(csvAbsPath);
		} catch (DataSeedingReaderException e) {
			log.error("Error reading file " + csvAbsPath , e);
		}
		return seedingDataEntity;
	}
	
	/**
	 * This method reads the csv data for the entity @param entityName.
	 * 
	 * @param entityName
	 *            The name of the entity for which the csv file data is
	 *            required.
	 * @param configDataDirectory: Config data directory 
	 * @param row: Row to read
	 * @return SeedingDataEntity
	 * @throws DataSeedingTransformerException : DataSeedingTransformerException
	 */
	public SeedingDataEntity readEntityCSV(String entityName, String configDataDirectory, String row) throws DataSeedingTransformerException{
		DataSeedingReader reader = new CSVDataSeedingReader();
		SeedingDataEntity seedingDataEntity = null;
		String csvAbsPath = configDataDirectory + AppConstants.FILE_SEPARATOR + entityName + CSVDataSeedingTransformer.CSV_FILE_EXTENSION;
		try {
			log.debug("Reading csv data: " + csvAbsPath);
			seedingDataEntity = reader.readData(csvAbsPath,row);
		} catch (DataSeedingReaderException e) {
			log.error("Error reading file " + csvAbsPath , e);
			throw new DataSeedingTransformerException("Error reading file" + csvAbsPath); 
		}
		return seedingDataEntity;
	}
	/**
	 * This method returns the value for the json property from the csv row.
	 * 
	 * @param processData : EntityJSONProcessData
	 * @param seedDataRecord : SeedDataRecord
	 * @param propertyName : Property name
	 * @param simpleNodeMap  :  Node map
	 * @return This method returns either Boolean, Integer or Float depending
	 *         upon the type specified in the json schema mapping
	 */
	public Object getPropertyValue(EntityJSONProcessData processData, SeedingDataRecord seedDataRecord,
			String propertyName, Map<String, String> simpleNodeMap) {
		Object jsonData;
		String entityName = processData.getEntityName();
		String key = processData.getKey();
		JsonNode rootNode = processData.getRootNode();

		String propertyType = rootNode.get(CSVDataSeedingTransformer.JSON_SCHEMA_PROPERTY_TYPE).asText();
		
		String propertyHeaderName = getPropertyHeaderName(processData.getParentName(), propertyName, entityName,simpleNodeMap);
		String val = seedDataRecord != null && propertyHeaderName != null ? seedDataRecord.getSeedData(propertyHeaderName) : "";
		val = val != null ? val : "";
		if (val.equalsIgnoreCase("<null>"))
			return null;
		jsonData = val ;
		switch (propertyType) {
		case CSVDataSeedingTransformer.JSON_SCHEMA_TYPE_BOOLEAN:
			
			if (StringUtils.isNotBlank(val))
					jsonData = Boolean.valueOf(val);
			break;
		case CSVDataSeedingTransformer.JSON_SCHEMA_TYPE_NUMBER:
			jsonData = getNumberPropertyValue(entityName, key, propertyHeaderName, val);
			break;
		case CSVDataSeedingTransformer.JSON_SCHEMA_TYPE_INTEGER:
			jsonData = getIntegerPropertyValue(entityName, key, propertyHeaderName, val);
			break;
		default:
			break;
		}
		return jsonData;
	}
	public  List<Object> createArrayOfArrayJson(String leafHeaderName,
			SeedingDataRecord seedDataRecord) {
		List<Object> jsonList = new ArrayList<>();
		String separatedValues = seedDataRecord.getSeedData(leafHeaderName);
		String[] values = separatedValues != null ? separatedValues.split(CSVDataSeedingTransformer.CSV_VALUE_SEPARATOR) : null;
		if (values != null && values.length > 0) {
			jsonList.addAll(Arrays.asList(values));
		}
		return jsonList;
	}

	private String getPropertyHeaderName(String parentName , String propertyName, String entityName, Map<String, String> simpleNodeMap) {
		String propertyHeaderName = propertyName;
		String simpleNodeName = simpleNodeMap.get(entityName);
		if(simpleNodeName != null && !entityName.equals(simpleNodeName)) {
			propertyHeaderName = entityName + CSVDataSeedingTransformer.CSV_HEADER_SEPARATOR + propertyName;
		} else if(simpleNodeName != null && entityName.equals(simpleNodeName)) {
			propertyHeaderName =  propertyName;
		}else if(parentName != null && !parentName.isEmpty()) {
			propertyHeaderName = parentName + "-" + propertyName;
		}
		return propertyHeaderName;
	}

	/**
	 * This method returns the integer value of the csv record for the
	 * propertyName
	 * 
	 * @param entityName: entity name
	 * @param key: property key
	 * @param propertyName : property name
	 * @param val : property value
	 * @return
	 */
	private Object getIntegerPropertyValue(String entityName, String key, String propertyName, String val) {
		Object jsonData;
		try {
			jsonData = Integer.valueOf(val);
		} catch (NumberFormatException e) {
			log.warn("Invalid value.Expected integer value of column:" + propertyName + ", key=" + key
					+ " for tool name=" + entityName);
			jsonData = "";
		}
		return jsonData;
	}
	
	/**
	 * This method returns the double value of the csv record for the
	 * propertyName
	 * 
	 * @param entityName: entity name
	 * @param key: property key
	 * @param propertyName : property name
	 * @param val : property value
	 * @return
	 */
	private Object getNumberPropertyValue(String entityName, String key, String propertyName, String val) {
		Object jsonData;
		try {
			if(val.contains(".")){
                jsonData = Double.valueOf(val);
         }else{
                jsonData = Long.valueOf(val);
         }

		} catch (NumberFormatException e) {
			log.warn("Invalid value.Expected number value of column:" + propertyName + ", key=" + key
					+ " for tool name=" + entityName);
			jsonData = "";
		}
		return jsonData;
	}

}
