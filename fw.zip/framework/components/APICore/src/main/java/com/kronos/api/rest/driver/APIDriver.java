package com.kronos.api.rest.driver;

import static com.jayway.restassured.RestAssured.given;

import java.io.File;
import java.lang.reflect.InvocationTargetException;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.log4j.Logger;

import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;
import com.kronos.api.rest.auth.IAuthentication;
import com.kronos.api.rest.base.BaseRestParameter;
import com.kronos.api.rest.exception.KronosCoreAPIException;
import com.kronos.api.rest.json.Request;
import com.kronos.api.rest.operations.APIResponse;
import com.kronos.api.rest.operations.RestOperationUtils;
import com.kronos.report.Reporter;
import com.kronos.tracking.Actions;
import com.kronos.tracking.CallingClassHelper;

public class APIDriver extends BaseAPIDriver{
	private static final String COOKIE = "Cookie";
	private static final String APPKEY = "appkey";
	private static final String AUTHORIZATION = "Authorization";
	
	private static final String CHARSET_UTF_8 = "charset=UTF-8";
	protected static final Logger logger = Logger.getLogger(APIDriver.class);
	protected static final Reporter reporter = Reporter.getInstance();
	
	public APIDriver(IAuthentication auth){
		super(auth);
		this.context = this.auth.getContext();
	}
	
	/**
	 * This method is for login at openAM and set cookies
	 * It will also get access_token if API gateway URL is given in textNG context
	 * @param username: String
	 * @param password: String
	 */
	public void login(String username, String password) throws KronosCoreAPIException{
		if(cookies != null){
			cookies = null;
		}
		cookies = auth.login(username, password);
		
		if (!context.getAPIGatewayServer().isEmpty())
		{
			if(access_token != null){
				access_token = null;
			}
			access_token = auth.getAccessTokenFromOpenAM(username,password);
		}
	}
	
	/**
	 * This method is for login at openAM and set cookies
	 * It will also get access_token if API gateway URL is given in textNG context
	 * @param user: Enum<?>
	 */
	public void login(Enum<?> user) throws KronosCoreAPIException{
		if(cookies != null){
			cookies = null;
		}
		try {
			cookies = auth.login(
					(String)user.getDeclaringClass().getMethod("getUserName").invoke(user), 
					(String)user.getDeclaringClass().getMethod("getPassword").invoke(user)
					);
		} catch (KronosCoreAPIException | IllegalAccessException | IllegalArgumentException
				| InvocationTargetException | NoSuchMethodException | SecurityException e) {
			throw new KronosCoreAPIException(e.getMessage(),e);
		}
		
		if (!context.getAPIGatewayServer().isEmpty())
		{
			if(access_token != null){
				access_token = null;
			}
			try
			{
				access_token = auth.getAccessTokenFromOpenAM((String)user.getDeclaringClass().getMethod("getUserName").invoke(user), 
					(String)user.getDeclaringClass().getMethod("getPassword").invoke(user)
					);
			}
			 catch (KronosCoreAPIException | IllegalAccessException | IllegalArgumentException
						| InvocationTargetException | NoSuchMethodException | SecurityException e) {
					throw new KronosCoreAPIException(e.getMessage(),e);
				}
		}
	}
	
	/**
	 * This method is for login at FrontEndURL and set cookies
	 * 
	 * @param username: String
	 * @param password: String
	 */
	public void loginAtFrontEnd(String username, String password) throws KronosCoreAPIException{
		if(cookies != null){
			cookies = null;
		}
		cookies = auth.loginAtFrontEnd(username, password);
	}

	/**
	 * This method is for login at FrontEndURL and set cookies
	 * 
	 * @param user: Enum<?>
	 */
	public void loginAtFrontEnd(Enum<?> user) throws KronosCoreAPIException{
		if(cookies != null){
			cookies = null;
		}
		try {
			cookies = auth.loginAtFrontEnd(
					(String)user.getDeclaringClass().getMethod("getUserName").invoke(user), 
					(String)user.getDeclaringClass().getMethod("getPassword").invoke(user)
					);
		} catch (KronosCoreAPIException | IllegalAccessException | IllegalArgumentException
				| InvocationTargetException | NoSuchMethodException | SecurityException e) {
			throw new KronosCoreAPIException(e.getMessage(),e);
		}
	}
	
	public void logout() throws KronosCoreAPIException{
		cookies = auth.logout();
	}
	
	
	public void loginUsingSystemUser(String username, String password) throws KronosCoreAPIException{
		if(cookies != null){
			cookies = null;
		}
		cookies = auth.loginUsingSystemUser(username, password);
	}
	
	/**
	 * This method is for setting Request specification
	 * 
	 * @return RequestSpecification
	 */
	private RequestSpecification generateCommonReqSpec() {
		if (context.getAPIGatewayServer().isEmpty())
			return generateCommonReqSpec_BackEndServer();
		return generateCommonReqSpec_APIGatewayExternalAppKey();
	}
	

	/**
	 * This method is for setting Request specification
	 * 
	 * @param type: APIType
	 * @return RequestSpecification
	 */
	private RequestSpecification generateCommonReqSpec(APIType type) {
		if (context.getAPIGatewayServer().isEmpty())
			return generateCommonReqSpec_BackEndServer();
		else
		{
			if (type == null)
				return generateCommonReqSpec_BackEndServer();
			else if (type.equals(APIType.PRIVATE))
				return generateCommonReqSpec_APIGatewayInternalAppKey();
			else
				return generateCommonReqSpec_APIGatewayExternalAppKey();
		}
	}
	
	/**
	 * This method is for setting Request specification when API is to be hit on WFM backend server
	 * 
	 * @param params: Map
	 * @return RequestSpecification
	 */
	private RequestSpecification generateCommonReqSpec_BackEndServer() {
		return given().headers(COOKIE, cookies)
				.contentType(CHARSET_UTF_8)
				.accept(ContentType.JSON)
				.contentType(ContentType.JSON);
	}
	
	/**
	 * This method is for setting Request specification when API is to be hit on API gateway Server internally
	 * 
	 * @param params: Map
	 * @return RequestSpecification
	 */
	private RequestSpecification generateCommonReqSpec_APIGatewayInternalAppKey() {
		return given().headers( COOKIE, cookies,APPKEY, this.getInternalAppKey())
				.contentType(CHARSET_UTF_8)
				.accept(ContentType.JSON)
				.contentType(ContentType.JSON);
		//.headers(APPKEY,this.getInternalAppKey())
	}
	
	/**
	 * This method is for setting Request specification when API is to be hit on API gateway Server externally
	 * 
	 * @param params: Map
	 * @return RequestSpecification
	 */
	private RequestSpecification generateCommonReqSpec_APIGatewayExternalAppKey() {
		return given().headers(APPKEY,this.getExternalAppkey(), AUTHORIZATION,this.getAccess_token())
				.contentType(CHARSET_UTF_8)
				.accept(ContentType.JSON)
				.contentType(ContentType.JSON);
	}
	
	/**
	 * This method is for setting Request specification with query parameter
	 * 
	 * @param params: Map
	 * @return RequestSpecification
	 */
	private RequestSpecification generateCommonReqSpec(Map<String,Object> params) {
		if(params == null)
			return generateCommonReqSpec();
		return generateCommonReqSpec().
				queryParameters(params);
	}
	
	
	/**
	 * This method is for setting Request specification with query parameter
	 * 
	 * @param params: Map
	 * @return RequestSpecification
	 */
	private RequestSpecification generateCommonReqSpec(Map<String,Object> params,APIType type) {
		if(params == null)
			return generateCommonReqSpec(type);
		return generateCommonReqSpec(type).
				queryParameters(params);
	}
	
	
	/**
	 * This method is for setting Request specification with query parameter
	 * 
	 * @param params: BaseRestParameter
	 * @return RequestSpecification
	 */
	private RequestSpecification generateCommonReqSpec(BaseRestParameter params) {
		if(params == null)
			return generateCommonReqSpec();
		return generateCommonReqSpec()
				.headers(params.getHeader())
				.queryParameters(params.getQuery());
	}
	
	/**
	 * This method is for setting Request specification with query parameter
	 * 
	 * @param params: BaseRestParameter
	 * @param type: APIType
	 * @return RequestSpecification
	 */
	private RequestSpecification generateCommonReqSpec(BaseRestParameter params, APIType type) {
		if(params == null)
			return generateCommonReqSpec(type);
		return generateCommonReqSpec(type)
				.headers(params.getHeader())
				.queryParameters(params.getQuery());
	}
	
	/**
	 * This method is for setting Request specification with minimal parameter settings, no content type or accept type are set
	 * 
	 * @param params: BaseRestParameter
	 * @return RequestSpecification
	 */
	private RequestSpecification generateMinimalReqSpec(BaseRestParameter params) {
		if (context.getAPIGatewayServer().isEmpty())
			return generateMinimalReqSpec_backEndSever(params);
		return generateMinimalReqSpec_APIGatewayServerExternalAppKey(params);
	}
	
	/**
	 * This method is for setting Request specification with minimal parameter settings, no content type or accept type are set
	 * 
	 * @param params: BaseRestParameter
	 * @return RequestSpecification
	 */
	private RequestSpecification generateMinimalReqSpec(BaseRestParameter params, APIType type) {
		if (context.getAPIGatewayServer().isEmpty())
			return generateMinimalReqSpec_backEndSever(params);
		else
		{
			if (type==null)
				return generateMinimalReqSpec_backEndSever(params);
			else if (type.equals(APIType.PRIVATE))
				return generateMinimalReqSpec_APIGatewayServerInternalAppKey(params);
			else
				return generateMinimalReqSpec_APIGatewayServerExternalAppKey(params);
		}	
	}
	
	
	/**
	 * This method is for setting Request specification with minimal parameter settings, no content type or accept type are set
	 * 
	 * @param params: BaseRestParameter
	 * @return RequestSpecification
	 */
	private RequestSpecification generateMinimalReqSpec_backEndSever(BaseRestParameter params) {
		if(params == null)
			return given().headers(COOKIE, cookies);
		return given().headers(COOKIE, cookies)
				.headers(params.getHeader())
				.queryParameters(params.getQuery());
	}
	
	/**
	 * This method is for setting Request specification with minimal parameter settings, no content type or accept type are set
	 * 
	 * @param params: BaseRestParameter
	 * @return RequestSpecification
	 */
	private RequestSpecification generateMinimalReqSpec_APIGatewayServerInternalAppKey(BaseRestParameter params) {
		if(params == null)
			return given().headers(COOKIE, cookies, APPKEY,this.getExternalAppkey());
		return given().headers(COOKIE, cookies, APPKEY,this.getExternalAppkey())
				.headers(params.getHeader())
				.queryParameters(params.getQuery());
	}
	
	/**
	 * This method is for setting Request specification with minimal parameter settings, no content type or accept type are set
	 * 
	 * @param params: BaseRestParameter
	 * @return RequestSpecification
	 */
	private RequestSpecification generateMinimalReqSpec_APIGatewayServerExternalAppKey(BaseRestParameter params) {
		if(params == null)
			return given().headers(AUTHORIZATION,this.getAccess_token(),APPKEY,this.getExternalAppkey());
		return given().headers(AUTHORIZATION, this.getAccess_token(), APPKEY,this.getExternalAppkey())
				.headers(params.getHeader())
				.queryParameters(params.getQuery());
	}
	
	/**
	 * This method is for setting cookie for JSON specific content type for File
	 * 
	 * @param file: String
	 * @param file: File
	 * @return RequestSpecification
	 */
	private RequestSpecification generateCommonReqSpec(File file,Map<String,Object> params) {
		if (context.getAPIGatewayServer().isEmpty())
			return given()
				.headers(COOKIE, cookies)
				.queryParameters(params)
				.multiPart(file)
				.contentType("multipart/form-data");
		return given()
				.headers(AUTHORIZATION, this.getAccess_token(),APPKEY, this.getExternalAppkey())
				.queryParameters(params)
				.multiPart(file)
				.contentType("multipart/form-data");
	}
	
	/**
	 * This method is for setting cookie for JSON specific content type for File
	 * 
	 * @param file: String
	 * @param file: File
	 * @return RequestSpecification
	 */
	private RequestSpecification generateCommonReqSpec(File file,Map<String,Object> params,APIType type) {
		if (context.getAPIGatewayServer().isEmpty())
			return given()
				.headers(COOKIE, cookies)
				.queryParameters(params)
				.multiPart(file)
				.contentType("multipart/form-data");
		else 
		{
			if (type==null)
			{
				return given()
						.headers(COOKIE, cookies)
						.queryParameters(params)
						.multiPart(file)
						.contentType("multipart/form-data");
			}
			else if (type.equals(APIType.PRIVATE))
			{
				return given()
						.headers(COOKIE, cookies,APPKEY, this.getInternalAppKey())
						.queryParameters(params)
						.multiPart(file)
						.contentType("multipart/form-data");
			}
			else
			{
				return given()
						.headers(AUTHORIZATION, this.getAccess_token(),APPKEY, this.getExternalAppkey())
						.queryParameters(params)
						.multiPart(file)
						.contentType("multipart/form-data");
			}
		}
		
	}
	
	/**
	 * This method is for setting Request specification with stateful operations
	 * 
	 * @param params: BaseRestParameter
	 * @return RequestSpecification
	 */
	public RequestSpecification generateStatefulReqSpec(String sessionId) {
		return given().sessionId(sessionId).accept(ContentType.JSON).contentType(ContentType.JSON);
	}
	
	private String generateURL(String uri){
		String finalURI = "";
		if (!(context.getAPIGatewayServer().isEmpty()))
			finalURI = generateURL_APIGateway(uri);
		else
			finalURI  = context.getBackEndServer() + uri;
		//String pattern = "(?<!http:)//";
		String pattern = "(?<!https?:)//";
		finalURI = finalURI.replaceAll(pattern, "/");
		return  finalURI;
	}
	
	private String generateURL_APIGateway(String uri)
	{
		String finalURI  = context.getAPIGatewayServer() + uri;
		finalURI = finalURI.replaceAll("wfc/restcall", "");
		return  finalURI;
	}
	
	private String generateURL(String uri, BaseRestParameter params){
		if(params == null)
			return generateURL(uri);
		if(params.getPath().isEmpty())
			return generateURL(uri);
		
		for(String key: params.getPath().keySet()){
			if (uri.contains("{" + key + "}")) {	
				uri = uri.replace("{" + key + "}", String.valueOf(params.getPath().get(key)) );
			}
		}
		
		return generateURL(uri);
	}
	
	private String generateURL(String uri, Map<String, Object> params) {
		if(params == null)
			return generateURL(uri);
		
		String generatedURI = uri;

		/*
		 * Generate path parameters 
		 */
		Map<String, Object> pathParams = 
				params.entrySet().stream()
				.filter(m -> uri.contains("{" + m.getKey() + "}"))
				.collect(Collectors.toMap(es -> es.getKey(), es -> es.getValue()));
		
		for(String key: pathParams.keySet()){
			if (generatedURI.contains("{" + key + "}")) {
				generatedURI = generatedURI.replace("{" + key + "}", String.valueOf(pathParams.get(key)));
			}
		}		
		return generateURL(generatedURI);
	}
	
	private Map<String,Object> extractQueryParameters(String uri,Map<String, Object> map){
		return map.entrySet().stream()
				.filter(m -> !uri.contains("{" + m.getKey() + "}"))
				.collect(Collectors.toMap(es -> es.getKey(), es -> es.getValue()));
		
	}
	
	/**
	 * This method is to perform POST with query and/or path parameters and the
	 * specified uri.
	 * 
	 * @param uri:
	 *            String
	 * 
	 * @param parameters:
	 *            Map
	 * 
	 * @throws KronosCoreAPIException
	 *             : kronos core API exception
	 * 
	 * @return apiResponse: APIResponse
	 */
	@Deprecated
	public APIResponse post(String uri, Map<String, Object> parameters) throws KronosCoreAPIException {
		Response res = RestOperationUtils.post(
				generateURL(uri, parameters), 
				null, 
				generateCommonReqSpec(extractQueryParameters(uri, parameters)),
				null
			);

		reporter.reportStepWithAPITracking(Actions.POST, uri,parameters.toString(),
				CallingClassHelper.INSTANCE.getCallingAPIClass().getName(),
				reporter.generateFormatedResponse(res));
		
		return new APIResponse(res);	
	}
	
	/**
	 * This method is to perform POST with query and/or path parameters and the
	 * specified uri.
	 * 
	 * @param uri:
	 *            String
	 * 
	 * @param parameters:
	 *            Map
	 * 
	 * @throws KronosCoreAPIException
	 *             : kronos core API exception
	 * 
	 * @return apiResponse: APIResponse
	 */
	@Deprecated
	public APIResponse post(String uri, Map<String, Object> parameters, APIType type) throws KronosCoreAPIException {
		Response res = RestOperationUtils.post(
				generateURL(uri, parameters), 
				null, 
				generateCommonReqSpec(extractQueryParameters(uri, parameters),type),
				null
			);

		reporter.reportStepWithAPITracking(Actions.POST, uri,parameters.toString(),
				CallingClassHelper.INSTANCE.getCallingAPIClass().getName(),
				reporter.generateFormatedResponse(res));
		
		return new APIResponse(res);	
	}
	
	
	/**
	 * This method is to perform POST with the specified uri. Input JsonRequest will be treated as request body
	 * 
	 * @param uri:
	 *            String
	 * @param params:
	 *            BaseRestParameter
	 * @throws KronosCoreAPIException
	 *             : kronos core API exception
	 * @return apiResponse: APIResponse
	 */
	public APIResponse post(String uri,BaseRestParameter params) throws KronosCoreAPIException {
		Response res = RestOperationUtils.post(
							generateURL(uri, params), 
							null, 
							generateCommonReqSpec(params),
							params
						);
		reporter.reportStepWithAPITracking(Actions.POST, uri,params.toString(),
				CallingClassHelper.INSTANCE.getCallingAPIClass().getName(),
				reporter.generateFormatedResponse(res));
		return new APIResponse(res);
	}
	
	
	/**
	 * This method is to perform POST with the specified uri.
	 * 
	 * @param uri:
	 *            String
	 * @param params:
	 *            BaseRestParameter
	 * @param type:
	 * 			APIType           
	 * @throws KronosCoreAPIException
	 *             : kronos core API exception
	 * @return apiResponse: APIResponse
	 */
	public APIResponse post(String uri,BaseRestParameter params, APIType type) throws KronosCoreAPIException {
		Response res = RestOperationUtils.post(
					generateURL(uri, params), 
					null, 
					generateCommonReqSpec(params,type),
					params
				);
		reporter.reportStepWithAPITracking(Actions.POST, uri,params.toString(),
				CallingClassHelper.INSTANCE.getCallingAPIClass().getName(),
				reporter.generateFormatedResponse(res));
		
		return new APIResponse(res);
	}
	
	/**
	 * This method is to perform POST with a json request body with the
	 * specified URI. Input JsonRequest will be treated as request body
	 * 
	 * @param uri:
	 *            String
	 * @param parameters:
	 *            Map
	 * @param payload:
	 *            Request
	 * @throws KronosCoreAPIException
	 *             : kronos core API exception
	 * @return apiResponse: APIResponse
	 */
	@Deprecated
	public APIResponse post(String uri,Request payload, Map<String, Object> parameters) throws KronosCoreAPIException {
		
		Response res = RestOperationUtils.post(
							generateURL(uri, parameters), 
							payload == null ? null : payload.getRequest().toString(), 
							generateCommonReqSpec(extractQueryParameters(uri, parameters)),
							null
						);
		
		reporter.reportStepWithAPITracking(Actions.POST, uri, parameters.toString(),
				CallingClassHelper.INSTANCE.getCallingAPIClass().getName(),
				reporter.generateFormatedResponse(res));
		
		return new APIResponse(res);
	}
		
	
	/**
	 * This method is to perform POST with a json request body with the
	 * specified URI. Input JsonRequest will be treated as request body
	 * 
	 * @param uri:
	 *            String
	 * @param parameters:
	 *            Map
	 * @param payload:
	 *            Request
	 * @throws KronosCoreAPIException
	 *             : kronos core API exception
	 * @return apiResponse: APIResponse
	 */
	@Deprecated
	public APIResponse post(String uri,Request payload, Map<String, Object> parameters, APIType type) throws KronosCoreAPIException {
		
		Response res = RestOperationUtils.post(
							generateURL(uri, parameters), 
							payload == null ? null : payload.getRequest().toString(), 
							generateCommonReqSpec(extractQueryParameters(uri, parameters),type),
							null
						);
		
		reporter.reportStepWithAPITracking(Actions.POST, uri, parameters.toString(),
				CallingClassHelper.INSTANCE.getCallingAPIClass().getName(),
				reporter.generateFormatedResponse(res));
		
		return new APIResponse(res);
	}
	
	/**
	 * This method is to perform POST with a json request body with the
	 * specified uri. Input JsonRequest will be treated as request body
	 * 
	 * @param payload:
	 *            Request
	 * @param uri:
	 *            String
	 * @param params:
	 *            BaseRestParameter
	 * @throws KronosCoreAPIException
	 *             : kronos core API exception
	 * @return apiResponse: APIResponse
	 */
	public APIResponse post(String uri,BaseRestParameter params,Request payload) throws KronosCoreAPIException {
		Response res = RestOperationUtils.post(
							generateURL(uri, params), 
							payload == null ? null : payload.getRequest().toString(), 
							generateCommonReqSpec(params),
							params
						);
		
		reporter.reportStepWithAPITracking(Actions.POST, uri,params.toString(),
				CallingClassHelper.INSTANCE.getCallingAPIClass().getName(),
				reporter.generateFormatedResponse(res));
		
		return new APIResponse(res);
	}
	
	
	/**
	 * This method is to perform POST with a json request body with the
	 * specified uri. Input JsonRequest will be treated as request body
	 * 
	 * @param payload:
	 *            Request
	 * @param uri:
	 *            String
	 * @param params:
	 *            BaseRestParameter
	 * @throws KronosCoreAPIException
	 *             : kronos core API exception
	 * @return apiResponse: APIResponse
	 */
	public APIResponse post(String uri,BaseRestParameter params,Request payload, APIType type) throws KronosCoreAPIException {
		Response res = RestOperationUtils.post(
							generateURL(uri, params), 
							payload == null ? null : payload.getRequest().toString(), 
							generateCommonReqSpec(params,type),
							params
						);
		
		reporter.reportStepWithAPITracking(Actions.POST, uri,params.toString(),
				CallingClassHelper.INSTANCE.getCallingAPIClass().getName(),
				reporter.generateFormatedResponse(res));
		
		return new APIResponse(res);
	}
	
	
	/**
	 * This method is to perform POST with a json request body with the
	 * specified uri. Input JsonRequest will be treated as request body, specification will be 
	 * rest assured RequestSpecification object in case the provided method does not satisfy your need.
	 * 
	 * @param payload:
	 *            Request
	 * @param uri:
	 *            String
	 * @param params:
	 *            BaseRestParameter
	 * @param specification:           
	 *            RequestSpecification
	 * @throws KronosCoreAPIException
	 *             : kronos core API exception
	 * @return apiResponse: APIResponse
	 */
	public APIResponse post(String uri,BaseRestParameter params,Request payload,RequestSpecification specification) throws KronosCoreAPIException {
		
		Response res = RestOperationUtils.post(
							generateURL(uri, params), 
							payload == null ? null : payload.getRequest().toString(), 
							generateMinimalReqSpec(params).spec(specification),
							params
						);
		
		reporter.reportStepWithAPITracking(Actions.POST, uri,params.toString(),
				CallingClassHelper.INSTANCE.getCallingAPIClass().getName(),
				reporter.generateFormatedResponse(res));
		
		return new APIResponse(res);
	}

   /**
    * This method is to perform POST with the specified uri. Specification will be
    * rest assured RequestSpecification object in case the provided method does not satisfy your need.
    *
    * @param uri:           String
    * @param params:        BaseRestParameter
    * @param specification: RequestSpecification
    * @return apiResponse: APIResponse
    * @throws KronosCoreAPIException : kronos core API exception
    */
   public APIResponse post(String uri, BaseRestParameter params, RequestSpecification specification) throws KronosCoreAPIException {

      Response res = RestOperationUtils.post(
            generateURL(uri, params),
            null,
            generateMinimalReqSpec(params).spec(specification),
            params
      );

      reporter.reportStepWithAPITracking(Actions.POST, uri, params.toString(),
            CallingClassHelper.INSTANCE.getCallingAPIClass().getName(),
            reporter.generateFormatedResponse(res));

      return new APIResponse(res);
   }
	
	/**
	 * This method is to perform POST with a json request body with the
	 * specified uri. Input JsonRequest will be treated as request body, specification will be 
	 * rest assured RequestSpecification object in case the provided method does not satisfy your need.
	 * 
	 * @param payload:
	 *            Request
	 * @param uri:
	 *            String
	 * @param params:
	 *            BaseRestParameter
	 * @param specification:           
	 *            RequestSpecification
	 * @throws KronosCoreAPIException
	 *             : kronos core API exception
	 * @return apiResponse: APIResponse
	 */
	public APIResponse post(String uri,BaseRestParameter params,Request payload,RequestSpecification specification, APIType type) throws KronosCoreAPIException {
		
		Response res = RestOperationUtils.post(
							generateURL(uri, params), 
							payload == null ? null : payload.getRequest().toString(), 
							generateMinimalReqSpec(params,type).spec(specification),
							params
						);
		
		reporter.reportStepWithAPITracking(Actions.POST, uri,params.toString(),
				CallingClassHelper.INSTANCE.getCallingAPIClass().getName(),
				reporter.generateFormatedResponse(res));
		
		return new APIResponse(res);
	}
	
	
	/**
	 * This method is to perform POST with a file as attachment and
	 * the specified URI.
	 * 
	 * @param URI:
	 *            String
	 * 
	 * @param parapayloadmeters:
	 *            Request
	 * 
	 * @throws KronosCoreAPIException
	 *             : kronos core API exception
	 * 
	 * @return apiResponse: APIResponse
	 */
	public APIResponse post(String uri, File file, BaseRestParameter params) throws KronosCoreAPIException {
		Response res = RestOperationUtils.post(
				generateURL(uri, params), 
				null, 
				generateCommonReqSpec(file,params.getQuery()),
				params
			);

		reporter.reportStepWithAPITracking(Actions.POST, uri,params.toString(),
				CallingClassHelper.INSTANCE.getCallingAPIClass().getName(),
				reporter.generateFormatedResponse(res));
		return new APIResponse(res);
	}

	
	
	/**
	 * This method is to perform POST with a file as attachment and
	 * the specified URI.
	 * 
	 * @param URI:
	 *            String
	 * 
	 * @param parapayloadmeters:
	 *            Request
	 * 
	 * @throws KronosCoreAPIException
	 *             : kronos core API exception
	 * 
	 * @return apiResponse: APIResponse
	 */
	public APIResponse post(String uri, File file, BaseRestParameter params, APIType type) throws KronosCoreAPIException {
		Response res = RestOperationUtils.post(
				generateURL(uri, params), 
				null, 
				generateCommonReqSpec(file,params.getQuery(),type),
				params
			);

		reporter.reportStepWithAPITracking(Actions.POST, uri,params.toString(),
				CallingClassHelper.INSTANCE.getCallingAPIClass().getName(),
				reporter.generateFormatedResponse(res));
		return new APIResponse(res);
	}
	
	/**
	 * This method is to perform POST with a file as attachment, query and/or
	 * path parameters and the specified URI.
	 * 
	 * @param URI:
	 *            String
	 * 
	 * @param parapayloadmeters:
	 *            Request
	 * 
	 * @throws KronosCoreAPIException
	 *             : kronos core API exception
	 * 
	 * @return apiResponse: APIResponse
	 */
	@Deprecated
	public APIResponse post(String uri, File file, Map<String, Object> parameters) throws KronosCoreAPIException {
		Response res = RestOperationUtils.post(
				generateURL(uri, parameters), 
				null, 
				generateCommonReqSpec(file,extractQueryParameters(uri, parameters)),
				null
			);

		reporter.reportStepWithAPITracking(Actions.POST, uri,parameters.toString(),
				CallingClassHelper.INSTANCE.getCallingAPIClass().getName(),
				reporter.generateFormatedResponse(res));
		return new APIResponse(res);
	}
	
	
	/**
	 * This method is to perform POST with a file as attachment, query and/or
	 * path parameters and the specified URI.
	 * 
	 * @param URI:
	 *            String
	 * 
	 * @param parapayloadmeters:
	 *            Request
	 * 
	 * @throws KronosCoreAPIException
	 *             : kronos core API exception
	 * 
	 * @return apiResponse: APIResponse
	 */
	@Deprecated
	public APIResponse post(String uri, File file, Map<String, Object> parameters, APIType type) throws KronosCoreAPIException {
		Response res = RestOperationUtils.post(
				generateURL(uri, parameters), 
				null, 
				generateCommonReqSpec(file,extractQueryParameters(uri, parameters), type),
				null
			);

		reporter.reportStepWithAPITracking(Actions.POST, uri,parameters.toString(),
				CallingClassHelper.INSTANCE.getCallingAPIClass().getName(),
				reporter.generateFormatedResponse(res));
		return new APIResponse(res);
	}
	
	
	/**
	 * This method is to perform GET with a specified URI.
	 *
	 * @param uri:
	 *            String
	 * 
	 * @throws KronosCoreAPIException
	 *             : kronos core API exception
	 * 
	 * @return apiResponse: APIResponse
	 */
	@Deprecated
	public APIResponse get(String uri, Map<String, Object> parameters) throws KronosCoreAPIException {
		Response res = RestOperationUtils.get(
				generateURL(uri, parameters), 
				generateCommonReqSpec(extractQueryParameters(uri, parameters)),
				null
			);
		
		reporter.reportStepWithAPITracking(Actions.GET, uri,parameters.toString(),
				CallingClassHelper.INSTANCE.getCallingAPIClass().getName(),
				reporter.generateFormatedResponse(res));
		return new APIResponse(res);
	}
	
	
	
	/**
	 * This method is to perform GET with a specified URI.
	 *
	 * @param uri:
	 *            String
	 * 
	 * @throws KronosCoreAPIException
	 *             : kronos core API exception
	 * 
	 * @return apiResponse: APIResponse
	 */
	@Deprecated
	public APIResponse get(String uri, Map<String, Object> parameters, APIType type) throws KronosCoreAPIException {
		Response res = RestOperationUtils.get(
				generateURL(uri, parameters), 
				generateCommonReqSpec(extractQueryParameters(uri, parameters),type),
				null
			);
		
		reporter.reportStepWithAPITracking(Actions.GET, uri,parameters.toString(),
				CallingClassHelper.INSTANCE.getCallingAPIClass().getName(),
				reporter.generateFormatedResponse(res));
		return new APIResponse(res);
	}
	
	
	/**
	 * This method is to perform GET with a specified URI.
	 *
	 * @param uri:
	 *            String
	 * 
	 * @throws KronosCoreAPIException
	 *             : kronos core API exception
	 * 
	 * @return apiResponse: APIResponse
	 */
	public APIResponse get(String uri, BaseRestParameter params) throws KronosCoreAPIException {
		Response res = RestOperationUtils.get(
				generateURL(uri, params), 
				generateCommonReqSpec(params),
				params
			);
		
		reporter.reportStepWithAPITracking(Actions.GET, uri,params.toString(),
				CallingClassHelper.INSTANCE.getCallingAPIClass().getName(),
				reporter.generateFormatedResponse(res));
		return new APIResponse(res);
	}
	
	
	/**
	 * This method is to perform GET with a specified URI.
	 *
	 * @param uri:
	 *            String
	 * 
	 * @throws KronosCoreAPIException
	 *             : kronos core API exception
	 * 
	 * @return apiResponse: APIResponse
	 */
	public APIResponse get(String uri, BaseRestParameter params,APIType type) throws KronosCoreAPIException {
		Response res = RestOperationUtils.get(
				generateURL(uri, params), 
				generateCommonReqSpec(params,type),
				params
			);
		
		reporter.reportStepWithAPITracking(Actions.GET, uri,params.toString(),
				CallingClassHelper.INSTANCE.getCallingAPIClass().getName(),
				reporter.generateFormatedResponse(res));
		return new APIResponse(res);
	}
	
	
	/**
	 * This method is to perform GET with a json request body with the
	 * specified uri. Input JsonRequest will be treated as request body, specification will be 
	 * rest assured RequestSpecification object in case the provided method does not satisfy your need.
	 * 
	 * @param payload:
	 *            Request
	 * @param uri:
	 *            String
	 * @param params:
	 *            BaseRestParameter
	 * @param specification:           
	 *            RequestSpecification
	 * @throws KronosCoreAPIException
	 *             : kronos core API exception
	 * @return apiResponse: APIResponse
	 */
	public APIResponse get(String uri,BaseRestParameter params, RequestSpecification specification) throws KronosCoreAPIException {
		
		Response res = RestOperationUtils.get(
							generateURL(uri, params), 
							generateMinimalReqSpec(params).spec(specification),
							params
						);
		
		reporter.reportStepWithAPITracking(Actions.GET, uri,params.toString(),
				CallingClassHelper.INSTANCE.getCallingAPIClass().getName(),
				reporter.generateFormatedResponse(res));
		
		return new APIResponse(res);
	}
	
	/**
	 * This method is to perform GET with a json request body with the
	 * specified uri. Input JsonRequest will be treated as request body, specification will be 
	 * rest assured RequestSpecification object in case the provided method does not satisfy your need.
	 * 
	 * @param payload:
	 *            Request
	 * @param uri:
	 *            String
	 * @param params:
	 *            BaseRestParameter
	 * @param specification:           
	 *            RequestSpecification
	 * @throws KronosCoreAPIException
	 *             : kronos core API exception
	 * @return apiResponse: APIResponse
	 */
	public APIResponse get(String uri,BaseRestParameter params, RequestSpecification specification, APIType type) throws KronosCoreAPIException {
		
		Response res = RestOperationUtils.get(
							generateURL(uri, params), 
							generateMinimalReqSpec(params,type).spec(specification),
							params
						);
		
		reporter.reportStepWithAPITracking(Actions.GET, uri,params.toString(),
				CallingClassHelper.INSTANCE.getCallingAPIClass().getName(),
				reporter.generateFormatedResponse(res));
		
		return new APIResponse(res);
	}
	
	/**
	 * This method is to perform PUT with query and/or path parameters and the
	 * specified URI.
	 * 
	 * @param URI:
	 *            String
	 * 
	 * @param parameters:
	 *            Map
	 * 
	 * @throws KronosCoreAPIException
	 *             : kronos core API exception
	 * 
	 * @return apiResponse: APIResponse
	 */
	@Deprecated
	public APIResponse put(String uri, Map<String, Object> parameters) throws KronosCoreAPIException {
		return put(uri,null,parameters);
	}
	
	
	/**
	 * This method is to perform PUT with query and/or path parameters and the
	 * specified URI.
	 * 
	 * @param URI:
	 *            String
	 * 
	 * @param parameters:
	 *            Map
	 * 
	 * @throws KronosCoreAPIException
	 *             : kronos core API exception
	 * 
	 * @return apiResponse: APIResponse
	 */
	@Deprecated
	public APIResponse put(String uri, Map<String, Object> parameters, APIType type) throws KronosCoreAPIException {
		return put(uri,null,parameters,type);
	}
	
	/**
	 * This method is to perform HTTP PUT with the specified uri and query and path parameters.
	 * 
	 * @param uri:
	 *            String
	 * @param params:
	 *            BaseRestParameter
	 * @throws KronosCoreAPIException
	 *             : kronos core API exception
	 * @return apiResponse: APIResponse
	 */
	public APIResponse put(String uri,BaseRestParameter params) throws KronosCoreAPIException {
		
		Response res = RestOperationUtils.put(
							generateURL(uri, params), 
							null, 
							generateCommonReqSpec(params),
							params
						);
		
		reporter.reportStepWithAPITracking(Actions.PUT, uri,params.toString(),
				CallingClassHelper.INSTANCE.getCallingAPIClass().getName(),
				reporter.generateFormatedResponse(res));
		
		return new APIResponse(res);
	}
	
	
	

	/**
	 * This method is to perform HTTP PUT with the specified uri. Input JsonRequest will be treated as request body
	 * 
	 * @param uri:
	 *            String
	 * @param params:
	 *            BaseRestParameter
	 * @param type: APIType   
	 * @throws KronosCoreAPIException
	 *             : kronos core API exception
	 * @return apiResponse: APIResponse
	 */
	public APIResponse put(String uri,BaseRestParameter params, APIType type) throws KronosCoreAPIException {
		
		Response res = RestOperationUtils.put(
							generateURL(uri, params), 
							null, 
							generateCommonReqSpec(params,type),
							params
						);
		
		reporter.reportStepWithAPITracking(Actions.PUT, uri,params.toString(),
				CallingClassHelper.INSTANCE.getCallingAPIClass().getName(),
				reporter.generateFormatedResponse(res));
		
		return new APIResponse(res);
	}
	
	/**
	 * This method is to perform PUT with a specified URI.
	 *
	 * @param URI:
	 *            String
	 * @param parameters:
	 *            Map
	 * @throws KronosCoreAPIException
	 *             : kronos core API exception
	 * 
	 * @return apiResponse: APIResponse
	 */
	@Deprecated
	public APIResponse put(String uri, Request payload, Map<String, Object> parameters) throws KronosCoreAPIException {
		return put(uri,payload,parameters,null);
	}

	/**
	 * This method is to perform Put with the specified uri. Input JsonRequest will be treated as request body
	 * 
	 * @param uri:
	 *            String
	 * @param payload:
	 *            Request
	 * @param parameters:
	 *            Map
	 * @param type: APIType           
	 * @throws KronosCoreAPIException
	 *             : kronos core API exception
	 * @return apiResponse: APIResponse
	 */
	@Deprecated
	public APIResponse put(String uri, Request payload, Map<String, Object> parameters, APIType type) throws KronosCoreAPIException {
		Response res = RestOperationUtils.put(
				generateURL(uri, parameters), 
				payload == null ? null : payload.getRequest().toString(), 
				generateCommonReqSpec(extractQueryParameters(uri, parameters),type),
				null
			);
		
		reporter.reportStepWithAPITracking(Actions.PUT, uri,parameters.toString(),
				CallingClassHelper.INSTANCE.getCallingAPIClass().getName(),
				reporter.generateFormatedResponse(res));
		
		return new APIResponse(res);
	}
	
	
	/**
	 * This method is to perform POST with a json request body with the
	 * specified uri. Input JsonRequest will be treated as request body
	 * 
	 * @param uri:
	 *            String
	 * @param params:
	 *            BaseRestParameter
	 * @param payload:
	 *            Request
	 * @throws KronosCoreAPIException
	 *             : kronos core API exception
	 * @return apiResponse: APIResponse
	 */
	public APIResponse put(String uri,BaseRestParameter params,Request payload) throws KronosCoreAPIException {
		
		Response res = RestOperationUtils.put(
							generateURL(uri, params), 
							payload == null ? null : payload.getRequest().toString(), 
							generateCommonReqSpec(params),
							params
						);
		
		reporter.reportStepWithAPITracking(Actions.PUT, uri,params.toString(),
				CallingClassHelper.INSTANCE.getCallingAPIClass().getName(),
				reporter.generateFormatedResponse(res));
		
		return new APIResponse(res);
	}
	
	
	/**
	 * This method is to perform POST with a json request body with the
	 * specified uri. Input JsonRequest will be treated as request body
	 * 
	 * @param uri:
	 *            String
	 * @param params:
	 *            BaseRestParameter
	 * @param payload:
	 *            Request
	 * @param type: APIType    
	 * @throws KronosCoreAPIException
	 *             : kronos core API exception
	 * @return apiResponse: APIResponse
	 */
	public APIResponse put(String uri,BaseRestParameter params,Request payload, APIType type) throws KronosCoreAPIException {
		
		Response res = RestOperationUtils.put(
							generateURL(uri, params), 
							payload == null ? null : payload.getRequest().toString(), 
							generateCommonReqSpec(params,type),
							params
						);
		
		reporter.reportStepWithAPITracking(Actions.PUT, uri,params.toString(),
				CallingClassHelper.INSTANCE.getCallingAPIClass().getName(),
				reporter.generateFormatedResponse(res));
		
		return new APIResponse(res);
	}
	
	/**
	 * This method is to perform PUT with a json request body with the
	 * specified uri. Input JsonRequest will be treated as request body, specification will be 
	 * rest assured RequestSpecification object in case the provided method does not satisfy your need.
	 * 
	 * @param payload:
	 *            Request
	 * @param uri:
	 *            String
	 * @param params:
	 *            BaseRestParameter
	 * @param specification:           
	 *            RequestSpecification
	 * @throws KronosCoreAPIException
	 *             : kronos core API exception
	 * @return apiResponse: APIResponse
	 */
	public APIResponse put(String uri,BaseRestParameter params,Request payload,RequestSpecification specification) throws KronosCoreAPIException {
		
		Response res = RestOperationUtils.put(
							generateURL(uri, params), 
							payload == null ? null : payload.getRequest().toString(), 
							generateMinimalReqSpec(params).spec(specification),
							params
						);
		
		reporter.reportStepWithAPITracking(Actions.PUT, uri,params.toString(),
				CallingClassHelper.INSTANCE.getCallingAPIClass().getName(),
				reporter.generateFormatedResponse(res));
		
		return new APIResponse(res);
	}

   /**
    * This method is to perform PUT with the specified uri. Specification will be
    * rest assured RequestSpecification object in case the provided method does not satisfy your need.
    *
    * @param uri:           String
    * @param params:        BaseRestParameter
    * @param specification: RequestSpecification
    * @return apiResponse: APIResponse
    * @throws KronosCoreAPIException : kronos core API exception
    */
   public APIResponse put(String uri, BaseRestParameter params, RequestSpecification specification) throws KronosCoreAPIException {

      Response res = RestOperationUtils.put(
            generateURL(uri, params),
            null,
            generateMinimalReqSpec(params).spec(specification),
            params
      );

      reporter.reportStepWithAPITracking(Actions.PUT, uri, params.toString(),
            CallingClassHelper.INSTANCE.getCallingAPIClass().getName(),
            reporter.generateFormatedResponse(res));

      return new APIResponse(res);
   }

	/**
	 * This method is to perform PUT with a json request body with the
	 * specified uri. Input JsonRequest will be treated as request body, specification will be 
	 * rest assured RequestSpecification object in case the provided method does not satisfy your need.
	 * 
	 * @param payload:
	 *            Request
	 * @param uri:
	 *            String
	 * @param params:
	 *            BaseRestParameter
	 * @param specification:           
	 *            RequestSpecification
	 * @param type: APIType           
	 * @throws KronosCoreAPIException
	 *             : kronos core API exception
	 * @return apiResponse: APIResponse
	 */
	public APIResponse put(String uri,BaseRestParameter params,Request payload,RequestSpecification specification, APIType type) throws KronosCoreAPIException {
		
		Response res = RestOperationUtils.put(
							generateURL(uri, params), 
							payload == null ? null : payload.getRequest().toString(), 
							generateMinimalReqSpec(params,type).spec(specification),
							params
						);
		
		reporter.reportStepWithAPITracking(Actions.PUT, uri,params.toString(),
				CallingClassHelper.INSTANCE.getCallingAPIClass().getName(),
				reporter.generateFormatedResponse(res));
		
		return new APIResponse(res);
	}
	
	/**
	 * This method is to perform DELETE with query and/or path parameters and
	 * the specified URI.
	 * 
	 * @param URI:
	 *            String
	 * 
	 * @param parameters:
	 *            Map
	 * 
	 * @throws KronosCoreAPIException
	 *             : kronos core API exception
	 * 
	 * @return apiResponse: APIResponse
	 */
	@Deprecated
	public APIResponse delete(String uri, Map<String, Object> parameters) throws KronosCoreAPIException {
		return delete(uri,null,parameters);
	}
	
	
	/**
	 * This method is to perform DELETE with query and/or path parameters and
	 * the specified URI. You can also specify the APIType as public or private
	 * 
	 * @param URI:
	 *            String
	 * 
	 * @param parameters:
	 *            Map
	 * 
	 * @param type:
	 * 			APIType
	 * 
	 * @throws KronosCoreAPIException
	 *             : kronos core API exception
	 * 
	 * @return apiResponse: APIResponse
	 */
	@Deprecated
	public APIResponse delete(String uri, Map<String, Object> parameters, APIType type) throws KronosCoreAPIException {
		return delete(uri,null,parameters,type);
	}
	
	/**
	 * This method is to perform DELETE with a json request body , query and/or
	 * path parameters and the specified URI. Input payload will be treated
	 * as request body
	 * 
	 * @param uri:
	 *            String
	 * 
	 * @param payload:
	 *            Request
	 * 
	 * @param parameters:
	 *            Map
	 * 
	 * @throws KronosCoreAPIException
	 *             : kronos core API exception
	 * 
	 * @return apiResponse: APIResponse
	 */
	@Deprecated
	public APIResponse delete(String uri, Request payload, Map<String, Object> parameters) throws KronosCoreAPIException{
		return delete(uri,payload,parameters,null);
	}
	
	/**
	 * This method is to perform DELETE with a json request body , query and/or
	 * path parameters and the specified URI. Input payload will be treated
	 * as request body
	 * 
	 * @param uri:
	 *            String
	 * 
	 * @param payload:
	 *            Request
	 * 
	 * @param parameters:
	 *            Map
	 *            
	 * @param type: APIType 	
	 * 
	 * @throws KronosCoreAPIException
	 *             : kronos core API exception
	 * 
	 * @return apiResponse: APIResponse
	 */
	@Deprecated
	public APIResponse delete(String uri, Request payload, Map<String, Object> parameters, APIType type) throws KronosCoreAPIException{
		Response res = RestOperationUtils.delete(
				generateURL(uri, parameters), 
				payload == null ? null : payload.getRequest().toString(), 
				generateCommonReqSpec(extractQueryParameters(uri, parameters),type),
				null
			);
		
		reporter.reportStepWithAPITracking(Actions.DELETE, uri,parameters.toString(),
				CallingClassHelper.INSTANCE.getCallingAPIClass().getName(),
				reporter.generateFormatedResponse(res));
		return new APIResponse(res);
	}
	
	
	/**
	 * This method is to perform DELETE with query and/or path parameters and
	 * the specified URI.
	 * 
	 * @param URI:
	 *            String
	 * 
	 * @param parameters:
	 *            BaseRestParameter
	 * 
	 * @throws KronosCoreAPIException
	 *             : kronos core API exception
	 * 
	 * @return apiResponse: APIResponse
	 */
	public APIResponse delete(String uri, BaseRestParameter parameters) throws KronosCoreAPIException {
		Response res  = RestOperationUtils.delete(
				generateURL(uri, parameters), null,
				generateCommonReqSpec(parameters),
				parameters
			);
	
		reporter.reportStepWithAPITracking(Actions.DELETE, uri,parameters.toString(),
			CallingClassHelper.INSTANCE.getCallingAPIClass().getName(),
			reporter.generateFormatedResponse(res));
	
		return new APIResponse(res);
	}
	
	/**
	 * This method is to perform DELETE with query and/or path parameters and
	 * the specified URI.
	 * 
	 * @param URI:
	 *            String
	 * 
	 * @param parameters:
	 *            BaseRestParameter
	 * @param type: APIType
	 * 
	 * @throws KronosCoreAPIException
	 *             : kronos core API exception
	 * 
	 * @return apiResponse: APIResponse
	 */
	public APIResponse delete(String uri, BaseRestParameter parameters, APIType type) throws KronosCoreAPIException {
		Response res  = RestOperationUtils.delete(
				generateURL(uri, parameters), null,
				generateCommonReqSpec(parameters,type),
				parameters
			);
	
		reporter.reportStepWithAPITracking(Actions.DELETE, uri,parameters.toString(),
			CallingClassHelper.INSTANCE.getCallingAPIClass().getName(),
			reporter.generateFormatedResponse(res));
	
		return new APIResponse(res);
	}
	
	/**
	 * This method is to perform DELETE with a json request body with the
	 * specified uri. Input JsonRequest will be treated as request body
	 * 
	 * @param uri:
	 *            String
	 * @param params:
	 *            BaseRestParameter
	 * @param payload:
	 *            Request
	 * @throws KronosCoreAPIException
	 *             : kronos core API exception
	 * @return apiResponse: APIResponse
	 */
	public APIResponse delete(String uri,BaseRestParameter params,Request payload) throws KronosCoreAPIException {
		
		Response res  = RestOperationUtils.delete(
				generateURL(uri, params), 
				payload == null ? null : payload.getRequest().toString(), 
				generateCommonReqSpec(params),
				params
			);
	
		reporter.reportStepWithAPITracking(Actions.DELETE, uri,params.toString(),
			CallingClassHelper.INSTANCE.getCallingAPIClass().getName(),
			reporter.generateFormatedResponse(res));
	
		return new APIResponse(res);
	}
	
	
	/**
	 * This method is to perform DELETE with a json request body with the
	 * specified uri. Input JsonRequest will be treated as request body
	 * 
	 * @param uri:
	 *            String
	 * @param params:
	 *            BaseRestParameter
	 * @param payload:
	 *            Request
	 * @param type: APIType
	 * @throws KronosCoreAPIException
	 *             : kronos core API exception
	 * @return apiResponse: APIResponse
	 */
	public APIResponse delete(String uri,BaseRestParameter params,Request payload, APIType type) throws KronosCoreAPIException {
		
		Response res  = RestOperationUtils.delete(
					generateURL(uri, params), 
					payload == null ? null : payload.getRequest().toString(), 
					generateCommonReqSpec(params,type),
					params
				);
		
		reporter.reportStepWithAPITracking(Actions.DELETE, uri,params.toString(),
				CallingClassHelper.INSTANCE.getCallingAPIClass().getName(),
				reporter.generateFormatedResponse(res));
		
		return new APIResponse(res);
	}
	
	
	/**
	 * This method is to perform DELETE with a json request body with the
	 * specified uri. Input JsonRequest will be treated as request body, specification will be 
	 * rest assured RequestSpecification object in case the provided method does not satisfy your need.
	 * 
	 * @param payload:
	 *            Request
	 * @param uri:
	 *            String
	 * @param params:
	 *            BaseRestParameter
	 * @param specification:           
	 *            RequestSpecification
	 * @throws KronosCoreAPIException
	 *             : kronos core API exception
	 * @return apiResponse: APIResponse
	 */
	public APIResponse delete(String uri,BaseRestParameter params,Request payload,RequestSpecification specification) throws KronosCoreAPIException {
		
		Response res = RestOperationUtils.delete(
							generateURL(uri, params), 
							payload == null ? null : payload.getRequest().toString(), 
							generateMinimalReqSpec(params).spec(specification),
							params
						);
		
		reporter.reportStepWithAPITracking(Actions.DELETE, uri,params.toString(),
				CallingClassHelper.INSTANCE.getCallingAPIClass().getName(),
				reporter.generateFormatedResponse(res));
		
		return new APIResponse(res);
	}

   /**
    * This method is to perform DELETE with the specified uri. Specification will be
    * rest assured RequestSpecification object in case the provided method does not satisfy your need.
    *
    * @param uri:           String
    * @param params:        BaseRestParameter
    * @param specification: RequestSpecification
    * @return apiResponse: APIResponse
    * @throws KronosCoreAPIException : kronos core API exception
    */
   public APIResponse delete(String uri, BaseRestParameter params, RequestSpecification specification) throws KronosCoreAPIException {

      Response res = RestOperationUtils.delete(
            generateURL(uri, params),
            null,
            generateMinimalReqSpec(params).spec(specification),
            params
      );

      reporter.reportStepWithAPITracking(Actions.DELETE, uri, params.toString(),
            CallingClassHelper.INSTANCE.getCallingAPIClass().getName(),
            reporter.generateFormatedResponse(res));

      return new APIResponse(res);
   }

	/**
	 * This method is to perform DELETE with a json request body with the
	 * specified uri. Input JsonRequest will be treated as request body, specification will be 
	 * rest assured RequestSpecification object in case the provided method does not satisfy your need.
	 * 
	 * @param payload:
	 *            Request
	 * @param uri:
	 *            String
	 * @param params:
	 *            BaseRestParameter
	 * @param specification:           
	 *            RequestSpecification
	 * @param type: APIType
	 * @throws KronosCoreAPIException
	 *             : kronos core API exception
	 * @return apiResponse: APIResponse
	 */
	public APIResponse delete(String uri,BaseRestParameter params,Request payload,RequestSpecification specification, APIType type) throws KronosCoreAPIException {
		
		Response res = RestOperationUtils.delete(
							generateURL(uri, params), 
							payload == null ? null : payload.getRequest().toString(), 
							generateMinimalReqSpec(params,type).spec(specification),
							params
						);
		
		reporter.reportStepWithAPITracking(Actions.DELETE, uri,params.toString(),
				CallingClassHelper.INSTANCE.getCallingAPIClass().getName(),
				reporter.generateFormatedResponse(res));
		
		return new APIResponse(res);
	}
	
	/**
	 * This method is to perform PATCH with the specified uri. Input JsonRequest will be treated as request body
	 * 
	 * @param uri:
	 *            String
	 * @param params:
	 *            BaseRestParameter
	 * @throws KronosCoreAPIException
	 *             : kronos core API exception
	 * @return apiResponse: APIResponse
	 */
	public APIResponse patch(String uri,BaseRestParameter params) throws KronosCoreAPIException {
		
		Response res = RestOperationUtils.patch(
							generateURL(uri, params), 
							null, 
							generateCommonReqSpec(params),
							params
						);
		reporter.reportStepWithAPITracking(Actions.POST, uri,params.toString(),
				CallingClassHelper.INSTANCE.getCallingAPIClass().getName(),
				reporter.generateFormatedResponse(res));
		
		return new APIResponse(res);
	}
		
	/**
	 * This method is to perform POST with a json request body with the
	 * specified uri. Input JsonRequest will be treated as request body
	 * 
	 * @param payload:
	 *            Request
	 * @param uri:
	 *            String
	 * @param params:
	 *            BaseRestParameter
	 * @throws KronosCoreAPIException
	 *             : kronos core API exception
	 * @return apiResponse: APIResponse
	 */
	public APIResponse patch(String uri,BaseRestParameter params,Request payload) throws KronosCoreAPIException {
		Response res = RestOperationUtils.patch(
							generateURL(uri, params), 
							payload == null ? null : payload.getRequest().toString(), 
							generateCommonReqSpec(params),
							params
						);
		
		reporter.reportStepWithAPITracking(Actions.POST, uri,params.toString(),
				CallingClassHelper.INSTANCE.getCallingAPIClass().getName(),
				reporter.generateFormatedResponse(res));
		
		return new APIResponse(res);
	}
	
	/**
	 * This method is to perform PATCH with a json request body with the
	 * specified uri. Input JsonRequest will be treated as request body, specification will be 
	 * rest assured RequestSpecification object in case the provided method does not satisfy your need.
	 * 
	 * @param payload:
	 *            Request
	 * @param uri:
	 *            String
	 * @param params:
	 *            BaseRestParameter
	 * @param specification:           
	 *            RequestSpecification
	 * @throws KronosCoreAPIException
	 *             : kronos core API exception
	 * @return apiResponse: APIResponse
	 */
	public APIResponse patch(String uri,BaseRestParameter params,Request payload,RequestSpecification specification) throws KronosCoreAPIException {
		
		Response res = RestOperationUtils.patch(
							generateURL(uri, params), 
							payload == null ? null : payload.getRequest().toString(), 
							generateMinimalReqSpec(params).spec(specification),
							params
						);
		
		reporter.reportStepWithAPITracking(Actions.POST, uri,params.toString(),
				CallingClassHelper.INSTANCE.getCallingAPIClass().getName(),
				reporter.generateFormatedResponse(res));
		
		return new APIResponse(res);
	}
}
