package com.kronos.api.rest.base;

import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.stream.Collectors;

import org.apache.log4j.Logger;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;

import com.jayway.restassured.RestAssured;
import com.kronos.api.rest.assertions.APIAssertions;
import com.kronos.api.rest.auth.APIConstants;
import com.kronos.api.rest.auth.FalconAuthenticator;
import com.kronos.api.rest.driver.APIDriver;
import com.kronos.api.rest.exception.KronosCoreAPIException;
import com.kronos.api.rest.json.JsonBuildHelper;
import com.kronos.exception.KronosCoreCommonException;
import com.kronos.logging.KronosLogger;
import com.kronos.testng.BaseTest;
import com.kronos.utils.common.ContextConstant;

public class BaseAPITest extends BaseTest{
	protected final static Logger logger = Logger.getLogger(BaseAPITest.class);					
	protected APIDriver apiDriver;	
	
	//API Object Implementation
	protected APIAssertions assertion;	
	
	/**
	 * Before suite, initialization
	 * 
	 * @param context: ITestContext
	 * @throws KronosCoreCommonException
	 * 		: customized kronos core common exception
	 */
	@BeforeSuite(alwaysRun = true)
	public void beforeSuiteAPI(ITestContext context) throws KronosCoreCommonException {
		KronosLogger.traceEnter();
		try {
			String strSysInfo = "";
			
			strSysInfo = configurator.getParameter(ContextConstant.BACKEND_SERVER);
			logger.info("BACKEND_SERVER:" + strSysInfo);
			reporter.addSystemInfo("Backend Server", strSysInfo == null?"":strSysInfo);
			
			strSysInfo = configurator.getParameter(ContextConstant.OPEN_AM_SERVER);
			logger.info("OPEN_AM_SERVER:" + strSysInfo);
			reporter.addSystemInfo("OpenAM Server", strSysInfo == null?"":strSysInfo);
			
			strSysInfo = configurator.getParameter(ContextConstant.TENANT);
			logger.info("TENANT:" + strSysInfo);
			reporter.addSystemInfo("Tenant", strSysInfo == null?"":strSysInfo);

		} catch (Exception e) {
			String errorMsg = "execution before suite fail!";
			logger.error(errorMsg, e);
			throw new KronosCoreCommonException(errorMsg,e);
		}
		KronosLogger.traceLeave();
	}
	
	/**
	 * Initialize variables before method test
	 * 
	 * @param context
	 *            ITestContext
	 * @param testResult
	 *            Describes the result of a test
	 * @throws KronosCoreCommonException
	 *             throws a KronosCoreCommonException
	 */
	@BeforeMethod(alwaysRun = true)
	public void beforeMethodAPI(ITestContext context, ITestResult testResult) throws KronosCoreAPIException {
		KronosLogger.traceEnter();
		
		try {
			//set REST Assured Static value
			RestAssured.useRelaxedHTTPSValidation();
			RestAssured.urlEncodingEnabled=true;
			//instantiate driver
			apiDriver = new APIDriver(new FalconAuthenticator(executionContext) );

			//set date parser for jsonBuilder
			JsonBuildHelper.setDateFormat(context.getCurrentXmlTest().getAllParameters());
			
			//instantiate assertion
			//set the assertion that will be used by listener
			assertion = new APIAssertions();
			testResult.setAttribute("assertion", assertion);
			
			//Set appKey if tests to be done via API Gateway Server
			if(!configurator.getParameter(ContextConstant.APIGATEWAY_SERVER).isEmpty())
			{
				String strSysInfo = "";
				strSysInfo = configurator.getParameter(ContextConstant.APIGATEWAY_SERVER);
				logger.info("APIGATEWAY_SERVER:" + strSysInfo);
				reporter.addSystemInfo("APIGateway Server", strSysInfo == null?"":strSysInfo);
				
				strSysInfo = APIConstants.INTERNAL_APPKEY_PREFIX + configurator.getParameter(ContextConstant.TENANT) + APIConstants.INTERNAL_APPKEY_SUFFIX;
				apiDriver.setInternalAppKey(strSysInfo);
				logger.info("INTERNAL APP KEY:" + strSysInfo);
				
				strSysInfo = configurator.getParameter(ContextConstant.EXTERNAL_APPKEY);
				apiDriver.setExternalAppkey(strSysInfo);
				
				logger.info("EXTERNAL APP KEY:" + strSysInfo);
			}
			
		} catch (Exception e) {
			String erroMsg = "[Before Method] : Failure";
			logger.error(erroMsg, e);
			throw new KronosCoreAPIException(erroMsg, e);
		}
		KronosLogger.traceLeave();
	}
	
	@AfterMethod(alwaysRun = true)
	public void afterMethodAPI(Method m, ITestResult result) throws KronosCoreAPIException {
		KronosLogger.traceEnter();
		if (!result.isSuccess()) {
			if (result.getThrowable() != null){
				result.getThrowable().printStackTrace();
				logger.error(result.getThrowable().toString() 
						+ "\n" 
						+ Arrays.asList(result.getThrowable().getStackTrace()).stream().map(x->x.toString()).collect(Collectors.joining("\n")));
			}
		}
		KronosLogger.traceLeave();
	}
}
