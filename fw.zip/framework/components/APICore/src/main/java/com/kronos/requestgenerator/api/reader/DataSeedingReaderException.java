package com.kronos.requestgenerator.api.reader;

/**
 * Exception class for DataSeeding Reader
 * @author Animesh.Sonkar
 *
 */
public class DataSeedingReaderException extends Exception {

	private static final long serialVersionUID = 1L;
	
	public DataSeedingReaderException() {

	}


	public DataSeedingReaderException(String msg, Throwable throwable) {
		super(msg, throwable);
	}
	public DataSeedingReaderException(String msg) {
		super(msg);
	}

}
