package com.kronos.requestgenerator.reader.csv;

import org.apache.commons.lang.StringUtils;

import com.kronos.requestgenerator.reader.csv.CSVRowListProcessor;
import com.kronos.requestgenerator.reader.csv.CSVRowProcessor;
import com.kronos.requestgenerator.reader.csv.CSVSelectedRowProcessor;
import com.kronos.requestgenerator.reader.csv.RowProcessorSelection;

public class CSVRowProcessorFactory {
	
	public CSVRowProcessor getRowProcessor(RowProcessorSelection rowToRead)
	{
		if (rowToRead.equals(RowProcessorSelection.SELECTED))
			return new CSVSelectedRowProcessor();
		else if(rowToRead.equals(RowProcessorSelection.ALL))
			return new CSVRowListProcessor();
		else
			return null;
	}


}
