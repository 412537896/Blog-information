package com.kronos.requestgenerator.api.transformer;

import java.util.Map;

import com.fasterxml.jackson.databind.JsonNode;
import com.kronos.requestgenerator.api.transformer.DataSeedingTransformerException;

/**
 * Interface for transforming data from a format to required map of json string.
 * 
 * @author Animesh.Sonkar
 *
 */
public interface DataSeedingTransformer {

	/**
	 * This method transforms the data to a json string
	 * @param schema: Json Schema file
	 *	@param csvFile:  parent CSV file to read
	 * @param row: Key of row to be read
	 * @return JsonNode
	 * @throws DataSeedingTransformerException Data Seeding transformer exception
	 */
	public JsonNode transform(String schema,String csvFile,String row) throws DataSeedingTransformerException;

}
