package com.kronos.api.rest.json;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.kronos.api.rest.exception.KronosCoreAPIException;

public abstract class BasePayloadGenerator {
	
	@SuppressWarnings("unchecked")
	protected static Map<String, Object> removeUnusedKey(Map<String, Object> map) throws KronosCoreAPIException {
		Map<String, Object> newMap = new LinkedHashMap<String, Object>();
		for (String key : map.keySet()) {
			if (map.get(key) instanceof Map) {
				Map<String, Object> temp = removeUnusedKey((Map<String, Object>) map.get(key));
				if (temp != null) {
					newMap.put(key, temp);
				}
			} else if (map.get(key) instanceof List) {
				if (((List<?>)map.get(key)).size() == 0)
				{
					continue;
				}
				if (((List<?>) map.get(key)).get(0) instanceof Map) {
					List<Map<String, Object>> tempList = traverseList(map, key);
					if (!tempList.isEmpty())
						newMap.put(key, tempList);
				} else 
					newMap.put(key, map.get(key));
			} else {
				if (map.get(key) == null || map.get(key).toString().isEmpty()) {
					continue;
				}
				newMap.put(key, getProperValue(map.get(key)));
			}
		}
		return newMap.size() == 0 ? null : newMap;
	}
	private static Object getProperValue(Object value){
		if("\"<null>\"".equalsIgnoreCase(value.toString())){
			return null;
		}else if("\"<blank>\"".equalsIgnoreCase(value.toString())){
			return "";	
		}else{
			return value;
		}
	}
	
	@SuppressWarnings("unchecked")
	private static List<Map<String, Object>> traverseList(Map<String, Object> map, String key)
			throws KronosCoreAPIException {
		List<Map<String, Object>> tempList = new ArrayList<Map<String, Object>>();
		for (Object o : (List<?>) map.get(key)) {
			Map<String, Object> temp = removeUnusedKey((Map<String, Object>) o);
			if (temp != null) {
				tempList.add(temp);
			}
		}
		return tempList;
	}
	
	protected static boolean toBoolean(Object value){
		return Boolean.parseBoolean((String) value);
	}
	
	protected static int toInteger(Object value){
		return Integer.parseInt((String) value);
	}
	
	protected static float toFloat(Object value){
		return Float.parseFloat((String) value);
	}
	
	protected static Map<String,Object> mergeMap(Map<String,Object> from, Map<String,Object> to){
		from.putAll(to);
		return from;
	}
}
