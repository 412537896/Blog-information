package com.kronos.api.rest.auth;

import com.kronos.api.rest.exception.KronosCoreAPIException;
import com.kronos.context.ExecutionContext;

public interface IAuthentication {
	
	public String login(String username, String password) throws KronosCoreAPIException;
	default String loginUsingSystemUser(String username, String password) throws KronosCoreAPIException
	{
		return "";
	}
	public String logout() throws KronosCoreAPIException;
	public String logout(String cookie) throws KronosCoreAPIException;
	public void setContext(ExecutionContext context);
	public ExecutionContext getContext();
	public String loginAtFrontEnd(String username, String password) throws KronosCoreAPIException;
	default String getAccessTokenFromOpenAM(String username, String password) throws KronosCoreAPIException
	{
		return "";
	}
}
