package com.kronos.api.rest.json;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.kronos.api.rest.exception.KronosCoreAPIException;
import com.kronos.exception.KronosCoreCommonException;
import com.kronos.facade.DateParser;

public class JsonBuildHelper {

	private static final String ID = "id";
	private static final String QUALIFIER = "qualifier";
	private static final String PROPERTIES = "properties";
	private static final String QUOTE = "\"";
	private static DateParser dateParser = new DateParser();
	private static final Pattern IS_DATE_PATTERN=Pattern.compile("(\\{{3})(.*)(\\}{3})");
	
	private JsonBuildHelper(){
		
	}
	/**
	 * 
	 * Set the date format for the date parser to work
	 * @param map :Map
	 */
	public static synchronized void setDateFormat(Map<String, String> map){
		dateParser = new DateParser(map);
	}
	
	/**
	 * @param startIndex:int
	 * @param endIndex:int
	 * @param map:Map
	 * @return rs:List of Map
	 */
	public static List<Map<String,Object>> mapInRange(int startIndex, int endIndex, Map<String,Object> map){
		List<Map<String,Object>> rs = new ArrayList<Map<String,Object>>();
		for(int i = startIndex; i <= endIndex;i++){
			rs.add(substitute(i,map));
		}
		return rs;
	}
	
	
	@SuppressWarnings("unchecked")
	private static Map<String,Object> substitute(int index,Map<String,Object> map){
		Map<String, Object> temp = new HashMap<String,Object>();
		for(Entry<String, Object> entry:map.entrySet()){
			if(map.get(entry.getKey()) instanceof String){
				temp.put(entry.getKey(),((String)entry.getValue()).replace("[index]", Integer.toString(index)));
			}else if (map.get(entry.getKey()) instanceof Map){
				temp.put(entry.getKey(), substitute(index,(Map<String,Object>)entry.getValue()));
			}else if (map.get(entry.getKey()) instanceof List){
				if (((List<?>)map.get(entry.getKey())).get(0) instanceof Map){
					List<Map<String,Object>> tempList = new ArrayList<Map<String,Object>>();
					for(Object o : (List<?>)map.get(entry.getKey())){
						tempList.add(substitute(index,(Map<String,Object>)o));	
					}
					temp.put(entry.getKey(), tempList);	
				}else{
					temp.put(entry.getKey(), entry.getValue());	
				}
			}else{
				temp.put(entry.getKey(), entry.getValue());
			}
		}
		return temp;
	}
	
	
	@SafeVarargs
	public static <T> Map<String,Object> map(T... objects) throws KronosCoreAPIException{
		if(objects.length % 2 != 0){
			throw new KronosCoreAPIException("You cannot give odd number of element");
		}else if( objects.length==0 ){
			throw new KronosCoreAPIException("You need to prepare at least two argument");
		}
				
		Map<String, Object> m = new LinkedHashMap<String, Object>();
		for(int i=0; i < objects.length; i+=2){
			if (objects[i] instanceof String)
				m.put((String) objects[i], objects[i+1]);
			else
				throw new KronosCoreAPIException("Key " + objects[i] + " must be string"); 
		}
		return m;
	}
	
	@SafeVarargs
	public static <T> Map<String,Object> mapWithSameValue(T... objects) throws KronosCoreAPIException{
		if( objects.length==0 ){
			throw new KronosCoreAPIException("You need to prepare at least two argument");
		}
		T value = objects[objects.length-1];
		Map<String, Object> m = new LinkedHashMap<String, Object>();
		for(int i=0; i < objects.length-1; i++){
			if (objects[i] instanceof String)
				m.put((String) objects[i], value);
			else
				throw new KronosCoreAPIException("Key " + objects[i] + " must be string"); 
		}
		return m;
	}
	
	@SafeVarargs
	public static List<Object> list(Object... objects) throws KronosCoreAPIException{
		return Arrays.asList(objects);
	}
	
	@SafeVarargs
	public static List<Object> list(Request... objects) throws KronosCoreAPIException{
		List<Object> result = new ArrayList<Object>();
		for(Request r : objects){
			result.add(r.getRequest().toString());
		}
		return result;
	}

	@SafeVarargs
	public static <T> Map<String,Object> objRef(T... objects) throws KronosCoreAPIException {
		if( objects.length == 0 || objects.length > 2){
			throw new KronosCoreAPIException("You need to give either 1 or 2 arguments");
		}
		
		if(objects.length == 1){
			return map(objects[0] instanceof String ? QUALIFIER : ID, objects[0]);
		}else{
			if(objects[1] instanceof String){
				return map(ID,objects[0],QUALIFIER,objects[1]);	
			}else{
				return map(ID,objects[1],QUALIFIER,objects[0]);
			}
		}		
	}

	public static Request build(Map<String, Object> dataMap) throws KronosCoreAPIException {
		try {
			return new Request(toJson(dataMap));
		} catch (Exception e) {
			throw new KronosCoreAPIException(e.getMessage(),e);
		}
	}
	
	@SuppressWarnings("unchecked")
	public static Request build(List<Object> dataList) throws KronosCoreAPIException {
		try {
			List<String> results= new ArrayList<String>();
			for(Object data : dataList){
				if(data instanceof Map){
					results.add(toJson((Map<String, Object>)data));
				}else{
					results.add( genernateValueNode(data) );
				}
			}
			return new Request( results.stream().collect(Collectors.joining("," , "[", "]")) );
		} catch (Exception e) {
			throw new KronosCoreAPIException(e.getMessage(),e);
		}
	}
	
	@SuppressWarnings("unchecked")
	private static String toJson(Map<String, Object> dataMap) throws KronosCoreCommonException {
		List<String> resultList = new ArrayList<String>();

		for(Entry<String, Object> entry:dataMap.entrySet()){
			Object value = entry.getValue();
			if(value instanceof List || value instanceof Object[]){
				List<String> temp = new ArrayList<String>();
				for(Object o : value instanceof Object[] ? Arrays.asList(value) : (List<?>)value){
					if(o instanceof Map){
						temp.add( toJson( (Map<String, Object>) o) );
					}else{
						temp.add( genernateValueNode(o) );
					}
				}
				resultList.add(QUOTE + entry.getKey() + QUOTE + " : " + temp.stream().collect(Collectors.joining("," , "[", "]")));
			}else if (value instanceof Map){
				if(((Map<String, Object>) value).isEmpty()){
					resultList.add(QUOTE + entry.getKey() + QUOTE + " : {}");
				}else{
					resultList.add(QUOTE + entry.getKey() + QUOTE + " : " + toJson( (Map<String, Object>) value ));
				}			
			}else{
				resultList.add(genernateValueNode(entry.getKey(), value));
			}
		}
		return resultList.isEmpty() ? "" : resultList.stream().collect(Collectors.joining("," , "{" ,"}"));
	}
	
	public static Request build(String schemaName, Map<String, Object> dataMap) throws KronosCoreAPIException {
		try {
			JSONObject root = getRootNode(schemaName);
			return new Request(toJson((JSONObject) root, dataMap));
		} catch (Exception e) {
			throw new KronosCoreAPIException(e.getMessage(),e);
		}
	}
	
	private static JSONObject getRootNode(String schemaName) throws IOException, ParseException{
		JSONObject jsonSchema;
		InputStream in = JsonBuildHelper.class.getClassLoader().getResourceAsStream(schemaName);
		Object obj =  new JSONParser().parse(new InputStreamReader(in, "UTF-8"));
		jsonSchema = (JSONObject) obj;
		return (JSONObject) ((JSONObject) jsonSchema.get(jsonSchema.keySet().iterator()
				.next().toString())).get(PROPERTIES);
	}
	
	@SuppressWarnings("unchecked")
	private static String toJson(JSONObject schema, Map<String, Object> dataMap) throws KronosCoreCommonException {
		List<String> resultList = new ArrayList<String>();
		for(Entry<String, Object> entry:dataMap.entrySet()){
			JSONObject typeObj = (JSONObject) schema.get(entry.getKey());
			if(typeObj != null){
				String type = (String) typeObj.get("type");
				if("array".equalsIgnoreCase(type)){
					JSONObject nextNode = (JSONObject) ((JSONObject) typeObj.get("items")).get(PROPERTIES);

					Object value = dataMap.get(entry.getKey());
					if(value instanceof List || value instanceof Object[]){
						resultList.add(QUOTE + entry.getKey() + QUOTE + " : " + processList(nextNode, value).stream().collect(Collectors.joining("," , "[", "]")));
					}else{
						throw new KronosCoreCommonException("Expecting value of key "+ entry.getKey() + " to be a list or array; but got "+ value.getClass());
					}
				}else if ("object".equalsIgnoreCase(type)) {
					JSONObject nextNode = (JSONObject) typeObj.get(PROPERTIES);
					resultList.add(QUOTE + entry.getKey() + QUOTE + " : " + toJson(nextNode, (Map<String, Object>)entry.getValue() ));
				}else{
					resultList.add(genernateValueNode(entry.getKey(), entry.getValue(), type));
				}
			}
		}
		return resultList.isEmpty() ? "" : resultList.stream().collect(Collectors.joining("," , "{" ,"}"));
	}
	
	@SuppressWarnings("unchecked")
	private static List<String> processList(JSONObject nextNode, Object value) throws KronosCoreCommonException {
		List<String> temp = new ArrayList<String>();
		for(Object o : value instanceof Object[] ? Arrays.asList(value) : (List<?>)value){
			temp.add( toJson(nextNode, (Map<String, Object>) o) );
		}
		return temp;
	}
	
	private static String genernateValueNode(Object value) throws KronosCoreCommonException{
		String rs = null;
		if (value instanceof String){
			if(IS_DATE_PATTERN.matcher((String)value).find()){
				rs = QUOTE + generateDate((String)value) + QUOTE;
			}else{
				//just in case the string is already another payload from another request
				if(((String) value).trim().startsWith("{") && ((String) value).trim().endsWith("}"))
					rs = (String) value;
				else{
					if(!((String) value).isEmpty())
						rs = QUOTE + value + QUOTE;
					else
						rs = (String) value;
				}
			}
		}else{
			if(value != null){
				rs = value.toString();
			}
		}
		return rs;
	}

	private static String genernateValueNode(String key, Object value) throws KronosCoreCommonException{
		if (value instanceof String){
			if(IS_DATE_PATTERN.matcher((String)value).find()){
				return QUOTE + key + QUOTE + " : " +  QUOTE + generateDate((String)value) + QUOTE;
			}else{
				return QUOTE + key + QUOTE + " : " +  QUOTE + value + QUOTE;
			}
		}else{
			return QUOTE + key + QUOTE + " : " + value;
		}
	}
	
	private static String genernateValueNode(String key, Object value,String type) throws KronosCoreCommonException{
		if (value instanceof String){
			if(IS_DATE_PATTERN.matcher((String)value).find()){
				return QUOTE + key + QUOTE + " : " +  QUOTE + generateDate((String)value) + QUOTE;
			}else{
				if("boolean".equalsIgnoreCase(type)){
					if("true".equalsIgnoreCase((String) value) || "false".equalsIgnoreCase((String) value)){
						return QUOTE + key + QUOTE + " : " + Boolean.parseBoolean((String)value);
					}
					return QUOTE + key + QUOTE + " : " + value ;  
				}
				return QUOTE + key + QUOTE + " : " +  QUOTE + value + QUOTE;
			}
		}
		
		return QUOTE + key + QUOTE + " : " + value;
	}
	
	private static String generateDate(String value) throws KronosCoreCommonException {
		Matcher m = IS_DATE_PATTERN.matcher(value);
		m.find();
		String innerExp = m.group(2).replaceAll(" ", "");
		return value.replace("{{{" + innerExp + "}}}" , dateParser.parseDatePattern(innerExp));

	} 
}
