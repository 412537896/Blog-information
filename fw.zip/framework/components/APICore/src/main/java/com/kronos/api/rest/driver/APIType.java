package com.kronos.api.rest.driver;

public enum APIType {
PUBLIC,
PRIVATE
}
