package com.kronos.requestgenerator;

import org.apache.log4j.Logger;

import com.fasterxml.jackson.databind.JsonNode;

import com.kronos.requestgenerator.RequestGeneratorException;
import com.kronos.requestgenerator.api.transformer.DataSeedingTransformer;
import com.kronos.requestgenerator.api.transformer.DataSeedingTransformerException;
import com.kronos.requestgenerator.transformer.csv.CSVDataSeedingTransformer;

/**
 * This class is the driving class for the data seeding tool.
 * 
 * @author Animesh.Sonkar
 *
 */
public class RequestGenerator {

	public static final Logger log = Logger.getLogger(RequestGenerator.class);
	public RequestGenerator() {

	}



	/**
	 * This method transforms the csv to json
	 * 
	 * @param jsonSchema : Json Schema file
	 *           
	 * @param csvFile : CSV File
	 *   
	 * @param rowToRead : Row key        
	 * @return JsonNode
	 * @throws RequestGeneratorException Exception
	 */
	public JsonNode transformCSVData(String jsonSchema, String csvFile, String rowToRead)
			throws RequestGeneratorException {
		DataSeedingTransformer transformer = new CSVDataSeedingTransformer();
		JsonNode configJson = null;
		try {
			configJson = transformer.transform(jsonSchema,csvFile,rowToRead);
		} catch (DataSeedingTransformerException e) {
			log.error("Error transforming csv data to json", e);
			throw new RequestGeneratorException(e);
		} 
		return configJson;
	}
}
