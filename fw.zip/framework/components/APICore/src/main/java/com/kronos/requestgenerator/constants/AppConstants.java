package com.kronos.requestgenerator.constants;


/**
 * Class to hold the constants of application.
 * 
 * @author Neha.Garg
 *
 */
public class AppConstants {
	
	

	// Json Converter utility constants
	public static final String DIRECTORY_NAME = "DataSeeding";
	public static final String RESPONSE_FILE_NAME = "Response.json";
	public static final String FILE_SEPARATOR = "/";
	public static final String META_CONFIG_FILE = "ExportConfig.json";
	public static final String ENCODING = "UTF-8";
	public static final String OBJECT_TAG = "@Object";
	public static final String DISPLAY_TEXT_TAG = "displayText";
	public static final String NAME_TAG = "name";
	public static final String UNIQUE_KEY = "uniqueKey";
	public static final String TITLE = "title";
	public static final String KEY = "key";
	public static final String URL_PARAMS = "urlparams";
	public static final String STATUS_TAG = "@Status";
	public static final String ACTION_TAG = "@Action";
	public static final String NAME = "@Name";
	public static final String ITEM_RETRIEVE_RESPONSES = "itemsRetrieveResponses";
	public static final String ITEM_DATA_INFO = "itemDataInfo";
	public static final String RESPONSE_OBJECT_NODE = "responseObjectNode";
	public static final String RETRIEVE_MAPPING_CONFIG_NAME = "retrieveMapping";
	public static final String SUCCESS = "Success";
	public static final String RETRIEVE_FOR_UPDATE = "RetrieveForUpdate";
	public static final String APP_CONFIG_NAME = "appConfig";
	public static final String EXPORT_CONFIG_NAME = "exportConfig";
	public static final int MAXCSVLENGTH = 100;
	
	private AppConstants(){
		
	}

}
