package com.kronos.api.rest.auth;


public class APIConstants {
	public static final String USERNAME_HEADER="X-OpenAM-Username";
	public static final String PASSWORD_HEADER="X-OpenAM-Password";
	public static final String REST_API_HEADER="x-rest-api";
	public static final String AUTH_INDEX_TYPE="authIndexType";
	public static final String AUTH_INDEX_VALUE="authIndexValue";
	
	public static final String TOKEN_ID="tokenId";
	//public static final String IPLANETDIRECTORYPRO="iPlanetDirectoryPro=";
	public static final String DEFAULT_COOKIE_NAME="authn_ssid=";
	//XML Service related constants
	
	public static final String LEGACY_BASE_PATH="wfc/XmlService";
	public static final String NODE_LOGON = "<Request Object='System' Action='Logon' Username='CHANGE_USER' Password='CHANGE_PWD'/>";
	public static final String NODE_LOGOFF = "<Request Object='System' Action='Logoff'/>";
	public static final String XML_REQUEST_HEADER = "<?xml version='1.0'?><Kronos_WFC version='1.0'>";
	public static final String XML_REQUEST_FOOTER = "</Kronos_WFC>";
	
	
	public static final String INTERNAL_APPKEY_PREFIX="internal_";
	public static final String INTERNAL_APPKEY_SUFFIX="_sdm";
	
	
	private APIConstants(){
	}
}
