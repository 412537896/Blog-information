package com.kronos.api.rest.auth;

import static com.jayway.restassured.RestAssured.given;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.path.json.JsonPath;
import com.jayway.restassured.response.Header;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;
import com.kronos.api.rest.exception.KronosCoreAPIException;
import com.kronos.api.rest.operations.APIResponse;
import com.kronos.api.rest.operations.RestOperationUtils;
import com.kronos.context.ExecutionContext;
import com.kronos.report.Reporter;
import com.kronos.report.StepStatus;

public class FalconAuthenticator implements IAuthentication{
	public static enum loginAt {
		OPENAM, FRONTEND
		};
	protected static final Reporter reporter = Reporter.getInstance();
	protected static final Logger logger = Logger.getLogger(FalconAuthenticator.class);
	public static final String AUTHENTICATE="authenticate";
	public static final String URL_SEPARATOR="/";
	
	public static final String OPENAM_JSON_SUFFIX="authn/json/";
	public static final String OPENAM_ACCESS_TOKEN_SUFFIX="authn/oauth2/";
	public static final String ACCESS_TOKEN="access_token";
    //Required for Node Authentication
    private static final String NODE_XSFR_HEADER="XSRF-TOKEN";

	public static final String QUERY_PARAMS_SYSTEMUSER = "?authIndexType=service&authIndexValue=SystemUserAuthService";

	private static final String ACTUAL_DECO = "<span style=\"font-weight: bold;\"> A : </span>";
	private static final String EXPECT_DECO = "<span style=\"font-weight: bold;\"> E : </span>";
	private static final String BREAK_LINE = "</br>";
	
	private ExecutionContext context;

	public FalconAuthenticator(ExecutionContext context){
		this.context = context == null ? new ExecutionContext() : context;
	}
	
	/**
	 * Login at openAM
	 * @param username: String
	 * @param password : String
	 * @return cookie in String
	 * @throws KronosCoreAPIException 
	 */
	@Override
	public String login(String username, String password) throws KronosCoreAPIException {
		Response res=null;
		String uri;

		if(context.getTenant().isEmpty()){
			uri=context.getOpenAmServer()+OPENAM_JSON_SUFFIX + AUTHENTICATE;
		}else{
			uri=context.getOpenAmServer()+OPENAM_JSON_SUFFIX + context.getTenant() + "/" + AUTHENTICATE;
		}
		
		String infoMessage="Going to Login at openAM with <br> Username :"+ username+ "<br> Password : "+password+"<br> Login endpoint as : "+ uri ;
		Map<String, String> headerParameters = new HashMap<String, String>();
		headerParameters.put(APIConstants.USERNAME_HEADER, username);
		headerParameters.put(APIConstants.PASSWORD_HEADER, password);
			    
		logger.info(infoMessage);
		reporter.reportStep(StepStatus.INFO, infoMessage);
		
		RequestSpecification spec = given().headers(headerParameters).accept(ContentType.JSON).contentType(ContentType.JSON);
		
		//try to login for the maximum of 3 times
		int statusCode;
		for(int i=0; i<3; i++) {
			try {
				res=RestOperationUtils.post(uri, null,spec,null);
				statusCode = res.getStatusCode();
				if(statusCode == 200 || statusCode == 401) {
					break;
				}
			}
			catch (KronosCoreAPIException error) {
				reporter.reportStep(StepStatus.INFO, "caught an exception while trying to login: " + error.getMessage());
				if(i<2) {
					reporter.reportStep(StepStatus.INFO, "retry to login again after 20 seconds");
					try {
						Thread.sleep(20000);
					} catch (InterruptedException e) {
						e.printStackTrace();
						logger.info("caught an exception while pausing for 20 seconds: " + e.getMessage());
					}
				}
				else { //throw an exception for the last try
					throw new KronosCoreAPIException("failed to login after 3 tries", error);
				}
			}
		}
		
		infoMessage = "Authentication Response: <br>" + reporter.generateFormatedResponse(res);
		logger.info(infoMessage);
		reporter.reportStep(StepStatus.INFO,infoMessage);
		validateOpenAMLogin(res);
		return generateCookie(res, loginAt.OPENAM);
	}
	
	
	/**
	 * Get access token from openAM
	 * @param username: String
	 * @param password : String
	 * @return access token in String
	 * @throws KronosCoreAPIException 
	 */
	@Override
	public String getAccessTokenFromOpenAM(String username, String password) throws KronosCoreAPIException {
		Response res=null;
		String uri;
		String access_token = null;
		String clientId = context.getoAuth_clientId();
		String clientSecret = context.getoAuth_clientSecret();
		
		if(context.getTenant().isEmpty()){
			uri=context.getOpenAmServer()+OPENAM_ACCESS_TOKEN_SUFFIX + ACCESS_TOKEN;
		}else{
			uri=context.getOpenAmServer()+OPENAM_ACCESS_TOKEN_SUFFIX + context.getTenant() + "/" + ACCESS_TOKEN;
		}
		
		//uri = uri+ "?grant_type=password&username="+username+"&password=" + password+"&client_id=kronos&client_secret=kronites&auth_chain=OAuthLdapService";
		uri = uri+ "?grant_type=password&username="+username+"&password=" + password+"&client_id="  + clientId + "&client_secret=" + clientSecret + "&auth_chain=OAuthLdapService";	
			    
		String infoMessage="Going to get Access Token from openAM with <br> Username :"+ username+ "<br> Password : "+password;
		
		logger.info(infoMessage);
		reporter.reportStep(StepStatus.INFO, infoMessage);
		
		RequestSpecification spec = given().contentType(ContentType.URLENC).accept(ContentType.JSON);
		res=RestOperationUtils.post(uri, null,spec,null);
		
		infoMessage = "Get access token Response: <br>" + reporter.generateFormatedResponse(res);
		logger.info(infoMessage);
		reporter.reportStep(StepStatus.INFO,infoMessage);
		validateAccessToken(res);
		
		access_token = JsonPath.with(res.asString()).get(ACCESS_TOKEN).toString();
		
		return access_token;
	}
	
	/**
	 * Validates the response from openAM for access token. It first validates status code for 200 and then if passed checks for the presence of access_token in the response.
	 * In case of failure throws KronosCoreAPIException so that test case execution halts if user is not catching this exception in test method.
	 * @param res: Response
	 * @throws KronosCoreAPIException 
	 */
	private void validateAccessToken(Response res) throws KronosCoreAPIException
	{		
		APIResponse accessTokenResponse = new APIResponse(res);
		
		String message = "Validating OpenAM access_token response code:"
				+ BREAK_LINE + ACTUAL_DECO + accessTokenResponse.getStatusCode()
				+ BREAK_LINE + EXPECT_DECO + "200";
		
		if ( accessTokenResponse.getStatusCode() != 200){	
			reporter.reportStep(StepStatus.FAIL ,message);
			throw new KronosCoreAPIException("Login failed");
		}
		else
		{
			message = "Validating openAM access_token response : " + BREAK_LINE + "'access_token' is present in response:"
					+ BREAK_LINE + ACTUAL_DECO + accessTokenResponse.isNodePresent("access_token")
					+ BREAK_LINE + EXPECT_DECO + "true";
			
			if ( (accessTokenResponse.isNodePresent("access_token")) == true){	
				reporter.reportStep(StepStatus.PASS ,message);
			}
			else{
				reporter.reportStep(StepStatus.FAIL ,message);
				throw new KronosCoreAPIException("Get access_Token from openAM failed");
			}	
		}
	}
	
	
	/**
	 * Login at openAM
	 * @param username: String
	 * @param password : String
	 * @return cookie in String
	 * @throws KronosCoreAPIException 
	 */
	@Override
	public String loginUsingSystemUser(String username, String password) throws KronosCoreAPIException {
		Response res=null;
		String uri;

		if(context.getTenant().isEmpty()){
			uri=context.getOpenAmServer()+OPENAM_JSON_SUFFIX + AUTHENTICATE+ QUERY_PARAMS_SYSTEMUSER ;
		}else{
			uri=context.getOpenAmServer()+OPENAM_JSON_SUFFIX + context.getTenant() + "/" + AUTHENTICATE+ QUERY_PARAMS_SYSTEMUSER;
		}
		
		String infoMessage="Going to Login at openAM with <br> Username :"+ username+ "<br> Password : "+password+"<br> Login endpoint as : "+ uri ;
		Map<String, String> headerParameters = new HashMap<String, String>();
		headerParameters.put(APIConstants.USERNAME_HEADER, username);
		headerParameters.put(APIConstants.PASSWORD_HEADER, password);
		headerParameters.put(APIConstants.REST_API_HEADER, "true");

		logger.info(infoMessage);
		reporter.reportStep(StepStatus.INFO, infoMessage);
		
		RequestSpecification spec = given().headers(headerParameters).accept(ContentType.JSON).contentType(ContentType.JSON);
		res=RestOperationUtils.post(uri, null,spec,null);
		
		infoMessage = "Authentication Response: <br>" + reporter.generateFormatedResponse(res);
		logger.info(infoMessage);
		reporter.reportStep(StepStatus.INFO,infoMessage);
		validateOpenAMLogin(res);
		
		return generateCookie(res, loginAt.OPENAM);
	}
	
	/**
	 * Validate Login at openAM. It first validates status code for 200 and then if passed, checks value of successUrl in response JSON.
	 * In case of failure throws KronosCoreAPIException so that test case execution halts if user is not catching this exception in test method.
	 * @param res: Response
	 * @throws KronosCoreAPIException 
	 */
	private void validateOpenAMLogin(Response res) throws KronosCoreAPIException
	{		
		APIResponse loginResponse = new APIResponse(res);
		
		String message = "Validating OpenAM Login response code:"
				+ BREAK_LINE + ACTUAL_DECO + loginResponse.getStatusCode()
				+ BREAK_LINE + EXPECT_DECO + "200";
		
		if ( loginResponse.getStatusCode() != 200){	
			reporter.reportStep(StepStatus.FAIL ,message);
			throw new KronosCoreAPIException("Login failed");
		}
		else
		{
			message = "Validating openAM Login response : " + BREAK_LINE + "'successUrl' is present in response:"
					+ BREAK_LINE + ACTUAL_DECO + loginResponse.isNodePresent("successUrl")
					+ BREAK_LINE + EXPECT_DECO + "true";
			
			if ( (loginResponse.isNodePresent("successUrl")) == true){	
				reporter.reportStep(StepStatus.PASS ,message);
			}
			else{
				reporter.reportStep(StepStatus.FAIL ,message);
				throw new KronosCoreAPIException("Login failed");
			}	
		}
	}

	/**
	 * Login at Front End
	 * @param username: String
	 * @param password : String
	 * @return cookie in String
	 * @throws KronosCoreAPIException 
	 */
	@Override
	public String loginAtFrontEnd(String username, String password) throws KronosCoreAPIException {
		String cookie = login(username, password);
		String csrfCookies = getCSRFCookies(cookie);
		String xsfrCookie = csrfCookies.split(";")[1].split("=")[1];
		cookie = cookie + ";" + csrfCookies;
		Response res=null;
		String uri;

		if(context.getTenant().isEmpty()){
			uri=context.getFrontEndServer();
		}else{
			uri=context.getFrontEndServer() + "wfc/portal" +  "?tenantId=" + context.getTenant();
		}
		
		String infoMessage="Going to login at FrontEnd : <br> Login Endpoint as : "+ uri ;
		Map<String, String> headerParameters = new HashMap<String, String>();
		headerParameters.put("Cookie", cookie);
		headerParameters.put(NODE_XSFR_HEADER, xsfrCookie);
			    
		logger.info(infoMessage);
		reporter.reportStep(StepStatus.INFO, infoMessage);
		
		RequestSpecification spec = given().headers(headerParameters).accept(ContentType.JSON).contentType(ContentType.JSON);
		res=RestOperationUtils.post(uri, null,spec,null);
		
		cookie = cookie + ";"  + generateCookie(res, loginAt.FRONTEND);
		
		infoMessage = "Authentication Response: <br>" + reporter.generateFormatedResponse(res);
		logger.info(infoMessage);
		reporter.reportStep(StepStatus.INFO,infoMessage);
		
		validateFrontEndlogin(res);
		
		return cookie;
	}

	private String getCSRFCookies(String openAMCookies) throws KronosCoreAPIException {
		Response res;
		String uri;
        String cookie;

		if(context.getTenant().isEmpty()){
			uri=context.getFrontEndServer();
		}else{
			uri=context.getFrontEndServer() + "ia" +  "?tenantId=" + context.getTenant();
		}

		String infoMessage="Getting CSRF cookies from FrontEnd : <br>  Endpoint as : "+ uri ;
		Map<String, String> headerParameters = new HashMap<String, String>();
		headerParameters.put("Cookie", openAMCookies);

		logger.info(infoMessage);
		reporter.reportStep(StepStatus.INFO, infoMessage);

		RequestSpecification spec = given().headers(headerParameters).accept(ContentType.TEXT).contentType(ContentType.TEXT);
		res=RestOperationUtils.get(uri,spec,null);

        cookie = generateCookie(res, loginAt.FRONTEND);

        String message = "Retrieving CSRF cookies.."
				+ BREAK_LINE + ACTUAL_DECO + res.getStatusCode()
				+ BREAK_LINE + EXPECT_DECO + "200";

        if ( res.getStatusCode() == 200){
            reporter.reportStep(StepStatus.PASS , message );
        }
        else
        {
            reporter.reportStep(StepStatus.FAIL ,message);
            throw new KronosCoreAPIException("Cannot retrieve CSRF  Cookies");
        }
        return cookie;
	}

	/**
	 * Validate Login at FrontEnd. It validates status code for 200. 
	 * In case of failure throws KronosCoreAPIException so that test case execution halts if user is not catching this exception in test method.
	 * @param res: Response
	 * @throws KronosCoreAPIException 
	 */
	private void validateFrontEndlogin(Response res) throws KronosCoreAPIException
	{		
		APIResponse loginResponse = new APIResponse(res);
		
		String message = "Validating FrontEnd Login response code:"
				+ BREAK_LINE + ACTUAL_DECO + loginResponse.getStatusCode()
				+ BREAK_LINE + EXPECT_DECO + "200";
		
		if ( loginResponse.getStatusCode() == 200){	
			reporter.reportStep(StepStatus.PASS ,message);
		}
		else
		{
			reporter.reportStep(StepStatus.FAIL ,message);
			throw new KronosCoreAPIException("Login failed");
		}
	}
	
	@Override
	public String logout() throws KronosCoreAPIException{
		return "";
	}
	
	@Override
	public void setContext(ExecutionContext context) {
		this.context = context;
	}
	
	@Override
	public ExecutionContext getContext() {
		return context;
	}
	

	/**
	 * Generate cookie via login response
	 * 
	 * @param response: Response
	 * @param appType : loginAt
	 * @return cookie in String
	 * @throws KronosCoreAPIException 
	 */
	private static String generateCookie(Response response,loginAt appType) throws KronosCoreAPIException {
		String cookie="";
		try{
			StringBuilder sb = new StringBuilder();
			for(Header h : response.getHeaders()){
				 if("Set-Cookie".equalsIgnoreCase(h.getName())){
					 sb.append(h.getValue().split("[;]")[0]).append(";");
				 }
			}
			cookie = sb.toString();
			if (appType.equals(loginAt.OPENAM))
				//cookie=cookie+APIConstants.IPLANETDIRECTORYPRO+JsonPath.with(response.asString()).get(APIConstants.TOKEN_ID);
				cookie=cookie+APIConstants.DEFAULT_COOKIE_NAME+JsonPath.with(response.asString()).get(APIConstants.TOKEN_ID);
		}catch(Exception e){
			logger.info("Exception occured while generating cookie .  Exception occured is due to : "+e.getMessage());
			reporter.reportStep(StepStatus.INFO, "Exception occured while generating cookie .  Exception occured is due to : "+e.getMessage());
			throw new KronosCoreAPIException(e);
		}
		return cookie;
	}
	
	
	@Override
	public String logout(String cookie) throws KronosCoreAPIException {
		return "";
	}
}
