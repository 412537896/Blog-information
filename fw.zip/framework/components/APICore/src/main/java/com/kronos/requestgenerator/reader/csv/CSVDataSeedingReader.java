package com.kronos.requestgenerator.reader.csv;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.file.Files;
import org.apache.log4j.Logger;

import com.kronos.requestgenerator.reader.csv.CSVDataSeedingReader;
import com.kronos.requestgenerator.reader.csv.CSVRowProcessor;
import com.kronos.requestgenerator.reader.csv.CSVRowProcessorFactory;
import com.kronos.requestgenerator.reader.csv.RowProcessorSelection;
import com.kronos.requestgenerator.api.reader.DataSeedingReader;
import com.kronos.requestgenerator.api.reader.DataSeedingReaderException;
import com.kronos.requestgenerator.api.reader.SeedingDataEntity;
import com.univocity.parsers.csv.CsvParser;
import com.univocity.parsers.csv.CsvParserSettings;

/**
 * This class reads the data from a csv file and populates it in the map using
 * univocity parser. It also finds out those indexes which are referred from a
 * parent csv, and puts them in a separate parentIndexmap.
 * 
 * @author Abhishek.Omar
 *
 */
public class CSVDataSeedingReader implements DataSeedingReader {

	public static final Logger log = Logger
			.getLogger(CSVDataSeedingReader.class);

	@Override
	public SeedingDataEntity readData(String csvFile)
			throws DataSeedingReaderException {

		try {
			return readObjectsFromCsv(csvFile);
		} catch (Exception e) {
			log.error("error occured while reading file: " + csvFile);
			throw new DataSeedingReaderException("Unable to parse the file", e);
		}

	}
	
	@Override
	public SeedingDataEntity readData(String csvFile, String row)
			throws DataSeedingReaderException {

		try {
			return readObjectsFromCsv(csvFile, row);
		} catch (Exception e) {
		//	log.error("error occured while reading file: {}", csvFile);
			throw new DataSeedingReaderException("unable to parse the file", e);
		}

	}

	private SeedingDataEntity readObjectsFromCsv(String file) throws IOException,DataSeedingReaderException {
		CSVRowProcessorFactory rowProFactory = new CSVRowProcessorFactory();
		CSVRowProcessor rowProcessor = rowProFactory.getRowProcessor(RowProcessorSelection.ALL);
		SeedingDataEntity seedingDataEntity = readObjectsFromCsvHelper(file,rowProcessor);
		return seedingDataEntity;
	}
	
	private SeedingDataEntity readObjectsFromCsv(String file, String row) throws IOException,DataSeedingReaderException {
		CSVRowProcessorFactory rowProFactory = new CSVRowProcessorFactory();
		CSVRowProcessor rowProcessor =  rowProFactory.getRowProcessor(RowProcessorSelection.SELECTED);
		rowProcessor.setRowNumber(row);
		SeedingDataEntity seedingDataEntity = readObjectsFromCsvHelper(file,rowProcessor);
		if (seedingDataEntity.getSeedingDataRecords().isEmpty())
			throw new DataSeedingReaderException("No record found in file " + file + " for key: "+ row);
		return seedingDataEntity;
	}
	
	
	private SeedingDataEntity readObjectsFromCsvHelper(String file, CSVRowProcessor rowProcessor) throws IOException {
		SeedingDataEntity seedingDataEntity = new SeedingDataEntity();
		CsvParserSettings parserSettings = new CsvParserSettings();
		parserSettings.getFormat().setLineSeparator("\n");
		parserSettings.setHeaderExtractionEnabled(true);

		//rowProcessor.setRowNumber(row);
		parserSettings.setRowProcessor(rowProcessor);
		CsvParser parser = new CsvParser(parserSettings);
		// This will kick in our column processor
		InputStream in = this.getClass().getClassLoader().getResourceAsStream(file);
		BufferedReader reader = null;
		try {
			//reader = Files.newBufferedReader(file.toPath());
			reader = new BufferedReader(new InputStreamReader(in));
			parser.parse(reader);
			// Finally, we can get the column values:
			seedingDataEntity.setSeedingDataRecords(rowProcessor.getRowValuesMapList());
			seedingDataEntity.setParentIndexMap(rowProcessor.getParentIndexMap());
			return seedingDataEntity;
		} finally {
			if (reader != null) {
				reader.close();
			}
		}
	}
	

}
