package com.kronos.requestgenerator.transformer.csv;

import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.databind.JsonNode;
import com.kronos.requestgenerator.transformer.csv.CSVDataSeedingTransformer;
import com.kronos.requestgenerator.transformer.csv.CSVDataSeedingTrnsSupport;
import com.kronos.requestgenerator.transformer.csv.EntityJSONProcessData;

public class CSVDataSeedingTrnsSupport {
	private static CSVDataSeedingTrnsSupport trnsSupport = null;
	
	
	public static CSVDataSeedingTrnsSupport getInstance() {
		if(trnsSupport == null)
			trnsSupport = new CSVDataSeedingTrnsSupport();
		return trnsSupport;
	}

	/**
	 * @param configJsonMap: config Json Map
	 * @param configNameList:configNameList
	 */
	public void printSummary(Map<String, Map<String, String>> configJsonMap, List<String> configNameList) {
		int totalRecords = configNameList != null ? configNameList.size() : 0;
		int totalSuccess = configJsonMap.size();
		int totalFail = totalRecords - totalSuccess;
		System.out.println(CSVDataSeedingTransformer.SUMMARY_OF_RUN + CSVDataSeedingTransformer.TOTAL_CONFIGURATION_ITEMS + totalRecords + "\n" 
				+ CSVDataSeedingTransformer.SUCCESSFUL_CONFIGURATION_ITEMS + totalSuccess + "\n" + CSVDataSeedingTransformer.FAILED_CONFIGURATION_ITEMS
				+ totalFail); 
	}
	/**
	 * Validates if a string is not null and not empty
	 * 
	 * @param value: String
	 * @return true is string is valid, else false.
	 */
	public boolean isValid(String value) {
		return value != null && !value.trim().isEmpty();
	}
	
	/**
	 * @param processData: EntityJSONProcessData
	 * @param entityName: entityName
	 * @param complextArrayParentNameMap: complextArrayParentNameMap
	 * @param duplicateEntityMap:duplicateEntityMap
	 */
	public void addToDuplicateEntityMap(EntityJSONProcessData processData, String entityName, Map<String, String> complextArrayParentNameMap,
			Map<String, String> duplicateEntityMap) {
		final String dupEntityNameFound = entityName;
		complextArrayParentNameMap.entrySet().forEach(entry -> {
			String csvName = entry.getKey();
			String duplicateEntityName = entry.getValue();
			if(duplicateEntityName.equals(dupEntityNameFound)) {
				duplicateEntityMap.put(csvName , duplicateEntityName);
			}
		});
		duplicateEntityMap.put(getXpathCSVNameFor(processData, entityName) , entityName);
		
	}
	public String getXpathCSVNameFor(EntityJSONProcessData processData, String entityName) {
		return processData.getParentName() + "-" +entityName;
	}
	/**
	 * @param entityName: Entity Name
	 * @param node: Json Node
	 * @param leafNodeTypes: Leaf Node Types
	 * @return String
	 */
	public String hasSingleSimpleLeaf(String entityName, JsonNode node, List<String> leafNodeTypes) {

		String itemChildType = node.get(CSVDataSeedingTransformer.JSON_SCHEMA_PROPERTY_TYPE) != null
				? node.get(CSVDataSeedingTransformer.JSON_SCHEMA_PROPERTY_TYPE).asText() : null;

		if (isLeafNodeType(itemChildType,leafNodeTypes)) {
			return entityName;
		} else if (CSVDataSeedingTransformer.JSON_SCHEMA_PROPERTY_OBJECT.equalsIgnoreCase(itemChildType)) {
			JsonNode propertiesNode = node.get(CSVDataSeedingTransformer.JSON_SCHEMA_PROPERTY_PROPERTIES);
			int noOfProperties = propertiesNode.size();
			if (noOfProperties == 1) {
				String propName = propertiesNode.fields().next().getKey();
				JsonNode propChildNode = propertiesNode.get(propName);
				return hasSingleSimpleLeaf(propName, propChildNode ,leafNodeTypes);
			}
		}
		return null;
	}
	/**
	 * @param entityName: Entity Name
	 * @param node: Json Node
	 * @param leafNodeTypes: Leaf Node Types
	 * @return String
	 */
	public String hasArrayTypeLeaf(String entityName, JsonNode node, List<String> leafNodeTypes) {
		
		String returnEntityName = null;
		String itemChildType = node.get(CSVDataSeedingTransformer.JSON_SCHEMA_PROPERTY_TYPE) != null
				? node.get(CSVDataSeedingTransformer.JSON_SCHEMA_PROPERTY_TYPE).asText() : null;

		if (CSVDataSeedingTransformer.JSON_SCHEMA_PROPERTY_ARRAY.equals(itemChildType)) {
			JsonNode itemsNode = node.get(CSVDataSeedingTransformer.JSON_SCHEMA_PROPERTY_ITEMS);
			if (itemsNode != null) {
				itemChildType = itemsNode.get(CSVDataSeedingTransformer.JSON_SCHEMA_PROPERTY_TYPE) != null
						? itemsNode.get(CSVDataSeedingTransformer.JSON_SCHEMA_PROPERTY_TYPE).asText() : null;
				boolean isLeaf = isLeafNodeType(itemChildType,leafNodeTypes);
				if(isLeaf) {
					returnEntityName = entityName;
				}
			}
		}
		return returnEntityName;
	}

	private boolean isLeafNodeType(String nodeType,List<String> leafNodeTypes) {
		return leafNodeTypes.contains(nodeType);
	}
	
}
