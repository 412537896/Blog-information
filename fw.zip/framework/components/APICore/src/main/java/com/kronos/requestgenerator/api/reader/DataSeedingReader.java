package com.kronos.requestgenerator.api.reader;

import com.kronos.requestgenerator.api.reader.DataSeedingReaderException;
import com.kronos.requestgenerator.api.reader.SeedingDataEntity;

/**
 * Interface for reading the CSV data.
 * @author Animesh.Sonkar
 *
 */
public interface DataSeedingReader {
	
	/**
	 * This method reads the CSV file.
	 * @param fileName: The csv file name
	 * @return CSV data in SeedingDataEntity
	 * @throws DataSeedingReaderException : DataSeedingReaderException
	 */
	public SeedingDataEntity readData(String fileName) throws DataSeedingReaderException;
	
	/**
	 * This method reads the CSV file.
	 * @param fileName: The csv file name
	 * @param row: row to read
	 * @return CSV data in SeedingDataEntity
	 * @throws DataSeedingReaderException : DataSeedingReaderException
	 */
	public SeedingDataEntity readData(String fileName, String row) throws DataSeedingReaderException;

}
