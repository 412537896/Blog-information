package com.kronos.requestgenerator.reader.csv;

import java.util.HashMap;
import java.util.Map;

import com.kronos.requestgenerator.api.reader.SeedingDataRecord;

/**
 * This class encapsulates a map for mapping a csv file row with columns.
 * 
 * @author Abhishek.Omar
 *
 */
public class CSVSeedingDataRecord implements SeedingDataRecord {

	private final Map<String, String> rowMap = new HashMap<>();

	@Override
	public String getSeedData(String mappingName) {
		return rowMap.get(mappingName);
	}

	/**
	 * This method populates the rowMap corresponding to a csv row.
	 * 
	 * @param key
	 *            : column name
	 * @param value
	 *            : value corresponding to the column
	 */
	public void putRecord(final String key, final String value) {
		rowMap.putIfAbsent(key, value);
	}

	@Override
	public String toString() {
		return rowMap.toString();
	}

}
