package com.kronos.api.rest.driver;

import org.apache.log4j.Logger;

import com.kronos.api.rest.auth.IAuthentication;
import com.kronos.context.ExecutionContext;
import com.kronos.report.Reporter;

public abstract class BaseAPIDriver {
	protected static final Logger logger = Logger.getLogger(BaseAPIDriver.class);
	protected static final Reporter reporter = Reporter.getInstance();
	
	protected IAuthentication auth;
	protected String cookies = null;
	protected String access_token = null;
	
	public String getAccess_token() {
		return access_token;
	}

	public void setAccess_token(String access_token) {
		this.access_token = access_token;
	}

	protected ExecutionContext context;
	
	protected String internalAppKey = null;
	protected String externalAppkey = null;
	
	public String getInternalAppKey() {
		return internalAppKey;
	}

	public void setInternalAppKey(String internalAppKey) {
		this.internalAppKey = internalAppKey;
	}
	
	public String getExternalAppkey() {
		return externalAppkey;
	}

	public void setExternalAppkey(String externalAppkey) {
		this.externalAppkey = externalAppkey;
	}

	public BaseAPIDriver(IAuthentication auth){
		this.auth = auth;
	}
	
	public IAuthentication getAuthenticator() {
		return auth;
	}

	public void setAuthenticator(IAuthentication auth) {
		this.auth = auth;
	}
	
	public String getCookies() {
		return cookies;
	}

	public void setCookies(String cookies) {
		this.cookies = cookies;
	}

	public ExecutionContext getContext() {
		return context;
	}

	public void setContext(ExecutionContext context) {
		this.context = context;
	}

}
