package com.kronos.requestgenerator.api.transformer;

/**
 * Exception class for tranformer.
 * @author Animesh.Sonkar
 *
 */
public class DataSeedingTransformerException extends Exception {
	
	private static final long serialVersionUID = 1L;
	
	public DataSeedingTransformerException() {
		
	}
	
	public DataSeedingTransformerException(String msg) {
		super(msg);
		
	}
	
	public DataSeedingTransformerException(Throwable t) {
		super(t);
		
	}

}
