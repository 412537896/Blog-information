
package com.kronos.api.rest.assertions;


import org.apache.log4j.Logger;
import org.testng.Assert;

import com.kronos.api.rest.exception.KronosCoreAPIException;
import com.kronos.assertion.KronosSoftAssertion;
import com.kronos.logging.KronosLogger;
import com.kronos.report.Reporter;
import com.kronos.report.StepStatus;

public class APIAssertions extends KronosSoftAssertion{
	protected static final Logger logger = Logger.getLogger(APIAssertions.class);
	protected Reporter reporter = Reporter.getInstance();

	private static final String ACTUAL_DECO = "<span style=\"font-weight: bold;\"> A : </span>";
	private static final String EXPECT_DECO = "<span style=\"font-weight: bold;\"> E : </span>";

	/**
	 * Verify if actual is true
	 * 
	 * @param actual: boolean
	 * @return true or false
	 */
	public boolean verifyTrue(final boolean actual) {
		return verifyTrue(actual, "");
	}

	/**
	 * Verify if actual is true, log message with step details
	 * Can be used when user needs to send custom message on to the reports
	 * @param actual: boolean
	 * @param stepDetail: String
	 * @return true or false
	 */
	public boolean verifyTrue(final boolean actual, final String stepDetail) {
		KronosLogger.traceEnter();
		boolean result = false;
		String message = "verifyTrue: [" + stepDetail + "]" 
						+ BREAK_LINE + ACTUAL_DECO + actual 
						+ BREAK_LINE + EXPECT_DECO + "true" + BREAK_LINE;
		try {
			Assert.assertTrue(actual);
			logger.info(message);
			reporter.reportStep(StepStatus.PASS, message);
			result=true;
		} catch (AssertionError ae) {
			verificationFailures.add(ae);
			logger.error(message + " - "+ ae.getMessage());
			reporter.reportStepWithAPITracking(StepStatus.FAIL, message);
		}
		KronosLogger.traceLeave();
		return result;
	}

	/**
	 * Verify if actual is false
	 * 
	 * @param actual: boolean
	 * @return true or false
	 */
	public boolean verifyFalse(final boolean actual) {
		return verifyFalse(actual, "");
	}

	/**
	 * Verify if actual is false, log message with step details
	 * Can be used when user needs to send custom message on to the reports
	 * @param actual: boolean
	 * @param stepDetail: String
	 * @return true or false
	 */
	public boolean verifyFalse(final boolean actual, final String stepDetail) {
		KronosLogger.traceEnter();
		boolean result = false;
		String message = "verifyFalse: ["+stepDetail  + "]" 
						+ BREAK_LINE + ACTUAL_DECO + actual
						+ BREAK_LINE + EXPECT_DECO + "false";

		try {
			Assert.assertFalse(actual);
			logger.info(message);
			reporter.reportStep(StepStatus.PASS, message);
			result=true;
		} catch (AssertionError ae) {
			verificationFailures.add(ae);
			logger.error(message+" - "+ ae.getMessage());
			reporter.reportStepWithAPITracking(StepStatus.FAIL, message);
		}
		KronosLogger.traceLeave();
		return result;
	}

	/**
	 * Verify if actual equals to expected
	 * 
	 * @param actual: Object
	 * @param expected: Object
	 * @return true or false
	 */
	public boolean verifyEquals(final Object actual, final Object expected) {
		return verifyEquals(actual, expected, "");
	}

	/**
	 * Verify if actual equals to expected, log message with step details
	 *  Can be used when user needs to send custom message on to the reports
	 * @param actual: Object
	 * @param expected: Object
	 * @param stepDetail: String
	 * @return true or false
	 */
	public boolean verifyEquals(final Object actual, final Object expected, final String stepDetail) {
		KronosLogger.traceEnter();
		boolean result = false;
		validateExpectedActualValues(actual, expected);
		String message = "verifyEquals: [" + stepDetail  + "]" 
				+ BREAK_LINE + ACTUAL_DECO + (actual != null ? actual.toString() : "null")  
				+ BREAK_LINE + EXPECT_DECO + (expected != null ? expected.toString() : "null");
		try {
			Assert.assertEquals(actual, expected);
			logger.info(message);
			reporter.reportStep(StepStatus.PASS, message);
			result = true;
		} catch (AssertionError ae) {
			verificationFailures.add(ae);
			logger.error(message+" - "+ ae.getMessage());
			reporter.reportStepWithAPITracking(StepStatus.FAIL,message);
		}
		KronosLogger.traceLeave();
		return result;
	}

	/**
	 * Verify if actual equals to expected, log message with step details
	 *  If the verify is failed, we don't log it as FAIL but WARNING
	 *  This method should only be used in the cleanup method
	 * @param actual: Object
	 * @param expected: Object
	 * @param stepDetail: String
	 * @return true or false
	 */
	public boolean verifyEqualsWithWarning(final Object actual, final Object expected, final String stepDetail) {
		boolean result = false;
		String message = "verifyEquals: [" + stepDetail  + "]" 
				+ BREAK_LINE + ACTUAL_DECO + (actual != null ? actual.toString() : "null")  
				+ BREAK_LINE + EXPECT_DECO + (expected != null ? expected.toString() : "null");
		try {
			Assert.assertEquals(actual, expected);
			logger.info(message);
			reporter.reportStep(StepStatus.PASS, message);
			result = true;
		} catch (AssertionError ae) {
			logger.warn(message+" - "+ ae.getMessage());
			reporter.reportStepWithAPITracking(StepStatus.WARNING,message);
		}
		return result;
	}
	
	/**
	 * Verify if actual string is same as expected string
	 * 
	 * @param actual: String
	 * @param expected: String
	 * @return true or false
	 */
	public boolean verifyEqualsIgnoreCase(final String actual, final String expected) {
		return verifyEqualsIgnoreCase(actual, expected, "");
	}
	
	/**
	 * compare two strings irrespective of case. Assertion passes if they are same.
	 * step details can be used when user needs to send custom message on to the reports
	 * @param actual: String
	 * @param expected: String
	 * @param stepDetail: String
	 * @return true or false
	 */
	public boolean verifyEqualsIgnoreCase(final String actual, final String expected, final String stepDetail) {
		KronosLogger.traceEnter();
		boolean result = false;
		validateExpectedActualValues(actual, expected);
		String message = "verifyEqualsIgnoreCase: [" + stepDetail  + "]"  
						+ BREAK_LINE + ACTUAL_DECO + actual 
						+ BREAK_LINE + EXPECT_DECO + expected;
		try {
			Assert.assertEquals((actual).toUpperCase(), (expected).toUpperCase());
			logger.info(message);
			reporter.reportStep(StepStatus.PASS, message);
			result = true;
		} catch (AssertionError ae) {
			verificationFailures.add(ae);
			logger.error(message+" - "+ ae.getMessage());
			reporter.reportStepWithAPITracking(StepStatus.FAIL, message);
		}
		KronosLogger.traceLeave();
		return result;
	}
	
	
	/**
	 * Verify if actual doesn't equal to expected
	 * 
	 * @param actual: Object
	 * @param expected: Object
	 * @return true or false
	 */
	public boolean verifyNotEquals(final Object actual, final Object expected) {
		return verifyNotEquals(actual, expected, "");
	}
	

	/**
	 * Verify if actual doesn't equal to expected, log message with step details
	 * Can be used when user needs to send custom message on to the reports
	 * @param actual: Object
	 * @param expected: Object
	 * @param stepDetail: String
	 * @return true or false
	 */
	public boolean verifyNotEquals(final Object actual, final Object expected, final String stepDetail) {
		KronosLogger.traceEnter();
		boolean result = false;

		validateExpectedActualValues(actual, expected);
		String message = "verifyNotEquals: [" + stepDetail  + "]"  
						+ BREAK_LINE + ACTUAL_DECO + (actual != null ? actual.toString() : "null") 
						+ BREAK_LINE + " Not E: " + (expected != null ? expected.toString() : "null");
		try {
			Assert.assertNotEquals(actual, expected);
			logger.info(message);
			reporter.reportStep(StepStatus.PASS, message);
			result = true;
		} catch (AssertionError ae) {
			verificationFailures.add(ae);
			logger.error(message+ " - "+ ae.getMessage());
			reporter.reportStepWithAPITracking(StepStatus.FAIL, message + " - "+ ae.getMessage());
		}
		KronosLogger.traceLeave();
		return result;

	}
	
	/**
	 * Verify if actual string is not equal to expected string
	 * 
	 * @param actual: String
	 * @param expected: String
	 * @return true or false
	 */
	public boolean verifyNotEqualsIgnoreCase(final String actual, final String expected) {
		return verifyNotEqualsIgnoreCase(actual, expected, "");
	}
	 
	
	/**
	 * Compare two strings irrespective of the case. Assertion passes if they are not same.
	 * step details can be used when user needs to send custom message to the reports
	 * @param actual: Object
	 * @param expected: Object
	 * @param stepDetail: String
	 * @return true or false
	 */
	public boolean verifyNotEqualsIgnoreCase(final String actual, final String expected, final String stepDetail) {
		KronosLogger.traceEnter();
		boolean result = false;

		validateExpectedActualValues(actual, expected);
		String message = "verifyNotEqualsIgnoreCase: [" + stepDetail  + "]"  
							+ BREAK_LINE + ACTUAL_DECO + actual 
							+ BREAK_LINE + " Not E: " + expected;
		try {
			Assert.assertNotEquals((actual).toUpperCase(), (expected).toUpperCase());
			logger.info(message);
			reporter.reportStep(StepStatus.PASS, message);
			result = true;
		} catch (AssertionError ae) {
			verificationFailures.add(ae);
			logger.error(message+ " - "+ ae.getMessage());
			reporter.reportStepWithAPITracking(StepStatus.FAIL, message + " - "+ ae.getMessage());
		}
		KronosLogger.traceLeave();
		return result;

	}
	
	
	/**
	 * Verify if actual status code equals to expected status code
	 * 
	 * @param actual: int
	 * @param expected: int
	 * @return true or false
	 */
	public boolean verifyStatusCode(int actual, int expected) {
		return verifyEquals(actual, expected, "verify HTTP response code");
	}
	
	
	/**
	 * Verify if actual status code equals to expected status code. Also, allows the assertion to be hard assertion or soft assertion. 
	 * In case of hard assertion, an exception will be thrown and if not caught, current test case execution will end, 
	 * otherwise it will continue running
	 * 
	 * @param actual: int
	 * @param expected: int
	 * @param isHardAssertion : boolean
	 * @return true or false
	 * @throws KronosCoreAPIException 
	 */
	public boolean verifyStatusCode(int actual, int expected, boolean isHardAssertion) throws KronosCoreAPIException {
		boolean result = verifyEquals(actual, expected, "verify HTTP response code");
		if(isHardAssertion && result != true)
			throw new KronosCoreAPIException("Verify HTTP response code failed: Actual:" + actual + ", Expected:" + expected);
		return result;
	}
	
	/**
	 * Verify if actual variable type equals to expected variable type
	 * 
	 * @param expected: Object
	 * @param actual: Object
	 * @throws IllegalArgumentException
	 * 			: illegal argument exception when variable type mismatches
	 * @return true or false
	 */
	private void validateExpectedActualValues(Object actual, Object expected){
		KronosLogger.traceEnter();
        //we should only proceed when both objects are not null 
        if(expected != null && actual != null){
        	String typeEpt= expected.getClass().getName();
        	String typeAtl= actual.getClass().getName();
		
        	if(!typeEpt.equals(typeAtl)){
        		KronosLogger.traceLeave();
        		throw new IllegalArgumentException("Variable type mismatch: expected object type is ["+expected.getClass()+"] ; acutal object type is ["+actual.getClass()+"]");
        	}
        }	
		KronosLogger.traceLeave();
	}


}