package com.kronos.api.rest.json;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

import org.apache.log4j.Logger;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.jayway.jsonpath.Configuration;
import com.jayway.jsonpath.spi.json.JacksonJsonNodeJsonProvider;
import com.jayway.jsonpath.spi.mapper.JacksonMappingProvider;
import com.jayway.restassured.path.json.JsonPath;
import com.kronos.api.rest.exception.KronosCoreAPIException;
import com.kronos.logging.KronosLogger;

public class Request {

	private JsonNode rootNode;
	final static Logger logger = Logger.getLogger(Request.class);
	public static final String BREAK_LINE = "</br>";

	private enum OPER {
		UPDATE, DELETE
	}

	public Request(JsonNode rootNode) {
		super();
		this.rootNode = rootNode;
	}
	
	public Request(String payload) throws KronosCoreAPIException {
		super();
		ObjectMapper mapper = new ObjectMapper();
		try {
			rootNode = mapper.readTree(payload);
		} catch (IOException e) {
			throw new KronosCoreAPIException(e.getMessage(),e);
		}
	}
	
	public JsonNode getRequest() {
		return rootNode;
	}
	
	public void setRequest(JsonNode jsonReq) {
		rootNode = jsonReq;
	}

	/**
	 * This method updates the value of any particular node.
	 * @param jsonPath:String
	 * @Param valueToupdate:String
	 * @throws KronosCoreAPIException : throws core API exception
	 */
	public void updateNodeValue(String jsonPath, Object valueTobeUpdated) throws KronosCoreAPIException {
		KronosLogger.traceEnter();
		try {
			String infoMessage = "jsonPath :" + jsonPath + " ,valueTobeUpdated : " + valueTobeUpdated;
			logger.info(infoMessage);
			if (isNodePresent(jsonPath)) {
				
				if (rootNode instanceof ArrayNode)
					updateNodeValue_WhenRootNodeIsArrayNode(jsonPath, valueTobeUpdated);
				else
					findNodeAndPerformOperation(rootNode, jsonPath, valueTobeUpdated, OPER.UPDATE);
				
				infoMessage = " Updated JsonNode:" + rootNode;
				logger.info(infoMessage);
			}
		} catch (Exception e) {
			logger.error(e);
			throw new KronosCoreAPIException(e);
		}
		KronosLogger.traceLeave();
	}

	
    /** This method updates the value of a node based on JSONPath when Request is of List Type
     * @param jsonPath:String 
     * @Param valuToupdate:String
     * @throws KronosCoreAPIException : throws core API exception
      */
    private void updateNodeValue_WhenRootNodeIsArrayNode(String jsonPath, Object valueTobeUpdated) throws KronosCoreAPIException {
        KronosLogger.traceEnter();
        try {
             Configuration configuration = Configuration.builder()
                        .jsonProvider(new JacksonJsonNodeJsonProvider())
                        .mappingProvider(new JacksonMappingProvider())
                        .build();
             
                JsonNode updatedNode =  com.jayway.jsonpath.JsonPath.using(configuration).parse(getRequest().toString()).set(jsonPath, valueTobeUpdated).json();
                setRequest(updatedNode); 
        } catch (Exception e) {
            logger.error(e);
            throw new KronosCoreAPIException(e);
        }
        KronosLogger.traceLeave();
    }
	
	/*
	 * This method delete the node.
	 * 
	 * @param jsonPath:String
	 * 
	 * @throws KronosCoreAPIException : throws core API exception
	 */
	public void deleteNode(String jsonPath) throws KronosCoreAPIException {
		KronosLogger.traceEnter();
		try {
			String infoMessage = "JsonPath :" + jsonPath;
			logger.info(infoMessage);
			if (isNodePresent(jsonPath)) {
				findNodeAndPerformOperation(rootNode, jsonPath, "", OPER.DELETE);
				infoMessage = " Updated JsonNode:" + rootNode;
				logger.info(infoMessage);
			}
		} catch (Exception e) {
			logger.error(e);
			throw new KronosCoreAPIException(e);
		}
		KronosLogger.traceLeave();

	}

	/*
	 * This method will replace all the .(period) within a field name with a |(pipe) in the JsonPath
	 * @param path String
	 */
	private String replacePersitableTokenizer(String path)
	{
		char[] jsonPath = path.toCharArray();
		Boolean quoteStarted = false;
		
		for(Integer i=0;i<jsonPath.length;i++)
		{
			if (jsonPath[i] == '\"')
			{
				quoteStarted = !quoteStarted;
			}
			else if (jsonPath[i]=='.' && quoteStarted)
			{
				jsonPath[i] = '|';
			}
		}
		String newPath = String.valueOf(jsonPath);
		return newPath;
	}
	
	/*
	 * This method will replace |(pipe) with .(period) in the list of fields of the JsonPath
	 * This will also remove " (double Quotes)
	 * @param listOfPath List<String>
	 */
	private List<String> getPersistedTokenizerBack(List<String> listOfPath)
	{	
		ListIterator<String> it = listOfPath.listIterator();
		while(it.hasNext()) {
			it.set(it.next().replace("|","."));
		}
		while(it.hasPrevious()) {
			it.set(it.previous().replace("\"",""));
		}
		return listOfPath;
	}
	
	/*
	 * This method find the node recursively and update the value of the node .
	 * 
	 * @param node:JsonNode
	 * 
	 * @param path:String
	 * 
	 * @Param valueToBeUpdated :String
	 * 
	 * @Param Oper : OPER
	 * 
	 * @throws KronosCoreAPIException : throws core API exception
	 */

	private void findNodeAndPerformOperation(JsonNode node, String path, Object valueToBeUpdated, OPER oper)
			throws KronosCoreAPIException {
		KronosLogger.traceEnter();
		String infoMessage = " node: " + node + ", path:" + path + ", valueToBeUpdated:" + valueToBeUpdated
				+ ", Operation:" + oper.toString();
		logger.info(infoMessage);

		String tokanizer = "\\.";
		
		//To preserve all the . within field names (ex: PeopleEditor APIs), replace them with a pipe
		path = replacePersitableTokenizer(path);
		
		//Split the JsonPath based on .
		List<String> listOfPath = Arrays.asList(path.split(tokanizer));
		
		//Get all the . back after replacing with pipe
		listOfPath = getPersistedTokenizerBack(listOfPath);
		
		String listLIndetifier = "[";
		String listRIndetifier = "]";
		String firstNode = null;
		int index = -1;

		firstNode = (String) listOfPath.get(0);

		// If firstNode in JsonPath is an array
		if (firstNode.contains(listLIndetifier)) {
			index = Integer.parseInt(
					firstNode.substring(firstNode.indexOf(listLIndetifier) + 1, firstNode.indexOf(listRIndetifier)));
			firstNode = firstNode.substring(0, firstNode.indexOf(listLIndetifier));
		}

		// If JsonPath has more than one level
		if (listOfPath.size() > 1) {
			if (node.get(firstNode) instanceof ArrayNode) {
				if (index == -1) {
					Iterator<JsonNode> itr = node.get(firstNode).elements();
					while (itr.hasNext()) {
						findNodeAndPerformOperation(itr.next(), getNextNodeNameInJsonPath(path), valueToBeUpdated,
								oper);
					}
				} else
					findNodeAndPerformOperation(node.get(firstNode).get(index), getNextNodeNameInJsonPath(path),
							valueToBeUpdated, oper);
			} else if (node.get(firstNode) instanceof ObjectNode) {

				findNodeAndPerformOperation(node.get(firstNode), getNextNodeNameInJsonPath(path), valueToBeUpdated,
						oper);
			}

		} else {
			switch (oper) {
			case UPDATE:
				updateValue(node, (String) listOfPath.get(0), valueToBeUpdated);
				break;
			case DELETE:
				delete(node, (String) listOfPath.get(0));
				break;
			}
		}
		KronosLogger.traceLeave();
	}

	private void delete(JsonNode node, String firstNode) {
		((ObjectNode) node).remove(firstNode);
	}

	/**
	 * This method update the value of the Node.
	 * 
	 * @param node:JsonNode
	 * @param strKey:String
	 * @param valueTobeUpdated
	 *            : Object
	 * @throws KronosCoreAPIException
	 *             : throws core API exception
	 */
	@SuppressWarnings("deprecation")
	private void updateValue(JsonNode node, String strKey, Object valueTobeUpdated) throws KronosCoreAPIException {
		KronosLogger.traceEnter();
		String infoMessage = "";

		if (valueTobeUpdated instanceof Integer)
			((ObjectNode) node).put(strKey, (Integer) valueTobeUpdated);
		else if (valueTobeUpdated instanceof String)
			((ObjectNode) node).put(strKey, (String) valueTobeUpdated);

		else if (valueTobeUpdated instanceof Boolean)
			((ObjectNode) node).put(strKey, (Boolean) valueTobeUpdated);
		else if (valueTobeUpdated instanceof Number)
			((ObjectNode) node).put(strKey, (Double) valueTobeUpdated);
		else if (valueTobeUpdated instanceof ArrayNode)
		{
			((ObjectNode) node).put(strKey, (ArrayNode) valueTobeUpdated);
		}
		else if (valueTobeUpdated instanceof ArrayList<?>)
		{
			ArrayNode array = convertArrayListToArrayNode((ArrayList<?>) valueTobeUpdated);
			((ObjectNode) node).put(strKey, array);
		}
		else if (valueTobeUpdated instanceof JsonNode)
        {
               ((ObjectNode) node).put(strKey, (JsonNode) valueTobeUpdated);
        }
		else if (valueTobeUpdated instanceof HashMap<?,?>)
		{
			JsonNode jsonNode = convertHashMapToJsonNode((HashMap<?,?>) valueTobeUpdated);
			((ObjectNode) node).put(strKey, jsonNode);
		}
		else {
			infoMessage = "Node at JSONPath is not of primitive type, ArrayList, ArrayNode, HashMap or JsonNode";
			logger.error(infoMessage);
			throw new KronosCoreAPIException(infoMessage);
		}
		KronosLogger.traceLeave();
	}
	
	
	private ArrayNode convertArrayListToArrayNode(ArrayList<?> arrayList) throws KronosCoreAPIException
	{
		ArrayNode arrayNode = null;
		try{
			ObjectMapper mapper = new ObjectMapper();
			arrayNode= mapper.valueToTree(arrayList);
		}
		catch(Exception e){
			throw new KronosCoreAPIException("Error converting ArrayList to Jackson ArrayNode.");
		}
		return arrayNode;
	}

	private JsonNode convertHashMapToJsonNode(HashMap <?,?> hashMap) throws KronosCoreAPIException
	{
		JsonNode jsonNode = null;
		try{
			ObjectMapper mapper = new ObjectMapper();
			jsonNode= mapper.valueToTree(hashMap);
		}
		catch(Exception e){
			throw new KronosCoreAPIException("Error converting HashMap to Jackson JsonNode.");
		}
		return jsonNode;
	}
	
	private String getNextNodeNameInJsonPath(String jsonPath) {
		return jsonPath.substring(jsonPath.indexOf(".") + 1);
	}

	/**
	 * This method verifies whether jsonPath is a valid path in Node.
	 * 
	 * @param jsonPath:String
	 * @return boolean
	 * @throws KronosCoreAPIException
	 *             : throws core API exception
	 */
	public boolean isNodePresent(String jsonPath) throws KronosCoreAPIException {
		KronosLogger.traceEnter();
		JsonPath j = new JsonPath(this.rootNode.toString());
		Boolean value = false;
		String infoMessage = " node: " + this.rootNode + BREAK_LINE + " jsonPath:" + jsonPath + BREAK_LINE;
		logger.info(infoMessage);
		try {
			if (j.get(jsonPath).getClass().equals(ArrayList.class)) {

				List<Object> jsonList = j.getJsonObject(jsonPath);
				if(jsonList.isEmpty()) {
					value =true;
				}else {
					for (Object obj : jsonList) {
						if (obj != null) {
							value = true;
							break;
						} else
							value = false;
					}
				}
			} else {
				value = (j.get(jsonPath).toString() != null);
			}
		} catch (Exception e) {
			logger.error(infoMessage, e);
			value = false;
		}

		KronosLogger.traceLeave();
		return (value);
	}
}
