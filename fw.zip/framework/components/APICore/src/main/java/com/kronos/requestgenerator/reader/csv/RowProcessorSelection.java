package com.kronos.requestgenerator.reader.csv;

public enum RowProcessorSelection {
	ALL,SELECTED
}
