package com.kronos.requestgenerator.transformer.csv;

import com.fasterxml.jackson.databind.JsonNode;

public class EntityJSONProcessData {
		private String entityName;
		private String key;
		private JsonNode rootNode;
		private String parentName;
		
		
		
		public EntityJSONProcessData(String entityName, String key, JsonNode rootNode) {
			super();
			this.entityName = entityName;
			this.key = key;
			this.rootNode = rootNode;
		}
		
		public String getEntityName() {
			return entityName;
		}
		public void setEntityName(String entityName) {
			this.entityName = entityName;
		}
		public String getKey() {
			return key;
		}
		public void setKey(String key) {
			this.key = key;
		}
		public JsonNode getRootNode() {
			return rootNode;
		}
		public void setRootNode(JsonNode rootNode) {
			this.rootNode = rootNode;
		}

		public String getParentName() {
			return parentName;
		}

		public void setParentName(String parentName) {
			this.parentName = parentName;
		}
		
				
	}