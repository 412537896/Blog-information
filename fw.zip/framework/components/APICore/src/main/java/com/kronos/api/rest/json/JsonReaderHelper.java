package com.kronos.api.rest.json;

import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import java.util.stream.Collectors;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.kronos.api.rest.exception.KronosCoreAPIException;
import com.kronos.exception.KronosCoreCommonException;
import com.kronos.facade.DateParser;

public class JsonReaderHelper {
	private static final String QUOTE = "\"";
	
	private JsonReaderHelper(){
	
	}
	
	/**
	 * Read file and return a Json node
	 * @param fileName: String
	 * @return a Json node
	 * @throws KronosCoreAPIException
	 * 			: kronos core API exception
	 */
	public static JsonNode read(String filePath) throws KronosCoreAPIException{
		try {
			return new ObjectMapper().readTree(
							new InputStreamReader(
									JsonReaderHelper.class.getClassLoader().getResourceAsStream(filePath))
							);
		} catch (IOException e) {
			throw new KronosCoreAPIException(e.getMessage(), e);
		} 
	}
	
	/**
	 * Get the value from Json node
	 * 
	 * @param path: String
	 * @param node: JsonNode
	 * @return the value in String
	 */
	public static String getValue(String path,JsonNode node){
		String toJsonPath = "/" + path.replace(".", "/").replace("[", "/").replace("]", "");
		String value = node.at(toJsonPath).asText();
		return value.isEmpty() ? null : value;
	}
	
	/**
	 * Set the value to Json node
	 * 
	 * @param value: String
	 * @param path: String
	 * @param node: JsonNode
	 */
	public static void setValue(String value, String path, JsonNode node){
		if(path.contains(".")){
			String objectPath = path.substring(0,path.lastIndexOf("."));
			String key = path.substring(path.lastIndexOf(".") + 1);
			String toJsonPath = "/" + objectPath.replace(".", "/").replace("[", "/").replace("]", "");
			if(!node.at(toJsonPath).isMissingNode())
				((ObjectNode)node.at(toJsonPath)).put(key, value);
		}else{
			if(!node.isMissingNode())
				((ObjectNode)node).put(path, value);
		}
	}
	
	/**
	 * Set the value to Json node
	 * 
	 * @param value: int
	 * @param path: String
	 * @param node: JsonNode
	 */
	public static void setValue(int value, String path, JsonNode node){
		if(path.contains(".")){
			String objectPath = path.substring(0,path.lastIndexOf("."));
			String key = path.substring(path.lastIndexOf(".") + 1);
			String toJsonPath = "/" + objectPath.replace(".", "/").replace("[", "/").replace("]", "");
			if(!node.at(toJsonPath).isMissingNode())
				((ObjectNode)node.at(toJsonPath)).put(key, value);
		}else{
			if(!node.isMissingNode())
				((ObjectNode)node).put(path, value);
		}
	}
	
	/**
	 * Set the value to Json node
	 * 
	 * @param value: boolean
	 * @param path: String
	 * @param node: JsonNode
	 */
	public static void setValue(boolean value, String path, JsonNode node){
		if(path.contains(".")){
			String objectPath = path.substring(0,path.lastIndexOf("."));
			String key = path.substring(path.lastIndexOf(".") + 1);
			String toJsonPath = "/" + objectPath.replace(".", "/").replace("[", "/").replace("]", "");
			if(!node.at(toJsonPath).isMissingNode())
				((ObjectNode)node.at(toJsonPath)).put(key, value);
		}else{
			if(!node.isMissingNode())
				((ObjectNode)node).put(path, value);
		}
	}
	
	/**
	 * Set the value to Json node
	 * 
	 * @param value: float
	 * @param path: String
	 * @param node: JsonNode
	 */
	public static void setValue(float value, String path, JsonNode node){
		if(path.contains(".")){
			String objectPath = path.substring(0,path.lastIndexOf("."));
			String key = path.substring(path.lastIndexOf(".") + 1);
			String toJsonPath = "/" + objectPath.replace(".", "/").replace("[", "/").replace("]", "");
			if(!node.at(toJsonPath).isMissingNode())
				((ObjectNode)node.at(toJsonPath)).put(key, value);
		}else{
			if(!node.isMissingNode())
				((ObjectNode)node).put(path, value);
		}
	}
	
	/**
	 * Build Json node
	 * 
	 * @param node: JsonNode
	 * @return a String of traverseTree
	 * @throws KronosCoreCommonException
	 * 			: kronos core common exception
	 */
	public static String build(JsonNode node) throws KronosCoreCommonException{
		return traverseTree(node,new DateParser());
	}
	
	/**
	 * Build Json node
	 * @param node: JsonNode
	 * @param dp: DateParser
	 * @return a String of traverseTree
	 * @throws KronosCoreCommonException
	 * 			: kronos core common exception
	 */
	public static String build(JsonNode node, DateParser dp) throws KronosCoreCommonException{
		return traverseTree(node,dp);
	}
	
	/**
	 * Traverse tree
	 * @param node: JsonNode	
	 * @param dp: DateParser
	 * @return a String of traverseTree
	 * @throws KronosCoreCommonException
	 * 			: konos core common exception
	 */
	private static String traverseTree(JsonNode node, DateParser dp) throws KronosCoreCommonException{
		List<String> resultList = new ArrayList<String>();
		Iterator<Entry<String, JsonNode>> it = node.fields();
			
		while(it.hasNext()){
			Entry<String, JsonNode> t = it.next();
			if(t.getValue().isBoolean() || t.getValue().isIntegralNumber()){
				resultList.add(QUOTE + t.getKey() + QUOTE + " : " + t.getValue());
				continue;
			}
			if(t.getValue().isTextual() || t.getValue().isValueNode()){
				if(dp.isValidatePattern(t.getValue().asText())){
					resultList.add(QUOTE + t.getKey() + QUOTE + " : " + QUOTE + dp.parseDatePattern(t.getValue().asText()) + QUOTE);
				}else{
					resultList.add(QUOTE + t.getKey() + QUOTE + " : " + t.getValue());
				}
			}else if(t.getValue().isObject()){
				resultList.add(QUOTE + t.getKey() + QUOTE + " : " + traverseTree(t.getValue(),dp));
			}else if(t.getValue().isArray()){
				List<String> temp = new ArrayList<String>();
				for(JsonNode n : t.getValue())
					temp.add(traverseTree(n,dp));
				
				if(!temp.isEmpty()){
					resultList.add(QUOTE + t.getKey() + QUOTE + " : " + temp.stream().collect(Collectors.joining("," , "[", "]")));
				}
			}
		}
		return resultList.isEmpty() ? "" : resultList.stream().collect(Collectors.joining("," , "{" ,"}"));
	}
	
}
