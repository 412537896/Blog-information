package com.kronos.api.rest.json;

import java.io.File;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.fasterxml.jackson.databind.JsonNode;
import com.kronos.api.rest.exception.KronosCoreAPIException;
import com.kronos.logging.KronosLogger;
import com.kronos.requestgenerator.RequestGenerator;
import com.kronos.requestgenerator.RequestGeneratorException;

public class RequestBuilder {
	protected final static Logger logger = Logger.getLogger(RequestBuilder.class);
	
	/**
	 * This method loads the schema file from the projects resource directory present at the root level and 
		generates the json with the data from the Hierarchical CSV files.
     *   
	 * @param schemaFile: Json schema
	 * 
	 * @param parentCSVFile: Parent CSV file
	 * 
	 * @param keyRow: csv row
	 * 
	 * @return Request
	 * @throws KronosCoreAPIException : KronosCoreAPIException
	 */
	
	public Request build(String schemaFile, String parentCSVFile, String keyRow) throws KronosCoreAPIException
	{
		KronosLogger.traceEnter();
		RequestGenerator ds = new RequestGenerator();
		JsonNode rootNode = null;
		try {
			if (StringUtils.isNotBlank(parentCSVFile) && StringUtils.isNotBlank(schemaFile) && StringUtils.isNotBlank(keyRow))

					rootNode = ds.transformCSVData(schemaFile, parentCSVFile, keyRow);
		}
		catch (RequestGeneratorException e){	
			String errMsg = "Error while transforming CSV to JSON";
			logger.error(errMsg, e);
			throw new KronosCoreAPIException(errMsg , e); 
		}
		KronosLogger.traceLeave();
		return new Request(rootNode);
	}
	
	/**
	 * This method checks if file exists or not.

	 * @param file: File path
	 * 
	 * @return true or false based on existence status
	 */
	private Boolean checkFileExistence(String file)
	{
		File f = new File(file);
		return (f.exists());
	}
}


