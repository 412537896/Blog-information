package com.kronos.requestgenerator.api.reader;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.kronos.requestgenerator.api.reader.SeedingDataRecord;

/**
 * This class contains the csv data.
 * @author Animesh.Sonkar
 *
 */
public class SeedingDataEntity {

	private List<SeedingDataRecord> seedingDataRecords;
	
	private Map<String, List<Integer>> parentIndexMap = new HashMap<String, List<Integer>>();

	/**
	 * @return the seedingDataRecords
	 */
	public List<SeedingDataRecord> getSeedingDataRecords() {
		return seedingDataRecords;
	}

	/**
	 * @param seedingDataRecords the seedingDataRecords to set
	 */
	public void setSeedingDataRecords(List<SeedingDataRecord> seedingDataRecords) {
		this.seedingDataRecords = seedingDataRecords;
	}

	/**
	 * @return the parentIndexMap
	 */
	public Map<String, List<Integer>> getParentIndexMap() {
		return parentIndexMap;
	}

	/**
	 * @param parentIndexMap: the parentIndexMap to set
	 */
	public void setParentIndexMap(Map<String, List<Integer>> parentIndexMap) {
		this.parentIndexMap = parentIndexMap;
	}
	 
	/**
	 * This method returns the list of records for a parent key.
	 * @param parentKey The parent key for which records are needed.
	 * @return the seedingDataRecords
	 */
	public List<SeedingDataRecord> getSeedingDataRecordsForParent(String parentKey) {
		List<SeedingDataRecord> returnList = new ArrayList<>();
		List<Integer> parentList = parentIndexMap.get(parentKey);
		if(parentList != null && !parentList.isEmpty()) {
			for(Integer indexVal:  parentList) {
				returnList.add(seedingDataRecords.get(indexVal));
			}
		}
		return returnList;
	}
	
	
	
	
	
}
