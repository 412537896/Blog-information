package com.kronos.requestgenerator;

/**
 * @author Animesh.Sonkar
 *
 */
public class RequestGeneratorException extends Exception{
	
	private static final long serialVersionUID = 1L;

	/**
	 * Constructor with string message.
	 * 
	 * @param message: Error message
	 */
	public RequestGeneratorException(String message) {
		super(message);
	}

	/**
	 * Constructor with exception.
	 * 
	 * @param ex :  Throwable object
	 */
	public RequestGeneratorException(Exception ex) {
		super(ex);
	}
	
	/**
	 * Constructor with string message and exception.
	 * @param message: Error message
	 * @param throwable:  Throwable object
	 */
	public RequestGeneratorException(String message, Throwable throwable) {
		super(message, throwable);
	}

}
