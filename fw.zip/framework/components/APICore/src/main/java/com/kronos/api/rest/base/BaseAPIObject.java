package com.kronos.api.rest.base;

import static com.jayway.restassured.RestAssured.given;
import static com.kronos.api.rest.json.JsonBuildHelper.build;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.testng.log4testng.Logger;

import com.kronos.api.rest.driver.APIDriver;
import com.kronos.api.rest.exception.KronosCoreAPIException;
import com.kronos.api.rest.json.BasePayloadGenerator;
import com.kronos.api.rest.json.JsonReaderHelper;
import com.kronos.api.rest.json.Request;
import com.kronos.api.rest.json.RequestBuilder;
import com.kronos.api.rest.operations.APIResponse;
import com.kronos.requestgenerator.constants.AppConstants;

public abstract class BaseAPIObject extends BasePayloadGenerator{
	private static final String TENANT_ID_KEY = "tenantId";
	private static final String SCRATCHPAD_ID = "scratchpad-id";
	private static final String TOKEN = "token";

	static final Logger logger = Logger.getLogger(BaseAPIObject.class);

	public static final String BASE_PATH = "wfc/restcall";
	public static final String SCHEMA_PARENT_FOLDER = "schema";

	protected APIDriver driver;

	// two different approaches for the parameter
	private static final List<String> GENERIC_PARAMETRS = new ArrayList<String>(Arrays.asList(TENANT_ID_KEY));
	protected Map<String, Object> parameters;
	protected BaseRestParameter params;

	/**
	 * Constructor to initialize apidriver object
	 * 
	 * @param apiDriver:APIDriver
	 * 
	 */
	public BaseAPIObject(APIDriver driver) {
		this.driver = driver;
		parameters = new HashMap<String, Object>();
		params = new BaseRestParameter();
	}

	/**
	 * @deprecated This method is for backward compatibility. Please use
	 *             driver.login in your test case layer directly
	 */
	@Deprecated
	public void login(String username, String password) throws KronosCoreAPIException {
		driver.login(username, password);
	}

	/**
	 * @deprecated This method is deprecated, please use the equivalence method
	 *             in the driver
	 */
	@Deprecated
	public APIResponse post(String uri, Map<String, Object> parameters) throws KronosCoreAPIException {
		return driver.post(uri, parameters);
	}

	/**
	 * @deprecated This method is deprecated, please use the equivalence method
	 *             in the driver
	 */
	@Deprecated
	public APIResponse post(String uri, BaseRestParameter params) throws KronosCoreAPIException {
		return driver.post(uri, params);
	}

	/**
	 * @deprecated This method is deprecated, please use the equivalence method
	 *             in the driver
	 */
	@Deprecated
	public APIResponse post(String uri, Request payload, Map<String, Object> parameters) throws KronosCoreAPIException {
		return driver.post(uri, payload, parameters);
	}

	/**
	 * @deprecated This method is deprecated, please use the equivalence method
	 *             in the driver
	 */
	@Deprecated
	public APIResponse post(String uri, Request payload) throws KronosCoreAPIException {
		return post(uri, params, payload);
	}

	/**
	 * @deprecated This method is deprecated, please use the equivalence method
	 *             in the driver
	 */
	@Deprecated
	public APIResponse post(String uri, BaseRestParameter params, Request payload) throws KronosCoreAPIException {
		return driver.post(uri, params, payload);
	}

	/**
	 * @deprecated This method is deprecated, please use the equivalence method
	 *             in the driver
	 */
	@Deprecated
	public APIResponse post(String uri, File file) throws KronosCoreAPIException {
		return driver.post(uri, file, params);
	}

	/**
	 * @deprecated This method is deprecated, please use the equivalence method
	 *             in the driver
	 */
	@Deprecated
	public APIResponse post(String uri, File file, Map<String, Object> parameters) throws KronosCoreAPIException {
		return driver.post(uri, file, parameters);
	}

	/**
	 * @deprecated This method is deprecated, please use the equivalence method
	 *             in the driver
	 */
	@Deprecated
	public APIResponse get(String uri) throws KronosCoreAPIException {
		return driver.get(uri, params);
	}

	/**
	 * @deprecated This method is deprecated, please use the equivalence method
	 *             in the driver
	 */
	@Deprecated
	public APIResponse get(String uri, Map<String, Object> parameters) throws KronosCoreAPIException {
		return driver.get(uri, parameters);
	}

	/**
	 * @deprecated This method is deprecated, please use the equivalence method
	 *             in the driver
	 */
	@Deprecated
	public APIResponse get(String uri, BaseRestParameter params) throws KronosCoreAPIException {
		return driver.get(uri, params);
	}

	/**
	 * @deprecated This method is deprecated, please use the equivalence method
	 *             in the driver
	 */
	@Deprecated
	public APIResponse put(String uri, Request payload) throws KronosCoreAPIException {
		return put(uri, params, payload);
	}

	/**
	 * @deprecated This method is deprecated, please use the equivalence method
	 *             in the driver
	 */
	@Deprecated
	public APIResponse put(String uri, Map<String, Object> parameters) throws KronosCoreAPIException {
		return put(uri, null, parameters);
	}

	/**
	 * @deprecated This method is deprecated, please use the equivalence method
	 *             in the driver
	 */
	@Deprecated
	public APIResponse put(String uri, BaseRestParameter params) throws KronosCoreAPIException {
		return driver.put(uri, params);
	}

	/**
	 * @deprecated This method is deprecated, please use the equivalence method
	 *             in the driver
	 */
	@Deprecated
	public APIResponse put(String uri, Request payload, Map<String, Object> parameters) throws KronosCoreAPIException {
		return driver.put(uri, payload, parameters);
	}

	/**
	 * @deprecated This method is deprecated, please use the equivalence method
	 *             in the driver
	 */
	@Deprecated
	public APIResponse put(String uri, BaseRestParameter params, Request payload) throws KronosCoreAPIException {
		return driver.put(uri, params, payload);
	}

	/**
	 * @deprecated This method is deprecated, please use the equivalence method
	 *             in the driver
	 */
	@Deprecated
	public APIResponse delete(String uri) throws KronosCoreAPIException {
		return driver.delete(uri, params);
	}

	/**
	 * @deprecated This method is deprecated, please use the equivalence method
	 *             in the driver
	 */
	@Deprecated
	public APIResponse delete(String uri, Map<String, Object> parameters) throws KronosCoreAPIException {
		return delete(uri, null, parameters);
	}

	/**
	 * @deprecated This method is deprecated, please use the equivalence method
	 *             in the driver
	 */
	@Deprecated
	public APIResponse delete(String uri, BaseRestParameter parameters) throws KronosCoreAPIException {
		return delete(uri, parameters, null);
	}

	/**
	 * @deprecated This method is deprecated, please use the equivalence method
	 *             in the driver
	 */
	@Deprecated
	public APIResponse delete(String uri, Request payload) throws KronosCoreAPIException {
		return delete(uri, params, payload);
	}

	/**
	 * @deprecated This method is deprecated, please use the equivalence method
	 *             in the driver
	 */
	@Deprecated
	public APIResponse delete(String uri, Request payload, Map<String, Object> parameters)
			throws KronosCoreAPIException {
		return driver.delete(uri, payload, parameters);
	}

	/**
	 * @deprecated This method is deprecated, please use the equivalence method
	 *             in the driver
	 */
	@Deprecated
	public APIResponse delete(String uri, BaseRestParameter params, Request payload) throws KronosCoreAPIException {
		return driver.delete(uri, params, payload);
	}

	/**
	 * This method gets all the generic parameters in the map as keys and empty
	 * values with tenant id fetched set from the testng.xml file
	 * 
	 * @throws KronosCoreAPIException
	 *             : kronos core API exception
	 */
	public void setGenericParameter() throws KronosCoreAPIException {
		parameters.clear();
		params.clear();
		for (String key : GENERIC_PARAMETRS) {
			parameters.put(key, "");
			//params.getHeader().put(key, "");
			params.getQuery().put(key, "");
		}

		//params.getHeader().put(TENANT_ID_KEY, driver.getContext().getTenant());
		params.getQuery().put(TENANT_ID_KEY, driver.getContext().getTenant());
		parameters.put(TENANT_ID_KEY, driver.getContext().getTenant());
	}

	/**
	 * This method gets all the generic parameters in the map as keys and empty
	 * values and set tenant id and scartchpad-id that stateful services needed
	 * 
	 * @throws KronosCoreAPIException
	 *             : kronos core API exception
	 */
	public void setGenericParameterStateful() throws KronosCoreAPIException {
		params.clear();
		for (String key : GENERIC_PARAMETRS) {
			params.getHeader().put(key, "");
		}

		//params.getHeader().put(TENANT_ID_KEY, driver.getContext().getTenant());
		params.getQuery().put(TENANT_ID_KEY, driver.getContext().getTenant());
		params.getQuery().put(TOKEN, token);
		params.getHeader().put(SCRATCHPAD_ID, token);
	}

	public BaseRestParameter getParams() {
		return params;
	}

	public void setParams(BaseRestParameter params) {
		this.params = params;
	}


	/**
	 * This method loads the schema file from the projects resource directory
	 * present at the root level and returns the file path.
	 * 
	 * @param schemaLocation:
	 *            String
	 * 
	 * @return schema:String
	 * @deprecated : This method should not be used schema file path is no more
	 *             fixed. User has ability to control the schema path
	 */
	@Deprecated
	protected String loadSchema(String schemaLocation) {
		return SCHEMA_PARENT_FOLDER + AppConstants.FILE_SEPARATOR + schemaLocation;
	}

	/**
	 * This method loads the schema file from the projects resource directory
	 * present at the root level and generates the json with the data from the
	 * map.
	 * 
	 * @param schema:
	 *            String
	 * 
	 * @param map:
	 *            Map
	 * @throws KronosCoreAPIException
	 *             : kronos core API exception
	 * 
	 * @return Request
	 */
	public Request buildPayLoad(String schema, Map<String, Object> map) throws KronosCoreAPIException {
		return build(schema, map);
	}

	/**
	 * This method loads the schema file from the projects resource directory
	 * present at the root level and generates the json with the data from the
	 * Hierarchical CSV files.
	 * 
	 * @param schema:
	 *            Schema file
	 * 
	 * @param csvFile
	 *            : Parent CSV file
	 * @param rowToRead:
	 *            csv row
	 * @throws KronosCoreAPIException
	 *             : kronos core API exception
	 * @return Request
	 */
	public Request buildPayLoad(String schema, String csvFile, String rowToRead) throws KronosCoreAPIException {
		return new RequestBuilder().build(schema, csvFile, rowToRead);
	}

	/**
	 * This method generates the json with the data from a map.
	 * 
	 * @param map:
	 *            Map
	 * @throws KronosCoreAPIException
	 *             : kronos core API exception
	 * 
	 * @return Request
	 */
	public Request buildPayLoad(Map<String, Object> map) throws KronosCoreAPIException {
		return build(map);
	}

	/**
	 * This method generates the json with the data from a List.
	 * 
	 * @param list:
	 *            List
	 * @throws KronosCoreAPIException
	 *             : kronos core API exception
	 * 
	 * @return Request
	 */
	public Request buildPayLoad(List<Object> list) throws KronosCoreAPIException {
		return build(list);
	}

	/**
	 * This method generates the Request object with give file path of the JSON
	 * payload
	 * 
	 * @param filePath
	 * @return
	 * @throws KronosCoreAPIException
	 */
	public Request buildPayLoad(String filePath) throws KronosCoreAPIException {
		return new Request(JsonReaderHelper.read(filePath));
	}

	/**
	 * We will remove this code later once we have setup correctly in scheduling
	 * team
	 */
	public static final String OPEN_TRANSACTION_URL = BASE_PATH + "/scheduling/v1/transaction";
	public static final String COMMIT_TRANSACTION_URL = BASE_PATH + "/scheduling/v1/transaction/{token}/commit";
	public static final String ROLLBACK_TRANSACTION_URL = BASE_PATH + "/scheduling/v1/transaction/{token}/rollback";
	public static final String CLOSE_TRANSACTION_URL = BASE_PATH + "/scheduling/v1/transaction/{token}";

	protected String token;
	protected String sessionId;

	public String getToken() {
		return token;
	}

	public String getSessionId() {
		return sessionId;
	}

	public APIResponse openTransaction() throws KronosCoreAPIException {
		setGenericParameter();
		APIResponse tokenResponse = driver.post(OPEN_TRANSACTION_URL, params);

		token = tokenResponse.getResponseAsString();
		sessionId = tokenResponse.getSessionId();
		return tokenResponse;
	}

	public APIResponse commit() throws KronosCoreAPIException {
		setGenericParameter();
		params.setPath("token", token);
		return driver.put(COMMIT_TRANSACTION_URL, params, null, given().sessionId(sessionId));
	}

	public APIResponse rollback() throws KronosCoreAPIException {
		setGenericParameter();
		params.setPath("token", token);
		return driver.put(ROLLBACK_TRANSACTION_URL, params, null, given().sessionId(sessionId));
	}

	public APIResponse closeTransaction() throws KronosCoreAPIException {
		setGenericParameter();
		params.setPath("token", token);
		return driver.delete(CLOSE_TRANSACTION_URL, params, null, given().sessionId(sessionId));
	}
}
