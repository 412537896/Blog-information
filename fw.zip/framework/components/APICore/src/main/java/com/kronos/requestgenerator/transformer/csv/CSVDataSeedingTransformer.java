package com.kronos.requestgenerator.transformer.csv;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.*;
import com.fasterxml.jackson.databind.ObjectMapper;

import com.kronos.requestgenerator.transformer.csv.CSVDataSeedingTrnsSupport;
import com.kronos.requestgenerator.transformer.csv.CSVDataSeedingTrnsUtils;
import com.kronos.requestgenerator.transformer.csv.EntityJSONProcessData;
import com.kronos.requestgenerator.api.reader.SeedingDataEntity;
import com.kronos.requestgenerator.api.reader.SeedingDataRecord;
import com.kronos.requestgenerator.api.transformer.DataSeedingTransformer;
import com.kronos.requestgenerator.api.transformer.DataSeedingTransformerException;
import com.kronos.requestgenerator.constants.AppConstants;
import com.kronos.requestgenerator.reader.csv.CSVSeedingDataRecord;

/**
 * This class transforms csv data to json for a set of configuration as per the
 * json mapping schema of the configuration. names.
 * 
 * @author Animesh.Sonkar
 *
 */
public class CSVDataSeedingTransformer implements DataSeedingTransformer {
	public static final String JSON_SCHEMA_TYPE_ANY = "any";
	public static final String APP_CONFIG_TOOL_PROPERTY_IS_LEGACY = "isLegacy";
	public static final String LEGACY_PROPERTY_PRE_STRING = "@";
	public static final String CSV_FILE_EXTENSION = ".csv";
	public static final String FAILED_CONFIGURATION_ITEMS = "Failed Configuration Items\t:\t";
	public static final String SUCCESSFUL_CONFIGURATION_ITEMS = "Successful Configuration items\t:\t";
	public static final String TOTAL_CONFIGURATION_ITEMS = "Total Configuration Items\t:\t";
	public static final String SUMMARY_OF_RUN = "Summary of run\n-------------------------------------------------\n";
	public static final String CSV_HEADER_SEPARATOR = "-";
	public static final String CSV_HEADER_KEY = "Key";
	public static final String SCHEMA_FILE_EXTENSION = ".json";
	public static final String JSON_SCHEMA_PROPERTY_ITEMS = "items";
	public static final String JSON_SCHEMA_TYPE_STRING = "string";
	public static final String JSON_SCHEMA_TYPE_INTEGER = "integer";
	public static final String JSON_SCHEMA_TYPE_NUMBER = "number";
	public static final String JSON_SCHEMA_TYPE_BOOLEAN = "boolean";
	public static final String JSON_SCHEMA_PROPERTY_ARRAY = "array";
	public static final String JSON_SCHEMA_PROPERTY_PROPERTIES = "properties";
	public static final String JSON_SCHEMA_PROPERTY_OBJECT = "object";
	public static final String JSON_SCHEMA_PROPERTY_TYPE = "type";
	public static final String MULTIPLE_CSV_ROW = ",";
	public static final String CSV_VALUE_SEPARATOR = "\\*\\*";
	private final List<String> leafNodeTypes = Arrays.asList(new String[] { JSON_SCHEMA_TYPE_BOOLEAN,
			JSON_SCHEMA_TYPE_STRING, JSON_SCHEMA_TYPE_INTEGER, JSON_SCHEMA_TYPE_NUMBER, JSON_SCHEMA_TYPE_ANY });

	private String configDataDirectory;

	private Map<String, SeedingDataEntity> seedingDataEntityMap = new HashMap<>();
	private Map<String, String> simpleNodeMap = new HashMap<>();
	private Map<String, String> arrayLeafNodeMap = new HashMap<>();

	private boolean isLegacyEntity;
	private Map<String, String> duplicateEntityMap = new HashMap<String, String>();
	private Map<String, String> complextArrayParentNameMap = new HashMap<String, String>();

	private static final Logger log = Logger.getLogger(CSVDataSeedingTransformer.class);
	private Properties prop;

	public CSVDataSeedingTransformer() {
		super();
	}

	/**
	 * This method transforms the csv to json
	 * 
	 * @param schema
	 *            : Json Schema
	 * @param csv
	 *            : CSV File
	 * @param row
	 *            : Row to read
	 * @return JsonNode
	 * @throws DataSeedingTransformerException:
	 *             Exception
	 */
	@Override
	public JsonNode transform(String schema, String csv, String row) throws DataSeedingTransformerException {

		JsonNode request = null;
		configDataDirectory = FilenameUtils.getFullPathNoEndSeparator(csv);
		// configDataDirectory =
		// FilenameUtils.normalizeNoEndSeparator(configDataDirectory);
		String csvFileName = FilenameUtils.getBaseName(csv);
		ObjectMapper mapper = new ObjectMapper();
		JsonNode rootNode;
		// String entityName =
		// FilenameUtils.removeExtension(schema.substring(schema.lastIndexOf("\\")+1));
		String entityName = null;
		try {
			InputStream in = this.getClass().getClassLoader().getResourceAsStream(schema);
			rootNode = mapper.readTree(in);
			in.close();
			
			if ((row.contains(MULTIPLE_CSV_ROW)) && (rootNode.has("items"))) {
				rootNode = rootNode.get("items");
			}
			// rootNode = mapper.readTree(new File(schema));
			Iterator<String> nodeIterator = rootNode.fieldNames();
			while (nodeIterator.hasNext()) {
				entityName = nodeIterator.next();

			}
			log.info("Starting transformation for API:" + entityName);
			if (entityName != null && !entityName.trim().isEmpty() && rootNode.get(entityName) != null) {
				checkDuplicateEntity(new EntityJSONProcessData(entityName, null, rootNode.get(entityName)), null);
				if (row.contains(MULTIPLE_CSV_ROW)) {
					request = mapper.createArrayNode();
					String[] arrRow = row.split(MULTIPLE_CSV_ROW);
					for (String currRow : arrRow) {
						JsonNode requestMap = null;
						requestMap = createEntityJSON(entityName, rootNode.get(entityName), csvFileName, currRow);
						((ArrayNode) request).add(requestMap);
					}
				} else {
					loadPropertyFile(csvFileName);
					request = createEntityJSON(entityName, rootNode.get(entityName), csvFileName, row);
				}
			} else {
				log.warn("Entity name is not valid. Could not create any json.");
			}

		} catch (IOException e) {
			log.error("Error reading schema file:" + schema, e);
			throw new DataSeedingTransformerException("Error reading schema file:" + schema);
		}
		log.info("Completed transformation for API:" + entityName);
		return request;

	}

	/**
	 * This method creates a json for a configuration using the json schema
	 * mapping details.
	 * 
	 * @param entityName
	 *            The configuration name for which json is needed.
	 * @param rootNode
	 *            The json schema root node.
	 * @param csvFileName
	 *            Name of CSV file
	 * @param row
	 *            Key of row to read
	 * @return Json Node
	 * @throws DataSeedingTransformerException
	 */
	private JsonNode createEntityJSON(String entityName, JsonNode rootNode, String csvFileName, String row)
			throws DataSeedingTransformerException {
		// Map<String, String> keyJsonMap = new HashMap<>();
		JsonNode entityJson = null;
		SeedingDataEntity seedingDataEntity;
		try {
			seedingDataEntity = CSVDataSeedingTrnsUtils.getInstance().readEntityCSV(csvFileName, configDataDirectory,
					row);
		} catch (DataSeedingTransformerException e) {
			throw new DataSeedingTransformerException(e);
		}
		seedingDataEntityMap.put(entityName, seedingDataEntity);
		List<SeedingDataRecord> seedingDataRecords = seedingDataEntity != null
				? seedingDataEntity.getSeedingDataRecords() : null;

		if (seedingDataRecords != null && !seedingDataRecords.isEmpty()) {

			for (SeedingDataRecord seedDataRecord : seedingDataRecords) {
				String entityKey = seedDataRecord.getSeedData(CSV_HEADER_KEY);
				if (entityKey == null || entityKey.trim().isEmpty()) {
					log.error("No Key Header present for entity:" + entityName);
					continue;
				}
				entityJson = createEntityJSON(entityName, entityKey, rootNode, seedDataRecord);
			}
		}
		return entityJson;
	}

	private JsonNode createEntityJSON(String entityName, String entityKey, JsonNode rootNode,
			SeedingDataRecord seedDataRecord) {
		ObjectMapper mapper = new ObjectMapper();
		JsonNode reqNode = null;
		EntityJSONProcessData processData = new EntityJSONProcessData(entityName, entityKey, rootNode);
		Object entityJsonObject = createJSON(processData, seedDataRecord, null);
		String entityJsonString = null;
		try {
			entityJsonString = mapper.writeValueAsString(entityJsonObject);
			reqNode = mapper.readTree(entityJsonString);
		} catch (Exception e) {
			log.error("Error creaating json value for entiry name:" + entityName, e);
		}
		return reqNode;
	}

	/**
	 * This method creates the json data of entity for a csv row. This method
	 * traverses the schema mapping node and creates the json data using the
	 * mapping details. When this method encounters another entity in the json
	 * schema, it reads the corresponding entity.
	 * 
	 * The json property name is the expected column name in the corresponding
	 * csv file.
	 * 
	 * @param entityName
	 *            The configuration name for which json needs to be created.
	 * @param key
	 *            The Key value from the csv for the row.
	 * @param rootNode
	 *            The json schema mapping node.
	 * @param seedDataRecord
	 *            CSV row record
	 * @param propertyName
	 *            The name of the property from json schema.
	 * @return JSON data for the entity
	 */
	private Object createJSON(EntityJSONProcessData processData, final SeedingDataRecord seedDataRecord,
			String propertyName) {
		Object jsonData = null;
		String entityName = processData.getEntityName();
		String key = processData.getKey();
		JsonNode rootNode = processData.getRootNode();

		String nodeType = rootNode.get(JSON_SCHEMA_PROPERTY_TYPE) != null
				? rootNode.get(JSON_SCHEMA_PROPERTY_TYPE).asText() : "";

		if (JSON_SCHEMA_PROPERTY_ARRAY.equalsIgnoreCase(nodeType)) {
			entityName = propertyName;

		}

		if (JSON_SCHEMA_PROPERTY_OBJECT.equalsIgnoreCase(nodeType)) {
			Map<String, Object> jsonMap = new HashMap<String, Object>();
			jsonData = jsonMap;
			createPropertiesJson(processData, seedDataRecord, jsonMap, propertyName);

		} else if (JSON_SCHEMA_PROPERTY_ARRAY.equalsIgnoreCase(nodeType)) {
			List<Object> jsonList = new ArrayList<Object>();
			jsonData = jsonList;
			EntityJSONProcessData processDataNew = new EntityJSONProcessData(entityName, key, rootNode);
			processDataNew.setParentName(processData.getParentName());
			createArrayJSON(processDataNew, jsonList, seedDataRecord);
		} else {
			jsonData = CSVDataSeedingTrnsUtils.getInstance().getPropertyValue(processData, seedDataRecord, propertyName,
					simpleNodeMap);
		}
		return jsonData;
	}

	/**
	 * This method reads the csv data for the entity @param entityName and
	 * populate seedingDataEntityMap
	 * 
	 * @param entityName
	 *            The name of the entity for which the csv file data is
	 *            required.
	 */
	private void readEntityCSVInMap(String entityName) {
		if (!seedingDataEntityMap.containsKey(entityName)) {
			SeedingDataEntity seedingDataEntity = CSVDataSeedingTrnsUtils.getInstance().readEntityCSV(entityName,
					configDataDirectory);
			seedingDataEntityMap.put(entityName, seedingDataEntity);
		}
	}

	/**
	 * This method creates a list of json data objects for the entity name.
	 * 
	 * @param entityName
	 * @param key
	 * @param rootNode
	 * @param jsonList
	 * @param seedDataRecord
	 */
	private void createArrayJSON(EntityJSONProcessData processData, List<Object> jsonList,
			SeedingDataRecord seedDataRecord) {
		String entityName = processData.getEntityName();
		String key = processData.getKey();
		JsonNode rootNode = processData.getRootNode();

		JsonNode itemsNode = rootNode.get(JSON_SCHEMA_PROPERTY_ITEMS);
		processArrayTypes(entityName, itemsNode);

		String simpleLeafProp = simpleNodeMap.get(entityName);
		// if not null then entity is simple array type
		if (simpleLeafProp != null && !simpleLeafProp.isEmpty()) {
			jsonList.addAll(createSimpleArrayJson(processData, simpleLeafProp, seedDataRecord, itemsNode));
			return;
		}
		String entityCSVName = entityName;
		if (jsonHasDuplicateEntity(processData, entityName)) {
			entityCSVName = CSVDataSeedingTrnsSupport.getInstance().getXpathCSVNameFor(processData, entityName);

			if (entityCSVName.length() > AppConstants.MAXCSVLENGTH && prop != null)
				entityCSVName = getMappedCSVName(processData.getParentName() + "-" + entityName);

		}
		readEntityCSVInMap(entityCSVName);
		// read the csv file with entityName and read records with parent = key.
		// iterate over those records here with the key value.
		SeedingDataEntity seedingDataEntity = seedingDataEntityMap.get(entityCSVName);
		List<SeedingDataRecord> childEntityRecords = seedingDataEntity != null
				? seedingDataEntity.getSeedingDataRecordsForParent(key) : new ArrayList<>();
		if (childEntityRecords == null || childEntityRecords.isEmpty()) {
			return;
		}

		createArrayJson(processData, jsonList, itemsNode, childEntityRecords);
	}

	/**
	 * This method takes the fully qualified path of CSV and returns the mapped
	 * CSV name in property file.
	 * 
	 * @param entityName
	 *            Fully qualified name of CSV.
	 * @return mapped CSV name in the property file.
	 */
	private String getMappedCSVName(String entityName) {
		return (prop.getProperty(entityName)) == null ? entityName : prop.getProperty(entityName);
	}

	/**
	 * This method load the property file.
	 * 
	 * @param filename
	 *            : property file name
	 * @throws DataSeedingTransformerException
	 */
	private void loadPropertyFile(String filename) throws DataSeedingTransformerException {
		InputStream inStream = this.getClass().getClassLoader()
				.getResourceAsStream(configDataDirectory + "\\" + filename + ".properties");

		if (inStream != null) {
			prop = new Properties();
			try {
				prop.load(inStream);
			} catch (IOException ex) {
				log.error("Error reading file " + configDataDirectory + System.getProperty("path.separator") + filename
						+ ".properties", ex);
				throw new DataSeedingTransformerException(ex);
			}
		}
	}

	private boolean jsonHasDuplicateEntity(EntityJSONProcessData processData, String entityName) {
		String csvName = processData.getParentName() + "-" + entityName;
		return duplicateEntityMap.containsKey(csvName);
	}

	private void checkDuplicateEntity(EntityJSONProcessData processData, String propertyName) {

		String entityName = processData.getEntityName();
		JsonNode rootNode = processData.getRootNode();

		String nodeType = rootNode.get(JSON_SCHEMA_PROPERTY_TYPE) != null
				? rootNode.get(JSON_SCHEMA_PROPERTY_TYPE).asText() : "";

		if (JSON_SCHEMA_PROPERTY_ARRAY.equalsIgnoreCase(nodeType)) {
			entityName = propertyName;
			processArrayTypes(entityName, rootNode.get(JSON_SCHEMA_PROPERTY_ITEMS));
			checkDuplicateInArrayTypes(processData, propertyName, entityName, rootNode);
		} else if (JSON_SCHEMA_PROPERTY_OBJECT.equalsIgnoreCase(nodeType)) {
			checkDuplicateInObjectTypes(processData, propertyName, rootNode);

		} else {
			return;
		}

	}

	public void checkDuplicateInObjectTypes(EntityJSONProcessData processData, String propertyName, JsonNode rootNode) {
		JsonNode propertiesNode = rootNode.get(JSON_SCHEMA_PROPERTY_PROPERTIES);
		if (propertiesNode != null) {
			Iterator<Entry<String, JsonNode>> propertyIterqtor = propertiesNode.fields();
			while (propertyIterqtor.hasNext()) {
				Entry<String, JsonNode> entry = propertyIterqtor.next();
				EntityJSONProcessData processDataNew = new EntityJSONProcessData(processData.getEntityName(),
						processData.getKey(), entry.getValue());

				String nestedParentName = StringUtils.isBlank(propertyName) ? "" : propertyName;

				nestedParentName = StringUtils.isBlank(processData.getParentName()) ? nestedParentName
						: processData.getParentName() + "-" + nestedParentName;
				processDataNew.setParentName(nestedParentName);
				checkDuplicateEntity(processDataNew, entry.getKey());
			}
		}
	}

	public void checkDuplicateInArrayTypes(EntityJSONProcessData processData, String propertyName, String entityName,
			JsonNode rootNode) {
		if (simpleNodeMap.get(entityName) == null && arrayLeafNodeMap.get(entityName) == null) {
			if (complextArrayParentNameMap.containsValue(entityName)) {
				CSVDataSeedingTrnsSupport.getInstance().addToDuplicateEntityMap(processData, entityName,
						complextArrayParentNameMap, duplicateEntityMap);
			}
			complextArrayParentNameMap.put(
					CSVDataSeedingTrnsSupport.getInstance().getXpathCSVNameFor(processData, entityName), entityName);
			EntityJSONProcessData processDataNew = new EntityJSONProcessData(entityName, null,
					rootNode.get(JSON_SCHEMA_PROPERTY_ITEMS));
			processDataNew.setParentName(processData.getParentName());
			// checkDuplicateEntity(processDataNew, propertyName); commented
			// because array inside array should not be checked for
			// duplicacy.This logic is in sync with template generation
		}
	}

	private void createArrayJson(EntityJSONProcessData processData, List<Object> jsonList, JsonNode itemsNode,
			List<SeedingDataRecord> childEntityRecords) {
		String entityName = processData.getEntityName();
		String key = processData.getKey();
		String arrayTypeLeafNode = arrayLeafNodeMap.get(entityName);
		if (arrayTypeLeafNode != null && !arrayTypeLeafNode.isEmpty()) {
			for (SeedingDataRecord record : childEntityRecords) {
				jsonList.add(CSVDataSeedingTrnsUtils.getInstance().createArrayOfArrayJson(arrayTypeLeafNode, record));
			}
			return;
		}
		for (SeedingDataRecord record : childEntityRecords) {
			key = record.getSeedData("Key");
			EntityJSONProcessData processDataNew = new EntityJSONProcessData(entityName, key, itemsNode);
			jsonList.add(createJSON(processDataNew, record, null));
		}
	}

	/**
	 * @param entityName
	 * @param itemsNode
	 */
	private void processArrayTypes(String entityName, JsonNode itemsNode) {
		if (!simpleNodeMap.containsKey(entityName)) {
			String simpleLeafProp = CSVDataSeedingTrnsSupport.getInstance().hasSingleSimpleLeaf(entityName, itemsNode,
					leafNodeTypes);
			simpleNodeMap.put(entityName, simpleLeafProp);
		}

		if (!arrayLeafNodeMap.containsKey(entityName)) {
			String arrayTypeLeafNode = CSVDataSeedingTrnsSupport.getInstance().hasArrayTypeLeaf(entityName, itemsNode,
					leafNodeTypes);
			arrayLeafNodeMap.put(entityName, arrayTypeLeafNode);
		}
	}

	private List<Object> createSimpleArrayJson(EntityJSONProcessData processData, String simpleLeafProp,
			SeedingDataRecord seedDataRecord, JsonNode itemsNode) {
		List<Object> jsonList = new ArrayList<>();
		String entityName = processData.getEntityName();
		String key = processData.getKey();

		String headername = entityName.equals(simpleLeafProp) ? simpleLeafProp
				: entityName + CSV_HEADER_SEPARATOR + simpleLeafProp;
		String headerNameCSV = StringUtils.isBlank(processData.getParentName()) ? headername
				: processData.getParentName() + "-" + headername;
		String separatedValues = seedDataRecord.getSeedData(headerNameCSV);
		String[] values = separatedValues != null ? separatedValues.split(CSV_VALUE_SEPARATOR) : null;
		EntityJSONProcessData processDataNew = new EntityJSONProcessData(entityName, key, itemsNode);
		processDataNew.setParentName(processData.getParentName());
		if (values != null && values.length > 0) {
			for (String value : values) {
				CSVSeedingDataRecord arrRecord = new CSVSeedingDataRecord();
				arrRecord.putRecord(headername, value);
				jsonList.add(createJSON(processDataNew, arrRecord, simpleLeafProp));
			}
		}
		return jsonList;
	}

	/**
	 * This method creates the json data objects for properties of json schema.
	 * 
	 * @param entityName
	 * @param key
	 * @param rootNode
	 * @param seedDataRecord
	 * @param jsonMap
	 * @param parentName
	 */
	private void createPropertiesJson(EntityJSONProcessData processData, SeedingDataRecord seedDataRecord,
			Map<String, Object> jsonMap, String parentName) {
		JsonNode rootNode = processData.getRootNode();
		JsonNode propertiesNode = rootNode.get(JSON_SCHEMA_PROPERTY_PROPERTIES);
		if (propertiesNode != null) {
			Iterator<Entry<String, JsonNode>> propertyIterqtor = propertiesNode.fields();
			while (propertyIterqtor.hasNext()) {
				Entry<String, JsonNode> entry = propertyIterqtor.next();
				String propertyNameKey = entry.getKey();
				EntityJSONProcessData processDataNew = new EntityJSONProcessData(processData.getEntityName(),
						processData.getKey(), entry.getValue());
				String nestedParentName = StringUtils.isBlank(parentName) ? "" : parentName;
				nestedParentName = StringUtils.isBlank(processData.getParentName()) ? nestedParentName
						: processData.getParentName() + "-" + nestedParentName;
				processDataNew.setParentName(nestedParentName);
				Object propertyJson = createJSON(processDataNew, seedDataRecord, entry.getKey());
				propertyNameKey = CSVDataSeedingTrnsUtils.getInstance().getPropertyNameForJson(propertyNameKey,
						propertyJson, isLegacyEntity);
				populateJsonMap(propertyNameKey, propertyJson, jsonMap);
			}
		}
	}

	private void populateJsonMap(String propertyNameKey, Object propertyJson, Map<String, Object> jsonMap) {
		if (propertyJson == null)
			jsonMap.put(propertyNameKey, propertyJson);
		else if (StringUtils.isNotBlank(propertyJson.toString())) {
			if (propertyJson instanceof Map) {
				@SuppressWarnings("rawtypes")
				Map objMap = (Map) propertyJson;
				if (!isObjectAnEmptyMap(objMap)) {
					jsonMap.put(propertyNameKey, propertyJson);
				}
			} else if (propertyJson instanceof List) {
				@SuppressWarnings("rawtypes")
				List objMap = (List) propertyJson;
				if (!objMap.isEmpty() && !isObjectAnEmptyMap(objMap.get(0))) {
					jsonMap.put(propertyNameKey, propertyJson);
				}
			} else {
				if (propertyJson instanceof String && ((String) propertyJson).equalsIgnoreCase("<blank>")) { // fix
																												// SUP-10030
					propertyJson = "";
				}
				jsonMap.put(propertyNameKey, propertyJson);
			}
		}
	}

	private boolean isObjectAnEmptyMap(Object object) {
		if (object instanceof Map) {
			@SuppressWarnings("rawtypes")
			Map objMap = (Map) object;
			return objMap.isEmpty();
		}
		return false;
	}

}
