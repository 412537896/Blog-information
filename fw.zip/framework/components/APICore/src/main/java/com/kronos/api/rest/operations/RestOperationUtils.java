package com.kronos.api.rest.operations;

import static com.jayway.restassured.RestAssured.given;

import org.apache.log4j.Logger;

import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;
import com.kronos.api.rest.base.BaseRestParameter;
import com.kronos.api.rest.exception.KronosCoreAPIException;
import com.kronos.report.Reporter;
import com.kronos.report.StepStatus;

public class RestOperationUtils {
	private static final String REQUEST_MSG = "Request: ";
	private static final String BREAK_LINE = "\n";
	protected static final Logger logger = Logger.getLogger(RestOperationUtils.class);
	protected static final Reporter reporter = Reporter.getInstance();
	
	private RestOperationUtils(){
		
	}
	
	public static Response post(String url, String payload, RequestSpecification spec, BaseRestParameter params) throws KronosCoreAPIException {
		Response res = null;
		try{
			String payloadOutput = (payload == null || payload.isEmpty()) ? "": reporter.generateFormatedPayload(payload);
			String infoMessage = BREAK_LINE + "<div> Type: [POST] </div>" 
								+ BREAK_LINE + "<div> Parameters: " + (params == null ? "[EMPTY]" : params.toString()) + "</div>"
								+ BREAK_LINE +"<div>  URI : " + url + "</div>" +  payloadOutput; 
			
			logger.info("Sending Request: [POST]: " + url);
			reporter.reportStep(StepStatus.INFO, REQUEST_MSG, infoMessage);
			
			if(payload == null){
				res = given().spec(spec).when().post(url);
			}else{
				res = given().spec(spec).body(payload).when().post(url);
			}
		}catch(Exception e){
			throw new KronosCoreAPIException(e);
		}
		return res;
	}

	public static Response get(String url, RequestSpecification spec, BaseRestParameter params) throws KronosCoreAPIException {
		Response res = null;
		try{
			String infoMessage = BREAK_LINE + "<div> Type: [GET] </div>" 
								+ BREAK_LINE + "<div> Parameters: " + (params == null ? "[EMPTY]" : params.toString()) + "</div>"
								+ BREAK_LINE + "<div> URI: " + url + "</div>"; 
			
			logger.info("Sending Request: [GET]: " + url);
			reporter.reportStep(StepStatus.INFO, REQUEST_MSG, infoMessage);
			
			res = given().spec(spec).when().get(url);
			
		}catch(Exception e){
			throw new KronosCoreAPIException(e);
		}
		return res;
	}

	public static Response put(String url, String payload, RequestSpecification spec, BaseRestParameter params) throws KronosCoreAPIException {
		Response res = null;
		try{
			String payloadOutput = (payload == null || payload.isEmpty()) ? "": reporter.generateFormatedPayload(payload);
			String infoMessage = BREAK_LINE + "<div> Type: [PUT] </div>" 
								+ BREAK_LINE + "<div> Parameters: " + (params == null ? "[EMPTY]" : params.toString()) + "</div>"
								+ BREAK_LINE + "<div>  URI : " + url + "</div>" + payloadOutput; 
			
			logger.info("Sending Request: [PUT]: " + url);
			reporter.reportStep(StepStatus.INFO, REQUEST_MSG, infoMessage);
			
			if(payload == null){
				res = given().spec(spec).when().put(url);
			}else{
				res = given().spec(spec).body(payload).when().put(url);
			}
		}catch(Exception e){
			throw new KronosCoreAPIException(e);
		}
		return res;
	}
	
	
	public static Response delete(String url, String payload, RequestSpecification spec, BaseRestParameter params) throws KronosCoreAPIException {
		Response res = null;
		try{
			String payloadOutput = payload == null ? "": reporter.generateFormatedPayload(payload);
			String infoMessage = BREAK_LINE + "<div> Type: [DELETE] </div>" 
								+ BREAK_LINE + "<div> Parameters: " + (params == null ? "[EMPTY]" : params.toString()) + "</div>"
								+ BREAK_LINE + "<div> URI : " + url + "</div>" + payloadOutput; 
			
			logger.info("Sending Request: [DELETE]: " + url);
			reporter.reportStep(StepStatus.INFO, REQUEST_MSG, infoMessage);
			
			if(payload == null){
				res = given().spec(spec).when().delete(url);
			}else{
				res = given().spec(spec).body(payload).when().delete(url);
			}
		}catch(Exception e){
			throw new KronosCoreAPIException(e);
		}
		return res;
	}
	
	
	public static Response patch(String url, String payload, RequestSpecification spec, BaseRestParameter params) throws KronosCoreAPIException {
		Response res = null;
		try{
			String payloadOutput = (payload == null || payload.isEmpty()) ? "": reporter.generateFormatedPayload(payload);
			String infoMessage = BREAK_LINE + "<div> Type: [PATCH] </div>" 
								+ BREAK_LINE + "<div> Parameters: " + (params == null ? "[EMPTY]" : params.toString()) + "</div>"
								+ BREAK_LINE +"<div>  URI : " + url + "</div>" +  payloadOutput; 
			
			logger.info("Sending Request: [PATCH]: " + url);
			reporter.reportStep(StepStatus.INFO, REQUEST_MSG, infoMessage);
			
			if(payload == null){
				res = given().spec(spec).when().patch(url);
			}else{
				res = given().spec(spec).body(payload).when().patch(url);
			}
		}catch(Exception e){
			throw new KronosCoreAPIException(e);
		}
		return res;
	}
	
}
