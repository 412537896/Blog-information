package com.kronos.requestgenerator.reader.csv;

import java.util.List;
import java.util.Map;

import com.kronos.requestgenerator.api.reader.SeedingDataRecord;
import com.univocity.parsers.common.processor.RowProcessor;

public interface CSVRowProcessor extends RowProcessor{

	public List<SeedingDataRecord> getRowValuesMapList();
	public Map<String, List<Integer>> getParentIndexMap();
	public void setRowNumber(String row);
}
