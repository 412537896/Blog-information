package com.kronos.requestgenerator.reader.csv;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.apache.commons.lang.StringUtils;

import com.kronos.requestgenerator.reader.csv.CSVColumnDataProcessor;
import com.kronos.requestgenerator.reader.csv.CSVRowProcessor;
import com.kronos.requestgenerator.reader.csv.CSVSeedingDataRecord;
import com.kronos.requestgenerator.api.reader.SeedingDataRecord;
import com.univocity.parsers.common.ParsingContext;

/**
 * Custom row list processor for mapping csv row values with columns.
 * 
 * @author Abhishek.Omar
 *
 */
public class CSVSelectedRowProcessor implements CSVRowProcessor {

	private List<SeedingDataRecord> rowValuesMapList;
	private Map<String, List<Integer>> parentIndexMap;
	private String[] headers;
	private String rowId = "";
	
	public CSVSelectedRowProcessor(String row)
	{
		setRowNumber(row);
	}
	
	public CSVSelectedRowProcessor()
	{
		
	}

	@Override
	public void processEnded(ParsingContext parsingContext) {
		// Nothing to do here.
	}

	@Override
	public void processStarted(ParsingContext parsingContext) {
		rowValuesMapList = new ArrayList<>();
		parentIndexMap = new HashMap<>();
	}

	@Override
	public void rowProcessed(String[] row, ParsingContext parsingContext) {
		getHeaders(parsingContext);
		CSVSeedingDataRecord rowValueMap = new CSVSeedingDataRecord();
		for (int i = 0; i < headers.length; i++) {
			String columnName = headers[i];
			String value = row[i];
			if (StringUtils.isNotBlank(value))
			{
				value = CSVColumnDataProcessor.replaceTwoVerticalLineToComma(value);
				if (CSVColumnDataProcessor.isDatePattern(value))
					value = CSVColumnDataProcessor.evalDate(value);
			}
			rowValueMap.putRecord(columnName, value);
		}

		if ((rowId=="")||
				((StringUtils.isNotBlank(rowId)) 
				&& (rowValueMap.getSeedData("Key").equalsIgnoreCase(rowId)) 
				&& (StringUtils.isBlank(rowValueMap.getSeedData("Parent")))))
		{
			rowValuesMapList.add(rowValueMap);
		String parent = rowValueMap.getSeedData("Parent");
		if (StringUtils.isNotBlank(parent)) {
			List<Integer> indexList = Optional.ofNullable(
					parentIndexMap.get(parent)).orElse(new ArrayList<>());
			parentIndexMap.put(parent, indexList);
			indexList.add(rowValuesMapList.size() - 1);
		}
		}
	}

	/**
	 * This method returns a list of all records in csv mapped as
	 * SeedingDataRecord.
	 * 
	 * @return list of all records in csv mapped as SeedingDataRecord.
	 */
	public List<SeedingDataRecord> getRowValuesMapList() {
		return rowValuesMapList;
	}

	/**
	 * @return map of parent and associated indexes
	 */
	public Map<String, List<Integer>> getParentIndexMap() {
		return parentIndexMap;
	}
	
	private String[] getHeaders(ParsingContext parsingContext){
		if(headers == null){
			headers = parsingContext.headers();
		}
		return headers;
	}
	
	@Override
	public void setRowNumber(String rowNumber)
	{
		this.rowId = rowNumber;
	}
}
