package com.kronos.requestgenerator.api.reader;

/**
 * Interface for holding records for data seeding.
 * 
 * @author Abhishek.Omar
 *
 */
public interface SeedingDataRecord {

	/**
	 * @param mappingName
	 *            key/column for the mapping.
	 * @return the mapped value against key/column.
	 */
	String getSeedData(final String mappingName);

}
