package com.kronos.operations;

import static com.jayway.restassured.RestAssured.given;
import static org.junit.Assert.assertEquals;

import java.util.HashMap;
import java.util.Map;

import org.junit.BeforeClass;
import org.junit.Test;

import com.jayway.restassured.http.ContentType;
import com.kronos.api.rest.auth.FalconAuthenticator;
import com.kronos.api.rest.base.BaseRestParameter;
import com.kronos.api.rest.driver.APIDriver;
import com.kronos.api.rest.exception.KronosCoreAPIException;
import com.kronos.api.rest.json.Request;
import com.kronos.api.rest.operations.APIResponse;
import com.kronos.context.ExecutionContext;
import com.kronos.exception.KronosCoreCommonException;
import com.kronos.mockServices.MockAPIObject;
import com.kronos.mockServices.MockService;
import com.kronos.report.Reporter;



public class TestApiDriver extends MockService{

	
	static APIDriver apiDriver;
	static Reporter reporter ;
	private static HashMap<String, String> parameterMap;
	private static ExecutionContext context;
	
	@BeforeClass
	public static void setUp() throws KronosCoreCommonException
	{
		context = new ExecutionContext();
		context.setOpenAmServer("http://localhost:9999/MockService/loginService");
		context.setBackEndServer("http://localhost:9999/");
		//context.setTenant("testTenant");
		context.setTenant("combined");
		apiDriver = new APIDriver(new FalconAuthenticator(context));
		parameterMap = new HashMap<String,String>();
		parameterMap.put("deepReporting","True");
		parameterMap.put("runMode","");
		reporter = Reporter.getInstance();
		reporter.initializeReport("","",parameterMap);
		String[] groups = {"P0"};
		String[] dependsOnMethods = {"TestSetup"};
		reporter.startTest("loginTest", "loginTest", groups, "location",dependsOnMethods);
		startMockedServices();
	}

	
	@Test()
	public void testGetWithQueryParameterParamMap() throws KronosCoreAPIException
	{
		apiDriver.setCookies("test");
		//test with old parameter map approach
		String URI ="/ShiftMockService/getShiftWithQueryParameter";
		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put("tenantId", "combined");
		map.put("id", 9);
		APIResponse res = apiDriver.get(URI,map);
		assertEquals(200,res.getStatusCode());
		assertEquals(9514,res.getNodeValue("id"));
		assertEquals(true,res.getNodeValue("posted"));
		assertEquals("People can WFH",res.getNodeValue("commentNotes[0].notes[0].text"));
	}
	
	@SuppressWarnings("unchecked")
	@Test()
	public void testGetWithQueryParameterBaseParamObject() throws KronosCoreAPIException
	{
		apiDriver.setCookies("test");
		//test with new BaseRestParameter
		String URI ="ShiftMockService/getShiftWithQueryParameter";
		BaseRestParameter params = new BaseRestParameter();
		params.setQuery("id", 9);
		params.setQuery("tenantId", "combined");
		APIResponse res = apiDriver.get(URI,params);
		assertEquals(200,res.getStatusCode());
		assertEquals(9514,res.getNodeValue("id"));
		assertEquals(true,res.getNodeValue("posted"));
		assertEquals("People can WFH",res.getNodeValue("commentNotes[0].notes[0].text"));
	}
	
	@Test()
	public void testGetWithPathParameterParamMap() throws KronosCoreAPIException
	{
		apiDriver.setCookies("test");
		//test with old parameter map approach
		String URI ="ShiftMockService/getShiftWithPathParameter/{sid}";
		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put("sid", 9);
		APIResponse res = apiDriver.get(URI,map);
		assertEquals(200,res.getStatusCode());
		assertEquals(9514,res.getNodeValue("id"));
		assertEquals(true,res.getNodeValue("posted"));
		assertEquals("People can WFH",res.getNodeValue("commentNotes[0].notes[0].text"));
	}
	/*
	@Test()
	public void testGetWithPathParameterBaseParamObject() throws KronosCoreAPIException
	{
		apiDriver.setCookies("test");
		MockAPIObject apiObj = new MockAPIObject(apiDriver);
		//context.setTenant("");
		APIResponse res =  apiObj.getWithPathParameter(9);
		
		assertEquals(200,res.getStatusCode());
		assertEquals(9514,res.getNodeValue("id"));
		assertEquals(true,res.getNodeValue("posted"));
		assertEquals("People can WFH",res.getNodeValue("commentNotes[0].notes[0].text"));
	}*/
	
	@Test
	public void testPostWithPathParameterParamMap() throws KronosCoreAPIException{
		apiDriver.setCookies("test");
		
		String URI ="ShiftMockService/createShiftWithPathParameter/{sid}";
		Map<String,Object> map = new HashMap<String, Object>();
		map.put("sid", "3");
		
		APIResponse res = apiDriver.post(URI,map);
		assertEquals(200,res.getStatusCode());
		assertEquals(9514,res.getNodeValue("id"));
		assertEquals(true,res.getNodeValue("posted"));
		assertEquals("People can WFH",res.getNodeValue("commentNotes[0].notes[0].text"));
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void testPostWithPathParameterBaseParamObject() throws KronosCoreAPIException{
		apiDriver.setCookies("test");
		
		String URI ="ShiftMockService/createShiftWithPathParameter/{sid}";
		BaseRestParameter params = new BaseRestParameter();
		params.setPath("sid", 9);
		APIResponse res = apiDriver.post(URI,params);
		assertEquals(200,res.getStatusCode());
		assertEquals(9514,res.getNodeValue("id"));
		assertEquals(true,res.getNodeValue("posted"));
		assertEquals("People can WFH",res.getNodeValue("commentNotes[0].notes[0].text"));
	}
	
	
	
	@Test
	public void testPostWithBodyParamMap() throws KronosCoreAPIException
	{
		apiDriver.setCookies("test");
	
		Request payload = new Request ("{\"employee\":{\"id\":178,\"qualifier\":\"396\"}}");
		String URI ="ShiftMockService/createShiftWithQueryParam";
		
		Map<String,Object> map = new HashMap<String, Object>();
		map.put("tenantId", "combined");
		
		APIResponse res=apiDriver.post(URI,payload,map);
		
		assertEquals(200,res.getStatusCode());
		assertEquals(9514,res.getNodeValue("id"));
		assertEquals(true,res.getNodeValue("posted"));
		assertEquals("People can WFH",res.getNodeValue("commentNotes[0].notes[0].text"));
	}
	
	@Test
	public void testPostWithBodyBaseParamObject() throws KronosCoreAPIException
	{
		apiDriver.setCookies("test");
	
		Request payload = new Request ("{\"employee\":{\"id\":178,\"qualifier\":\"396\"}}");
		String URI ="ShiftMockService/createShiftWithQueryParam";
		
		BaseRestParameter params = new BaseRestParameter();
		params.setQuery("tenantId", "combined");
		
		APIResponse res=apiDriver.post(URI,params,payload);
		
		assertEquals(200,res.getStatusCode());
		assertEquals(9514,res.getNodeValue("id"));
		assertEquals(true,res.getNodeValue("posted"));
		assertEquals("People can WFH",res.getNodeValue("commentNotes[0].notes[0].text"));
	}
	
	@Test
	public void testPostWithUserDefinedContext() throws KronosCoreAPIException
	{
		apiDriver.setCookies("test");
	
		Request payload = new Request ("{\"employee\":{\"id\":178,\"qualifier\":\"396\"}}");
		String URI ="ShiftMockService/createShiftWithQueryParam?tenantId=combined";
		APIResponse res=apiDriver.post(URI,
				new BaseRestParameter(),
				payload,
				given().contentType("charset=UTF-8").accept(ContentType.JSON).contentType(ContentType.URLENC));
		
		assertEquals(200,res.getStatusCode());
		assertEquals(9514,res.getNodeValue("id"));
		assertEquals(true,res.getNodeValue("posted"));
		assertEquals("People can WFH",res.getNodeValue("commentNotes[0].notes[0].text"));
	}

   @Test
   public void testPostWithPathParameterBaseParamObjectStateful() throws KronosCoreAPIException{
      apiDriver.setCookies("test");

      String URI ="ShiftMockService/createShiftWithPathParameter/{sid}";
      BaseRestParameter params = new BaseRestParameter();
      params.setPath("sid", 9);
      APIResponse res = apiDriver.post(URI,
            params,
            given().contentType("charset=UTF-8").accept(ContentType.JSON).contentType(ContentType.URLENC));
      assertEquals(200,res.getStatusCode());
      assertEquals(9514,res.getNodeValue("id"));
      assertEquals(true,res.getNodeValue("posted"));
      assertEquals("People can WFH",res.getNodeValue("commentNotes[0].notes[0].text"));
   }

	@Test
	public void testPutWithPathParameterParamMap() throws KronosCoreAPIException{
		apiDriver.setCookies("test");
		
		String URI ="ShiftMockService/updateShiftWithPathParam/{updateShift}";
		Map<String,Object> map = new HashMap<String, Object>();
		map.put("updateShift", "9");
		APIResponse res = apiDriver.put(URI,map);
		assertEquals(200,res.getStatusCode());
		assertEquals(9514,res.getNodeValue("id"));
		assertEquals(true,res.getNodeValue("posted"));
		assertEquals("People can WFH",res.getNodeValue("commentNotes[0].notes[0].text"));
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void testPutWithPathParameterBaseParamObj() throws KronosCoreAPIException{
		apiDriver.setCookies("test");
		
		String URI ="ShiftMockService/updateShiftWithPathParam/{updateShift}";
		
		BaseRestParameter params = new BaseRestParameter();
		params.setPath("updateShift", 9);
		
		APIResponse res = apiDriver.put(URI,params);
		assertEquals(200,res.getStatusCode());
		assertEquals(9514,res.getNodeValue("id"));
		assertEquals(true,res.getNodeValue("posted"));
		assertEquals("People can WFH",res.getNodeValue("commentNotes[0].notes[0].text"));

	}
	
	@Test
	public void testPutWithBodyParamMap() throws KronosCoreAPIException
	{
		apiDriver.setCookies("test");
		Request payload = new Request ("{\"employee\":{\"id\":178,\"qualifier\":\"396\"}}");
		String URI ="ShiftMockService/updateShiftWithQueryParam";
		Map<String,Object> map = new HashMap<String, Object>();
		map.put("tenantId", "combined");
		
		APIResponse res = apiDriver.put(URI,payload,map);
		
		assertEquals(200,res.getStatusCode());
		assertEquals(9514,res.getNodeValue("id"));
		assertEquals(true,res.getNodeValue("posted"));
		assertEquals("People can WFH",res.getNodeValue("commentNotes[0].notes[0].text"));
	}
	
	@Test
	public void testPutWithBodyBaseParamObj() throws KronosCoreAPIException
	{
		apiDriver.setCookies("test");
		Request payload = new Request ("{\"employee\":{\"id\":178,\"qualifier\":\"396\"}}");
		String URI ="ShiftMockService/updateShiftWithQueryParam";

		BaseRestParameter params = new BaseRestParameter();
		params.setQuery("tenantId", "combined");
		
		APIResponse res = apiDriver.put(URI,params,payload);
		
		assertEquals(200,res.getStatusCode());
		assertEquals(9514,res.getNodeValue("id"));
		assertEquals(true,res.getNodeValue("posted"));
		assertEquals("People can WFH",res.getNodeValue("commentNotes[0].notes[0].text"));
	}

	@Test
	public void testPutWithUserDefinedContext() throws KronosCoreAPIException
	{
		apiDriver.setCookies("test");
	
		apiDriver.setCookies("test");
		Request payload = new Request ("{\"employee\":{\"id\":178,\"qualifier\":\"396\"}}");
		String URI ="ShiftMockService/updateShiftWithQueryParam";

		BaseRestParameter params = new BaseRestParameter();
		params.setQuery("tenantId", "combined");
		
		APIResponse res = apiDriver.put(URI,params,payload,
				given().contentType("charset=UTF-8").accept(ContentType.JSON).contentType(ContentType.URLENC));
		
		assertEquals(200,res.getStatusCode());
		assertEquals(9514,res.getNodeValue("id"));
		assertEquals(true,res.getNodeValue("posted"));
		assertEquals("People can WFH",res.getNodeValue("commentNotes[0].notes[0].text"));
	}

   @Test
   public void testPutWithPathParameterBaseParamObjectStateful() throws KronosCoreAPIException{
      apiDriver.setCookies("test");

      String URI ="ShiftMockService/updateShiftWithPathParam/{updateShift}";
      BaseRestParameter params = new BaseRestParameter();
      params.setPath("updateShift", "9");
      APIResponse res = apiDriver.put(URI,params,
            given().contentType("charset=UTF-8").accept(ContentType.JSON).contentType(ContentType.URLENC));
      assertEquals(200,res.getStatusCode());
      assertEquals(9514,res.getNodeValue("id"));
      assertEquals(true,res.getNodeValue("posted"));
      assertEquals("People can WFH",res.getNodeValue("commentNotes[0].notes[0].text"));
   }

	@Test
	public void testDeletePathParameterParamMap() throws KronosCoreAPIException
	{
		apiDriver.setCookies("test");
		
		String URI ="ShiftMockService/deleteShiftWithPathParam/{deleteShift}";
		Map<String,Object> map = new HashMap<String, Object>();
		map.put("deleteShift", "9");
		APIResponse res = apiDriver.delete(URI,map);
		assertEquals(res.getStatusCode(), 204);
	}
	
	@Test
	public void testDeletePathParameterBaseParamObj() throws KronosCoreAPIException
	{
		apiDriver.setCookies("test");
		
		String URI ="ShiftMockService/deleteShiftWithPathParam/{deleteShift}";
		BaseRestParameter params = new BaseRestParameter();
		params.setPath("deleteShift", "9");
		APIResponse res = apiDriver.delete(URI,params);
		
		assertEquals(res.getStatusCode(), 204);
	}
	
	
	@Test
	public void testDeleteBodyParamMap() throws KronosCoreAPIException
	{
		apiDriver.setCookies("test");
		Request payload = new Request ("{\"employee\":{\"id\":178,\"qualifier\":\"396\"}}");
		
		String URI ="ShiftMockService/deleteShiftWithPathParam/{deleteShift}";
		Map<String,Object> map = new HashMap<String, Object>();
		map.put("deleteShift", "9");
		APIResponse res = apiDriver.delete(URI,payload,map);
		assertEquals(res.getStatusCode(), 204);
	}
	
	@Test
	public void testDeleteBodyBaseParamObj() throws KronosCoreAPIException
	{
		apiDriver.setCookies("test");
		Request payload = new Request ("{\"employee\":{\"id\":178,\"qualifier\":\"396\"}}");
		
		String URI ="ShiftMockService/deleteShiftWithPathParam/{deleteShift}";
		BaseRestParameter params = new BaseRestParameter();
		params.setPath("deleteShift", "9");
		APIResponse res = apiDriver.delete(URI,params,payload);
		
		assertEquals(res.getStatusCode(), 204);
	}

   @Test
   public void testDeleteWithPathParameterBaseParamObjectStateful() throws KronosCoreAPIException
   {
      apiDriver.setCookies("test");

      String URI ="ShiftMockService/deleteShiftWithPathParam/{deleteShift}";
      BaseRestParameter params = new BaseRestParameter();
      params.setPath("deleteShift", "9");
      APIResponse res = apiDriver.delete(URI,params,
            given().contentType("charset=UTF-8").accept(ContentType.JSON).contentType(ContentType.URLENC));
      assertEquals(res.getStatusCode(), 204);
   }
	
	@SuppressWarnings("unchecked")
	@Test
	public void testPatchWithPathParameterBaseParamObj() throws KronosCoreAPIException{
		apiDriver.setCookies("test");
		
		String URI ="ShiftMockService/updateShiftWithPathParam/{updateShift}";
		
		BaseRestParameter params = new BaseRestParameter();
		params.setPath("updateShift", 9);
		
		APIResponse res = apiDriver.patch(URI,params);
		assertEquals(200,res.getStatusCode());
		assertEquals(9514,res.getNodeValue("id"));
		assertEquals(true,res.getNodeValue("posted"));
		assertEquals("People can WFH",res.getNodeValue("commentNotes[0].notes[0].text"));

	}
	
	@Test
	public void testPatchWithBodyParams() throws KronosCoreAPIException
	{
		apiDriver.setCookies("test");
		Request payload = new Request ("{\"employee\":{\"id\":178,\"qualifier\":\"396\"}}");
		String URI ="ShiftMockService/updateShiftWithQueryParam";
		
		BaseRestParameter params = new BaseRestParameter();
		params.setQuery("tenantId", "combined");
		
		APIResponse res = apiDriver.patch(URI,params, payload);
		
		assertEquals(200,res.getStatusCode());
		assertEquals(9514,res.getNodeValue("id"));
		assertEquals(true,res.getNodeValue("posted"));
		assertEquals("People can WFH",res.getNodeValue("commentNotes[0].notes[0].text"));
	}
	
	
}

