package com.kronos.requestgenerator.test.reader.csv;

import static org.junit.Assert.*;

import java.net.URL;

import org.junit.Before;
import org.junit.Test;

import com.kronos.requestgenerator.api.reader.DataSeedingReader;
import com.kronos.requestgenerator.api.reader.DataSeedingReaderException;
import com.kronos.requestgenerator.api.reader.SeedingDataEntity;
import com.kronos.requestgenerator.reader.csv.CSVDataSeedingReader;

public class TestCSVDataSeedingReader {
	
	
	DataSeedingReader reader ;
	
	String parentFileName ;
	
	String childFileName;

	private URL resource;
	
	@Before
	public void setUp() {
		reader = new CSVDataSeedingReader();
		resource = this.getClass().getResource("/WSAFunctionAccessProfile.csv");
		parentFileName = resource.getPath();
		
		resource = this.getClass().getResource("/WSAPermission.csv");
		childFileName = resource.getPath();
	}
	
	@Test (expected = DataSeedingReaderException.class)
	public void testInvalidCSVFileName() throws DataSeedingReaderException {		
		reader.readData("aaaa");		
	}
	
	@Test
	public void testReadCSVWithoutParent() throws DataSeedingReaderException {
		
		SeedingDataEntity seedingDataEntity = reader.readData("WSAFunctionAccessProfile.csv");
		
		assertNotNull(seedingDataEntity);
		assertNotNull(seedingDataEntity.getSeedingDataRecords());
		assertTrue(seedingDataEntity.getParentIndexMap().isEmpty());
		assertNotNull(seedingDataEntity.getSeedingDataRecordsForParent("1"));
		
		assertFalse(seedingDataEntity.getSeedingDataRecords().isEmpty());
		assertEquals(1, seedingDataEntity.getSeedingDataRecords().size());
		
	}
	
	@Test
	public void testReadCSVWithParent() throws DataSeedingReaderException {
		
		SeedingDataEntity seedingDataEntity = reader.readData("WSAPermission.csv");
		
		assertNotNull(seedingDataEntity);
		assertNotNull(seedingDataEntity.getSeedingDataRecords());
		assertNotNull(seedingDataEntity.getParentIndexMap());
		assertNotNull(seedingDataEntity.getSeedingDataRecordsForParent("1"));
		
		assertFalse(seedingDataEntity.getSeedingDataRecords().isEmpty());
		assertEquals(2, seedingDataEntity.getSeedingDataRecords().size());
		
		assertEquals(2, seedingDataEntity.getSeedingDataRecordsForParent("All Access").size());
	}
	
	

}
