package com.kronos.operations;

import static com.jayway.restassured.RestAssured.when;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FileUtils;
//import org.json.simple.JSONObject;
import org.junit.BeforeClass;
import org.junit.Test;

import com.jayway.restassured.response.Response;
import com.kronos.api.rest.exception.KronosCoreAPIException;
import com.kronos.api.rest.operations.APIResponse;
import com.kronos.mockServices.MockService;

public class TestAPIResponse extends MockService{

	static String url;
	static Response res;
	static APIResponse apiResponse;
	
	@BeforeClass
	public  static void executeBeforeClass() {
		url = "http://localhost:9999/ShiftMockService/getShiftWithQueryParameter?id=1&tenantId=combined";
		res = when().get(url).then().extract().response();
		apiResponse = new APIResponse(res);
	}
 
	
	@Test
	public void test1_StatusCode() throws KronosCoreAPIException
	{
		assertEquals(200, apiResponse.getStatusCode());
	}
	
	@Test
	public void test2_getNodeValue() throws KronosCoreAPIException, IOException {
		assertEquals("", apiResponse.getNodeValue("commentNotess[0].comment.id"));
		assertEquals("", apiResponse.getNodeValue("commentNotes[0].comments.id"));
		assertEquals("", apiResponse.getNodeValue("commentNotes[0].comment.ids"));
		
		assertEquals(5, apiResponse.getNodeValue("commentNotes[0].comment.id"));
		Map<String, Object> commentmap = new HashMap();
		commentmap.put("id", 5);
		commentmap.put("name", "Union business");
		commentmap.put("active", true);
		assertEquals((Object)commentmap, apiResponse.getNodeValue("commentNotes[0].comment"));
	}
	
	@Test
	public void test3_getNodeValues() throws KronosCoreAPIException
	{
		HashMap<String,Object> obj = new HashMap<String,Object>();
		obj.put("text", "People can WFH");
		obj.put("timestamp", "2016-07-01T09:04:59");
		obj.put("dataSourceDisplayName", "TKCSOWNER");
		obj.put("dataSourceId", 1);
		obj.put("commentNoteId", 715);
		
		List<Object> actual = new ArrayList<Object>();
		actual.add(obj);
		assertEquals(actual,apiResponse.getNodeValues("commentNotes[0].notes"));
		assertEquals(Collections.emptyList(),apiResponse.getNodeValues("wrongJsonpath.notes"));
	}
	
	@Test
	public void test4_isNodePresent() throws KronosCoreAPIException{
		assertIsPresent("generated");
		assertIsPresent("employee.id");
		assertIsPresent("commentNotes[0].notes[0].text");
		assertIsPresent("commentNotes.notes.text");

		assertIsNotPresent("employeeId");
		assertIsNotPresent("commentNotes[0].notes[1].text");
		assertIsNotPresent("somePropertyThatDoesNotExist");
		assertIsNotPresent("some.chain.of.objects.that.do.not.exist");
		assertIsNotPresent("employee.propertyThatDoesNotExist");
		assertIsNotPresent("commentNotes.subPropertyThatDoesNotExistOnAnyInstanceOfArrayObject");
	}

	@Test
	public void test5_getJsonPathRegEx() throws KronosCoreAPIException{
		assertEquals(true, apiResponse.getJsonPathRegEx("commentNotes.notes", "[a-z]"));
		assertEquals(true, apiResponse.getJsonPathRegEx("commentNotes.notes", "[a-z]"));
		assertEquals(true, apiResponse.getJsonPathRegEx("segments[0].id", "[0-9]"));
		assertEquals(false, apiResponse.getJsonPathRegEx("segments[0].id", "[a-z]"));
	}
	
	@Test
	public void test6_getJsonPathCount() throws KronosCoreAPIException{
		assertEquals(1, apiResponse.getJsonPathCount("commentNotes"));
		assertEquals(1, apiResponse.getJsonPathCount("segments"));
		assertEquals(1, apiResponse.getJsonPathCount("commentNotes[0].notes"));
	}
	
	@Test
	public void test7_isInListOfHTTPCodes() throws KronosCoreAPIException
	{
		ArrayList<Integer> arrCodes= new ArrayList<>();
		arrCodes.add(201);
		arrCodes.add(200);
		assertEquals(true, apiResponse.isInListOfHTTPCodes(arrCodes));
		arrCodes.clear();
		arrCodes.add(400);
		assertEquals(false, apiResponse.isInListOfHTTPCodes(arrCodes));	
	}
	
	
	@Test
	public void test8_contains() throws KronosCoreAPIException
	{
		assertEquals(true,apiResponse.contains("People can WFH"));
		assertEquals(true,apiResponse.contains("715"));
		assertEquals(false, apiResponse.contains("REGULAR_SEGMENT_changed"));
	}
	

	
	@Test
	public void test9_assertJsonSort() throws KronosCoreAPIException
	{
		assertEquals(true,apiResponse.isJsonSort("commentNotes.comment", "id", true));
		assertEquals(true,apiResponse.isJsonSort("commentNotes.comment", "id",false));
		assertEquals(true,apiResponse.isJsonSort("segments", "id",true));
	}
	
	@Test
	public void test10_isJSONCompare() throws IOException, KronosCoreAPIException, URISyntaxException {
		
		String expectedJson = "";
		File file;
		
		//Get file from resources folder
		ClassLoader classLoader = getClass().getClassLoader();
		//file = new File(classLoader.getResource("testCompare1.json").getFile());
		file = new File(classLoader.getResource("testCompare1.json").toURI());
		
		expectedJson = FileUtils.readFileToString(file);
		assertEquals(true, apiResponse.isJSONCompare(expectedJson));

		file = new File(classLoader.getResource("testCompare2.json").toURI());
		assertEquals(true, apiResponse.isJSONCompare(file));
		
		file = new File(classLoader.getResource("testCompare3.json").toURI());
		assertEquals(true, apiResponse.isJSONCompare(file));
		
		file = new File(classLoader.getResource("testCompare4.json").toURI());
		assertEquals(false, apiResponse.isJSONCompare(file));
	}
	
	@Test
	public void test11_isJSONContains() throws IOException, KronosCoreAPIException, URISyntaxException {
		
		String expectedStr;
		File file;
		
		ClassLoader classLoader = getClass().getClassLoader();
		file = new File(classLoader.getResource("testContain1.json").toURI());
		
		
		expectedStr = FileUtils.readFileToString(file,"UTF-8");
		assertEquals(true, apiResponse.isJSONContains(expectedStr));

		// calling overloaded assertion with file
		file = new File(classLoader.getResource("testContain2.json").toURI());
		assertEquals(true, apiResponse.isJSONContains(file));
		
		file = new File(classLoader.getResource("testContain3.json").toURI());
		assertEquals(true, apiResponse.isJSONContains(file));
		// assertEquals(true, apiResponse.isJSONContainsFile("testContain3.json"));
		
		file = new File(classLoader.getResource("testContain4.json").toURI());
		assertEquals(false, apiResponse.isJSONContains(file));
		// assertEquals(false, apiResponse.isJSONContainsFile("testContain4.json"));
	}

	private void assertIsPresent(String jsonPath) throws KronosCoreAPIException {
		assertTrue(apiResponse.isNodePresent(jsonPath));
	}

	private void assertIsNotPresent(String jsonPath) throws KronosCoreAPIException {
		assertFalse(apiResponse.isNodePresent(jsonPath));
	}
	
}
