package com.kronos.objectBuilderHelper;


import static com.kronos.api.rest.json.JsonBuildHelper.build;
import static com.kronos.api.rest.json.JsonBuildHelper.list;
import static com.kronos.api.rest.json.JsonBuildHelper.map;
import static com.kronos.api.rest.json.JsonBuildHelper.mapInRange;
import static com.kronos.api.rest.json.JsonBuildHelper.objRef;
import static com.kronos.api.rest.json.JsonBuildHelper.mapWithSameValue;
import static org.junit.Assert.assertEquals;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kronos.api.rest.exception.KronosCoreAPIException;
import com.kronos.api.rest.json.Request;
import com.kronos.facade.DateGenerator;

public class TestBuilderHelper {
	private static final String FORMAT = "yyyy-MM-dd";
	private ObjectMapper mapper;
	DateGenerator dg;

	@Before
	public void setUp() throws Exception {
		HashMap<String,String> options = new HashMap<String,String>();
		options.put("dateFormat", FORMAT);
		dg = new DateGenerator(options);
		mapper = new ObjectMapper();

	}
	
	@Test
	public void testBuilderHelperTest() throws IOException, KronosCoreAPIException{
		String expectedPayLoad = "{\"startDateTime\" : \""+dg.getDateTime(2, "T22:30:19")+""+"\",\"commentNotes\" :"
				+ " [{\"comment\" : {\"name\" : \"some comments\",\"active\" : true,\"id\" : 20}},"
				+ "{\"comment\" : {\"name\" : \"another comments\",\"active\" : false,\"id\" : 21}}],"
				+ "\"employee\" : {\"id\" : 1,\"qualifier\" : \"382\"},\"endDateTime\" : \""+dg.getWeekAs(2)+"T22:30:19\","
				+ "\"segments\" : [{\"workruleRef\" : {\"id\" : 2, \"qualifier\" : \"Full time\"},\"type\" : \"REGULAR_SEGMENT\",\"orgJobRef\" : {\"qualifier\" : \"Organization/Division 1/Facility 1/Store 2/Department 21/Register\"}},"
				+ "{\"workruleRef\" : {\"qualifier\" : \"Part time\"},\"type\" : \"TRANSFER_SEGMENT\",\"skillCertProfileRefs\" : [{\"qualifier\" : \"CP001\"}],\"orgJobRef\" : {\"qualifier\" : \"Organization/Division 1/Facility 1/Store 2/Department 22/RN\"}}]}";
		
		//String schemaLocation = new java.io.File(".").getCanonicalPath() + "\\resources\\unitTest\\schema\\shift.json";
		ClassLoader classLoader = getClass().getClassLoader();
		File file = new File(classLoader.getResource("schema/shift.json").getFile());
		String schemaLocation = "schema/shift.json";
		Request req = build(schemaLocation,
				map(
						"startDateTime", dg.getDateTime(2, "T22:30:19"),
						"commentNotes", list( 
										map(
												"comment" , map("name","some comments", "active", true, "id", 20)
										),
										map(
												"comment" , map("name","another comments", "active", false, "id", 21)
										)
								),
						"employee", objRef("382",1),
						"endDateTime", "{{{2w}}}T22:30:19",
						"segments",
						list(
								map(
										"workruleRef", objRef("Full time",2),
										"type", "REGULAR_SEGMENT",
										"orgJobRef", objRef("Organization/Division 1/Facility 1/Store 2/Department 21/Register")
								), 
								map( 
										"workruleRef", objRef("Part time"),
										"type", "TRANSFER_SEGMENT",
										"skillCertProfileRefs", list(
																	objRef("CP001")
																),
										"orgJobRef",	objRef("Organization/Division 1/Facility 1/Store 2/Department 22/RN")
								)
						)
				)
		);
		String payload = req.getRequest().toString();
		String actualPrettyPrint = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(mapper.readTree(payload));
		String expectedPrettyPrint = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(mapper.readTree(expectedPayLoad));
		assertEquals(expectedPrettyPrint.trim(),actualPrettyPrint.trim());
	}
	
	@Test
	public void testBuilderHelperForMapTest() throws IOException, KronosCoreAPIException{
		String expectedPayLoad = "{\"startDateTime\" : \""+dg.getDateTime(2, "T22:30:19")+""+"\",\"commentNotes\" :"
				+ " [{\"comment\" : {\"name\" : \"TODAY is the test\",\"active\" : true,\"id\" : 20}},"
				+ "{\"comment\" : {\"name\" : \"another comments\",\"active\" : false,\"id\" : 21}}],"
				+ "\"employee\" : {\"id\" : 1,\"qualifier\" : \"382\"},\"endDateTime\" : \"2016-07-23T22:30:19\","
				+ "\"segments\" : [{\"startDateTime\" : \""+dg.getDateTime(0, "T08:00:00")+"\",\"workruleRef\" : {\"qualifier\" : \"Full time\", \"id\" : 2},\"type\" : \"REGULAR_SEGMENT\",\"endDateTime\" : \""+dg.getDateTime(0, "T08:00:00")+"\",\"orgJobRef\" : {\"qualifier\" : \"Organization/Division 1/Facility 1/Store 2/Department 21/Register0\"}},"
				+ "{\"startDateTime\" : \""+dg.getDateTime(1, "T08:00:00")+"\",\"workruleRef\" : {\"qualifier\" : \"Full time\", \"id\" : 2},\"type\" : \"REGULAR_SEGMENT\",\"endDateTime\" : \""+dg.getDateTime(1, "T08:00:00")+"\",\"orgJobRef\" : {\"qualifier\" : \"Organization/Division 1/Facility 1/Store 2/Department 21/Register1\"}}]}";
		
		//String schemaLocation = new java.io.File(".").getCanonicalPath() + "\\resources\\unitTest\\schema\\shift.json";
		ClassLoader classLoader = getClass().getClassLoader();
		File file = new File(classLoader.getResource("schema/shift.json").getFile());
		String schemaLocation = "schema/shift.json";
		Request req = build(schemaLocation,
				map(
						"startDateTime", dg.getDateTime(2, "T22:30:19"),
						"commentNotes", list( 
										map(
												"comment" , map("name","TODAY is the test", "active", true, "id", 20)
										),
										map(
												"comment" , map("name","another comments", "active", false, "id", 21)
										)
								),
						"employee", objRef("382",1),
						"endDateTime", "2016-07-23T22:30:19",
						"segments",
						mapInRange(0,1,
								map(
										"workruleRef", objRef("Full time",2),
										"type", "REGULAR_SEGMENT",
										"startDateTime", "{{{[index]d}}}T08:00:00",
							            "endDateTime", "{{{[index]d}}}T08:00:00",
										"orgJobRef", objRef("Organization/Division 1/Facility 1/Store 2/Department 21/Register[index]")
								)
						)
						
				)
		);
		String payload = req.getRequest().toString();
		String actualPrettyPrint = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(mapper.readTree(payload));
		String expectedPrettyPrint = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(mapper.readTree(expectedPayLoad));
		assertEquals(expectedPrettyPrint.trim(),actualPrettyPrint.trim());
	}
	
	@Test
	public void testWithoutSchemaValidation() throws IOException, KronosCoreAPIException{
		String expectedPayLoad = "{\"startDateTime\" : \""+dg.getDateTime(2, "T22:30:19")+"\",\"commentNotes\" :"
				+ " [{\"comment\" : {\"name\" : \"some comments\",\"active\" : true,\"id\" : 20}},"
				+ "{\"comment\" : {\"name\" : \"another comments\",\"active\" : false,\"id\" : 21}}],"
				+ "\"employee\" : {\"id\" : 1,\"qualifier\" : \"382\"},\"endDateTime\" : \"2016-07-23T22:30:19\","
				+ "\"segments\" : [{\"workruleRef\" : {\"id\" : 2, \"qualifier\" : \"Full time\"},\"type\" : \"REGULAR_SEGMENT\",\"orgJobRef\" : {\"qualifier\" : \"Organization/Division 1/Facility 1/Store 2/Department 21/Register\"}},"
				+ "{\"workruleRef\" : {\"qualifier\" : \"Part time\"},\"type\" : \"TRANSFER_SEGMENT\",\"skillCertProfileRefs\" : [{\"test\" : [{\"id\":1,\"active\":false}]}],\"orgJobRef\" : {\"qualifier\" : \"Organization/Division 1/Facility 1/Store 2/Department 22/RN\"}}]}";
		
		Request req = build(
				map(
						"startDateTime", dg.getDateTime(2, "T22:30:19"),
						"commentNotes", list( 
										map(
												"comment" , map(
																"name","some comments", 
																"active", true, 
																"id", 20
															)
										),
										map(
												"comment" , map(
																"name","another comments", 
																"active", false, 
																"id", 21
															)
										)
								),
						"employee", objRef("382",1),
						"endDateTime", "2016-07-23T22:30:19",
						"segments",
						list(
								map(
										"workruleRef", objRef("Full time",2),
										"type", "REGULAR_SEGMENT",
										"orgJobRef", objRef("Organization/Division 1/Facility 1/Store 2/Department 21/Register")
								), 
								map( 
										"workruleRef", objRef("Part time"),
										"type", "TRANSFER_SEGMENT",
										"skillCertProfileRefs", list(
																	map("test" , 
																			list(
																					map(
																						"id", 1,
																						"active", false
																					)
																				)
																	)
																),
										"orgJobRef",	objRef("Organization/Division 1/Facility 1/Store 2/Department 22/RN")
								)
						)
				)
		);
		String payloadWithoutValidation = req.getRequest().toString();
		String actualPrettyPrint = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(mapper.readTree(payloadWithoutValidation));
		String expectedPrettyPrint = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(mapper.readTree(expectedPayLoad));
//		System.out.println(actualPrettyPrint);
//		System.out.println(expectedPrettyPrint);
		assertEquals(expectedPrettyPrint.trim(),actualPrettyPrint.trim());
	}
	
	@Test
	public void testBuilderHelperListTest() throws IOException, KronosCoreAPIException{
		String expectedPayLoad = "[{\"startDateTime\" : \""+dg.getDateTime(2, "T22:30:19")+""+"\",\"commentNotes\" :"
				+ " [{\"comment\" : {\"name\" : \"some comments\",\"active\" : true,\"id\" : 20}},"
				+ "{\"comment\" : {\"name\" : \"another comments\",\"active\" : false,\"id\" : 21}}],"
				+ "\"employee\" : {\"id\" : 1,\"qualifier\" : \"382\"},\"endDateTime\" : \"2016-07-23T22:30:19\","
				+ "\"segments\" : [{\"startDateTime\" : \""+dg.getDateTime(0, "T08:00:00")+"\",\"workruleRef\" : {\"qualifier\" : \"Full time\", \"id\" : 2},\"type\" : \"REGULAR_SEGMENT\",\"endDateTime\" : \""+dg.getDateTime(0, "T08:00:00")+"\",\"orgJobRef\" : {\"qualifier\" : \"Organization/Division 1/Facility 1/Store 2/Department 21/Register0\"}},"
				+ "{\"startDateTime\" : \""+dg.getDateTime(1, "T08:00:00")+"\",\"workruleRef\" : {\"qualifier\" : \"Full time\", \"id\" : 2},\"type\" : \"REGULAR_SEGMENT\",\"endDateTime\" : \""+dg.getDateTime(1, "T08:00:00")+"\",\"orgJobRef\" : {\"qualifier\" : \"Organization/Division 1/Facility 1/Store 2/Department 21/Register1\"}}]}"
				+ ",{\"startDateTime\" : \""+dg.getDateTime(2, "T22:30:19")+""+"\",\"commentNotes\" :"
				+ " [{\"comment\" : {\"name\" : \"some comments\",\"active\" : true,\"id\" : 20}},"
				+ "{\"comment\" : {\"name\" : \"another comments\",\"active\" : false,\"id\" : 21}}],"
				+ "\"employee\" : {\"id\" : 1,\"qualifier\" : \"382\"},\"endDateTime\" : \"2016-07-23T22:30:19\","
				+ "\"segments\" : [{\"startDateTime\" : \""+dg.getDateTime(0, "T08:00:00")+"\",\"workruleRef\" : {\"qualifier\" : \"Full time\", \"id\" : 2},\"type\" : \"REGULAR_SEGMENT\",\"endDateTime\" : \""+dg.getDateTime(0, "T08:00:00")+"\",\"orgJobRef\" : {\"qualifier\" : \"Organization/Division 1/Facility 1/Store 2/Department 21/Register0\"}},"
				+ "{\"startDateTime\" : \""+dg.getDateTime(1, "T08:00:00")+"\",\"workruleRef\" : {\"qualifier\" : \"Full time\", \"id\" : 2},\"type\" : \"REGULAR_SEGMENT\",\"endDateTime\" : \""+dg.getDateTime(1, "T08:00:00")+"\",\"orgJobRef\" : {\"qualifier\" : \"Organization/Division 1/Facility 1/Store 2/Department 21/Register1\"}}]}]";
		//String schemaLocation = new java.io.File(".").getCanonicalPath() + "\\resources\\unitTest\\schema\\shift.json";
		ClassLoader classLoader = getClass().getClassLoader();
		File file = new File(classLoader.getResource("schema/shift.json").getFile());
		String schemaLocation = file.getAbsolutePath();
		Request payload = build(
				list(
						map(
							"startDateTime", dg.getDateTime(2, "T22:30:19"),
							"commentNotes", list( 
											map(
													"comment" , map("name","some comments", "active", true, "id", 20)
											),
											map(
													"comment" , map("name","another comments", "active", false, "id", 21)
											)
									),
							"employee", objRef("382",1),
							"endDateTime", "2016-07-23T22:30:19",
							"segments",
							mapInRange(0,1,
									map(
											"workruleRef", objRef("Full time",2),
											"type", "REGULAR_SEGMENT",
											"startDateTime", "{{{[index]d}}}T08:00:00",
								            "endDateTime", "{{{[index]d}}}T08:00:00",
											"orgJobRef", objRef("Organization/Division 1/Facility 1/Store 2/Department 21/Register[index]")
									)
							)
						),
						map(
								"startDateTime", dg.getDateTime(2, "T22:30:19"),
								"commentNotes", list( 
												map(
														"comment" , map("name","some comments", "active", true, "id", 20)
												),
												map(
														"comment" , map("name","another comments", "active", false, "id", 21)
												)
										),
								"employee", objRef("382",1),
								"endDateTime", "2016-07-23T22:30:19",
								"segments",
								mapInRange(0,1,
										map(
												"workruleRef", objRef("Full time",2),
												"type", "REGULAR_SEGMENT",
												"startDateTime", "{{{[index]d}}}T08:00:00",
									            "endDateTime", "{{{[index]d}}}T08:00:00",
												"orgJobRef", objRef("Organization/Division 1/Facility 1/Store 2/Department 21/Register[index]")
										)
								)
							)
					)
		);
		
		String actualPrettyPrint = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(mapper.readTree(payload.getRequest().toString()));
		String expectedPrettyPrint = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(mapper.readTree(expectedPayLoad));
		assertEquals(expectedPrettyPrint.trim(),actualPrettyPrint.trim());
	}
	
	@Test
	public void testVariousInputForEmptyList() throws KronosCoreAPIException, JsonProcessingException, IOException{
		Request payload = build(list());
				
		String actualPrettyPrint = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(mapper.readTree(payload.getRequest().toString()));
		String expectedPrettyPrint = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(mapper.readTree("[]"));
		assertEquals(expectedPrettyPrint.trim(),actualPrettyPrint.trim());
	
		
		payload = build(map(
			    "forEmployees", list(
			        map(
			            "employeeRef", map(
			                "qualifier", "382"
			            ),
			            "shifts", map(
			                "create", list(),
			                "update", list(
			                    map(
			                        "id", 2031,
			                        "employee", map(
			                            "qualifier", "618"
			                        ),
			                        "segments", list(
			                            map(
			                                "startDateTime", "2016-05-28T08:00:00",
			                                "endDateTime", "2016-05-28T16:00:00",
			                                "type", "TRANSFER_SEGMENT"
			                            )
			                        )
			                    )
			                )
			            )
			        )
			    )
			));
		
		
		actualPrettyPrint = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(mapper.readTree(payload.getRequest().toString()));
		expectedPrettyPrint = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(mapper.readTree("{\"forEmployees\": [{\"employeeRef\": {\"qualifier\": \"382\"},\"shifts\": { \"create\": [],\"update\": [{\"id\": 2031,\"employee\": {\"qualifier\": \"618\"},\"segments\": [{\"startDateTime\": \"2016-05-28T08:00:00\",\"endDateTime\": \"2016-05-28T16:00:00\", \"type\": \"TRANSFER_SEGMENT\"}]}]}}]}"));
		assertEquals(expectedPrettyPrint.trim(),actualPrettyPrint.trim());
	}
	
	@Test
	public void testVariousInputForList() throws KronosCoreAPIException, JsonProcessingException, IOException{
		Request payload = build(map("test",list(
				"test1",
				"test2",
				2
			)));
				
		String actualPrettyPrint = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(mapper.readTree(payload.getRequest().toString()));
		String expectedPrettyPrint = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(mapper.readTree("{\"test\":[\"test1\",\"test2\",2]}"));
		assertEquals(expectedPrettyPrint.trim(),actualPrettyPrint.trim());
		
		
		payload = build(list(
				map("testkey","value"),
				"test1",
				"test2",
				2
			));
		
		actualPrettyPrint = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(mapper.readTree(payload.getRequest().toString()));
		expectedPrettyPrint = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(mapper.readTree("[{\"testkey\" : \"value\"},\"test1\",\"test2\",2]"));
		assertEquals(expectedPrettyPrint.trim(),actualPrettyPrint.trim());
	}
	
	@Test
	public void testVariousInputForListComplicateExample() throws KronosCoreAPIException, JsonProcessingException, IOException{
		Request payload = build(map(
			    "glossary", map(
			            "title", "example glossary",
			            "GlossDiv", map(
			                "title", "S",
			                "GlossList", map(
			                    "GlossEntry", map(
			                        "ID", "SGML",
			                        "SortAs", "SGML",
			                        "GlossTerm", "Standard Generalized Markup Language",
			                        "Acronym", "SGML",
			                        "Abbrev", "ISO 8879,1986",
			                        "GlossDef", map(
			                            "para", "A meta-markup language, used to create markup languages such as DocBook.",
			                            "GlossSeeAlso", list(
			                                "GML",
			                                "XML"
			                            )
			                        ),
			                        "GlossSee", "markup"
			                    )
			                )
			            )
			        )
			    ));
		String expectedPayLoad = "{\"glossary\" : {\"title\" : \"example glossary\",\"GlossDiv\" : {\"title\" : \"S\",\"GlossList\" : "
				+ "{\"GlossEntry\" : {\"ID\" : \"SGML\",\"SortAs\" : \"SGML\",\"GlossTerm\" : \"Standard Generalized Markup Language\", "
				+ "\"Acronym\" : \"SGML\",\"Abbrev\" : \"ISO 8879,1986\",\"GlossDef\" : {\"para\" : \"A meta-markup language, "
				+ "used to create markup languages such as DocBook.\",\"GlossSeeAlso\" : [ \"GML\", \"XML\" ]},\"GlossSee\" : \"markup\"}}}}}";
				
		String actualPrettyPrint = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(mapper.readTree(payload.getRequest().toString()));
		String expectedPrettyPrint = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(mapper.readTree(expectedPayLoad));
		assertEquals(expectedPrettyPrint.trim(),actualPrettyPrint.trim());
		
		
		payload = build(map(
			    "RestResponse", map(
			            "messages", list(
			                "Total list(12) records found."
			            ),
			            "result", list(
			                map(
			                    "name", "Brunei Darussalam",
			                    "alpha2_code", "BN",
			                    "alpha3_code", "BRN"
			                ),
			                map(
			                    "name", "Burundi",
			                    "alpha2_code", "BI",
			                    "alpha3_code", "BDI"
			                )
			            )
			        )
			    ));
		
		expectedPayLoad = "{\"RestResponse\" : {\"messages\" : [ \"Total list(12) records found.\" ],\"result\" : [ { \"name\" : "
				+ "\"Brunei Darussalam\", \"alpha2_code\" : \"BN\", \"alpha3_code\" : \"BRN\"}, { \"name\" : \"Burundi\",\"alpha2_code\" : "
				+ "\"BI\", \"alpha3_code\" : \"BDI\"}]}}";
		actualPrettyPrint = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(mapper.readTree(payload.getRequest().toString()));
		expectedPrettyPrint = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(mapper.readTree(expectedPayLoad));
		assertEquals(expectedPrettyPrint.trim(),actualPrettyPrint.trim());
	}
	
	@Test
	public void testEmptyValueInList() throws KronosCoreAPIException{
		Request payload = build(
				map("test", 
						map("tokeRows", list(""),
							"selectedAction", "test",
							"loaded", "test")
		));
		assertEquals(payload.getRequest().toString(),"{\"test\":{\"tokeRows\":[],\"selectedAction\":\"test\",\"loaded\":\"test\"}}");
	}
	
	@Test
	public void testNegativeInputForMap(){
		Map<String,Object> map = null;
		try {
			map = map("testKey");
		} catch (KronosCoreAPIException e) {
			assertEquals("You cannot give odd number of element", e.getMessage());
		}
		assertEquals(map, null);

		try {
			map = map("testKey",1,2);
		} catch (KronosCoreAPIException e) {
			assertEquals("You cannot give odd number of element", e.getMessage());
		}
		assertEquals(map, null);
		
		try {
			map = map();
		} catch (KronosCoreAPIException e) {
			assertEquals("You need to prepare at least two argument", e.getMessage());
		}
		assertEquals(map, null);
		
		try {
			map = map(2,"testKey");
		} catch (KronosCoreAPIException e) {
			assertEquals("Key 2 must be string", e.getMessage());
		}
		assertEquals(map, null);
		
		
		try {
			map = objRef();
		} catch (KronosCoreAPIException e) {
			assertEquals("You need to give either 1 or 2 arguments", e.getMessage());
		}
		assertEquals(map, null);
		
		//if more than two parameters are given to objRef, a map of {"id": null, "qualifier" : null} will be returned
		try {
			map = objRef(2, "test" ,43);
		} catch (KronosCoreAPIException e) {
			assertEquals("You need to give either 1 or 2 arguments", e.getMessage());
		}
	}
	
	@Test
	public void testEmptyMap() throws KronosCoreAPIException{
		Map<String,Object> empty = new HashMap<String, Object>();
		Request payload = build(
				map("test", 
						map("tokeRows", list(""),
							"selectedAction", "test",
							"loaded", empty)
		));
		assertEquals(payload.getRequest().toString(),"{\"test\":{\"tokeRows\":[],\"selectedAction\":\"test\",\"loaded\":{}}}");
	}
	
	@Test
	public void testMapWithSameValue() throws KronosCoreAPIException{
		Request payload = build(
				map("test", 
						mapWithSameValue("tokeRows", "selectedAction", "test", "loaded", "1")
		));
		assertEquals(payload.getRequest().toString(),"{\"test\":{\"tokeRows\":\"1\",\"selectedAction\":\"1\",\"test\":\"1\",\"loaded\":\"1\"}}");
	}
	
	@Test
	public void testEmptyList() throws KronosCoreAPIException{
		Request payload = build(
				map("test", 
						map("tokeRows", list(),
							"selectedAction", "test",
							"loaded", list())
		));
		assertEquals(payload.getRequest().toString(),"{\"test\":{\"tokeRows\":[],\"selectedAction\":\"test\",\"loaded\":[]}}");
	}
}