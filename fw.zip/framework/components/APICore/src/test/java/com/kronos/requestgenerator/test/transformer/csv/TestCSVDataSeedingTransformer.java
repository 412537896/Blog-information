package com.kronos.requestgenerator.test.transformer.csv;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.net.URL;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Before;
import org.junit.Test;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.kronos.requestgenerator.api.transformer.DataSeedingTransformer;
import com.kronos.requestgenerator.api.transformer.DataSeedingTransformerException;
import com.kronos.requestgenerator.transformer.csv.CSVDataSeedingTransformer;

public class TestCSVDataSeedingTransformer {
	protected static final Logger logger = Logger.getLogger(TestCSVDataSeedingTransformer.class);
	DataSeedingTransformer transformer;

	String mappingDir;

	String dataDir;

	@Before
	public void setup() {
		URL resource1 = this.getClass().getResource("/mapping/testmapping");
		mappingDir =  resource1.getPath();
		URL resource = this.getClass().getResource("/data/testdata");
		dataDir = resource.getPath();
		transformer = new CSVDataSeedingTransformer();
	}

	@Test(expected = DataSeedingTransformerException.class)
	public void testInvalidPathsTest() throws DataSeedingTransformerException {

		transformer = new CSVDataSeedingTransformer();
		transformer.transform("/mapping/testmapping/APIHolidayProfile.json","/data/testdata/Invalid/APIHolidayProfile/APIHolidayProfile.csv","1");
	}

	@Test
	public void testSchemaTypes() throws DataSeedingTransformerException {

		URL resource = this.getClass().getResource("/data/testschemadata");
		dataDir = resource.getPath();
		
		URL resource1 = this.getClass().getResource("/mapping/testschema");
		mappingDir = resource1.getPath();

		transformer = new CSVDataSeedingTransformer();
		JsonNode jsonData = transformer.transform(  "mapping/testschema/WSAFunctionAccessProfile.json", "data/testschemadata" + "/WSAFunctionAccessProfile/WSAFunctionAccessProfile.csv","All Access");
		assertNotNull(jsonData);
		
		ObjectMapper mapper = new ObjectMapper();
		Map<String, Object> entityJsons = (Map<String, Object>) mapper.convertValue(jsonData, Map.class);
		assertNotNull(entityJsons.get("Name"));
		assertEquals(10, entityJsons.keySet().size());
		assertEquals("All Access", entityJsons.get("Name"));
		
		JSONObject entityJsonObject = new JSONObject(jsonData.toString());
		String namePropNode = entityJsonObject.getString("Name");
		assertNotNull(namePropNode);

		JSONObject entityPermsJson = entityJsonObject.getJSONObject("Permissions");
		assertNotNull(entityPermsJson);
		assertTrue(!entityPermsJson.toString().trim().isEmpty());

		JSONArray jsonPermsArray = entityPermsJson.getJSONArray("WSAPermission");
		assertNotNull(jsonPermsArray);
		assertTrue(!jsonPermsArray.toString().trim().isEmpty());
		assertEquals(2, jsonPermsArray.length());

		entityPermsJson = entityJsonObject.getJSONObject("Permissions2");
		assertNotNull(entityPermsJson);
		assertTrue(!entityPermsJson.toString().trim().isEmpty());

		jsonPermsArray = entityPermsJson.getJSONArray("WSAPermission2");
		assertNotNull(jsonPermsArray);
		assertTrue(!jsonPermsArray.toString().trim().isEmpty());
		assertEquals(2, jsonPermsArray.length());
		assertEquals("Perm21", jsonPermsArray.getString(0));
		assertEquals("Perm22", jsonPermsArray.getString(1));
		

		entityPermsJson = entityJsonObject.getJSONObject("Permissions3");
		assertNotNull(entityPermsJson);
		assertTrue(!entityPermsJson.toString().trim().isEmpty());

		jsonPermsArray = entityPermsJson.getJSONArray("WSAPermission3");
		assertNotNull(jsonPermsArray);
		assertTrue(!jsonPermsArray.toString().trim().isEmpty());
		assertEquals(2, jsonPermsArray.length());

		JSONObject jsonPermArrObject = jsonPermsArray.getJSONObject(0);
		assertNotNull(jsonPermArrObject);
		assertNotNull(jsonPermArrObject.getJSONObject("WSAPermission31"));
		JSONObject arrObjChild = jsonPermArrObject.getJSONObject("WSAPermission31");
		assertNotNull(arrObjChild.get("WSAPermission32"));
		assertEquals("Perm321", arrObjChild.get("WSAPermission32"));

		entityPermsJson = entityJsonObject.getJSONObject("Permissions4");
		assertNotNull(entityPermsJson);
		assertTrue(!entityPermsJson.toString().trim().isEmpty());

		jsonPermsArray = entityPermsJson.getJSONArray("WSAPermission4");
		assertNotNull(jsonPermsArray);
		assertTrue(!jsonPermsArray.toString().trim().isEmpty());
		assertEquals(2, jsonPermsArray.length());

		jsonPermArrObject = jsonPermsArray.getJSONObject(0);
		assertNotNull(jsonPermArrObject);
		JSONArray jsonPerm41Array = jsonPermArrObject.getJSONArray("WSAPermission41");
		assertNotNull(jsonPerm41Array);
		assertEquals(3, jsonPerm41Array.length());

		entityPermsJson = entityJsonObject.getJSONObject("Permissions5");
		assertNotNull(entityPermsJson);
		assertTrue(!entityPermsJson.toString().trim().isEmpty());

		jsonPermsArray = entityPermsJson.getJSONArray("WSAPermission5");
		assertNotNull(jsonPermsArray);
		assertTrue(!jsonPermsArray.toString().trim().isEmpty());
		assertEquals(2, jsonPermsArray.length());

		JSONArray jsonPerm5Array = jsonPermsArray.getJSONArray(0);
		assertNotNull(jsonPerm5Array);
		assertEquals(3, jsonPerm5Array.length());
		
	}

	@Test
	public void testTransform() throws DataSeedingTransformerException {

		assertFAPData(transformer.transform("mapping/testmapping" + "/WSAFunctionAccessProfile.json", "data/testdata" + "/WSAFunctionAccessProfile/WSAFunctionAccessProfile.csv", "No Access"));
		assertAPIHolidayProfile(transformer.transform("mapping/testmapping" + "/APIHolidayProfile.json", "data/testdata" + "/APIHolidayProfile/APIHolidayProfile.csv", "1"));
		assertWSAWorkRule(transformer.transform("mapping/testmapping" + "/WSAWorkRule.json", "data/testdata" + "/WSAWorkRule/WSAWorkRule.csv", "Rule 1"));
	/*	assertduplicateArrayWithDiffParent(transformer.transform("requestGenerator/duplicateArrayWithDiffParent/duplicateArrayWithDiffParent.json",
				"requestGenerator/duplicateArrayWithDiffParent/duplicateArrayWithDiffParent.csv", "p01"));*/
		/*assertLongNameCSVwithDuplicate(transformer.transform("requestGenerator/LongNameCSVwithDuplicate/LongNameCSVwithDuplicate.json",
				"requestGenerator/LongNameCSVwithDuplicate/LongNameCSVwithDuplicate.csv", "p01"));*/
		//assertProcessingOrderRule(jsonData);
		JsonNode multiNode = transformer.transform("mapping/testmapping" + "/WSAFunctionAccessProfile_List.json", "data/testdata" + "/WSAFunctionAccessProfile/WSAFunctionAccessProfile.csv", "No Access,All Access");
		assertTrue(multiNode instanceof ArrayNode);
		ObjectMapper mapper = new ObjectMapper();
		@SuppressWarnings("unchecked")
		List<Object> jsonNode = (List<Object>) mapper.convertValue(multiNode, List.class);
		assertEquals(2, jsonNode.size());
	}

	private void assertProcessingOrderRule(Map<String, Map<String, String>> jsonData) {
		Map<String, String> entityJsons = jsonData.get("WSAProcessingOrderRule");	
		assertNotNull(entityJsons.get("Ds ProcessingOrderRule one"));
		assertEquals(5, entityJsons.keySet().size());
		
		String entityJson = entityJsons.get("Ds ProcessingOrderRule one");
		JSONObject entityJsonObject = new JSONObject(entityJson);
		
		JSONObject doFirstJsonObject = entityJsonObject.getJSONObject("DoFirstList");
		JSONArray seqItemArr = doFirstJsonObject.getJSONArray("WSASequencedItem");
		String nameAttr = seqItemArr.getJSONObject(0).getString("@Name");
		assertEquals("DS-TRUE DFL", nameAttr);
		
		JSONObject doLastJsonObject = entityJsonObject.getJSONObject("DoLastList");
		seqItemArr = doLastJsonObject.getJSONArray("WSASequencedItem");
		nameAttr = seqItemArr.getJSONObject(0).getString("@Name");
		assertEquals("DS-TRUE DLL", nameAttr);
	}

	private void assertWSAWorkRule(JsonNode jsonData) {
		ObjectMapper mapper = new ObjectMapper();
		Map<String, Object> entityJsons = (Map<String, Object>) mapper.convertValue(jsonData, Map.class);
		assertNotNull(entityJsons.get("Name"));
		assertEquals("DS Rule 1", entityJsons.get("Name"));
		assertEquals(3, entityJsons.keySet().size());
		
	//	String entityJson = entityJsons.get("Rule 1");
		JSONObject entityJsonObject = new JSONObject(jsonData.toString());
		assertNotNull(entityJsonObject);
		
		JSONObject wrokRuleJsonObject = entityJsonObject.getJSONObject("EffectiveWorkRules");
		assertNotNull(wrokRuleJsonObject);
		JSONArray effWorkRuleArrJsonArr = wrokRuleJsonObject.getJSONArray("WSAEffectiveWorkRule");
		assertNotNull(effWorkRuleArrJsonArr);
		
		JSONObject wSAAutoBreakPlacement = effWorkRuleArrJsonArr.getJSONObject(0).getJSONObject("AutoBreakPlacement").getJSONObject("WSAAutoBreakPlacement");
		assertEquals(12 , wSAAutoBreakPlacement.get("MaxStartTimeForBreak"));
		assertEquals(10.5 , wSAAutoBreakPlacement.get("MinStartTimeForBreak"));
		
		JSONObject workRuleGeneral = effWorkRuleArrJsonArr.getJSONObject(0).getJSONObject("WorkRuleGeneral");
		assertNotNull(workRuleGeneral);
		
		JSONObject wsaWorkRulePCDist = effWorkRuleArrJsonArr.getJSONObject(0).getJSONObject("WorkRulePCDistr").getJSONObject("WSAWorkRulePCDistr");
		assertNotNull(wsaWorkRulePCDist);
		
		JSONObject wsaWorkRuleGeneral = workRuleGeneral.getJSONObject("WSAWorkRuleGeneral");
		assertNotNull(wsaWorkRuleGeneral);
		
		JSONArray bonusDeducRuleArr = wsaWorkRuleGeneral.getJSONObject("BonusDeductRuleNames").getJSONArray("SimpleValue");
		assertNotNull(bonusDeducRuleArr);
		assertEquals("BDRValue1", bonusDeducRuleArr.getJSONObject(0).get("Value"));
		assertEquals("BDRValue2", bonusDeducRuleArr.getJSONObject(1).get("Value"));
		
		JSONArray breakRuleArr = wsaWorkRuleGeneral.getJSONObject("BreakRuleNames").getJSONArray("SimpleValue");
		assertNotNull(breakRuleArr);
		assertEquals("BRNValue1", breakRuleArr.getJSONObject(0).get("Value"));
		assertEquals("BRNValue2", breakRuleArr.getJSONObject(1).get("Value"));
		
		JSONArray coreHoursRuleNamesArr = wsaWorkRuleGeneral.getJSONObject("CoreHoursRuleNames").getJSONArray("SimpleValue");
		assertNotNull(coreHoursRuleNamesArr);
		assertEquals("CHRValue1", coreHoursRuleNamesArr.getJSONObject(0).get("Value"));
		assertEquals("CHRValue2", coreHoursRuleNamesArr.getJSONObject(1).get("Value"));
		
		
		JSONArray overTimesRuleNamesArr = wsaWorkRulePCDist.getJSONObject("OvertimeRuleNames").getJSONArray("SimpleValue");
		assertNotNull(overTimesRuleNamesArr);
		assertEquals("ORN1", overTimesRuleNamesArr.getJSONObject(0).get("Value"));
		assertEquals("ORN2", overTimesRuleNamesArr.getJSONObject(1).get("Value"));		
		
	}

	private void assertAPIHolidayProfile(JsonNode jsonData) {
		ObjectMapper mapper = new ObjectMapper();
		Map<String, Object> entityJsons = (Map<String, Object>) mapper.convertValue(jsonData, Map.class);
		
		assertNotNull(entityJsons.get("Name"));
		assertEquals(4, entityJsons.keySet().size());
		JSONObject entityJsonObject = new JSONObject(jsonData.toString());
		
		String namePropNode = entityJsonObject.getString("Name");
		assertNotNull(namePropNode);
		assertTrue(!namePropNode.isEmpty());
		assertEquals("Holiday profile name", namePropNode);
		
		JSONObject dataSetObject = entityJsonObject.getJSONObject("HolidayProfileDataSet");
		assertNotNull(dataSetObject);
		
		JSONObject apiDataSet = dataSetObject.getJSONObject("APIHolidayProfileDataSet");
		assertNotNull(apiDataSet);
		
		JSONObject dataMemebers = apiDataSet.getJSONObject("DataMembers");
		assertNotNull(dataMemebers);
		
		String apiDataSetPropName = apiDataSet.getString("Name");
		assertNotNull(apiDataSetPropName);
		assertTrue(!apiDataSetPropName.isEmpty());		
		assertEquals("data set name", apiDataSetPropName);
		
	}

	private void assertFAPData(JsonNode jsonData) {
		ObjectMapper mapper = new ObjectMapper();
		Map<String, Object> entityJsons = (Map) mapper.convertValue(jsonData, Map.class);

		assertEquals("No Access",entityJsons.get("Name"));
		assertEquals(5, entityJsons.keySet().size());
		
		JSONObject entityJsonObject = new JSONObject(jsonData.toString());

		String nameProp = "Name";
		String namePropNode = entityJsonObject.getString(nameProp);
		assertNotNull(namePropNode);
		assertTrue(!namePropNode.isEmpty());

		JSONObject entityPermsJson = entityJsonObject.getJSONObject("Permissions");
		assertNotNull(entityPermsJson);
		assertTrue(!entityPermsJson.toString().trim().isEmpty());

		JSONArray jsonPermsArray = entityPermsJson.getJSONArray("WSAPermission");
		assertNotNull(jsonPermsArray);
		assertTrue(!jsonPermsArray.toString().trim().isEmpty());
		assertEquals(2, jsonPermsArray.length());

		JSONObject perm1 = jsonPermsArray.getJSONObject(0);

		String controlProp = "ControlPointKey";
		assertNotNull(perm1.getString(controlProp));
		assertTrue(!perm1.getString(controlProp).isEmpty());
		assertEquals("UDM_WEBSERVICE", perm1.getString(controlProp));
		
		String scopeName = "ScopeName";
		assertNotNull(perm1.getString(scopeName));
		assertTrue(!perm1.getString(scopeName).isEmpty());
		assertEquals("ALL", perm1.getString(scopeName));
		
		String actionName = "ActionName";
		assertNotNull(perm1.getString(actionName));
		assertTrue(!perm1.getString(actionName).isEmpty());
		assertEquals("ALLOWED", perm1.getString(actionName));
	}


/*	private void assertLongNameCSVwithDuplicate(JsonNode transform) {
		
		System.out.println("entering into assertLongnameCSVWithDuplicate ****");
		String expected = "{\"A\":{\"A1\":\"aaaa\",\"A2\":100,\"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaab\":{\"C1\":\"aaaaa_1\",\"zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz\":{\"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\":[{\"C1\":\"bbbb\",\"C2\":true}],\"B1\":true},\"C2\":false},\"zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz\":{\"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\":[{\"C1\":\"bbb\",\"C2\":true}],\"B1\":true}}}";
		System.out.println(transform.toString());
		
		try{
			System.out.println(transform.get("A").get("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaab").get("zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz").get("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa").get(0));
		}catch(Exception e){
			System.out.println("problem with A.aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaab.zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz.aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
			e.printStackTrace();
		}
		
		try{
			System.out.println(transform.get("A").get("zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz").get("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"));
			System.out.println(transform.get("A").get("zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz").get("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa").get(0));

		}catch(Exception e){
			System.out.println("problem with A.zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz.aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
			e.printStackTrace();
		}
		
		try{
			System.out.println(transform.get("A").get("zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz").get("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa").get(0).get("C1"));

		}catch(Exception e){
			System.out.println("problem with A.zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz.aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa.c1");
			e.printStackTrace();
		}
		try{
			System.out.println(transform.get("A").get("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaab"));
		}catch(Exception e){
			System.out.println("problem with A.aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaab");
			e.printStackTrace();
		}
		try{
			System.out.println(transform.get("A").get("zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz"));
		}catch(Exception e){
			System.out.println("problem with A.zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz");
			e.printStackTrace();
		}
		
		assertEquals("aaaa", transform.get("A").get("A1").asText());
		assertEquals(100, transform.get("A").get("A2").asInt());
		assertEquals(true,transform.get("A").get("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaab").get("zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz").get("B1").asBoolean());
		assertEquals(true,transform.get("A").get("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaab").get("zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz").get("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa").get(0).get("C2").asBoolean());
		assertEquals("bbbb",transform.get("A").get("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaab").get("zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz").get("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa").get(0).get("C1").asText());
		assertEquals("bbb",transform.get("A").get("zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz").get("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa").get(0).get("C1").asText());
		
		System.out.println("leaving  assertLongnameCSVWithDuplicate ****");
	}*/

	/*private void assertduplicateArrayWithDiffParent(JsonNode transform) {
		assertEquals("assertduplicateArrayWithDiffParent", transform.toString());
		logger.info("entering into assertduplicateArrayWithDiffParent****");
		try{
			logger.info("Request :"+transform.toString());
			logger.info(transform.get("classicData").get("com").get("approverAll").get(0).get("com").get("pre_approverAll").get(0));
		}catch(Exception e){
			logger.info("problem with classicData.com.approveall.get.preapprovall");
			e.printStackTrace();
		}
		try{
			logger.info(transform.get("classicData").get("com2").get("approverAll").get(0).get("com").get("pre_approverAll").get(0));
		}catch(Exception e){
			logger.info("problem with classicData.com2.approveall.get.preapprovall");
			e.printStackTrace();
		}
		try{
			logger.info(transform.get("classicData").get("com2").get("approverAll").get(0));
		}catch(Exception e){
			logger.info("problem with classicData.com2.approveall");
			e.printStackTrace();
		}
		try{
			logger.info(transform.get("classicData").get("com").get("approverAll").get(0));
		}catch(Exception e){
			logger.info("problem with classicData.com.approveall");
			e.printStackTrace();
		}
		try{
			logger.info(transform.get("classicData").get("com").get("approverAll").get(0).get("com"));
		}catch(Exception e){
			logger.info("problem with classicData.com.approveall.com");
			e.printStackTrace();
		}
		
		assertEquals(false,transform.get("classicData").get("com").get("approverAll").get(0).get("com").get("pre_approverAll").get(0).get("modified_1").asBoolean());
		assertEquals(true, transform.get("classicData").get("com").get("approverAll").get(0).get("com").get("pre_approverAll").get(0).get("deleted_1").asBoolean());
		assertEquals(true, transform.get("classicData").get("com").get("approverAll").get(0).get("modified").asBoolean());
		assertEquals(true, transform.get("classicData").get("loaded").asBoolean());
		assertEquals(true,transform.get("classicData").get("com2").get("approverAll").get(0).get("com").get("pre_approverAll").get(0).get("modified_1").asBoolean());
		assertEquals(false,transform.get("classicData").get("com2").get("approverAll").get(0).get("com").get("pre_approverAll").get(0).get("inserted_1").asBoolean());
		logger.info("leaving  assertduplicateArrayWithDiffParent****");
	}*/
}
