package com.kronos.requestgenerator;

import java.io.File;
import java.io.IOException;
import java.net.URL;

import org.apache.commons.io.FileUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.fasterxml.jackson.databind.JsonNode;
import com.kronos.requestgenerator.RequestGenerator;
import com.kronos.requestgenerator.RequestGeneratorException;

/**
 * @author Animesh.Sonkar
 *
 */
public class RequestGeneratorTest {

	@Test(expected = RequestGeneratorException.class)
	public void testException() throws RequestGeneratorException {
		RequestGenerator ds = new RequestGenerator();
		JsonNode req = ds.transformCSVData("toolConfig", "config", "tempfileName");
	}

}
