package com.kronos.operations;

import static org.junit.Assert.assertEquals;

import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.HashMap;

import org.junit.Before;
import org.junit.Test;
import com.kronos.api.rest.exception.KronosCoreAPIException;
import com.kronos.api.rest.json.Request;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.restassured.path.json.JsonPath;

public class TestRequest {
	private Request requestParser;
	private File file;
    private File file_array;
	private ObjectMapper mapper;
	private JsonNode root;
    private JsonNode root_array;

	@Before
	public void setUp() throws JsonProcessingException, IOException, URISyntaxException {
		ClassLoader classLoader = getClass().getClassLoader();
		file = new File(classLoader.getResource("requestTest.json").toURI());
		mapper = new ObjectMapper();
		root = mapper.readTree(file);
		
        file_array = new File(classLoader.getResource("requestTest_Array.json").toURI());
        root_array = mapper.readTree(file_array);
	}

	@Test
	public void test1_updateNodeValue() throws  KronosCoreAPIException {
        //Tests when request starts as a map
        requestParser = new Request(root);

		String jsonPath = "commentNotes[0].id";
		Object valueToupdate = 800;
		requestParser.updateNodeValue(jsonPath, valueToupdate);
		assertEquals(true, valueToupdate.equals(JsonPath.with(requestParser.getRequest().toString()).get(jsonPath)));

		jsonPath = "employee.id";
		valueToupdate = "";
		requestParser.updateNodeValue(jsonPath, valueToupdate);
		assertEquals(true, valueToupdate.equals(JsonPath.with(requestParser.getRequest().toString()).get(jsonPath)));

		jsonPath = "employee.id";
		valueToupdate = 180;
		requestParser.updateNodeValue(jsonPath, valueToupdate);
		assertEquals(true, valueToupdate.equals(JsonPath.with(requestParser.getRequest().toString()).get(jsonPath)));

		jsonPath = "commentNotes[0].notes[0].commentNoteId";
		valueToupdate = 1;
		requestParser.updateNodeValue(jsonPath, valueToupdate);
		assertEquals(true, valueToupdate.equals(JsonPath.with(requestParser.getRequest().toString()).get(jsonPath)));

		//jsonPath = "relations.id";
        jsonPath = "relations[1].id";
		valueToupdate = 182;
		requestParser.updateNodeValue(jsonPath, valueToupdate);
        assertEquals(false,
                valueToupdate.equals(JsonPath.with(requestParser.getRequest().toString()).get("relations[0].id")));
/*
		assertEquals(true,
				valueToupdate.equals(JsonPath.with(requestParser.getRequest().toString()).get("relations.id[0]")));
		assertEquals(true,
				valueToupdate.equals(JsonPath.with(requestParser.getRequest().toString()).get("relations.id[1]")));
*/
		assertEquals(true,		
				valueToupdate.equals(JsonPath.with(requestParser.getRequest().toString()).get("relations[1].id")));

		jsonPath = "commentNotes[0].comment.name";
		valueToupdate = "European Business";
		requestParser.updateNodeValue(jsonPath, valueToupdate);
		assertEquals(true, valueToupdate.equals(JsonPath.with(requestParser.getRequest().toString()).get(jsonPath)));
		
		//When valueToBeUpdated is of type ArrayList
		jsonPath = "commentNotes";
		valueToupdate = getDummyArrayList();
		requestParser.updateNodeValue(jsonPath, valueToupdate);
		assertEquals(true, valueToupdate.equals(JsonPath.with(requestParser.getRequest().toString()).get(jsonPath)));
		
		//When valueToBeUpdated is of type HashMap
		jsonPath = "segments[0].primaryOrgJobRef";
		valueToupdate = getDummyHashMap();
		requestParser.updateNodeValue(jsonPath, valueToupdate);
		assertEquals(true, valueToupdate.equals(JsonPath.with(requestParser.getRequest().toString()).get(jsonPath)));
		
	//Tests when request starts as an array
        requestParser = new Request(root_array);
        
        jsonPath = "[1].commentNotes[0].id";
        valueToupdate = 800;
        requestParser.updateNodeValue(jsonPath,valueToupdate);
        assertEquals(true, valueToupdate.equals(JsonPath.with(requestParser.getRequest().toString()).get(jsonPath)));

        jsonPath = "[1].employee.id";
        valueToupdate = "";
        requestParser.updateNodeValue(jsonPath,valueToupdate);
        assertEquals(true, valueToupdate.equals(JsonPath.with(requestParser.getRequest().toString()).get(jsonPath)));
        
        jsonPath = "[1].employee.id";
        valueToupdate = 180;
        requestParser.updateNodeValue(jsonPath,valueToupdate);
        assertEquals(true, valueToupdate.equals(JsonPath.with(requestParser.getRequest().toString()).get(jsonPath)));

        jsonPath = "[1].commentNotes[0].notes[0].commentNoteId";
        valueToupdate = 1;
        requestParser.updateNodeValue(jsonPath,valueToupdate);
        assertEquals(true, valueToupdate.equals(JsonPath.with(requestParser.getRequest().toString()).get(jsonPath)));

        jsonPath = "[1].relations[1].id";
        valueToupdate = 182;
        requestParser.updateNodeValue(jsonPath,valueToupdate);
        assertEquals(false, valueToupdate.equals(JsonPath.with(requestParser.getRequest().toString()).get("[1].relations[0].id")));
        assertEquals(true, valueToupdate.equals(JsonPath.with(requestParser.getRequest().toString()).get("[1].relations[1].id")));

        jsonPath = "[1].commentNotes[0].comment.name";
        valueToupdate = "European Business";
        requestParser.updateNodeValue(jsonPath,valueToupdate);
        assertEquals(true, valueToupdate.equals(JsonPath.with(requestParser.getRequest().toString()).get(jsonPath)));
        
		//When valueToBeUpdated is of type ArrayList
		jsonPath = "[1].commentNotes";
		valueToupdate = getDummyArrayList();
		requestParser.updateNodeValue(jsonPath, valueToupdate);
		assertEquals(true, valueToupdate.equals(JsonPath.with(requestParser.getRequest().toString()).get(jsonPath)));
		
		//When valueToBeUpdated is of type HashMap
		jsonPath = "[1].segments[0].primaryOrgJobRef";
		valueToupdate = getDummyHashMap();
		requestParser.updateNodeValue(jsonPath, valueToupdate);
		assertEquals(true, valueToupdate.equals(JsonPath.with(requestParser.getRequest().toString()).get(jsonPath)));        
    }

	private ArrayList<Object> getDummyArrayList()
	{
		ArrayList<Object> arrayList = new ArrayList<>();
		
		HashMap<String,Object> hmap1 = new HashMap<>();
		hmap1.put("Name", "Amit");
		HashMap<String,String> addressMap = new HashMap<>();
		addressMap.put("AddressLine1", "Kronos Solutions");
		addressMap.put("AddressLine2", "Sector 62");
		addressMap.put("City", "Noida");
		hmap1.put("Address", addressMap);
		
		HashMap<String,Object> hmap2 = new HashMap<>();
		hmap2.put("Name", "John");
		addressMap.clear();
		addressMap.put("AddressLine1", "Kronos Inc");
		addressMap.put("AddressLine2", "Crosspoint");
		addressMap.put("City", "Lowell");
		hmap2.put("Address", addressMap);
		
		arrayList.add(hmap1);
		arrayList.add(hmap2);
		return arrayList;
	}
    
	
	private HashMap<String,Object> getDummyHashMap()
	{
		HashMap<String,Object> hmap = new HashMap<>();
		
		hmap.put("Id", "DummyHashMap001");
		HashMap<String,String> detailsMap = new HashMap<>();
		detailsMap.put("Name", "DummyPrimaryOrgJobRef");
		detailsMap.put("qualifier", "Organization/DummyPrimaryOrgJobRef");
		detailsMap.put("description", "This is just a dummy primaryOrgJobRef");
		hmap.put("details", detailsMap);
		
		return hmap;
	}
	
/*    @Test
    public void test1_updateNodeValues() throws  KronosCoreAPIException {

        String jsonPath = "[1].commentNotes[0].id";
        requestParser = new Request(root);
        Object valueToupdate = 800;
        requestParser.updateNodeValue(valueToupdate,jsonPath);
        assertEquals(true, valueToupdate.equals(JsonPath.with(requestParser.getRequest().toString()).get(jsonPath)));

        jsonPath = "[1].employee.id";
        valueToupdate = "";
        requestParser.updateNodeValue(valueToupdate,jsonPath);
        assertEquals(true, valueToupdate.equals(JsonPath.with(requestParser.getRequest().toString()).get(jsonPath)));
        
        jsonPath = "[1].employee.id";
        valueToupdate = 180;
        requestParser.updateNodeValue(valueToupdate,jsonPath);
        assertEquals(true, valueToupdate.equals(JsonPath.with(requestParser.getRequest().toString()).get(jsonPath)));

        jsonPath = "[1].commentNotes[0].notes[0].commentNoteId";
        valueToupdate = 1;
        requestParser.updateNodeValue(valueToupdate,jsonPath);
        assertEquals(true, valueToupdate.equals(JsonPath.with(requestParser.getRequest().toString()).get(jsonPath)));

        jsonPath = "[1].relations[1].id";
        valueToupdate = 182;
        requestParser.updateNodeValue(valueToupdate,jsonPath);
        assertEquals(false, valueToupdate.equals(JsonPath.with(requestParser.getRequest().toString()).get("[1].relations[0].id")));
        assertEquals(true, valueToupdate.equals(JsonPath.with(requestParser.getRequest().toString()).get("[1].relations[1].id")));

        jsonPath = "[1].commentNotes[0].comment.name";
        valueToupdate = "European Business";
        requestParser.updateNodeValue(valueToupdate,jsonPath);
        assertEquals(true, valueToupdate.equals(JsonPath.with(requestParser.getRequest().toString()).get(jsonPath)));
    }*/

    


	@Test
	public void test1_deleteNode() throws KronosCoreAPIException {

		String jsonPath = "employee.id";
		requestParser = new Request(root);
		requestParser.deleteNode(jsonPath);
		assertEquals(false, requestParser.isNodePresent(jsonPath));

		jsonPath = "commentNotes[0].id";
		requestParser = new Request(root);
		requestParser.deleteNode(jsonPath);
		assertEquals(false, requestParser.isNodePresent(jsonPath));

		jsonPath = "commentNotes[0].notes[0].commentNoteId";
		requestParser = new Request(root);
		requestParser.deleteNode(jsonPath);
		assertEquals(false, requestParser.isNodePresent( jsonPath));

		jsonPath = "commentNotes[0].notes";
		requestParser = new Request(root);
		requestParser.deleteNode(jsonPath);
		assertEquals(false, requestParser.isNodePresent(jsonPath));

		jsonPath = "relations.id";
		requestParser = new Request(root);
		requestParser.deleteNode(jsonPath);
		assertEquals(false, requestParser.isNodePresent("relations.id[0]"));
		assertEquals(false, requestParser.isNodePresent("relations.id[1]"));

	}

}
