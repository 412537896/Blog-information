package com.kronos.mockServices;

import com.kronos.api.rest.base.BaseAPIObject;
import com.kronos.api.rest.driver.APIDriver;
import com.kronos.api.rest.exception.KronosCoreAPIException;
import com.kronos.api.rest.operations.APIResponse;

public class MockAPIObject extends BaseAPIObject {
	public static final String GET_PATH_PARAMETER = "ShiftMockService/getShiftWithPathParameter/{sid}";
	public MockAPIObject(APIDriver driver) {
		super(driver);
	}

	@SuppressWarnings("unchecked")
	public APIResponse getWithPathParameter(int id) throws KronosCoreAPIException{
		setGenericParameter();
		params.setPath("sid", id);
		return driver.get(GET_PATH_PARAMETER,params);
		
	}
	
}
