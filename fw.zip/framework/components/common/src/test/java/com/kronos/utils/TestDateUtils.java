package com.kronos.utils;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;

import org.junit.Before;
import org.junit.Test;

import com.kronos.facade.DateGenerator;

public class TestDateUtils {
	private static final String FORMAT = "yyyy-MM-dd";
	DateGenerator dg;
	
	SimpleDateFormat sdf;
	Calendar cal;
	Date now;
	
	@Before
	public void setUp() throws Exception {
		HashMap<String,String> options = new HashMap<String,String>();
		options.put("dateFormat", FORMAT);
		dg = new DateGenerator(options);
		
		//set up objects that generates expected date
		sdf = new SimpleDateFormat(FORMAT);
		cal = new GregorianCalendar();
		now = new Date();
	}

	@Test
	public void testGetDate() {
		// test current day
		cal.setTime(now);
		assertEquals(sdf.format(cal.getTime()), dg.getDate(0));
		assertEquals(sdf.format(cal.getTime()), dg.getToday());
		
		// test 10 day in the future
		cal.setTime(now);
		cal.add(Calendar.DAY_OF_MONTH, 10);
		assertEquals(sdf.format(cal.getTime()), dg.getDate(10));

		// test 30 day in the past
		cal.setTime(now);
		cal.add(Calendar.DAY_OF_MONTH, -30);
		assertEquals(sdf.format(cal.getTime()), dg.getDate(-30));
		
		// test tomorrow
		cal.setTime(now);
		cal.add(Calendar.DAY_OF_MONTH, 1);
		assertEquals(sdf.format(cal.getTime()), dg.getTomorrow());
		
		
		// test day after tomorrow
		cal.setTime(now);
		cal.add(Calendar.DAY_OF_MONTH, 2);
		assertEquals(sdf.format(cal.getTime()), dg.getDayAfterTomorrow());
		
		// test yesterday
		cal.setTime(now);
		cal.add(Calendar.DAY_OF_MONTH, -1);
		assertEquals(sdf.format(cal.getTime()), dg.getYesterday());
		
		//test day before yesterday
		cal.setTime(now);
		cal.add(Calendar.DAY_OF_MONTH, -2);
		assertEquals(sdf.format(cal.getTime()), dg.getDayBeforeYesterday());
	}
	
	@Test
	public void testGetYear() {
		//test day in next year
		cal.setTime(now);
		cal.add(Calendar.YEAR, 1);
		assertEquals(sdf.format(cal.getTime()), dg.getYearAs(1));
		assertEquals(sdf.format(cal.getTime()), dg.getNextYear());

		//test date in past year
		cal.setTime(now);
		cal.add(Calendar.YEAR, -10);
		assertEquals(sdf.format(cal.getTime()), dg.getYearAs(-10));
		
		cal.setTime(now);
		assertEquals(sdf.format(cal.getTime()), dg.getYearAs(0));
		assertEquals(sdf.format(cal.getTime()), dg.getCurrentYear());

		cal.setTime(now);
		cal.add(Calendar.YEAR, -1);
		assertEquals(sdf.format(cal.getTime()), dg.getLastYear());
	}
	
	@Test
	public void testGetMonth() {
		cal.setTime(now);
		assertEquals(sdf.format(cal.getTime()), dg.getMonthAs(0));
		assertEquals(sdf.format(cal.getTime()), dg.getCurrentMonth());
		
		//test day in next month
		cal.setTime(now);
		cal.add(Calendar.MONTH, 1);
		assertEquals(sdf.format(cal.getTime()), dg.getMonthAs(1));
		assertEquals(sdf.format(cal.getTime()), dg.getNextMonth());

		//test date in past month
		cal.setTime(now);
		cal.add(Calendar.MONTH, -10);
		assertEquals(sdf.format(cal.getTime()), dg.getMonthAs(-10));
		
		cal.setTime(now);
		cal.add(Calendar.MONTH, -1);
		assertEquals(sdf.format(cal.getTime()), dg.getLastMonth());
	}
	
	
	@Test
	public void testGetWeek() {
		cal.setTime(now);
		assertEquals(sdf.format(cal.getTime()), dg.getWeekAs(0));
		assertEquals(sdf.format(cal.getTime()), dg.getCurrentWeek());
		
		//test date in next week
		cal.setTime(now);
		cal.add(Calendar.DAY_OF_MONTH, 1*7);
		assertEquals(sdf.format(cal.getTime()), dg.getWeekAs(1));
		assertEquals(sdf.format(cal.getTime()), dg.getNextWeek());

		//test date in past week
		cal.setTime(now);
		cal.add(Calendar.DAY_OF_MONTH, -10*7);
		assertEquals(sdf.format(cal.getTime()), dg.getWeekAs(-10));
		
		cal.setTime(now);
		cal.add(Calendar.DAY_OF_MONTH, -1*7);
		assertEquals(sdf.format(cal.getTime()), dg.getLastWeek());
	}
	
	@Test
	public void testGetDayOfWeek() throws ParseException {

		final String[] DaysOfWeekText = { "SUNDAY", "MONDAY", "TUESDAY", "WEDNESDAY", "THURSDAY", "FRIDAY",
				"SATURDAY" };
		Calendar currentDate = new GregorianCalendar();
		currentDate.setTime(now);

		cal.setTime(sdf.parse(dg.getNextMonday()));
		assertEquals(Calendar.MONDAY, cal.get(Calendar.DAY_OF_WEEK));
		assertTrue(cal.compareTo(currentDate) >= 0);

		cal.setTime(sdf.parse(dg.getLastMonday()));
		assertEquals(Calendar.MONDAY, cal.get(Calendar.DAY_OF_WEEK));
		assertTrue(cal.compareTo(currentDate) <= 0);

		cal.setTime(sdf.parse(dg.getNextTuesday()));
		assertEquals(Calendar.TUESDAY, cal.get(Calendar.DAY_OF_WEEK));

		assertTrue(cal.compareTo(currentDate) >= 0);

		cal.setTime(sdf.parse(dg.getLastTuesday()));
		assertEquals(Calendar.TUESDAY, cal.get(Calendar.DAY_OF_WEEK));
		assertTrue(cal.compareTo(currentDate) <= 0);

		cal.setTime(now);

		assertEquals(DaysOfWeekText[cal.get(Calendar.DAY_OF_WEEK) - 1], dg.getTodayWeekDayInText());

//		cal.add(Calendar.DAY_OF_MONTH, 15);
//		cal.setFirstDayOfWeek(Calendar.MONDAY);
//		assertEquals(cal.get(Calendar.DAY_OF_WEEK) - 1, dg.getWeekDayInValue(15));
	}
	
	
	@Test
	public void testAfteBeforeBetween() {
		
		cal.setTime(now);
		String startDate = sdf.format(cal.getTime());
		String endDate = sdf.format(cal.getTime());
		
		cal.add(Calendar.DAY_OF_MONTH, 1);
		String endDate1 = sdf.format(cal.getTime());

		cal.setTime(now);
		cal.add(Calendar.DAY_OF_MONTH, 2);
		String endDate2 = sdf.format(cal.getTime());

		cal.setTime(now);
		cal.add(Calendar.DAY_OF_MONTH, 3);
		String endDate3 = sdf.format(cal.getTime());

		cal.setTime(now);
		cal.add(Calendar.DAY_OF_MONTH, 4);
		String endDate4 = sdf.format(cal.getTime());
		
		cal.setTime(now);
		cal.add(Calendar.DAY_OF_MONTH, 5);
		String endDate5 = sdf.format(cal.getTime());
		
		cal.setTime(now);
		cal.add(Calendar.DAY_OF_MONTH, 10);
		String startDate1 = sdf.format(cal.getTime());
		
		// test 15 day in the future
		cal.setTime(now);
		cal.add(Calendar.DAY_OF_MONTH, 15);
		assertEquals(sdf.format(cal.getTime()), dg.after(startDate));
		
		
		cal.setTime(now);
		cal.add(Calendar.DAY_OF_MONTH, 15);
		assertEquals(startDate, dg.before(sdf.format(cal.getTime())));
		
		cal.setTime(now);
		assertEquals(startDate, dg.between(startDate,endDate));
		
		cal.setTime(now);
		assertEquals(startDate1, dg.between(startDate1,endDate));
		
		cal.setTime(now);
		cal.add(Calendar.DAY_OF_MONTH, 1);
		assertEquals(sdf.format(cal.getTime()), dg.between(startDate,endDate1));
		
		cal.setTime(now);
		cal.add(Calendar.DAY_OF_MONTH, 1);
		assertEquals(sdf.format(cal.getTime()), dg.between(startDate,endDate2));
		
		cal.setTime(now);
		cal.add(Calendar.DAY_OF_MONTH, 2);
		assertEquals(sdf.format(cal.getTime()), dg.between(startDate,endDate3));
		
		cal.setTime(now);
		cal.add(Calendar.DAY_OF_MONTH, 3);
		assertEquals(sdf.format(cal.getTime()), dg.between(startDate,endDate4));
		
		cal.setTime(now);
		cal.add(Calendar.DAY_OF_MONTH, 3);
		assertEquals(sdf.format(cal.getTime()), dg.between(startDate,endDate5));
	}

}
