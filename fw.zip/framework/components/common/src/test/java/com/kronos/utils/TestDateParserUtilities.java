package com.kronos.utils;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import org.joda.time.DateTime;
import org.joda.time.DateTimeConstants;
import org.junit.Before;
import org.junit.Test;

import com.kronos.exception.KronosCoreCommonException;
import com.kronos.utils.datetime.DateGeneratorUtilities;
import com.kronos.utils.datetime.DateParserUtilities;

public class TestDateParserUtilities {

	private static final String FORMAT = "yyyy-MM-dd";
	DateParserUtilities dateParserUtilities;
	Calendar cal;
	Date now;
	SimpleDateFormat sdf;

	@Before
	public void setUP() {
		dateParserUtilities = new DateParserUtilities();
		cal = new GregorianCalendar();
		now = new Date();
		sdf = new SimpleDateFormat(FORMAT);
	}

	
	@Test
	public void testDateGeneratorUtilities() {
		DateParserUtilities dgu = new DateParserUtilities();
		assertNotNull(dgu);

	}

	@Test
	public void testDateGeneratorUtilitiesWithParameter() {
		DateParserUtilities dgu = new DateParserUtilities(now);
		assertNotNull(dgu);
		cal.setTime(now);
		assertEquals(sdf.format(cal.getTime()), dgu.getCurrentDate().toString(FORMAT));

	}
	
	
	
	@Test
	public void testIsValidPattern() {
		String[] symbolicDayPattern = { "today", "yesterday", "tomorrow", "dayaftertomorrow", "daybeforeyesterday",
				"today+5d", "today+5M", "today+5y", "today+5w", "yesterday-4d", "tomorrow+18", "+20w", "+7d", "-20d",
				"-56y", "7M", "+3y", "+3dSunday", "+10MFriday", "-3yThursday" };

		for (int i = 0; i < symbolicDayPattern.length; i++) {
			assertTrue(dateParserUtilities.isValidPattern(symbolicDayPattern[i]));
		}

	}

	@Test
	public void testGetDayOfWeek() {
		final String[] DaysOfWeekText = { "SUNDAY", "MONDAY", "TUESDAY", "WEDNESDAY", "THURSDAY", "FRIDAY",
				"SATURDAY" };
		cal.setTime(now);
		assertEquals(DaysOfWeekText[cal.get(Calendar.DAY_OF_WEEK) - 1],
				DayOfWeek.of(dateParserUtilities.getDayOfWeek()).name());

	}

	@Test
	public void testGetDayOfWeekWithParam() throws ParseException {

		dateParserUtilities = new DateParserUtilities(sdf.parse("2016-06-27"));
		assertEquals(DayOfWeek.MONDAY, DayOfWeek.of(dateParserUtilities.getDayOfWeek()));
		dateParserUtilities = new DateParserUtilities(sdf.parse("2016-07-20"));
		dateParserUtilities = new DateParserUtilities(sdf.parse("2016-11-01"));
		assertEquals(DayOfWeek.TUESDAY, DayOfWeek.of(dateParserUtilities.getDayOfWeek()));
		dateParserUtilities = new DateParserUtilities(sdf.parse("2016-11-02"));
		assertEquals(DayOfWeek.WEDNESDAY, DayOfWeek.of(dateParserUtilities.getDayOfWeek()));
		dateParserUtilities = new DateParserUtilities(sdf.parse("2016-12-01"));
		assertEquals(DayOfWeek.THURSDAY, DayOfWeek.of(dateParserUtilities.getDayOfWeek()));
		dateParserUtilities = new DateParserUtilities(sdf.parse("2016-08-05"));
		assertEquals(DayOfWeek.FRIDAY, DayOfWeek.of(dateParserUtilities.getDayOfWeek()));
		dateParserUtilities = new DateParserUtilities(sdf.parse("2016-09-03"));
		assertEquals(DayOfWeek.SATURDAY, DayOfWeek.of(dateParserUtilities.getDayOfWeek()));
		dateParserUtilities = new DateParserUtilities(sdf.parse("2016-10-02"));
		assertEquals(DayOfWeek.SUNDAY, DayOfWeek.of(dateParserUtilities.getDayOfWeek()));

	}

	@Test
	public void testIsWeekDayPatternPresents() {
		String[] testDateExpression = { "+3monday", "-7Tuesday", "-10Wednesday", "17thursday", "20friday", "+35saturday",
				"-13sunday" };
		for (int i = 0; i < testDateExpression.length; i++) {
			assertTrue(dateParserUtilities.isWeekDayPatternPresents(testDateExpression[i]));
		}

	}

	@Test
	public void testCalculateDatePattern() {
		cal.setTime(now);
		DateTime dt = DateTime.now();
		cal.add(Calendar.DAY_OF_MONTH, 1);
		assertEquals(sdf.format(cal.getTime()), dateParserUtilities.calculateDatePattern(dt, "+1d").toString(FORMAT));
		cal.setTime(now);
		cal.add(Calendar.DAY_OF_MONTH, -5);
		assertEquals(sdf.format(cal.getTime()), dateParserUtilities.calculateDatePattern(dt, "-5d").toString(FORMAT));
		cal.setTime(now);
		cal.add(Calendar.MONTH, 7);
		assertEquals(sdf.format(cal.getTime()), dateParserUtilities.calculateDatePattern(dt, "+7M").toString(FORMAT));
		cal.setTime(now);
		cal.add(Calendar.MONTH, -7);
		assertEquals(sdf.format(cal.getTime()), dateParserUtilities.calculateDatePattern(dt, "-7M").toString(FORMAT));
		cal.setTime(now);
		cal.add(Calendar.YEAR, 10);
		assertEquals(sdf.format(cal.getTime()), dateParserUtilities.calculateDatePattern(dt, "+10y").toString(FORMAT));
		cal.setTime(now);
		cal.add(Calendar.YEAR, -9);
		assertEquals(sdf.format(cal.getTime()), dateParserUtilities.calculateDatePattern(dt, "-9y").toString(FORMAT));
		cal.setTime(now);
		cal.add(Calendar.DAY_OF_MONTH, 10 * 7);
		assertEquals(sdf.format(cal.getTime()), dateParserUtilities.calculateDatePattern(dt, "+10w").toString(FORMAT));
		cal.setTime(now);
		cal.add(Calendar.DAY_OF_MONTH, 10 * -7);
		assertEquals(sdf.format(cal.getTime()), dateParserUtilities.calculateDatePattern(dt, "-10w").toString(FORMAT));
		cal.setTime(now);
		cal.add(Calendar.DAY_OF_MONTH, -1);
		cal.add(Calendar.DAY_OF_MONTH, 10 * -7);
		assertEquals(sdf.format(cal.getTime()), dateParserUtilities.calculateDatePattern(dt, "yesterday-10w").toString(FORMAT));
		cal.setTime(now);
		cal.add(Calendar.DAY_OF_MONTH, 1);
		cal.add(Calendar.DAY_OF_MONTH, 10 * -7);
		assertEquals(sdf.format(cal.getTime()), dateParserUtilities.calculateDatePattern(dt, "tomorrow-10w").toString(FORMAT));
		cal.setTime(now);
		cal.add(Calendar.DAY_OF_MONTH, 2);
		cal.add(Calendar.MONTH, 5);
		assertEquals(sdf.format(cal.getTime()), dateParserUtilities.calculateDatePattern(dt, "dayaftertomorrow+5M").toString(FORMAT));
		cal.setTime(now);
		cal.add(Calendar.DAY_OF_MONTH, 2);
		cal.add(Calendar.MONTH, 5);
		cal.add(Calendar.YEAR, 7);
		assertEquals(sdf.format(cal.getTime()), dateParserUtilities.calculateDatePattern(dt, "dayaftertomorrow+5M+7y").toString(FORMAT));
		cal.setTime(now);
		cal.add(Calendar.DAY_OF_MONTH, 2);
		cal.add(Calendar.MONTH, 5);
		cal.add(Calendar.YEAR, 7);
		assertEquals(sdf.format(cal.getTime()), dateParserUtilities.calculateDatePattern(dt, "today+2d+5M+7y").toString(FORMAT));

	}

	@Test
	public void testCalculateArbitraryText() {
		String[] dateExpression = { "today+5d+5M+5y+3monday", "+10d+5M+3y-tuesday", "1y+2Friday" };
		for (int i = 0; i < dateExpression.length; i++) {
			assertEquals("", dateParserUtilities.calculateArbitraryText(dateExpression[i]));
		}

	}

	@Test
	public void testCalculateWeekDayPattern() throws KronosCoreCommonException, ParseException {
		Date date = sdf.parse("2016-06-28");

		DateGeneratorUtilities dg = new DateGeneratorUtilities(date);

		assertEquals(sdf.format(sdf.parse("2016-07-18")),
				dateParserUtilities.calculateWeekDayPattern(dg, DateTimeConstants.SUNDAY, "+3Monday").toString(FORMAT));
		assertEquals(sdf.format(sdf.parse("2016-07-18")),
				dateParserUtilities.calculateWeekDayPattern(dg, DateTimeConstants.MONDAY, "+3Monday").toString(FORMAT));

		date = sdf.parse("2016-06-29");

		dg = new DateGeneratorUtilities(date);

		assertEquals(sdf.format(sdf.parse("2016-07-11")),
				dateParserUtilities.calculateWeekDayPattern(dg, DateTimeConstants.SUNDAY, "+2Monday").toString(FORMAT));
		assertEquals(sdf.format(sdf.parse("2016-07-15")),
				dateParserUtilities.calculateWeekDayPattern(dg, DateTimeConstants.MONDAY, "+2Friday").toString(FORMAT));

		date = sdf.parse("2016-07-01");
		dg = new DateGeneratorUtilities(date);
		assertEquals(sdf.format(sdf.parse("2016-07-10")),
				dateParserUtilities.calculateWeekDayPattern(dg, DateTimeConstants.SUNDAY, "+2Sunday").toString(FORMAT));
		assertEquals(sdf.format(sdf.parse("2016-07-23")), dateParserUtilities
				.calculateWeekDayPattern(dg, DateTimeConstants.MONDAY, "+3Saturday").toString(FORMAT));

		date = sdf.parse("2016-07-03");
		dg = new DateGeneratorUtilities(date);
		assertEquals(sdf.format(sdf.parse("2016-07-17")),
				dateParserUtilities.calculateWeekDayPattern(dg, DateTimeConstants.SUNDAY, "+2Sunday").toString(FORMAT));
		assertEquals(sdf.format(sdf.parse("2016-07-14")), dateParserUtilities
				.calculateWeekDayPattern(dg, DateTimeConstants.MONDAY, "+2thursday").toString(FORMAT));

	}
	
	
	
	@Test
	public void testCalculateWeekDayPattern1() throws KronosCoreCommonException, ParseException {
		Date date = sdf.parse("2017-10-22");
		DateGeneratorUtilities dg = new DateGeneratorUtilities(date);
		assertEquals(sdf.format(sdf.parse("2017-11-06")),
				dateParserUtilities.calculateWeekDayPattern(dg, DateTimeConstants.SUNDAY, "2Monday").toString(FORMAT));

		assertEquals(sdf.format(sdf.parse("2017-10-30")),
				dateParserUtilities.calculateWeekDayPattern(dg, DateTimeConstants.SUNDAY, "1Monday").toString(FORMAT));
		
		assertEquals(sdf.format(sdf.parse("2017-10-23")),
				dateParserUtilities.calculateWeekDayPattern(dg, DateTimeConstants.SUNDAY, "0Monday").toString(FORMAT));
		
		date = sdf.parse("2017-10-23");
		dg = new DateGeneratorUtilities(date);
		assertEquals(sdf.format(sdf.parse("2017-11-06")),
				dateParserUtilities.calculateWeekDayPattern(dg, DateTimeConstants.SUNDAY, "2Monday").toString(FORMAT));

		assertEquals(sdf.format(sdf.parse("2017-10-30")),
				dateParserUtilities.calculateWeekDayPattern(dg, DateTimeConstants.SUNDAY, "1Monday").toString(FORMAT));
		
		assertEquals(sdf.format(sdf.parse("2017-10-23")),
				dateParserUtilities.calculateWeekDayPattern(dg, DateTimeConstants.SUNDAY, "0Monday").toString(FORMAT));
		
		date = sdf.parse("2017-10-28");
		dg = new DateGeneratorUtilities(date);
		assertEquals(sdf.format(sdf.parse("2017-11-06")),
				dateParserUtilities.calculateWeekDayPattern(dg, DateTimeConstants.SUNDAY, "2Monday").toString(FORMAT));

		assertEquals(sdf.format(sdf.parse("2017-10-30")),
				dateParserUtilities.calculateWeekDayPattern(dg, DateTimeConstants.SUNDAY, "1Monday").toString(FORMAT));
		
		assertEquals(sdf.format(sdf.parse("2017-10-23")),
				dateParserUtilities.calculateWeekDayPattern(dg, DateTimeConstants.SUNDAY, "0Monday").toString(FORMAT));
		
		date = sdf.parse("2017-10-29");
		dg = new DateGeneratorUtilities(date);
		assertEquals(sdf.format(sdf.parse("2017-11-13")),
				dateParserUtilities.calculateWeekDayPattern(dg, DateTimeConstants.SUNDAY, "2Monday").toString(FORMAT));
	}
}
