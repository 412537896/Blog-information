package com.kronos.utils;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import org.joda.time.DateTimeConstants;
import org.junit.Before;
import org.junit.Test;

import com.kronos.utils.datetime.DateGeneratorUtilities;

public class TestDateGeneratorUtilities {

	private static final String FORMAT = "yyyy-MM-dd";
	DateGeneratorUtilities dateGeneratorUtilities = null;
	Calendar cal;
	Date now;
	SimpleDateFormat sdf;

	@Before
	public void setUP() {

		dateGeneratorUtilities = new DateGeneratorUtilities();
		cal = new GregorianCalendar();
		now = new Date();
		sdf = new SimpleDateFormat(FORMAT);

	}

	@Test
	public void testDateGeneratorUtilities() {
		DateGeneratorUtilities dgu = new DateGeneratorUtilities();
		assertNotNull(dgu);

	}

	@Test
	public void testDateGeneratorUtilitiesWithParameter() {
		DateGeneratorUtilities dgu = new DateGeneratorUtilities(now);
		assertNotNull(dgu);
		cal.setTime(now);
		assertEquals(sdf.format(cal.getTime()), dateGeneratorUtilities.getCurrentTime().toString(FORMAT));

	}

	@Test
	public void testGetYearWithOffset() {
		cal.setTime(now);
		cal.add(Calendar.YEAR, 5);
		assertEquals(sdf.format(cal.getTime()), dateGeneratorUtilities.getYearWithOffset(5).toString(FORMAT));

	}

	@Test
	public void testGetMonthWithOffset() {
		cal.setTime(now);
		cal.add(Calendar.MONTH, 7);
		assertEquals(sdf.format(cal.getTime()), dateGeneratorUtilities.getMonthWithOffset(7).toString(FORMAT));

	}

	@Test
	public void testGetWeekWithOffset() {
		cal.setTime(now);
		cal.add(Calendar.DAY_OF_MONTH, 7 * 7);
		assertEquals(sdf.format(cal.getTime()), dateGeneratorUtilities.getWeekWithOffset(7).toString(FORMAT));

	}

	@Test
	public void testGetDayWithOffset() {
		cal.setTime(now);
		cal.add(Calendar.DAY_OF_MONTH, 6);
		assertEquals(sdf.format(cal.getTime()), dateGeneratorUtilities.getDayWithOffset(6).toString(FORMAT));

	}

	@Test
	public void testGetNthWeekDayAs() throws ParseException {
		DateGeneratorUtilities dgu = new DateGeneratorUtilities(sdf.parse("2016-06-01"));
		assertEquals("2016-06-12",
				dgu.getNthWeekDayAs(DateTimeConstants.SUNDAY, 2, DateTimeConstants.SUNDAY).toString(FORMAT));
		assertEquals("2016-06-19",
				dgu.getNthWeekDayAs(DateTimeConstants.MONDAY, 2, DateTimeConstants.SUNDAY).toString(FORMAT));

	}

	@Test
	public void testGetWeekDayAs() throws ParseException {
		DateGeneratorUtilities dgu = new DateGeneratorUtilities(sdf.parse("2016-06-07"));
		assertEquals("2016-06-29", dgu.getWeekDayAs(3, DateTimeConstants.WEDNESDAY).toString(FORMAT));

	}

	@Test
	public void testGetDayOfWeekAs() throws ParseException {

		DateGeneratorUtilities dgu = new DateGeneratorUtilities(sdf.parse("2016-06-01"));
		assertEquals(DayOfWeek.MONDAY, dgu.getDayOfWeekAs(5));
		assertEquals(DayOfWeek.TUESDAY, dgu.getDayOfWeekAs(6));
		assertEquals(DayOfWeek.WEDNESDAY, dgu.getDayOfWeekAs(7));
		assertEquals(DayOfWeek.THURSDAY, dgu.getDayOfWeekAs(8));
		assertEquals(DayOfWeek.FRIDAY, dgu.getDayOfWeekAs(9));
		assertEquals(DayOfWeek.SATURDAY, dgu.getDayOfWeekAs(10));
		assertEquals(DayOfWeek.SUNDAY, dgu.getDayOfWeekAs(11));

	}

	@Test
	public void testGetCurrentTime() {

		cal.setTime(now);
		assertEquals(sdf.format(cal.getTime()), dateGeneratorUtilities.getCurrentTime().toString(FORMAT));
	}

}
