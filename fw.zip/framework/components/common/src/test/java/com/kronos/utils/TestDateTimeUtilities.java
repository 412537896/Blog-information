package com.kronos.utils;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.junit.Assert;
import org.junit.Test;

import com.kronos.exception.KronosCoreCommonException;
import com.kronos.facade.DateGenerator;
import com.kronos.utils.datetime.DateTimeUtilities;


public class TestDateTimeUtilities {
      DateGenerator dg = null;
      @Test
      public void test_ymdhmsTime() throws KronosCoreCommonException {
            DateFormat ymdhms = new SimpleDateFormat("HH-mm-ss_dd-MM-yy");
            Assert.assertEquals(DateTimeUtilities.ymdhmsTime(), ymdhms.format(new Date()));
            
            Map<String, String> options = new HashMap<>();
            options.put("dateFormat", "HH-mm-ss_dd-MM-yy");
            dg = new DateGenerator(new Date(), options);
            Assert.assertEquals(DateTimeUtilities.ymdhmsTime(), dg.getToday());
            
            Assert.assertEquals(DateTimeUtilities.ymdhmsTime(), dg.getDate(0));
      }
      
      @Test
      public void test_hmsTime() throws KronosCoreCommonException {
            DateFormat ymdhms = new SimpleDateFormat("HH:mm:ss");
            Assert.assertEquals(DateTimeUtilities.hmsTime(), ymdhms.format(new Date()));
            
            dg = new DateGenerator();
            Assert.assertNotEquals(DateTimeUtilities.hmsTime(), dg.getToday());
      }
      
      @Test
      public void test_dateTime() {
            DateFormat ymdhms = new SimpleDateFormat("yyyyMMddHHmmss");
            Assert.assertEquals(ymdhms.format(new Date()), DateTimeUtilities.dateTime().substring(0, 14));
            
            Assert.assertNotEquals(DateTimeUtilities.dateTime(), new Date());
      }
      
      @Test
      public void test_Computername() throws KronosCoreCommonException {
            Assert.assertTrue(DateTimeUtilities.getComputerName() instanceof String);
      }
      
      @Test
      public void test_timeDifference() throws KronosCoreCommonException {
            Assert.assertEquals(String.valueOf(DateTimeUtilities.timeDifference("00:00:00", "00:00:01")), "1.0");
            Assert.assertEquals(String.valueOf(DateTimeUtilities.timeDifference("00:00:00", "00:01:01")), "61.0");
            Assert.assertEquals(String.valueOf(DateTimeUtilities.timeDifference("01:01:01", "00:01:01")), "3600.0");
            Assert.assertEquals(String.valueOf(DateTimeUtilities.timeDifference("23:59:59", "00:00:00")), "86399.0");
            
            Assert.assertNotEquals(String.valueOf(DateTimeUtilities.timeDifference("00:00:00", "00:00:01")), "1");
      }
      
      @Test
      public void test_yyyyMMDDHHmmssTime() throws KronosCoreCommonException {
            DateFormat ymdhms = new SimpleDateFormat("yyyyMMDDHHmmss");
            Assert.assertEquals(DateTimeUtilities.yyyyMMDDHHmmssTime(), ymdhms.format(new Date()));
            
            Assert.assertNotEquals(DateTimeUtilities.dateTime(), new Date());
      }
      
      @Test
      public void test_getDayofTheDate() throws KronosCoreCommonException {
            DateFormat ymdhms = new SimpleDateFormat("EEEE");
            Assert.assertEquals(DateTimeUtilities.getDayofTheDate(), ymdhms.format(new Date()));
            
            Assert.assertNotEquals(DateTimeUtilities.dateTime(), new Date());
      }
      
      @Test
      public void test_isLeapYear() {
            Assert.assertTrue(DateTimeUtilities.isLeapYear(2000));
            Assert.assertTrue(DateTimeUtilities.isLeapYear(2004));
            
            Assert.assertFalse(DateTimeUtilities.isLeapYear(2100));
            Assert.assertFalse(DateTimeUtilities.isLeapYear(1900));
      }
      
      @Test
      public void test_daysInMonth() {
            Assert.assertTrue(DateTimeUtilities.daysInMonth() >= 28);
            Assert.assertTrue(DateTimeUtilities.daysInMonth() <= 31);
      }
      
      @Test
      public void test_getMinutes() {
            Assert.assertEquals(DateTimeUtilities.getMinutes(new Date().getTime() + 60000), "-1 minutes");
            Assert.assertEquals(DateTimeUtilities.getMinutes(new Date().getTime() - 60000), "1 minutes");
      }

}
