package com.kronos.utils;
import java.util.HashMap;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.kronos.context.ExecutionContext;
import com.kronos.exception.KronosCoreCommonException;
import com.kronos.testng.Configurator;


public class TestExecutionContext {
	private static Configurator configurator = Configurator.getInstance();
	private static ExecutionContext executionContext;
	
	@BeforeClass
	public static void setUp() throws KronosCoreCommonException {
		HashMap<String, String> params = new HashMap<String, String>();
		params.put("Tenant", "data1");
		params.put("Tenant1", "data2");
		params.put("Frontend_Server", "data1");
		params.put("Frontend_Server1", "http://data2");
		params.put("Backend_Server", "http://data1");
		params.put("Backend_Server1", "data2");
		params.put("OpenAM_Server", "data1");
		params.put("OpenAM_Server1", "data2");
		configurator.initializeParameters(params);
		executionContext= new ExecutionContext();
	}
	
	@Test
	public void testTenant() {
		Assert.assertEquals(executionContext.getTenant(), "data1");
		executionContext.setTenant(configurator.getParameter("Tenant1"));
		Assert.assertEquals(executionContext.getTenant(), "data2");
		executionContext.setTenant();
		Assert.assertEquals(executionContext.getTenant(), "data1");
	}
	
	@Test
	public void testFrontEndServer() {
		Assert.assertEquals(executionContext.getFrontEndServer(), "http://data1/");
		executionContext.setFrontEndServer(configurator.getParameter("Frontend_Server1"));
		Assert.assertEquals(executionContext.getFrontEndServer(), "http://data2/");
		executionContext.setFrontEndServer();
		Assert.assertEquals(executionContext.getFrontEndServer(), "http://data1/");
	}
	
	@Test
	public void testBackEndServer() {
		Assert.assertEquals(executionContext.getBackEndServer(), "http://data1/");
		executionContext.setBackEndServer(configurator.getParameter("Backend_Server1"));
		Assert.assertEquals(executionContext.getBackEndServer(), "http://data2/");
		executionContext.setBackEndServer();
		Assert.assertEquals(executionContext.getBackEndServer(), "http://data1/");
	}
	
	@Test
	public void testOpenAmServer() {
		Assert.assertEquals(executionContext.getOpenAmServer(), "http://data1/");
		executionContext.setOpenAmServer(configurator.getParameter("OpenAM_Server1"));
		Assert.assertEquals(executionContext.getOpenAmServer(), "http://data2/");
		executionContext.setOpenAmServer();
		Assert.assertEquals(executionContext.getOpenAmServer(), "http://data1/");
	}

}
