package com.kronos.utils.fileio;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.joda.time.LocalDateTime;
import org.testng.Reporter;

import com.kronos.exception.KronosCoreCommonException;
import com.kronos.logging.KronosLogger;
import com.kronos.testng.Configurator;
import com.kronos.utils.datetime.DateTimeUtilities;

public class FileUtilities {
	
	static final Logger log = Logger.getLogger(FileUtilities.class);
	
	private FileUtilities(){
		
	}
	
	/**
	 * This provides the List of Response Files generated during the Test-Case
	 * Execution
	 * 
	 * @param sFilepath: String,  contains the File Path.
	 * @throws KronosCoreCommonException
	 * 		: customized kronos core common exception
	 * @return the List of Files
	 */
	public static List<String> getFileName(String sFilepath) throws KronosCoreCommonException {
		KronosLogger.traceEnter();
		try {
			List<String> listofFiles = new ArrayList<String>();
			log.info("The value of path is-------------->" + sFilepath);
			log.info("In get File Name Method------------>");
	
			File file = new File(sFilepath);
			if (file.exists()) {
				File[] listoffile = file.listFiles();
				if (listoffile != null) {
					log.info("The list of files are " + Arrays.toString(listoffile));
					log.info("Length of the Files " + listoffile.length);
					for (int i = 0; i < listoffile.length; i++) {
						log.info("The name given is---------->"
								+ listoffile[i].getAbsolutePath());
						listofFiles.add(listoffile[i].getAbsolutePath());
					}
				} else {
					log.info("The list of files are " + listoffile);
				}
			} else {
				log.info("FILE NOT FOUND");
			}
			KronosLogger.traceLeave();
			return listofFiles;
		} catch (Exception e) {
			String message = "Get File Exception: ";
			log.error(message ,e);
			throw new KronosCoreCommonException(message,e);
		}
	}

	/**
	 * This Method Provide to move the response file for Failed Test-Case to
	 * another Folder and Renaming it according to the TestCase Name
	 * 
	 * @param sFilepath: Contains the path for the Downloads Folder.
	 * @param destPath: Contains the Path for the Response Folder.
	 * @param sTestcaseName:Contains the Test case name.
	 * @throws KronosCoreCommonException
	 * 		: customized kronos core common exception
	 * @return:Returning only the boolean value
	 */
	public static boolean moveFile(String sFilepath, String destPath,
			String sTestcaseName) throws KronosCoreCommonException {
		KronosLogger.traceEnter();
		try{
			File file = null;
			log.info("File path :::" + sFilepath);
			log.info("DestPath ::::" + destPath);
			log.info("TestcaseName:::" + sTestcaseName);
			log.info("In the moveFile Method-------------");
			List<String> listofFiles = new ArrayList<String>();
			if (getFileName(sFilepath) != null) {
				listofFiles.addAll(getFileName(sFilepath));
				file = new File(listofFiles.get(0));
				listofFiles = getFileName(sFilepath);
				log.info("The file name is--------" + file.getName());
				log.info("---------------------The file is being Moved -------------");
			}
			Reporter.log("<a href=\""
					+ destPath
					+ "/"
					+ sTestcaseName
					+ "\"target='blank'><p align=\"left\"><h5>Click to get Response Data"
					+ "value" + "</h5></p></a>");
			log.info("The file destPath path is--------" + destPath + "/"
					+ sTestcaseName);
			KronosLogger.traceLeave();
			return file.renameTo(new File(destPath, sTestcaseName));
		} catch (Exception e) {
			String message = "Move File Exception: ";
			log.error(message ,e);
			throw new KronosCoreCommonException(message,e);
		}

	}

	/**
	 * This Method help us to check the Status of the file if it is moved
	 * to the new folder and Renamed with the same name as TestCase Name
	 * 
	 * @param destPath: Contains the path for the Response Folder
	 * @param sTestcaseName: Contains the test-case name.
	 * @throws KronosCoreCommonException
	 * 		: customized kronos core common exception
	 */
	public static void checkFileStatus(String destPath, String sTestcaseName) throws KronosCoreCommonException {
		KronosLogger.traceEnter();
		try{
			log.info("In Status Check Method------------>");
			File file = new File(destPath);
			File[] listoffile = file.listFiles();
			String slistofFiles;
			if (listoffile != null) {
				for (int i = 0; i < listoffile.length; i++) {
					slistofFiles = listoffile[i].getName();
					if (sTestcaseName.equalsIgnoreCase(slistofFiles)) {
						boolean var = listoffile[i].exists();
					}
				}
			} else {
				log.info("List of files is ------------>" + listoffile);
			}
		}catch (Exception e) {
			String message = "Check File Exception: ";
			log.error(message ,e);
			throw new KronosCoreCommonException(message,e);
		}
		log.info("destPath:---->"+destPath);
		log.info("sTestcaseName:---->"+sTestcaseName);
		log.info("Check is Ok.");
		KronosLogger.traceLeave();
	}


	/**
	 * This Method Creates a Directory which stores all the responses.
	 * 
	 * @param sFolderName: Contains the path for the DownLoads Folder were Response file
	 *  is created.
	 * @param sDestPath: Contains the Path for the Response Folder.
	 * @throws KronosCoreCommonException
	 * 		: customized kronos core common exception
	 */
	public static void createResponseDirectory(String sFolderName, String sDestPath) throws KronosCoreCommonException {
		KronosLogger.traceEnter();
		try{
			File file1 = new File(getFilePath(sDestPath));
			File file = new File(getFilePath(sFolderName));
			file1.mkdir();
			if (file.exists() || file.isDirectory()) {
				log.info("Folder Exist---------->");
				log.info("The value of the Absolute File is--------->"
						+ file.getAbsoluteFile().toString());
	
				if (file.getAbsoluteFile().exists()) {
					log.info("Searching for the File------------->");
	
					File[] fileArr = file.getAbsoluteFile().listFiles();
					log.info("The Files are Present------------->" + Arrays.toString(fileArr));
					log.info("The Files are Present------------->" + fileArr.length);
	
					for (int i = 0; i < fileArr.length; i++) {
						if (fileArr[i].exists()) {
							fileArr[i].delete();
							log.info("The File is Deleted");
						} else if (file.length() <= 0) {
							log.info("Folder is Empty");
						}
					}
				}
			} else {
				file.mkdir();
				log.info("The Folder is Created");
			}
		}catch (Exception e) {
			String message = "Create Directory Exception: ";
			log.error(message ,e);
			throw new KronosCoreCommonException(message,e);
		}
		log.info("sFolderName:---->"+sFolderName);
		log.info("sFolderName:---->"+sDestPath);
		log.info("Create Directory is Ok.");
		KronosLogger.traceLeave();
	}

	/**
	 * This Method moves the Response Folder and Html Reports to the Backup
	 * Folder in the Framework.
	 * 
	 * @param sResponseFolder
	 *            :Contains the Path for the Response Folder.
	 * @param sBackupFolder
	 *            : Contains the Path for the Backup Folder.
	 * @param sHtmlReportFolder
	 *            : Contains the path for the HTML Reports.
	 * @throws KronosCoreCommonException 
	 * 		: customized kronos core common exception
	 */
	public static void moveDataBackup(String sResponseFolder, String sBackupFolder,
			String sHtmlReportFolder) throws KronosCoreCommonException {
		KronosLogger.traceEnter();
		log.info("In the DataBack_Up Folder");
		File file = new File(getFilePath(sResponseFolder));
		File file1 = new File(getFilePath(sBackupFolder));
		File file2 = new File(getFilePath(sHtmlReportFolder));
		file1.mkdir();
		log.info("The BackUp directory is created");
		try {
			file.renameTo(new File(file1, file.getName()
					+ DateTimeUtilities.yyyyMMDDHHmmssTime()));
			Thread.sleep(5000);
			file2.renameTo(new File(file1, file2.getName()
					+ DateTimeUtilities.yyyyMMDDHHmmssTime()));
			file.mkdir();
		} catch (Exception e) {
			String errMsg = "Move Data Backup fail";
			log.error(errMsg ,e);
			throw new KronosCoreCommonException(errMsg,e);
		}
		log.info("sResponseFolder:---->"+sResponseFolder);
		log.info("sBackupFolder:---->"+sBackupFolder);
		log.info("sHtmlReportFolder:---->"+sHtmlReportFolder);
		KronosLogger.traceLeave();
	}

	/**
	 * This method will check for existance of file
	 * 
	 * @param sFilePath: File
	 * @return true or false if file exists or not
	 */
	public static boolean fileExist(File sFilePath) {
		log.info("In the File Exist Method");
		boolean status = false;
		if (sFilePath.isFile()) {
			log.info("File is Present-------");
		} else {
			log.info("File does not exist.........");
		}
		return status;
	}

	/**
	 * This method will check for existance of directory
	 * 
	 * @param sFilePath: File
	 * @return an array
	 */
	public static String[] directoryExist(File sFilePath) {
		String[] list = null;
		if (sFilePath.isDirectory()) {
			list = sFilePath.list();
			log.info("Directoryis fount and files are getting added");
		} else {
			log.info("The above is not Directory");

		}
		return list;
	}

	/**
	 * This method will write messages on file
	 * 
	 * @param msg: Message to write on file
	 * @throws KronosCoreCommonException 
	 * 			: customized kronos core common exeception
	 */
	public static void flog(String msg) throws KronosCoreCommonException {
		flog("flog.html", msg);
	}

	/**
	 * This method will write messages on file
	 * 
	 * @param fileName
	 *            : Name of file
	 * @param msg
	 *            : Message to write on file
	 * @param suffix
	 *            : Suffix added to message
	 * @throws KronosCoreCommonException 
	 * 		: customized kronos core common exception
	 */
	public static void flog(String fileName, String msg, String suffix) throws KronosCoreCommonException {
		KronosLogger.traceEnter();
		FileWriter fw = null;
		try {
			fw = new FileWriter(fileName, true);
			fw.write(msg + suffix);
			fw.close();
		} catch (Exception e) {
			String errMsg = "Flog fail and throw an exception";
			log.error(errMsg);
			throw new KronosCoreCommonException(errMsg + e.getMessage());
		} 
		log.info("fileName :--->"+fileName);
		log.info("msg :--->"+msg);
		log.info("suffix :--->"+suffix);
		KronosLogger.traceLeave();
	}

	/**
	 * This method will write messages on file
	 * 
	 * @param fileName
	 *            : Name of file
	 * @param msg
	 *            : Message to write on file
	 * @throws KronosCoreCommonException 
	 * 		: customized kronos core common exception
	 */
	public static void flog(String fileName, String msg) throws KronosCoreCommonException {
		flog(fileName, msg, "<br>\n");
	}


	/**
	 * This Method is used to create the file
	 * 
	 * @param filePath: String
	 * @throws KronosCoreCommonException 
	 * 		: customized kronos core common exception
	 * @return ture or false
	 */
	public static boolean createFile(String filePath) throws KronosCoreCommonException {
		KronosLogger.traceEnter();
		try {
			File file = new File(filePath);
			log.info("filePath :--->"+filePath);
			if (file.createNewFile())
			{
				KronosLogger.traceLeave();
				return true;
			}
			else
			{
				KronosLogger.traceLeave();
				return false;
			}
		} catch (Exception e) {
			String errMsg = "Create file failed.";
			log.error(errMsg ,e);
			KronosLogger.traceLeave();
			throw new KronosCoreCommonException(errMsg,e);
		}
	}

	/**
	 * This Method is used to set the file permission
	 * 
	 * @param setExecutable: boolean
	 * @param setReadable: boolean
	 * @param setWritable: boolean
	 * @param filePathWithExtn: String
	 * @throws KronosCoreCommonException 
	 * 		: customized kronos core common exception
	 */
	public static void setFilePermissions(boolean setExecutable,
			boolean setReadable, boolean setWritable, String filePathWithExtn) throws KronosCoreCommonException {
		KronosLogger.traceEnter();
		try {
			File file = new File(filePathWithExtn);
			file.setExecutable(setExecutable);
			file.setReadable(setReadable);
			file.setWritable(setWritable);
		} catch (Exception e) {
			String errMsg = "Set File Permissions failed";
			log.error(errMsg ,e);
			throw new KronosCoreCommonException(errMsg,e);
		}
		log.info("filePathWithExtn:-->"+filePathWithExtn);
		KronosLogger.traceLeave();
	}

	/**
	 * This Method is used reading from file
	 * 
	 * @param filePathWithExtn: String
	 * @throws KronosCoreCommonException
	 * 		: customized kronos core common exception
	 * @return the file in String
	 * @throws IOException Java input output exception
	 * @throws KronosCoreCommonException 
	 * 		: customized kronos core common exception
	 */
	public static String readFileAsString(String filePathWithExtn) throws KronosCoreCommonException, IOException  {
		KronosLogger.traceEnter();
		BufferedReader br = null;
		try {
			String strData = null, strTemp = null;
			br = new BufferedReader(new FileReader(filePathWithExtn));
			while ((strTemp = br.readLine()) != null) {
				strData = strData + strTemp;
			}
			log.info("ReadFile success!");
			log.info("filePathWithExtn:-->"+filePathWithExtn);
			KronosLogger.traceLeave();
			return strData;
		} catch (Exception e) {
			String errMsg = "ReadFile failed!";
			log.error(errMsg ,e);
			throw new KronosCoreCommonException(errMsg,e);
		} finally {
				br.close();
		}
	}

	/**
	 * This Method is used for writing into file
	 * 
	 * @param filePathWithExtn: String
	 * @param dataToWrite: String
	 * @exception KronosCoreCommonException
	 * 		: customized kronos core common exception
	 */
	public static void writeToFile(String filePathWithExtn, String dataToWrite) throws KronosCoreCommonException {
		KronosLogger.traceEnter();
		try {
			File file = new File(filePathWithExtn);
			if (!file.exists())
				file.createNewFile();
			FileWriter fw = new FileWriter(file.getAbsoluteFile());
			BufferedWriter bw = new BufferedWriter(fw);
			bw.write(dataToWrite);
			bw.close();
		} catch (Exception e) {
			String errMsg = "Write file failed!";
			log.error(errMsg ,e);
			throw new KronosCoreCommonException(errMsg,e);
		}
		log.info("filePathWithExtn:-->"+filePathWithExtn);
		log.info("dataToWrite:-->"+dataToWrite);
		log.info("Write file success!");
		KronosLogger.traceLeave();
	}

	/**
	 * This Method is used appending the data
	 * 
	 * @param filePathWithExtn: String
	 * @param dataToAppend: String
	 * @exception KronosCoreCommonException
	 * 		: customized kronos core common exception
	 */
	public static void appendToFile(String filePathWithExtn, String dataToAppend) throws KronosCoreCommonException {
		KronosLogger.traceEnter();
		try {
			File file = new File("javaio-appendfile.txt");
			if (!file.exists())
				file.createNewFile();
			FileWriter fileWritter = new FileWriter(file.getName(), true);
			BufferedWriter bufferWritter = new BufferedWriter(fileWritter);
			bufferWritter.write(dataToAppend);
			bufferWritter.close();
		} catch (Exception e) {
			String errMsg = "Append failed!";
			log.error(errMsg ,e);
			throw new KronosCoreCommonException(errMsg,e);
		}
		log.info("filePathWithExtn:-->"+filePathWithExtn);
		log.info("dataToAppend:-->"+dataToAppend);
		log.info("Append success!");
		KronosLogger.traceLeave();
	}

	/**
	 * This Method is used for deleting the file
	 * 
	 * @param filePathWithExtn: String
	 * @throws KronosCoreCommonException
	 * 		: customized kronos core common exception
	 * @return true or false
	 */
	public static boolean deleteFile(String filePathWithExtn) throws KronosCoreCommonException {
		KronosLogger.traceEnter();
		try {
			File file = new File(filePathWithExtn);
			log.info("filePathWithExtn:-->"+filePathWithExtn);
			log.info("File loaded !");
			KronosLogger.traceLeave();
			return file.delete();
		} catch (Exception e) {
			String errMsg = "Delete file failed!";
			log.error(errMsg ,e);
			throw new KronosCoreCommonException(errMsg,e);
		}
		
	}

	/**
	 * This Method is used to rename the file
	 * 
	 * @param oldFilePathWithExtn: String
	 * @param newFilePathWithExtn: String
	 * @throws KronosCoreCommonException
	 * 		: customized kronos core common exception
	 * @return true or false
	 */
	public static boolean renameFile(String oldFilePathWithExtn,
			String newFilePathWithExtn) throws KronosCoreCommonException {
		KronosLogger.traceEnter();
		try {
			File oldfile = new File(oldFilePathWithExtn);
			File newfile = new File(newFilePathWithExtn);
			log.info("oldFilePathWithExtn:-->"+oldFilePathWithExtn);
			log.info("newFilePathWithExtn:-->"+newFilePathWithExtn);
			log.info("File loaded !");
			KronosLogger.traceLeave();
			return oldfile.renameTo(newfile);
		} catch (Exception e) {
			String errMsg = "Rename file failed!";
			log.error(errMsg ,e);
			throw new KronosCoreCommonException(errMsg,e);
		}
	}

	/**
	 * This Method is used to copy one file to another
	 * 
	 * @param srcFileWithExtn: String
	 * @param destFileWithExtn: String
	 * @throws KronosCoreCommonException
	 * 		: customized kronos core common exception
	 */
	public static void copyFile(String srcFileWithExtn, String destFileWithExtn) throws KronosCoreCommonException {
		KronosLogger.traceEnter();
		try {
			InputStream inStream = null;
			OutputStream outStream = null;
			File afile = new File(srcFileWithExtn);
			File bfile = new File(destFileWithExtn);
			inStream = new FileInputStream(afile);
			outStream = new FileOutputStream(bfile);
			byte[] buffer = new byte[1024];
			int length;
			while ((length = inStream.read(buffer)) > 0)
				outStream.write(buffer, 0, length);
			inStream.close();
			outStream.close();
		} catch (Exception e) {
			String errMsg = "Copy file failed!";
			log.error(errMsg ,e);
			throw new KronosCoreCommonException(errMsg,e);
		}
		log.info("srcFileWithExtn:-->"+srcFileWithExtn);
		log.info("destFileWithExtn:-->"+destFileWithExtn);
		log.info("Copy file success!");
		KronosLogger.traceLeave();
	}

	/**
	 * This Method is used to move the file
	 * 
	 * @param srcFileWithExtn: String
	 * @param destFileWithExtn: String
	 * @throws KronosCoreCommonException
	 * 		: customized kronos core common exception
	 */
	public static void moveFile(String srcFileWithExtn, String destFileWithExtn) throws KronosCoreCommonException {
		KronosLogger.traceEnter();
		try {
			InputStream inStream = null;
			OutputStream outStream = null;
			File afile = new File(srcFileWithExtn);
			File bfile = new File(destFileWithExtn);
			inStream = new FileInputStream(afile);
			outStream = new FileOutputStream(bfile);
			byte[] buffer = new byte[1024];
			int length;
			while ((length = inStream.read(buffer)) > 0)
				outStream.write(buffer, 0, length);
			inStream.close();
			outStream.close();
			afile.delete();
		} catch (Exception e) {
			String errMsg = "Move file failed!";
			log.error(errMsg ,e);
			throw new KronosCoreCommonException(errMsg,e);
		}
		log.info("srcFileWithExtn:-->"+srcFileWithExtn);
		log.info("destFileWithExtn:-->"+destFileWithExtn);
		log.info("Move file success!");
		KronosLogger.traceLeave();
	}

	/**
	 * This Method is used to check whether the file exist or not
	 * 
	 * @param filePathWithExtn: String
	 * @throws KronosCoreCommonException
	 * 		: customized kronos core common exception
	 * @return true or false
	 */
	public static boolean checkFileExists(String filePathWithExtn) throws KronosCoreCommonException {
		KronosLogger.traceEnter();
		try {
			File f = new File(filePathWithExtn);
			log.info("filePathWithExtn:-->"+filePathWithExtn);
			log.info("File loaded!");
			KronosLogger.traceLeave();
			return f.exists();
		} catch (Exception e) {
			String errMsg = "Check file failed!";
			log.error(errMsg ,e);
			throw new KronosCoreCommonException(errMsg,e);
		}

	}

	/**
	 * This Method is used to get the Absolute path of the File
	 * 
	 * @param sFilepath: String
	 * @throws KronosCoreCommonException 
	 * 		: customized kronos core common exception
	 * @return It returns the Path of the File
	 */
	public static String getFilePath(String sFilepath) throws KronosCoreCommonException {
		KronosLogger.traceEnter();
		try
		{
			char cforwardslash = (char) 47;
			char cbackslash = (char) 92;
			String sPath = System.getProperty("user.dir").replace(cbackslash,
					cforwardslash)
					+ sFilepath;
			
			File file = new File(sPath);
			log.info("sFilepath:-->"+sFilepath);
			KronosLogger.traceLeave();
			return file.getAbsolutePath();
		}catch (Exception e)
		{
			String errMsg = "Get File Path failed!";
			log.error(errMsg ,e);
			throw new KronosCoreCommonException(errMsg,e);
		}
	}
	
	/**
	 * wait for a file or a directory size not changed; can be used to wait for download or delete operation complete
	 * 
	 * @param filePath the file or directory path
	 * @param timeout maximum time to wait
	 * @throws KronosCoreCommonException
	 * 		: customized kronos core common exception
	 * @throws InterruptedException 
	 */
	public static void waitForFileDownloaded(String filePath, int timeout) throws KronosCoreCommonException, InterruptedException {
		boolean isDir;
		waitToStartDownload(new String(filePath));
		File file = new File(filePath);
		if (!file.exists()) {
			return;
		} else {
			isDir = file.isDirectory();
		}
		long endtime = System.currentTimeMillis() + timeout * 1000;

		long initialFileSize = 0;
		//long finalFileSize = isDir ? FileUtils.sizeOfDirectory(file) : FileUtils.sizeOf(file);
		long finalFileSize = 50;
		
		File initialFile = new File(filePath);
		File finalFile = new File(filePath);

		while (initialFileSize != finalFileSize && System.currentTimeMillis() < endtime) {
			try {
				initialFileSize = isDir ? FileUtils.sizeOfDirectory(initialFile) : FileUtils.sizeOf(initialFile);
				Thread.sleep(500);
				finalFileSize = isDir ? FileUtils.sizeOfDirectory(finalFile) : FileUtils.sizeOf(finalFile);
			} catch (Exception e) {
				log.warn("InterruptedException exception accoured during wait for file size not changed", e);
				initialFileSize = isDir ? FileUtils.sizeOfDirectory(initialFile) : FileUtils.sizeOf(initialFile);
				Thread.sleep(500);
				finalFileSize = isDir ? FileUtils.sizeOfDirectory(finalFile) : FileUtils.sizeOf(finalFile);
			}
		}
		if (System.currentTimeMillis() > endtime) {
			throw new KronosCoreCommonException("File is not downloaded in the given time.");
		}
	}
	
	
	/**
	 * wait for a file or a directory size not changed; can be used to wait for download or delete operation complete. This 
	 * will use the default timeout mentioned in testng.xml
	 * 
	 * @param filePath the file or directory path
	 * @throws KronosCoreCommonException
	 * 		: customized kronos core common exception
	 * @throws InterruptedException 
	 */
	public static void waitForFileDownloaded(String filePath) throws KronosCoreCommonException, InterruptedException {
		boolean isDir;
		
		waitToStartDownload(new String(filePath));
		
		File file = new File(filePath);
		if (!file.exists()) {
			return;
		} else {
			isDir = file.isDirectory();
		}
	
		int timeout =  Integer.parseInt(Configurator.getInstance().getParameter("timeout"));
		long endtime = System.currentTimeMillis() + timeout * 1000;

		long initialFileSize = 0;
		//long finalFileSize = isDir ? FileUtils.sizeOfDirectory(file) : FileUtils.sizeOf(file);
		long finalFileSize = 50;
		
		File initialFile = new File(filePath);
		File finalFile = new File(filePath);
		
		while (System.currentTimeMillis() < endtime && initialFileSize != finalFileSize) {
			try {
				initialFileSize = isDir ? FileUtils.sizeOfDirectory(initialFile) : FileUtils.sizeOf(initialFile);
				Thread.sleep(500);
				finalFileSize = isDir ? FileUtils.sizeOfDirectory(finalFile) : FileUtils.sizeOf(finalFile);
			} catch (Exception e) {
				log.warn("InterruptedException exception accoured during wait for file size not changed", e);
				initialFileSize = isDir ? FileUtils.sizeOfDirectory(initialFile) : FileUtils.sizeOf(initialFile);
				Thread.sleep(500);
				finalFileSize = isDir ? FileUtils.sizeOfDirectory(finalFile) : FileUtils.sizeOf(finalFile);
			}
		}
		if (System.currentTimeMillis() > endtime) {
			throw new KronosCoreCommonException("File is not downloaded in the given time.");
		}
	}
	
	/**
	 * wait for a file or a directory size not changed; can be used to wait for download or delete operation complete. This 
	 * will use the default timeout mentioned in testng.xml
	 * 
	 * @param filePath the file or directory path
	 * @throws KronosCoreCommonException
	 * 		: customized kronos core common exception
	 * @throws InterruptedException 
	 */
	private static void waitToStartDownload(String filePath) throws KronosCoreCommonException, InterruptedException {
		File file = new File(filePath);
		if (!file.exists()) {
			return;
		} else if (!file.isDirectory()) {
			return;
		}
		int timeout =  Integer.parseInt(Configurator.getInstance().getParameter("timeout"));
		//Delete 24 hours old files
		FileFilter deleteFilter = new FileFilter() {
			@Override
			public boolean accept(File pathname) {
				LocalDateTime dt = new LocalDateTime(pathname.lastModified());
				if ((pathname.getName().endsWith(".crdownload") || pathname.getName().endsWith(".partial")
						|| pathname.getName().endsWith(".part")) && dt!=null && (new LocalDateTime()).toDateTime().minusHours(2).compareTo(dt.toDateTime()) >0) {
					return true;
				}
				return false;
			}
		};
		File[] files = file.listFiles(deleteFilter);
		for(int i=0;i<files.length;i++)
			files[i].delete();
		
		long endtime = System.currentTimeMillis() + timeout * 1000;
		while (System.currentTimeMillis() < endtime) {
			FileFilter filter = new FileFilter() {
				@Override
				public boolean accept(File pathname) {
				LocalDateTime dt = new LocalDateTime(pathname.lastModified());
				if ((pathname.getName().endsWith(".crdownload") || pathname.getName().endsWith(".partial")
							|| pathname.getName().endsWith(".part"))) {
						return true;
					}
					return false;
				}
			};
			files = file.listFiles(filter);
			if(files.length >0) {
				break;
			}
			
			else {
				Thread.sleep(100);
				continue;
			}
		}
		/*if (System.currentTimeMillis() > endtime) {
			throw new KronosCoreCommonException("File downloaded did not start in the given time.");
		}*/
		files=null;
	}
	
	/**
	 * get file count in a directory, the count is not include the file name end with .crdownload, .partial, .part
	 * @param dir: where the file will be downloaded
	 * @return it returns the file count 
	 */
	public static int getFileCount(String dir) {
		File file = new File(dir);
		if (!file.exists()) {
			return 0;
		} else if (!file.isDirectory()) {
			return 0;
		}
		FileFilter filter = new FileFilter() {
			@Override
			public boolean accept(File pathname) {
				if (pathname.getName().endsWith(".crDownloading started download") || pathname.getName().endsWith(".partial")
						|| pathname.getName().endsWith(".part")) {
					return false;
				}
				return true;
			}
		};
		File[] files = file.listFiles(filter);
		return files.length;
	}
	

}
