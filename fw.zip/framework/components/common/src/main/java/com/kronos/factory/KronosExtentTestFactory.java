package com.kronos.factory;

import com.kronos.exception.KronosCoreCommonException;
import com.kronos.report.KronosExtentTest;
import com.kronos.tracking.SessionUsageAPI;
import com.kronos.tracking.SessionUsageUI;
import com.relevantcodes.extentreports.ExtentTest;

public class KronosExtentTestFactory {	
	/**
	 * Create an element usage tracker
	 * @param kronosExtentTest 
	 * @param apiTracker 
	 * @param retryCount 
	 * @param groups 
	 * 
	 * @param name: String
	 * @param  port: String
	 * @return CaseUsageTracker
	 * @throws KronosCoreCommonException
	 * 		: customized kronos core common exception
	 */
	public static KronosExtentTest createKronosExtentTest(String name, String desc,
			String[] groups, String packageLocation, String[] dependsOnMethods, String retryName, int retryCount, 
			SessionUsageAPI apiSession,
			SessionUsageUI uiSession,
			KronosExtentTest testAtClass){
			
		return new KronosExtentTest( 
				new ExtentTest(name + retryName, generateTestCaseInformation(desc, groups,packageLocation,dependsOnMethods)),
				apiSession == null ? null : apiSession.resetCaseUsage(name,desc, groups,packageLocation,dependsOnMethods),
				uiSession == null ? null : uiSession.resetCaseUsage(name,desc, groups,packageLocation,dependsOnMethods),
				retryCount, name, testAtClass);
	}
	
	public static KronosExtentTest createKronosExtentTest(String name, String desc,
			String[] groups, String packageLocation, String[] dependsOnMethods, 
			SessionUsageAPI apiSession,
			SessionUsageUI uiSession,
			KronosExtentTest testAtClass){
			
		return new KronosExtentTest( 
				new ExtentTest(name, generateTestCaseInformation(desc,groups,packageLocation,dependsOnMethods)),
				apiSession == null ? null : apiSession.resetCaseUsage(name,desc, groups,packageLocation,dependsOnMethods),
				uiSession == null ? null : uiSession.resetCaseUsage(name,desc, groups,packageLocation,dependsOnMethods),
				0, name, testAtClass);
	}
	
	
	public static KronosExtentTest createKronosExtentTest(SessionUsageAPI apiSession,SessionUsageUI uiSession){
			
		return new KronosExtentTest( 
				new ExtentTest("", ""),
				apiSession == null ? null : apiSession.resetCaseUsage("","",null,"",null),
				uiSession == null ? null : uiSession.resetCaseUsage("","",null,"",null),
				0, "", null);
	}
	
	
	private static String generateTestCaseInformation(String description, String[] groups, String packageLocation, String[] dependsOnMethods){
		return "<div>Groups: <span style=\"font: italic bold 12px/30px Georgia, serif;\">" 
				+ listToCommaSeparatedString(groups)+ "</span>"
				+ "</div><div>"
				+ "Location: <span style=\"font: italic bold 12px/30px Georgia, serif;\">" 
				+ packageLocation + "</span>"
				+ "</div><div>"
				+ "dependsOnMethods: <span style=\"font: italic bold 12px/30px Georgia, serif;\">" 
				+ listToCommaSeparatedString(dependsOnMethods)+ "</span>"
				+ "</div>"
				+ "Description: " + description;
	}
	
	
	private static String listToCommaSeparatedString(String[] list)
	{
		String CSString = "";
		if(list !=null)
			for(String g:list){
				CSString = CSString + g + ", "; 
			}
		if (CSString.endsWith(", "))
			CSString = CSString.substring(0, CSString.length()-2);
		return CSString;
	}
	
}
