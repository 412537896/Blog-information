package com.kronos.tracking;

public enum Actions {
	POST,
	PUT,
	DELETE,
	GET,
	PATCH;
}
