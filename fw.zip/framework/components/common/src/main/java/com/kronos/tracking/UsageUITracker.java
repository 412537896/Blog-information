package com.kronos.tracking;

import org.bson.Document;

import com.kronos.utils.common.TrackingConstant;
import com.mongodb.client.MongoDatabase;

public class UsageUITracker {
	private String locatorName;
	private String locatorValue;
	private String navigation;
	private String action;

	private int lineNumber;
	private String usedFor;
	/**
	 * Default constructor
	 */
	public UsageUITracker(){
		
	}
	
	/**
	 * Constructor with four parameters
	 * @param locatorName: String
	 * @param locatorValue: String
	 * @param navigation: String
	 * @param action: String
	 */
	public UsageUITracker(String locatorName, String locatorValue, String navigation,String action) {
		this.locatorName = locatorName;
		this.locatorValue = locatorValue;
		this.navigation = navigation;
		this.action = action;
		
		
	}
	
	/**
	 * Get locator name
	 * @return locatorName: String
	 */
	public String getLocatorName() {
		return locatorName;
	}
	
	/**
	 * Set locator name
	 * @param locatorName: String
	 */
	public void setLocatorName(String locatorName) {
		this.locatorName = locatorName;
	}
	
	/**
	 * Get locator value
	 * @return locatorValue: String
	 */
	public String getLocatorValue() {
		return locatorValue;
	}
	
	/**
	 * Set locator value
	 * @param locatorValue: String
	 */
	public void setLocatorValue(String locatorValue) {
		this.locatorValue = locatorValue;
	}
	
	/**
	 * Get navigation
	 * @return navigation: String
	 */
	public String getNavigation() {
		return navigation;
	}
	
	/**
	 * Set navigation
	 * @param navigation: String
	 */
	public void setNavigation(String navigation) {
		this.navigation = navigation;
	}

	/**
	 * Get action
	 * @return action: String
	 */
	public String getAction() {
		return action;
	}

	/**
	 * Set action
	 * @param action: String
	 */
	public void setAction(String action) {
		this.action = action;
	}
	
	public int getLineNumber() {
		return lineNumber;
	}

	public void setLineNumber(int lineNumber) {
		this.lineNumber = lineNumber;
	}

	public String getUsedFor() {
		return usedFor;
	}

	public void setUsedFor(String usedFor) {
		this.usedFor = usedFor;
	}

	public void save(MongoDatabase trackerDB, Object sessionId, Object caseId) {
		trackerDB.getCollection(TrackingConstant.TRACKER_COLLECTION).insertOne(
				new Document()
				.append("session", sessionId)
				.append("case", caseId)
				.append("name", this.locatorName)
				.append("value", this.locatorValue)
				.append("action", this.action)
				.append("navigation", this.navigation)
		);
	}

}
