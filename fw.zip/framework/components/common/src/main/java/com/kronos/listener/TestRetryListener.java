package com.kronos.listener;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;

import org.testng.IAnnotationTransformer;
import org.testng.IRetryAnalyzer;
import org.testng.annotations.ITestAnnotation;

import com.kronos.assertion.KronosRetryAnalyzer;

public class TestRetryListener implements IAnnotationTransformer{
	
	/**
	 * Automatically set retry to every method 
	 */
	@Override
	public void transform(ITestAnnotation annotation, Class testClass, Constructor testConstructor, Method testMethod) {
		IRetryAnalyzer retry = annotation.getRetryAnalyzer();
		if (retry == null)	{
			annotation.setRetryAnalyzer(KronosRetryAnalyzer.class);
		}
	}
}
