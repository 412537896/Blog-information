package com.kronos.utils.datetime;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.log4j.Logger;

import com.kronos.exception.KronosCoreCommonException;
import com.kronos.logging.KronosLogger;

import java.net.InetAddress;

public class DateTimeUtilities {
	
	static final Logger logger = Logger.getLogger(DateTimeUtilities.class);
	
	private DateTimeUtilities(){
		
	}
	/**
	 * Customize DateFormat in (HH-mm-ss_dd-MM-yy)
	 * 
	 * @throws KronosCoreCommonException
	 * 		: customized kronos core common exception
	 * @return Time-date in the format of String
	 */
	public static String ymdhmsTime() throws KronosCoreCommonException {
		KronosLogger.traceEnter();
		try {
			String ymdhmsTime = null;
			DateFormat ymdhms = new SimpleDateFormat("HH-mm-ss_dd-MM-yy");
			Date date = new Date();
			ymdhmsTime = ymdhms.format(date);
			logger.info("Operation output is: " + ymdhmsTime);
			KronosLogger.traceLeave();
			return ymdhmsTime;
		} catch (Exception e) {
			String message = "Get current date failed: ";
			logger.error(message, e);
			throw new KronosCoreCommonException(message,e);
		}
	}

	
	/**
	 * Customize Time in Format(HH:mm:ss)
	 * 
	 * @throws KronosCoreCommonException
	 * 			: customized krons core common exception
	 * @return time in the format of String
	 */
	public static String hmsTime() throws KronosCoreCommonException {
		KronosLogger.traceEnter();
		try {
			String hmsTime = null;
			DateFormat hms = new SimpleDateFormat("HH:mm:ss");
			Date date = new Date();
			hmsTime = hms.format(date);
			logger.info("Operation output is: " + hmsTime);
			KronosLogger.traceLeave();
			return hmsTime;
		} catch (Exception e) {
			String message = "Get current time failed : ";
			logger.error(message ,e);
			throw new KronosCoreCommonException(message,e);
		}
	}

	/**
	 * Format a date time
	 * 
	 * @return time in the format of String
	 */
	public static String dateTime() {
		return new SimpleDateFormat("yyyyMMddHHmmssSSS").format(new Date());
	}

	/**
	 * Get Computer name
	 * 
	 * @throws KronosCoreCommonException
	 * : customized krons core common exception
	 * @return computer name in String
	 */
	public static String getComputerName() throws KronosCoreCommonException {
		KronosLogger.traceEnter();
		try{
			String str = InetAddress.getLocalHost().getHostName().replace("-", "")
					.substring(0, 6);
			logger.info("Operation output is: " + str);
			KronosLogger.traceLeave();
			return str;
		}catch(Exception e){
			String message = "Get hostName failed :  ";
			logger.error(message ,e);
			throw new KronosCoreCommonException(message,e);
		}
	}
	
	/**
	 * Calculating difference between the startTime and endTime
	 * 
	 * @param startTime: String
	 * @param endTime: String
	 * @throws KronosCoreCommonException
	 * 			: customized kronos core common exception
	 * @return time-difference in the format of double
	 */
	public static double timeDifference(String startTime, String endTime) throws KronosCoreCommonException {
		KronosLogger.traceEnter();
		try {
			DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
			Date time1 = dateFormat.parse(startTime);
			Date time2 = dateFormat.parse(endTime);
			long t1 = time1.getTime();
			long t2 = time2.getTime();
			double diffTime = Math.abs(t2 - t1) / 1000;
			logger.info("Operation input String is: " + startTime+"Operation input String is: "+endTime);
			KronosLogger.traceLeave();
			return diffTime;
		} catch (Exception e) {
			String message = "Failed to process data: ";
			logger.error(message ,e);
			throw new KronosCoreCommonException(message,e);
		}

	}
	
	/**
	 * Customize DateFormat in (yyyyMMDDHHmmss)
	 * 
	 * @throws KronosCoreCommonException
	 * 			: customized krons core common exception
	 * @return date in the format of String yyyyMMDDHHmmss
	 */
	public static String yyyyMMDDHHmmssTime() throws KronosCoreCommonException   {
		KronosLogger.traceEnter();
		try {
			String ymdhmsTime = null;
			DateFormat ymdhms = new SimpleDateFormat("yyyyMMDDHHmmss");
			Date date = new Date();
			ymdhmsTime = ymdhms.format(date);
			logger.info("Operation output is: " + ymdhmsTime);
			KronosLogger.traceLeave();
			return ymdhmsTime;
		} catch (Exception e) {
			String message = "Get current dateTime failed : ";
			logger.error(message ,e);
			throw new KronosCoreCommonException(message,e);
		}
	}

	/**
	 * Get day of the date
	 * 
	 * @throws KronosCoreCommonException
	 * 			: customized krons core common exception
	 * @return day in String
	 */
	public static String getDayofTheDate() throws KronosCoreCommonException {
		KronosLogger.traceEnter();
		try {
			Date d1 = new Date();
			String day = null;
			DateFormat f = new SimpleDateFormat("EEEE");
			day = f.format(d1);
			logger.info("Operation output is: " + day);
			KronosLogger.traceLeave();
			return day;
		} catch (Exception e) {
			String message = "Get date failed:";
			logger.error(message ,e);
			throw new KronosCoreCommonException(message,e);
		}
	}
	
	/**
	 * Find the leap year
	 * 
	 * @param year: int
	 * @return boolean value
	 */	
	public static boolean isLeapYear(int year) {
		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.YEAR, year);
		return cal.getActualMaximum(Calendar.DAY_OF_YEAR) > 365;
	}
	/**
	 * Get number of days in the month
	 * 
	 * @return no of days
	 */	
	public static int daysInMonth() {
		Calendar c1 = Calendar.getInstance();
		int year = c1.get(Calendar.YEAR);
		int month = c1.get(Calendar.MONTH);
		int[] daysInMonths = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30,31 };
		daysInMonths[1] += isLeapYear(year) ? 1 : 0;
		return daysInMonths[month];
	}
	

	/**
	 * Calculate the minutes
	 * 
	 * @param startTime: long
	 * @return minutes in the form of String
	 */
	public static String getMinutes(long startTime) {
		return (new Date().getTime() - startTime) / 1000 / 60 + " minutes";
	}
}
