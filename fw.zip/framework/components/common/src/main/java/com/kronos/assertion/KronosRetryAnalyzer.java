package com.kronos.assertion;

import java.util.Map;

import org.testng.IRetryAnalyzer;
import org.testng.ITestResult;

public class KronosRetryAnalyzer implements IRetryAnalyzer {
    private int retryCount = 0;
    private int maxRetryCount = 1;
   
    public boolean retry(ITestResult result) {
    	Map<String, String> params = result.getTestContext().getCurrentXmlTest().getAllParameters();
    	maxRetryCount = Integer.parseInt(params.containsKey("retryMaxCount") ? params.get("retryMaxCount") : "0");
        if(maxRetryCount < 0){
           maxRetryCount = 1;
        }
        if (retryCount < maxRetryCount) {
            retryCount++;
            return true;
        }
        return false;
    }
}