package com.kronos.testng;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Method;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.testng.ITestContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.kronos.context.ExecutionContext;
import com.kronos.exception.KronosCoreCommonException;
import com.kronos.facade.DateGenerator;
import com.kronos.facade.DateParser;
import com.kronos.listener.TestResultListener;
import com.kronos.logging.KronosLogger;
import com.kronos.report.Reporter;
import com.kronos.utils.common.ContextConstant;
import com.kronos.utils.common.SSHHandler;

@Listeners(TestResultListener.class)
public abstract class BaseTest {

	private static final String TIMESTAMP = new SimpleDateFormat("yyyy_MM_dd_HHmmssSSS").format(new Date());
	private static final Logger logger =Logger.getLogger(BaseTest.class);

	protected static DateParser dateParser;
	protected static DateGenerator dateGenerator;

	protected Reporter reporter=Reporter.getInstance();
	protected Configurator configurator = Configurator.getInstance();
	protected ExecutionContext executionContext;
	protected String sauceLabsReportDir = "";
	/**
	 * Before suite, initialization
	 * 
	 * @param context: ITestContext
	 * @throws KronosCoreCommonException
	 * 		: customized kronos core common exception
	 */
	@BeforeSuite(alwaysRun = true)
	public void beforeSuite(ITestContext context) throws KronosCoreCommonException {
		KronosLogger.traceEnter();
		try {
			Logger.getLogger("org.apache.http.wire").setLevel(Level.OFF);

			Map<String,String> params = context.getCurrentXmlTest().getAllParameters();
			configurator.initializeParameters(params);
			reporter.initializeReport(configurator.getDirectoryParameter("current_report"), 
					configurator.getDirectoryParameter("current_sc_report"), 
					params);

			dateParser = new DateParser(params);
			dateGenerator = new DateGenerator(params);
		} catch (Exception e) {
			String errorMsg = "execution before suite fail!";
			logger.error(errorMsg, e);
			throw new KronosCoreCommonException(errorMsg,e);
		}
		KronosLogger.traceLeave();
	}

	/**
	 * After suite, end the report
	 * 
	 * @throws KronosCoreCommonException
	 * 		: customized kronos core common exception
	 * @throws IOException 
	 */
	@AfterSuite(alwaysRun=true)
	public void afterSuite(ITestContext context) throws KronosCoreCommonException, IOException {
		KronosLogger.traceEnter();
		if (context.getAllTestMethods().length > 0){
			reporter.endReport();
		}else{
			logger.info("No test was found candidate for this run as per testNG.xml");
			reporter.customReportGenerator(configurator.getDirectoryParameter("current_report"), context);
		}		
		if ("true".equalsIgnoreCase(configurator.getParameter("PUBLISH_RESULTS_TO_ALM"))){
			String wfmBuildNumber = "";
			String wfmHostName = "";
			SSHHandler sshHandler = new SSHHandler();
			String serverUrl = configurator.getParameter(ContextConstant.WFM_URL).replace("http://", "").replace("https://", "");
			if(serverUrl.contains("back")){
				String[] splitData = serverUrl.split("-");
				wfmHostName = splitData[0] + "-" + splitData[1] + "-back.int.dev.mykronos.com";
			}
			else{
				wfmHostName = serverUrl.substring(0 , serverUrl.indexOf("."))  + "-back.int.dev.mykronos.com";
			}
			logger.info("WFM Backend server " + wfmHostName);
			logger.info("WFM username " + configurator.getParameter("wfm_username"));
			logger.info("WFM pwd " + configurator.getParameter("wfm_password"));
			wfmBuildNumber = sshHandler.getWFMBuildNumber(wfmHostName, configurator.getParameter("wfm_username"), configurator.getParameter("wfm_password"));
			Map<String,Object> almMapping= new HashMap<String,Object>();
			TestResultListener.testMethods.remove("update");

			String[] testSetIds= configurator.getParameter("ALM_TEST_SET_ID").split("[,]");
			almMapping.put("TestSetId", Arrays.asList(testSetIds));
			almMapping.put("TestCases", TestResultListener.testMethods);
			almMapping.put("Build", wfmBuildNumber);
			almMapping.put(ContextConstant.WFM_BUILD_VERSION, configurator.getParameter(ContextConstant.WFM_BUILD_VERSION));

			JSONObject json=new JSONObject(almMapping);
			logger.info("JSON created : " + json.toString());
			FileWriter file = new FileWriter(configurator.getParameter("Report_Loc") + File.separator + "ALM_" + TIMESTAMP + ".json"); 
			file.write(json.toString());
			file.close();
		}
		KronosLogger.traceLeave();
	}

	/**
	 * Before method, initialization.
	 * 
	 * @param m: Method
	 * @param context: ITestContext
	 * @throws KronosCoreCommonException
	 * 		: customized kronos core common exception
	 */
	@BeforeMethod(alwaysRun=true)
	public void beforeMethod(Method m) throws KronosCoreCommonException {
		KronosLogger.traceEnter();
		try {
			logger.info("Start test case [" + m.getName() + "]");
			reporter.startTest(m.getName(), 
					m.getAnnotation(Test.class).description(),
					m.getAnnotation(Test.class).groups(),
					m.getDeclaringClass().toString(),
					m.getAnnotation(Test.class).dependsOnMethods());

			executionContext = new ExecutionContext();
			configurator.getExecutionContextMap().put(Thread.currentThread().getId(), executionContext);
			logger.info("Execution context parameter set " + executionContext);
		} catch (Exception e) {
			String erroMsg ="execute before test method fail";
			logger.error(erroMsg, e);
			throw new KronosCoreCommonException(erroMsg, e);
		}
		KronosLogger.traceLeave();
	}

	/**
	 * This method is only used for before and after class implementation
	 *  Create a temporary KronosExtentTest to holds all the reporting detail during the global setup
	 *  This temporary test will always be created, if there is no global setup written in the test
	 *  In the constructor of KronosExtentTest, this temp test will simply be ignored
	 * */
	@BeforeClass(alwaysRun=true)
	public void beforeClass(){
		reporter.startClassTest();
	}

	/**
	 * This method is only used for before and after class implementation
	 */
	@AfterClass(alwaysRun=true)
	public void afterClass(){
		//Clean the temporary KronosExtentTest for next case
		reporter.endClassTest();
	}

	/**
	 * This method is only used for before and after class implementation
	 * @throws KronosCoreCommonException 
	 */
	@AfterMethod(alwaysRun=true)
	public void cleanCurCase() throws KronosCoreCommonException{
		reporter.endMethodTest();
		reporter.endReportAtMethod();
	}

}
