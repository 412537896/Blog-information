package com.kronos.testng;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PatternLayout;
import org.apache.log4j.RollingFileAppender;

import com.epam.ta.reportportal.log4j.appender.ReportPortalAppender;
import com.kronos.context.ExecutionContext;
import com.kronos.exception.KronosCoreCommonException;
import com.kronos.logging.KronosLogger;
import com.kronos.utils.common.ContextConstant;

public class Configurator {
	private static Configurator instance;
	private static final String TIME_STAMP = new SimpleDateFormat("yyyy_MM_dd_HHmmss").format(new Date());
	private Map<String, String> directoryMap;
	private Map<String, String> parameterMap;
	private Map<Long, ExecutionContext> executionContextMap;
	private static final Logger logger = Logger.getLogger(Configurator.class);

	/**
	 * Constructor for Configurator
	 * 
	 * @throws KronosCoreCommonException
	 *             : KronosCoreCommonException
	 */
	private Configurator() {
		KronosLogger.traceEnter();
		try {
			directoryMap = new HashMap<String, String>();
			parameterMap = new HashMap<String, String>();
			executionContextMap = new Hashtable<Long, ExecutionContext>();
		} catch (Exception e) {
			String message = "Configurator Create Failed";
			logger.error(message, e);
		}
		logger.info("Configurator Created. ");
		KronosLogger.traceLeave();
	}

	/**
	 * Creates an instance of Configurator
	 * 
	 * @return instance: Configurator
	 */
	public static synchronized Configurator getInstance() {
		if (instance == null) {
			instance = new Configurator();
			logger.info("Configurator Created. ");
		}
		return instance;
	}
	
	/**
	 * Initializes global parameterMap using testng context.
	 * 
	 * @param params:Map
	 * @throws KronosCoreCommonException
	 *             : customized kronos core common exception
	 */
	public void initializeParameters(Map<String, String> params) throws KronosCoreCommonException {
		String defaultDateFormat = "";
		
		if (!params.containsKey(ContextConstant.FRONTEND_SERVER) && !(params.containsKey(ContextConstant.BACKEND_SERVER)||params.containsKey(ContextConstant.APIGATEWAY_SERVER)))
		{
			String message = "Either FrontEnd_Server or either of BackEnd_Server and APIGateway_Server is mandatory. Please set this value and run again";
			logger.error(message);
			throw new KronosCoreCommonException(message);
		}
		
		if (params.containsKey(ContextConstant.FRONTEND_SERVER)) {
			parameterMap.put(ContextConstant.FRONTEND_SERVER, normalizeURL(params.get(ContextConstant.FRONTEND_SERVER)));
			defaultDateFormat = "MM/dd/yyyy";
		} 
		if (params.containsKey(ContextConstant.BACKEND_SERVER)) {
			parameterMap.put(ContextConstant.BACKEND_SERVER, normalizeURL(params.get(ContextConstant.BACKEND_SERVER)));
			defaultDateFormat = "yyyy-MM-dd";
		} 
		//Presence of APIGATEWAY_SERVER in parameterMap tells that execution has to be done via API Gateway server
		if (params.containsKey(ContextConstant.APIGATEWAY_SERVER) && !(params.get(ContextConstant.APIGATEWAY_SERVER).toString().isEmpty())){
			parameterMap.put(ContextConstant.APIGATEWAY_SERVER, normalizeURL(params.get(ContextConstant.APIGATEWAY_SERVER)));
			defaultDateFormat = "yyyy-MM-dd";
		}
				
		try {
			setOptionalParameter(params,defaultDateFormat);
			setDirectoryInformation(params);
			setEnvironmentParameter();
		} catch (Exception e) {
			String message = "Exception when setting TestNG parameters in configurator";
			logger.error(message + ". Exception: " + e.getMessage());
			throw new KronosCoreCommonException(message,e);
		}
	}

	/**
	 * Get a parameter value based on key
	 * 
	 * @param key:String
	 * @return value of key: String
	 */
	public String getParameter(String key) {
		if (parameterMap.containsKey(key))
			return parameterMap.get(key);
		else
			return "";
	}

	/**
	 * Get directory value based on the key.
	 * 
	 * @param key
	 *            : key in map
	 * @return String : value of key
	 */
	public String getDirectoryParameter(String key) {
		return directoryMap.containsKey(key) ? directoryMap.get(key) : null;
	}

	
	public Map<Long, ExecutionContext> getExecutionContextMap() {
		return executionContextMap;
	}
	
	
	/**
	 * This function should be called at the beginning of the session execution
	 * to set up the folder structure
	 * 
	 * @param params : Map
	 * @throws IOException
	 *             : IOException
	 * @throws KronosCoreCommonException
	 *             : KronosCoreCommonException
	 */
	private void setOptionalParameter(Map<String, String> params, String defaultDateFormat) throws KronosCoreCommonException {
		
		parameterMap.put(ContextConstant.TENANT, params.containsKey(ContextConstant.TENANT) ? params.get(ContextConstant.TENANT) : "");
		parameterMap.put(ContextConstant.OPEN_AM_SERVER, normalizeURL(params.get(ContextConstant.OPEN_AM_SERVER)));
		parameterMap.put(ContextConstant.DATE_FORMAT, params.containsKey(ContextConstant.DATE_FORMAT) ? params.get(ContextConstant.DATE_FORMAT) : defaultDateFormat);
		parameterMap.put(ContextConstant.TIMEOUT, params.containsKey(ContextConstant.TIMEOUT) ? params.get(ContextConstant.TIMEOUT) : "30");
		parameterMap.put(ContextConstant.DEEPREPORTING,params.containsKey(ContextConstant.DEEPREPORTING) ? params.get(ContextConstant.DEEPREPORTING) : "True");
		parameterMap.put(ContextConstant.LOG_LEVEL, params.containsKey(ContextConstant.LOG_LEVEL) ? params.get(ContextConstant.LOG_LEVEL) : "True");
		parameterMap.put(ContextConstant.PUBLISH_RESULTS_TO_ALM, params.containsKey(ContextConstant.PUBLISH_RESULTS_TO_ALM) ? params.get(ContextConstant.PUBLISH_RESULTS_TO_ALM) : "false");
		//add run mode to make user's local develop more easier 
		parameterMap.put(ContextConstant.RUN_MODE, params.containsKey(ContextConstant.RUN_MODE) ? params.get(ContextConstant.RUN_MODE) : "");
		parameterMap.put(ContextConstant.WFM_BUILD_VERSION, params.containsKey(ContextConstant.WFM_BUILD_VERSION) ? params.get(ContextConstant.WFM_BUILD_VERSION) : "");
		parameterMap.put(ContextConstant.WFM_USERNAME_KEY, ContextConstant.WFM_USERNAME_VALUE);
		parameterMap.put(ContextConstant.WFM_PASSWORD_KEY, ContextConstant.WFM_PASSWORD_VALUE);
		
		if (params.containsKey(ContextConstant.APIGATEWAY_SERVER) && !(params.get(ContextConstant.APIGATEWAY_SERVER).toString().isEmpty())){
			defaultDateFormat = "yyyy-MM-dd";
			parameterMap.put(ContextConstant.EXTERNAL_APPKEY, params.containsKey(ContextConstant.EXTERNAL_APPKEY)?params.get(ContextConstant.EXTERNAL_APPKEY):"");
			if (params.containsKey(ContextConstant.TMS_DB_SERVER))
			{
				parameterMap.put(ContextConstant.TMS_DB_SERVER, formatDBServerURL(params.get(ContextConstant.TMS_DB_SERVER)));
				parameterMap.put(ContextConstant.TMS_DB_SID,params.containsKey(ContextConstant.TMS_DB_SID) && !(params.get(ContextConstant.TMS_DB_SID).toString().trim().isEmpty())?params.get(ContextConstant.TMS_DB_SID).trim():"ppas_tms");
				setOAuthClientIdNSecret();
			}
		}
		
		if(params.containsKey(ContextConstant.BACKEND_SERVER))
			parameterMap.put(ContextConstant.WFM_URL, (!StringUtils.isEmpty(params.get(ContextConstant.BACKEND_SERVER).trim())) ? params.get(ContextConstant.BACKEND_SERVER) : params.get(ContextConstant.FRONTEND_SERVER));
		else
			parameterMap.put(ContextConstant.WFM_URL, params.get(ContextConstant.FRONTEND_SERVER));
		for(Entry<String,String> e: params.entrySet()){
			if (!parameterMap.containsKey(e.getKey())){
				parameterMap.put(e.getKey().toString(), e.getValue().toString());
			}
		}
	}
    
    
	/**
	 * This function extract the oAuth clientId and clientSecret from TMS database present in testng.xml based on tenant shortname.
	 * It also sets the clientId and clientSecret in Execution Context.
	 * 
	 * @throws KronosCoreCommonException : KronosCoreCommonException
	 */
	private void setOAuthClientIdNSecret() throws KronosCoreCommonException{
		String infoMessage = "";
		Connection connection = null;
		Statement stmt = null;
		ResultSet rs = null;

		try {
			Class.forName("com.edb.Driver").newInstance();
		
			connection = DriverManager.getConnection(
					"jdbc:edb://"  + parameterMap.get(ContextConstant.TMS_DB_SERVER) + ":5444/" + parameterMap.get(ContextConstant.TMS_DB_SID) , "tkcsowner", "tkcsowner");
			
			String query = "SELECT oauth_id,oauth_secret FROM tmsservice.tenant WHERE short_name = '" + this.getParameter(ContextConstant.TENANT)+ "'";
			
			stmt = connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);

			rs = stmt.executeQuery(query);
			if (rs.next())
			{
				parameterMap.put(ContextConstant.OAUTH_CLIENTID, rs.getString("oauth_id"));
				System.out.println(parameterMap.get(ContextConstant.OAUTH_CLIENTID));
				
				parameterMap.put(ContextConstant.OAUTH_CLIENTSECRET, rs.getString("oauth_secret"));
				System.out.println(parameterMap.get(ContextConstant.OAUTH_CLIENTSECRET));
			} else {
				infoMessage = "Failure while trying to get client_Id and Client_Secret for the tenant from TMS DB. ";
				logger.info(infoMessage);
			}
			
		} catch (Exception e) {
			infoMessage = "Failure while trying to get client_Id and Client_Secret for the tenant from TMS DB. "
					+ e.getMessage();
			logger.info(infoMessage,e);
			//throw new KronosCoreCommonException(infoMessage, e);
		}
		finally
		{
			try
			{
				rs.close();
				stmt.close();
				connection.close();
			}
			catch(Exception e)
			{
				infoMessage = "Failure while trying to close database ResultSet, Statement and Connection Objects. "
						+ e.getMessage();
				logger.info(infoMessage,e);
			}
		}
	}

	/**
	 * This function should be called at the beginning of the session execution
	 * to set up the folder structure
	 * 
	 * @param params : Map
	 * @throws IOException
	 *             : IOException
	 * @throws KronosCoreCommonException
	 *             : KronosCoreCommonException
	 */
	private void setDirectoryInformation(Map<String, String> params) throws KronosCoreCommonException {
		KronosLogger.traceEnter();
		String root = "";
		try {
			root = new java.io.File(".").getCanonicalPath();
			directoryMap.put(ContextConstant.REPORT_LOCATION, params.containsKey(ContextConstant.REPORT_LOCATION) ? params.get(ContextConstant.REPORT_LOCATION) : root);
			directoryMap.put("root", root + "/");
			directoryMap.put("resources", root + "/resources/");
			directoryMap.put("report", directoryMap.get(ContextConstant.REPORT_LOCATION) + "/test-output/");
			
			String reportPartialName = "develop".equalsIgnoreCase(parameterMap.get(ContextConstant.RUN_MODE)) ? "develop" : TIME_STAMP;
			directoryMap.put("current_report", directoryMap.get(ContextConstant.REPORT_LOCATION) + "/test-output/extent/" + reportPartialName);
			directoryMap.put("current_sc_report", directoryMap.get(ContextConstant.REPORT_LOCATION) + "/test-output/extent/" + reportPartialName + "/sc");

			directoryMap.put(ContextConstant.LOG_LOCATION, params.containsKey(ContextConstant.LOG_LOCATION) ? params.get(ContextConstant.LOG_LOCATION) : directoryMap.get("current_report"));
			directoryMap.values().stream().forEach(f -> new File(f).mkdirs());

			//Set log level
			if ("False".equalsIgnoreCase(parameterMap.get(ContextConstant.LOG_LEVEL)))
				Logger.getRootLogger().setLevel((Level)Level.WARN);
			else
				Logger.getRootLogger().setLevel((Level)Level.INFO);
		// Add the appender to root logger
			Logger.getRootLogger().addAppender(new RollingFileAppender(
						new PatternLayout("%d{yyyy-MM-dd HH:mm:ss} %-5p %c{1}:%L - %m%n"),  directoryMap.get(ContextConstant.LOG_LOCATION) + File.separator + TIME_STAMP + ".log"));
			
			ReportPortalAppender reportPortalAppender= new ReportPortalAppender();
			reportPortalAppender.setLayout(new PatternLayout("%d{yyyy-MM-dd HH:mm:ss} %-5p %c{1}:%L - %m%n"));
			reportPortalAppender.setName("com.epam.ta.apache");
			Logger.getRootLogger().addAppender(reportPortalAppender);
		
			logger.info("Project Root Directory at : " + root);
		} catch (IOException e) {
			logger.error("Failed to set direcotry!", e);
		}
		KronosLogger.traceLeave();
	}
	
	/**
	 * This function should be called at the beginning of the session execution
	 * to set up the environment parameter.
	 * 
	 * @param params : Map
	 * @throws IOException
	 *             : IOException
	 * @throws KronosCoreCommonException
	 *             : KronosCoreCommonException
	 */
	private void setEnvironmentParameter() throws KronosCoreCommonException {
		//Initialize driver
	    String os = System.getProperty("os.name", "generic").toLowerCase(Locale.ENGLISH);
	    String osArch = System.getProperty("os.arch");
	    String chromeDriverEnvName = "chrome_driver";
	    String ieEnvName = "ie_driver";
	    String edgeEnvName = "edge_driver";

		if (os.indexOf("win") >= 0 && osArch.indexOf("amd64") >= 0) {
			directoryMap.put(chromeDriverEnvName, "drivers/chromedriver_win.exe");
			directoryMap.put(ieEnvName, "drivers/IEDriverServer_32.exe");
			directoryMap.put(edgeEnvName, "drivers/MicrosoftEdgeDriver.exe");
		} else if (os.indexOf("win") >= 0 && osArch.indexOf("x86") >= 0) {
			directoryMap.put(chromeDriverEnvName, "drivers/chromedriver_win.exe");
			directoryMap.put(ieEnvName, "drivers/IEDriverServer_32.exe");
			directoryMap.put(edgeEnvName, "drivers/MicrosoftEdgeDriver.exe");
		} else if (os.indexOf("mac") >= 0) {
			directoryMap.put(chromeDriverEnvName, "drivers/chromedriver_mac");
		}
	}
	
	private String normalizeURL(String url){
		if(url!=null && !url.endsWith("/"))
			url=url+"/";
		if (url!=null && !url.startsWith(ContextConstant.SERVER_PROTOCOL))
			url = ContextConstant.SERVER_PROTOCOL+ContextConstant.SERVER_PROTOCOL_SLASHES+ url;
		return url; 
	}
	
	
	private String formatDBServerURL(String url){
		if (url.startsWith(ContextConstant.SERVER_PROTOCOL))
		{
			url = url.substring(url.indexOf(ContextConstant.SERVER_PROTOCOL_SLASHES)+1, url.length());
		}
		return url;
	}
}
