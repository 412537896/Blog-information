package com.kronos.report;

public enum StepStatus {
PASS,FAIL,INFO,ERROR,SKIPPED, WARNING
}

