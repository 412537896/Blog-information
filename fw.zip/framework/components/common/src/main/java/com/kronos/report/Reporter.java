package com.kronos.report;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.io.Writer;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.imageio.ImageIO;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.testng.ITestContext;
import org.testng.xml.XmlClass;
import org.testng.xml.XmlPackage;
import org.w3c.dom.Document;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.restassured.response.Response;
import com.kronos.exception.KronosCoreCommonException;
import com.kronos.factory.KronosExtentTestFactory;
import com.kronos.factory.KronosReportFactory;
import com.kronos.factory.KronosTrackerFactory;
import com.kronos.logging.KronosLogger;
import com.kronos.testng.Configurator;
import com.kronos.tracking.Actions;
import com.kronos.tracking.CaseUsageAPI;
import com.kronos.tracking.CaseUsageUI;
import com.kronos.tracking.SessionUsageAPI;
import com.kronos.tracking.SessionUsageUI;
import com.kronos.tracking.UsageAPITracker;
import com.kronos.tracking.UsageUITracker;
import com.kronos.utils.common.ContextConstant;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.relevantcodes.extentreports.model.Log;

public class Reporter implements IReport {
	protected static Map<Long, KronosExtentTest> extentTestMap = new LinkedHashMap<Long, KronosExtentTest>();
	protected static Map<Long, KronosExtentTest> extentTestAtClassMap = new LinkedHashMap<Long, KronosExtentTest>();
	protected static Map<String, KronosExtentTest> testCaseMap = new LinkedHashMap<String, KronosExtentTest>();
	protected static Map<String, KronosExtentTest> testCaseATMethodMap = new LinkedHashMap<String, KronosExtentTest>();
	protected static Map<String, KronosExtentTest> testCaseOriMap = new LinkedHashMap<String, KronosExtentTest>();
	private List<String> includeGroups = new ArrayList<>();
	private List<String> excludeGroups = new ArrayList<>();
	private List<XmlPackage> packages = new ArrayList<>();
	private List<XmlClass> classes = new ArrayList<>();
	private static Reporter instance;

	private final SimpleDateFormat screenShotFormat = new SimpleDateFormat("HHmmssSSS");
	private boolean deepReporting;
	private boolean includeRetryReport;
	private String imagePath;
	
	private KronosExtentReports report;
	private KronosExtentReports interimReport;
	private KronosExtentReports oriReport;

	private static final Logger logger = Logger.getLogger(Reporter.class);
	private static final String BREAK_LINE = "</br>";
	private static final String HTTP_INFO_STYLE = "<span style=\"font: bold 12px/30px Georgia, serif;margin-right:5px\" >";
	
	//tracking object
	private SessionUsageAPI apiSession;
	private SessionUsageUI uiSession;

	private static int STACK_TRACE_LIMIT = 15;
	
	/**
	 * Creates an instance of Reporter
	 * @return Reporter
	 */
	public static Reporter getInstance() {
		KronosLogger.traceEnter();
		//Double checked locking principle is used
		if (instance == null) {
			synchronized (Reporter.class) {
				if (instance == null) {
					instance = new Reporter();
					logger.info("Reporter instance created.");
				}
			}
		}
		KronosLogger.traceLeave();
		return instance;
	}

	/**
	 * Initializes extent report
	 * 
	 * @param params
	 *            :HashMap
	 */
	@Override
	public void initializeReport(String reportRootPath, String imagePath, Map<String, String> params) throws KronosCoreCommonException {
		try {
			includeRetryReport = (params.get(ContextConstant.INCLUDE_RETRY_REPORT) == null) ? true : Boolean.parseBoolean(params.get(ContextConstant.INCLUDE_RETRY_REPORT));
			deepReporting = Boolean.parseBoolean(params.get(ContextConstant.DEEPREPORTING));
			this.imagePath = imagePath;
			String timestamp = new SimpleDateFormat("yyyy_MM_dd_HHmmss").format(new Date());
			String reportPartialName = timestamp;
			
			if(params.containsKey(ContextConstant.RUN_MODE)){
				reportPartialName = "develop".equalsIgnoreCase(params.get(ContextConstant.RUN_MODE)) ? "develop" : timestamp;
			}
			
			report = KronosReportFactory.createExtentReport(reportRootPath + "/report_" + reportPartialName + ".html");
			interimReport = KronosReportFactory.createExtentReport(reportRootPath + "/report_" + reportPartialName + "_interim.html");
			File interimConfigFile = new File("Extent-Report-config.xml");
			InputStream inputStream = Thread.currentThread().getContextClassLoader().getResourceAsStream("Extent-Interim-config.xml");
		    FileUtils.copyInputStreamToFile(inputStream, interimConfigFile);
			interimReport.loadConfig(interimConfigFile);

			if(includeRetryReport){
				oriReport = KronosReportFactory.createExtentReport(reportRootPath + "/report_" + reportPartialName + "_previousRun.html");
			}
			/*
			 * Initialize heat tracker reporting
			 */
			if((params.containsKey(ContextConstant.TRACKER_DB_NAME) || params.containsKey(ContextConstant.TRACKER_DB_HOST)) && params.containsKey(ContextConstant.TRACKER_TYPE)){
				logger.info("Tracker DB detected: Initinalizing Tracking Object");
				if("UI".equalsIgnoreCase(params.get(ContextConstant.TRACKER_TYPE))){
					uiSession = KronosTrackerFactory.createUISessionTracker(params);
				}else{
					apiSession = KronosTrackerFactory.createAPISessionTracker(params);
				}				
			}
		} catch (Exception e) {
			String message = "initialize Reporting Failed: ";
			logger.error(message, e);
			throw new KronosCoreCommonException(message, e);
		}
		logger.info("Initialize Reporting Success. ");
	}
	
	public static Map<String, KronosExtentTest> getTestCaseMap() {
		return testCaseMap;
	}
	
	public static Map<String, KronosExtentTest> getTestCaseAtMethodMap() {
		return testCaseATMethodMap;
	}
	
	public SessionUsageAPI getApiSession() {
		return apiSession;
	}

	public SessionUsageUI getUiSession() {
		return uiSession;
	}

	/**
	 * Add system information to report, need to pass key attribute and it's
	 * value
	 * 
	 * @param key:String 
	 * @param value:String
	 */
	@Override
	public void addSystemInfo(String key, String value) {
		report.addSystemInfo(key, value == null?"":value);
	}

	private synchronized ExtentTest getTest() {
		//the test could only be null if the report step function was called in a before class
		//Fix - SUP-11505
		if (extentTestMap.get((long)(Thread.currentThread().getId())) == null)
		{
			if (extentTestAtClassMap.get(((long)(Thread.currentThread().getId())))== null)
				return null;
			else
				return extentTestAtClassMap.get((long)(Thread.currentThread().getId())).getTest();	
		}
		return extentTestMap.get((long)(Thread.currentThread().getId())).getTest();
		
		/*return extentTestMap.get((long)(Thread.currentThread().getId())) == null ? 
				extentTestAtClassMap.get((long)(Thread.currentThread().getId())).getTest()
				: extentTestMap.get((long)(Thread.currentThread().getId())).getTest();
				*/
				
	}
	
	private synchronized CaseUsageAPI getAPITracker() {
		return extentTestMap.get((long)(Thread.currentThread().getId())) == null ? 
				extentTestAtClassMap.get((long)(Thread.currentThread().getId())).getApiTracker()
				: extentTestMap.get((long)(Thread.currentThread().getId())).getApiTracker();
	}
	
	private synchronized CaseUsageUI getUITracker() {
		return extentTestMap.get((long)(Thread.currentThread().getId())) == null ? 
				extentTestAtClassMap.get((long)(Thread.currentThread().getId())).getUiTracker()
				: extentTestMap.get((long)(Thread.currentThread().getId())).getUiTracker();
	}
	
	private synchronized KronosExtentTest getKronosTest() {
		return extentTestMap.get((long)(Thread.currentThread().getId()));
	}
	/**
	 * Ends test with failed test case
	 * @throws KronosCoreCommonException 
	 */
	@Override
	public synchronized void endTest(String failureReason, String stackTrace) {
		if(failureReason != null)
			getKronosTest().setFailureReason(failureReason);
		if(stackTrace != null)
			getKronosTest().setStackTrace(stackTrace);
		endTest();
	}
	
	/**
	 * Ends test with the result 
	 * @throws KronosCoreCommonException 
	 */
	@Override
	public synchronized void endTest() {
		/**
		 * Because we end the test in the end report function, by then extent report
		 * will set the end time for each test case as the end time for the entire execution.
		 * Therefore we set the endtime here in the endTest to avoid the endTest() override the value.
		 */
		getTest().setEndedTime(Calendar.getInstance().getTime());
	}
	
	/**
	 * SUP-7750
	 */
	@Override
	public synchronized void addSkipExtentTest(String testName, String desc, String[] groups, String packageLocation, String[] dependsOnMethods){
		if(testCaseMap.containsKey(testName)){
			return;
		}else{
			KronosExtentTest test = null;
			test = KronosExtentTestFactory.createKronosExtentTest(testName, desc, groups,packageLocation,dependsOnMethods,
					apiSession, uiSession, extentTestAtClassMap.get((long)(Thread.currentThread().getId())));

			testCaseMap.put(testName, test);
			testCaseATMethodMap.put(testName, test);
			extentTestMap.put((long)(Thread.currentThread().getId()), test);
		}
	}

	/**
	 * Start a class level test
	 * 
	 * @param testName
	 *            : String
	 * @param desc
	 *            : String
	 * @param string 
	 * @param strings 
	 * @return test
	 */
	public synchronized void startClassTest() {
		KronosExtentTest test = null;
		test = KronosExtentTestFactory.createKronosExtentTest(apiSession,uiSession);
		extentTestAtClassMap.put((long)(Thread.currentThread().getId()), test);
	}
	
	/**
	 * End a class level test
	 * 
	 * @param testName
	 *            : String
	 * @param desc
	 *            : String
	 * @param string 
	 * @param strings 
	 * @return test
	 */
	public synchronized void endClassTest() {
		KronosExtentTest test = extentTestAtClassMap.get((long)(Thread.currentThread().getId()));
		if (test!= null)
		{
			List<Log> globalCleanupList = test.getTest().getTest().getLogList().subList(
													test.getSetupMethodStopIndex(), 
													test.getTest().getTest().getLogList().size()
												);
	
			for(String s : test.getTestMethodsInClass()){
				if(testCaseMap.containsKey(s)){
					for(Log l : globalCleanupList){
						testCaseMap.get(s).getTest().getTest().getLogList().add(l);
					}
				}
			}
		}
		//reset both map at the end of class
		extentTestMap.put((long)(Thread.currentThread().getId()), null);
		extentTestAtClassMap.put((long)(Thread.currentThread().getId()), null);
		
	}
	
	/**
	 * This line is critical for the BeforeClass/AfterClass to work
	 * I set this map to null between each execution to make sure when the last method in the class finish
	 * Should there be any afterclass execution, all the report will go to the temporary test in the extentTestAtClassMap map 
	 * instead of appending to the test of the last method
	 * If a bug to be fixed need to remove this line or change this line, please contact JI
	 * 
	 * **/
	public synchronized void endMethodTest() {
		extentTestMap.put((long)(Thread.currentThread().getId()), null);
	}
	
	/**
	 * Creates a toggle for a test in extent report
	 * 
	 * @param testName
	 *            : String
	 * @param desc
	 *            : String
	 * @param string 
	 * @param strings 
	 * @return test
	 */
	@Override
	public synchronized void startTest(String testName, String desc, String[] groups, String packageLocation, String[] dependsOnMethods) {
		KronosExtentTest test = null;
		
		if(testCaseMap.containsKey(testName)){
			//executing this block of code will mean the retry is enabled
			int retryCount = testCaseMap.get(testName).getRetryCounter() + 1;
			String retryName = " => RETRY[" + retryCount + "]";
			//set the previous run result aside
			testCaseOriMap.put(retryCount==1 ? testName : testName + retryName, testCaseMap.get(testName));
			test = KronosExtentTestFactory.createKronosExtentTest(testName, desc, groups,packageLocation,dependsOnMethods,
					retryName, retryCount,
					apiSession,uiSession,
					extentTestAtClassMap.get((long)(Thread.currentThread().getId())));
				
		}else{
			test = KronosExtentTestFactory.createKronosExtentTest(testName, desc, groups,packageLocation,dependsOnMethods,
					apiSession, uiSession, 
					extentTestAtClassMap.get((long)(Thread.currentThread().getId())));
				
		}
		testCaseMap.put(testName, test);
		testCaseATMethodMap.put(testName, test);
		extentTestMap.put((long)(Thread.currentThread().getId()), test);
	}

	/**
	 * closes extent report
	 * @throws KronosCoreCommonException 
	 * 
	 *   The entire refactoring is based on the retry scenario.
	 *	 We will only show the retry result in the final report with RETRY[count] append after the test case
	 *	 
	 *	 we only actually start the test in Extend report to be able to push the test object in to the test array in ExtendReports
	 *	 Since extentReport does not provide a startTest(ExtentTest) API, I have to create a child class extends from ExtendReports
	 *	 to be able to add the missing method.
	 *	 The whole point of doing that is to hold off the push of the test to the reports until the afterSuites. this way we can swap out
	 *	 previous failed test. 
	 * 
	 */
	@Override
	public void endReport() throws KronosCoreCommonException {
		try{
			for(Entry<String, KronosExtentTest> e: testCaseMap.entrySet()){
				
				ExtentTest t = e.getValue().getTest();
				t.getTest().setName(t.getTest().getName() + "</BR><B><font color='blue'> (" + t.getTest().getRunDuration() + ")</font></B>");
				
				report.startTest(t);
				report.endTest(t);
				
				if(apiSession!=null){
					apiSession.saveTestCaseUsage(e.getValue());
				}
				if(uiSession!=null){
					uiSession.saveTestCaseUsage(e.getValue());
				}
			}
			
			if(apiSession!=null){
				apiSession.updateSessionEndInformation();
			}
			
			if(uiSession!=null){
				uiSession.updateSessionEndInformation();
			}
			
			testCaseMap.clear();
			testCaseMap = null;
			
			interimReport.close();
			report.close();
			deleteInterimReport();
			
			if(includeRetryReport){
				for(Entry<String, KronosExtentTest> e: testCaseOriMap.entrySet()){
					
					ExtentTest t = e.getValue().getTest();
					t.getTest().setName(t.getTest().getName() + "</BR><B><font color='blue'> (" + t.getTest().getRunDuration() + ")</font></B>");
					
					oriReport.startTest(t);
					oriReport.endTest(t);
				}
				//Fix SUP-7685
				if(testCaseOriMap.size() > 0){
					
					testCaseOriMap.clear();
					testCaseOriMap = null;
					
					oriReport.close();
				}
			}
		}
		catch (Exception e) {
			String message = "Failed while closing extent report";
			logger.error(message, e);
			throw new KronosCoreCommonException(message, e);
		}
		logger.info("Extent Report closed successfully. ");
	}
	
	/**
	 * Flush extent report after Each Test Execution
	 * @throws KronosCoreCommonException 
	 *	This method will write the Extent report after Execution of each Test Method.
	 *  Report will be genetrated in with name __intrim.html
	 * 
	 */
	@Override
	public void endReportAtMethod() throws KronosCoreCommonException {
		try{
			for(Entry<String, KronosExtentTest> e: testCaseATMethodMap.entrySet()){
				
				ExtentTest t = e.getValue().getTest();
				t.getTest().setName(t.getTest().getName());
				interimReport.startTest(t);
				interimReport.endTest(t);
			}
			
			interimReport.flush();
			testCaseATMethodMap.clear();
		}
		catch (Exception e) {
			String message = "Failed while flushing test to Interim Extent Report";
			logger.error(message, e);
			throw new KronosCoreCommonException(message, e);
		}
	}

	/**
	 * Remove IntrimExtent Report if Test Suite is executing successfully
	 */
	private void deleteInterimReport() throws KronosCoreCommonException{
		String filePath = Configurator.getInstance().getDirectoryParameter("current_report");
		String fileName = "interim.html";
		try{
		File file= new File(filePath);
		File fileList[] = file.listFiles();
 		
		for (int i = 0; i < fileList.length; i++) {
			File interimFile = fileList[i];
			if(interimFile.getName().contains(fileName)){
				interimFile.delete();
			}
		}
		}catch(Exception e) {
			String message = "Failed while deleting Interim Extent Report";
			logger.error(message, e);
			throw new KronosCoreCommonException(message, e);
		}
		logger.info("InterimExtent Report removed successfully.");
	}
	
	/**
	 * writes the status of a step in extent report with LogStatus as INFO
	 * 
	 * @param stepName
	 *            :String
	 */
	@Override
	public void reportStep(String stepName) {
		if (getTest() != null)
		getTest().log(LogStatus.INFO, HTTP_INFO_STYLE+stepName+"</span>");
	}

	/**
	 * writes the status of a step in extent report
	 * 
	 * @param status
	 *            :StepStatus
	 * @param stepName
	 *            : String
	 */
	@Override
	public void reportStep(StepStatus status, String stepName) {
		if (getTest() != null)
		getTest().log(getLogStatus(status), stepName);
	}

	/**
	 * writes the status of a step in extent report
	 * 
	 * @param status
	 *            :StepStatus
	 * @param stepName
	 *            : String
	 * @param t
	 *            : Throwable
	 */
	@Override
	public void reportStep(StepStatus status, String stepName, Throwable t) {
		if (getTest() != null)
        getTest().log(getLogStatus(status),
                stepName + BREAK_LINE + t.getMessage() + BREAK_LINE + getFormatedStack(t));

	}

	/**
	 * writes the status of a step in extent report
	 * 
	 * @param status
	 *            :StepStatus
	 * @param stepName
	 *            : String
	 * @param details
	 *            : String           
	 */
	@Override
	public void reportStep(StepStatus status, String stepName, String details) {
		if (getTest() != null)
			getTest().log(getLogStatus(status), stepName + BREAK_LINE + details);
	}

	/**
	 * writes the status of a step in extent report. Adds screenshot file to it.
	 * 
	 * @param status
	 *            :StepStatus
	 * @param message
	 *            : String
	 * @param file
	 *            : File
	 */
	@Override
	public void reportStep(StepStatus status, String message, File file) {
		//add tracking information
		if(uiSession!=null){
			getUITracker().addFailureAssertion(message);
		}
		reportStep(status, message + getScreenShotPath(file));
	}

	/**
	 * writes the status of a step in extent report. Adds screenshot file to it
	 * with message of exception
	 * 
	 * @param status
	 *            :StepStatus
	 * @param stepName
	 *            : String 
	 * @param file
	 *            : screenshot file
	 * @param t   
	 * 			  :Throwable
	 */
	@Override
	public void reportStep(StepStatus status, String stepName, File file, Throwable t) {
		reportStep(status, stepName + getScreenShotPath(file), t);
	}

	/**
	 * writes the status of a step and details in extent report. Adds screenshot
	 * file to it.
	 * 
	 * @param status
	 *            :StepStatus
	 * @param stepName
	 *            : String
	 * 
	 * @param details :
	 * 					String
	 * @param file
	 *            : File
	 */
	@Override
	public void reportStep(StepStatus status, String stepName, String details, File file) {
		reportStep(status, stepName, details + getScreenShotPath(file));
	}

	/**
	 * writes the status of a step in extent report only if deep reporting is on
	 * or on failure
	 * 
	 * @param status
	 *            :StepStatus
	 * @param stepName
	 *            : String
	 */
	@Override
	public void deepReportStep(StepStatus status, String stepName) {
		if (status.equals(StepStatus.ERROR) || status.equals(StepStatus.FAIL))
			reportStep(status, stepName);
		else {
			if (deepReporting)
				reportStep(status, stepName);
		}
	}


	/**
	 * Writes the status of a step in extent report. Adds screenshot file to it
	 * with message of exception. Only if deep reporting is on or on failure.
	 * 
	 * @param status
	 *            :LogStatus
	 * @param stepName
	 *            : String 
	 * @param file
	 *            : File
	 * @param t
	 * 			  :Throwable
	 */
	@Override
	public void deepReportStep(StepStatus status, String stepName, File file, Throwable t) {
		if (status.equals(StepStatus.ERROR) || status.equals(StepStatus.FAIL))
			reportStep(status, stepName, file, t);
		else if (deepReporting)
			reportStep(status, stepName, file, t);
	}


	/**
	 * writes the status of a step in extent report and create tracking records as well
	 * Mostly used by API Dirver
	 * @param status
	 *            :StepStatus
	 * @param details
	 *            : String           
	 * @param params 
	 * @param uri 
	 * @param string 
	 */
	public void reportStepWithUITracking(StepStatus status, String message, String action,  String locatorKey, String locator, String navigation) {
		reportStep(status, message);		
		//add tracking information
		if(uiSession!=null){
			getUITracker().addTracker(new UsageUITracker(locatorKey,locator,navigation,action));
		}
	}
	
	/**
	 * writes the status of a step in extent report and create tracking records as well
	 * Mostly used by API Dirver
	 * @param status
	 *            :StepStatus
	 * @param details
	 *            : String           
	 * @param params 
	 * @param uri 
	 * @param string 
	 */
	public void reportStepWithAPITracking(Actions post,  String uri, String params, String apiObject ,String details) {
		if (getTest() != null)
		getTest().log(getLogStatus(StepStatus.INFO), details);
		
		//add tracking information
		if(apiSession!=null){
			getAPITracker().addTracker(new UsageAPITracker(uri,apiObject,params,post));
		}
	}
	
	/**
	 * writes the status of a step in extent report and create tracking records as well
	 * Mostly used by Assertion
	 * @param status
	 *            :StepStatus
	 * @param details
	 *            : String           
	 * @param params 
	 * @param uri 
	 * @param string 
	 */
	public void reportStepWithAPITracking(StepStatus status, String message) {
		reportStep(status, message);
		//add tracking information
		if(apiSession!=null){
			getAPITracker().addFailureAssertion(message);
		}
	}
	
	/**
	 * writes the status of a step in extent report and create tracking records as well
	 * Mostly used by Listener
	 * @param status
	 *            :StepStatus
	 * @param details
	 *            : String           
	 * @param params 
	 * @param uri 
	 * @param string 
	 */
	public void reportStepWithAPITracking(StackTraceElement[] stackTrace, String message) {
		//add tracking information
		if(apiSession!=null){
			getAPITracker().addFailureAssertion(stackTrace, message);
		}
		//add tracking information
		if(uiSession!=null){
			getUITracker().addFailureAssertion(stackTrace, message);
		}
	}
	
	/**
	 * Generated user friendly format of the json payload
	 * @param payload
	 * @return
	 */
	public String generateFormatedResponse(Response res) {			
		return "Response: </br><a style=\"cursor:pointer\" onclick=\"$(this).next('div').toggle()\"> HTTP Info (Click to Expand)</a>"+
				"<div style=\"display:none\">"+
				HTTP_INFO_STYLE + " Status: </span><span> " + res.getStatusLine()+"</span>" +  BREAK_LINE + 
				HTTP_INFO_STYLE + " Content Type: </span><span>" + res.getContentType()+"</span>" +  BREAK_LINE + 
				HTTP_INFO_STYLE + " Content Length: </span><span>" + res.getHeader("Content-Length")+"</span>" +  BREAK_LINE + 
				HTTP_INFO_STYLE + " Date: </span><span>" + res.getHeader("Date")+"</span>" +  BREAK_LINE + 
				HTTP_INFO_STYLE + " Response Time (ms):</span><span>" + res.getTime() +"</span>" +  BREAK_LINE + 
				"</div></>" + generateFormatedPayload(res.asString());
		
	}
	
	public String generateFormatedPayload(String payload) {	
		try {
			String prettyPayload = "";
			if(payload == null)
				prettyPayload = "No Payload Body";
			else if(payload.trim().isEmpty())
				prettyPayload = "No Payload Body";
			else if (payload.startsWith("<XML"))
				prettyPayload = prettyPrintXML(payload);
			else if (payload.trim().startsWith("{") || payload.trim().startsWith("["))
				prettyPayload = new ObjectMapper().writerWithDefaultPrettyPrinter().writeValueAsString(new ObjectMapper().readTree(payload));	
			else
				prettyPayload = payload;
			
			return BREAK_LINE + "<a style=\"cursor:pointer\" onclick=\"$(this).next('xmp').toggle()\"> Payload (Click to Expand)</a><xmp style=\"display:none\">"+prettyPayload+"</xmp></>";
		} catch (Exception  e) {
			logger.error(e.getMessage(),e);
			return BREAK_LINE + "<a style=\"cursor:pointer\" onclick=\"$(this).next('xmp').toggle()\"> Invalid JSON/XML Payload (Click to Expand)</a><xmp style=\"display:none\">"+payload+"</xmp></>";
		}
	}
	
	/**
	 * Adds a snapshot to the log event details
	 * 
	 * Note: this method does not create the screen-capture for the report, it
	 * only sets the path of the image file in the report. The user is
	 * responsible for capturing the screen and for constructing the path to the
	 * image file.
	 * 
	 * 
	 * @param file
	 * @return String: A formed HTML img tag
	 */
	private String getScreenShotPath(File file) {
        String htmlTagPath = "";
		if (file != null) {
			try {
				String screenShotName = "/_" + screenShotFormat.format(new Date()) + ".png";
				File pngFile=new File(imagePath + screenShotName);
				FileUtils.moveFile(file, pngFile);

				File jpgFile = new File(pngFile.getAbsolutePath().replaceAll("png", "jpg"));
				BufferedImage image = ImageIO.read(pngFile);
				BufferedImage result = new BufferedImage(image.getWidth(), image.getHeight(),
						BufferedImage.TYPE_INT_RGB);
				result.createGraphics().drawImage(image, 0, 0, null);
				ImageIO.write(result, "jpg", jpgFile);
				if (pngFile.isFile())
					pngFile.delete();

				htmlTagPath = BREAK_LINE + getTest().addScreenCapture("./sc/" + jpgFile.getName());
			} catch (IOException e) {
				String errMsg = " Fail to copy file";
				logger.error(errMsg, e);
			}
		} else {
			String errMsg = " Fail: Screenshot file is null, cannot add screenshot";
			logger.error(errMsg);
		}
        return htmlTagPath;
	}
	
	/**
	 * 
	 * @param payload
	 * @return
	 * @throws Exception
	 */
	private String prettyPrintXML(String payload){
		String formattedPayload = "";
		try{
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		
			dbf.setValidating(false);
			DocumentBuilder db = dbf.newDocumentBuilder();
			InputStream is = new ByteArrayInputStream(payload.getBytes("UTF-8"));
			Document xml = db.parse(is);
			
			Transformer tf = TransformerFactory.newInstance().newTransformer();
			tf.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
			tf.setOutputProperty(OutputKeys.INDENT, "yes");
			Writer out = new StringWriter();
			tf.transform(new DOMSource(xml), new StreamResult(out));
			formattedPayload =  out.toString();
		}
		catch (Exception  e) {
			//return payload if there is a error pretty print the xml
			logger.debug(e.getMessage(),e);
			return payload;
		}
		return formattedPayload;
	}
	
	/**
	 * Return corresponding ExtentReport LogStatus for incoming StepStatus
	 * 
	 * @param status
	 *            : StepStatus 
	 * @return status 
	 * 				: LogStatus
	 */
	private LogStatus getLogStatus(StepStatus status) {
		switch (status) {
		case PASS:
			return LogStatus.PASS;
		case FAIL:
			return LogStatus.FAIL;
		case ERROR:
			return LogStatus.ERROR;
		case SKIPPED:
			return LogStatus.SKIP;
		case WARNING:
			return LogStatus.WARNING;
		default:
			return LogStatus.INFO;
		}
	}

	/**
	 * Format the stack message and return first N lines as defined by
	 * STACK_TRACE_LIMIT variable
	 * 
	 * @param e
	 *            : Throwable object
	 * @return string
	 *           : String
	 */
	private String getFormatedStack(Throwable e) {
		StringBuilder sb = new StringBuilder();
		int nline = 1;
		if (e != null)
			for (StackTraceElement element : e.getStackTrace()) {
				if (nline <= STACK_TRACE_LIMIT && element != null)
					sb.append(element.toString() + BREAK_LINE);
				else
					break;
				nline++;
			}
		return sb.toString();

	}
	
	/**
	 * To Generate the Custom Extent Report if 
	 * No test found in testng.xml
	 * 
	 * @param e
	 *            : String reportRootPath
	 *            : ITestContext context
	 */
	
	public void customReportGenerator(String reportRootPath, ITestContext context) throws KronosCoreCommonException{
		try {
			String reportPartialName = new SimpleDateFormat("yyyy_MM_dd_HHmmss").format(new Date());
			String reportName = reportRootPath + "/report_" + reportPartialName + ".html";
			File file = new File(reportName);
			FileWriter filewriter = new FileWriter(file);
			
			filewriter.write(writeInCustomReport(context));
			filewriter.close();
			
		} catch (Exception e) {
			String message = "Custom Report Generation Failed: ";
			logger.error(message, e);
			throw new KronosCoreCommonException(message, e);
		}
	}
	
	/**
	 * To Get the Included Groups in testng.xml
	 * 
	 * @param e
	 *            : ITestContext context
	 * @return List
	 * 			  : List of Groups           
	 */
	private List<String> getIncludeGroups(ITestContext context) throws KronosCoreCommonException{
		try {
			includeGroups = context.getCurrentXmlTest().getIncludedGroups();
			if(includeGroups.isEmpty()){
				logger.info("No Group Included in textng.xml");
			}
		} catch (Exception e) {
			String message = "getIncludeGroups in Reporting Failed: ";
			logger.error(message, e);
			throw new KronosCoreCommonException(message, e);
		}
		return includeGroups;
	}
	
	/**
	 * To Get the Excluded Groups in testng.xml
	 * 
	 * @param e
	 *            : ITestContext context
	 * @return List
	 * 			  : List of Groups           
	 */
	private List<String> getExcludeGroups(ITestContext context) throws KronosCoreCommonException{
		try {
			excludeGroups = context.getCurrentXmlTest().getExcludedGroups();
			if(excludeGroups.isEmpty()){
				logger.info("No Test Group excluded in textng.xml");
			}
		} catch (Exception e) {
			String message = "getExcludeGroups in Reporting Failed: ";
			logger.error(message, e);
			throw new KronosCoreCommonException(message, e);
		}
		return excludeGroups;
	}
	
	/**
	 * To Get the Included Packages in testng.xml
	 * 
	 * @param e
	 *            : ITestContext context
	 * @return List
	 * 			  : List of Packages           
	 */
	private List<XmlPackage> getPackages(ITestContext context) throws KronosCoreCommonException{
		try {
			packages = context.getCurrentXmlTest().getXmlPackages();
			if(packages.isEmpty()){
				logger.info("No Package included in testng.xml");
			}
		} catch (Exception e) {
			String message = "getPackages in Reporting Failed: ";
			logger.error(message, e);
			throw new KronosCoreCommonException(message, e);
		}
		return packages;
	}
	
	/**
	 * To Get the Included Classes in testng.xml
	 * 
	 * @param e
	 *            : ITestContext context
	 * @return List
	 * 			  : List of Classes           
	 */
	private List<XmlClass> getClasses(ITestContext context) throws KronosCoreCommonException{
		try {
			classes = context.getCurrentXmlTest().getXmlClasses();
			if(classes.isEmpty()){
				logger.info("No Class Included in testng.xml");
			}
		} catch (Exception e) {
			String message = "getClasses in Reporting Failed: ";
			logger.error(message, e);
			throw new KronosCoreCommonException(message, e);
		}
		return classes;
	}
	
	/**
	 * To the Report Content in Report html file
	 * 
	 * @param e
	 *            : ITestContext context
	 * @return String
	 * 			  : String           
	 */
	private String writeInCustomReport(ITestContext context) throws KronosCoreCommonException{
		List<String> includeGroups = getIncludeGroups(context);
		List<String> excludeGroups = getExcludeGroups(context);
		List<XmlPackage> packages = getPackages(context);
		List<XmlClass> classes = getClasses(context);
		
		String str =  "<h2 style=\"color:red\"> No test was found for execution with the given groups and packages/classes combination in KATE job/testng.xml</h2> <head> <style> table, th, td { border: 1px solid #dddddd; text-align: left; border-collapse: collapse;}</style></head>";
		
		if (!includeGroups.isEmpty()) {
			str = str + "<table ><tr><th> Included Groups</th></tr>";
			for (String group : includeGroups) {
				str = str + "<tr style=\"color:blue\" ; bgcolor=\"#f2f2f2\"><td>" + group + "</td></tr>";
			}
		}

		if (!excludeGroups.isEmpty()) {
			str = str + "<table><br><tr><th> Excluded Groups</th></tr>";
			for (String group : excludeGroups) {
				str = str + "<tr style=\"color:blue\" ; bgcolor=\"#f2f2f2\"><td>" + group + "</td></tr>";
			}
		}
		
		if (!packages.isEmpty()) {
			str = str + "<table><br><tr><th> Included Packages</th></tr>";
			for (XmlPackage pkgName : packages) {
				str = str + "<tr style=\"color:blue\" ; bgcolor=\"#f2f2f2\"><td >" + pkgName.getName() + "</td></tr>";
			}
		} else {
			str = str + "<table><br><tr><th> Included Classes</th></tr>";
			for (XmlClass className : classes) {
				str = str + "<tr style=\"color:blue\" ; bgcolor=\"#f2f2f2\"><td>" + className.getName() + "</td></tr>";
			}
		}
		str = str + "</table>";

		str = str + "<h3 style=\"color:red\"> Please verify your KATE job/testng.xml for further analysis. <h3>";
		return str;
	}

}
