package com.kronos.utils.common;
import java.io.IOException;
import java.io.InputStream;
import org.apache.log4j.Logger;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.kronos.exception.KronosCoreCommonException;
import com.kronos.logging.KronosLogger;


public class SSHHandler {
	private Session session=null;
	private final Logger logger = Logger.getLogger(SSHHandler.class);
	
	
	/**
	 * Open a session with the host
	 * 
	 * @param hostName: String
	 * @param userName: String
	 * @param password: String
	 * @throws KronosCoreCommonException
	 * 		: customized kronos core common exception
	 */
	public void openSession(String hostName, String userName, String password) throws KronosCoreCommonException {
		KronosLogger.traceEnter();
		JSch jsch = new JSch();
		try {
			session = jsch.getSession(userName, hostName, 22);
			session.setPassword(password);
			session.setConfig("StrictHostKeyChecking", "no");
			session.setConfig("PreferredAuthentications","publickey,keyboard-interactive,password");
			session.connect();
		} catch (JSchException e) {
			String message = "Failed to get connected " ;
			logger.error(message, e);
			throw new KronosCoreCommonException(message,e);
		}
		logger.info("Connected To Host::> " +hostName);
		KronosLogger.traceLeave();
		return ;
	}
	
	
	/**
	 * Close a opened session
	 */
	public void closeSession(){
		if(session!=null && session.isConnected())
			session.disconnect();
	}
	
	
	/**
	 * execute a command on Linux machine and get the result
	 * 
	 * @param command: String
	 * @return the command result in StringBuffer
	 * @throws KronosCoreCommonException
	 * 		: customized kronos core common exception
	 */
	public StringBuffer executeCommand(String command) throws KronosCoreCommonException {
		KronosLogger.traceEnter();
		Channel channel =null;
		StringBuffer buffer = new StringBuffer();
		
		try {
			channel = this.session.openChannel("exec");
			((ChannelExec) channel).setCommand(command);

			channel.setInputStream(null);

			((ChannelExec) channel).setErrStream(System.err);
			InputStream in = channel.getInputStream();

			channel.connect();

			byte[] tmp = new byte[1024];

			buffer = new StringBuffer();
			while (true) {
				while (in.available() > 0) {
					int i = in.read(tmp, 0, 1024);
					if (i < 0) {
						break;
					}
					buffer.append(new String(tmp, 0, i));
					buffer.append("\n");
				}
				if (channel.isClosed()) {
					logger.info("exit-status: "+ channel.getExitStatus());
					break;
				}
				try {
					Thread.sleep(1000);
				} catch (Exception ee) {
				}
			}
			
			
		} catch (JSchException e) {
			String message = "Failed to open channel " ;
			logger.error(message, e);
			throw new KronosCoreCommonException(message,e);
		} catch (IOException e) {
			String message = "Failed to get input stream " ;
			logger.error(message, e);
			throw new KronosCoreCommonException(message,e);
		}finally{
			if(channel!=null)
				channel.disconnect();
		}
		KronosLogger.traceLeave();
		return buffer;
	}
	
	/**
	 * execute command on linux machine to get WFM details
	 * 
	 * @param hostname	: 	String
	 * @param username 	:	String 
	 * @param password	:	String
	 * @return
	 * @throws KronosCoreCommonException
	 * 		: customized kronos core common exception
	 */
	public String getWFMBuildNumber(String hostname, String username, String password) {
		StringBuffer sb = new StringBuffer();
		String command = "cat /root/image_builds.txt";
		String buildNumber = "";
		try {
			openSession(hostname , username, password);
			sb = executeCommand(command);
			String result = sb.toString();
			String buildData[] = result.split("\\r?\\n")[0].split("-");
			buildNumber = buildData[3].substring(1);
			closeSession();
		} catch (Exception e) {
			String message = "Failed to execute command on linux machine " ;
			logger.error(message, e);
		}finally{
			if(session!=null && session.isConnected())
				session.disconnect();
		}
		return buildNumber;
	}
}
