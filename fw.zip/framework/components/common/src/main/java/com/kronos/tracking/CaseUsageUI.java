package com.kronos.tracking;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.log4j.Logger;

import com.kronos.exception.KronosCoreCommonException;
import com.kronos.logging.KronosLogger;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;

public class CaseUsageUI {
	static final Logger LOGGER = Logger.getLogger(CaseUsageUI.class);
	private List<UsageUITracker> trackers;
	private List<String> groups;
	private String packageLocation;
	private String caseName;
	private String description;
	private String almId;
	private Map<Integer,String> failureAssertions = new LinkedHashMap<Integer,String>();
	private List<String> dependsOnMethods;
	
	private String screenshot;
	private List<String> elink;

	private boolean isSetup = true;
	
	public void setCaseName(String caseName) {
		this.almId = caseName.contains("ALM") ? caseName.split("ALM")[1].split("_")[0] : "UD";
		String temp = caseName.split("</BR>")[0];
		if(temp != null){
			this.caseName = temp;
		}else{
			this.caseName = caseName;
		}
	}

	/**
	 * Constructor with one parameter
	 * 
	 * @param caseName: String
	 */
	public CaseUsageUI(String caseName, String description, String[] groups, String packageLocation, String[] dependsOnMethods) {
		if(System.getenv("JOB_URL") != null){
			this.screenshot = new StringBuffer(System.getenv("JOB_URL"))
					.append(System.getenv("BUILD_NUMBER")).toString();
			this.elink = Arrays.asList(new StringBuffer(System.getenv("JOB_URL")).append(System.getenv("BUILD_NUMBER")).toString());
		}
		
		this.caseName = caseName;
		this.description = description;
		this.almId =  caseName.contains("ALM") ? caseName.split("ALM")[1].split("_")[0] : "UD";
		this.trackers = new ArrayList<UsageUITracker>();
		this.groups = groups == null ? null : Arrays.asList(groups);
		this.packageLocation=packageLocation;
		this.dependsOnMethods = dependsOnMethods==null?null:Arrays.asList(dependsOnMethods);
	}

	/**
	 * Add tracker
	 * @param tracker: UsageTracker
	 */
	public void addTracker(UsageUITracker tracker){
		int lineNumber = 0;
		
		lineNumber = getLineNumber(Thread.currentThread().getStackTrace(), caseName);
		
		if(lineNumber == 0 && isSetup==true){
			tracker.setLineNumber(lineNumber);
			lineNumber = getLineNumber(Thread.currentThread().getStackTrace(), "invoke0");
			tracker.setUsedFor("SETUP");
		}else if(lineNumber == 0 && isSetup==false){
			tracker.setLineNumber(lineNumber);
			lineNumber = getLineNumber(Thread.currentThread().getStackTrace(), "invoke0");
			tracker.setUsedFor("CLEANUP");
		}
		
		if(lineNumber > 0){
			isSetup = false;
			tracker.setLineNumber(lineNumber);
			tracker.setUsedFor("BODY");
		}
		this.trackers.add(tracker);
	}

	/**
	 * Add tracker
	 * @param tracker: UsageTracker
	 */
	public synchronized void addFailureAssertion(String message){
		int lineNumber = getLineNumber(Thread.currentThread().getStackTrace(), caseName);
		if(lineNumber == 0){
			lineNumber = getLineNumber(Thread.currentThread().getStackTrace(), "invoke0");
		}
		failureAssertions.put(lineNumber, message);
	}
	
	/**
	 * Add tracker
	 * @param tracker: UsageTracker
	 */
	public synchronized void addFailureAssertion(StackTraceElement[] stackTrace, String message){
		int lineNumber = getLineNumber(stackTrace, caseName);
		if(lineNumber == 0){
			lineNumber = getLineNumber(stackTrace, "invoke0");
		}
		failureAssertions.put(lineNumber, message);
	}
	
	private int getLineNumber(StackTraceElement[] stackTrace, String stopPoint){
		int previousLineNumber = 0;
		for(StackTraceElement s: stackTrace){
			if(s.getMethodName().equals(stopPoint)){
				if("invoke0".equals(stopPoint)){
					return previousLineNumber;
				}
				return s.getLineNumber();
			}
			previousLineNumber = s.getLineNumber();
		}
		return 0;
	}
	
	public String getFailureToken(){
		String failureToken = null;
		Map<Integer, List<Integer>> failures = calcluateFailureToken();
		if(!failures.isEmpty())
			failureToken = failures.toString();
		
		LOGGER.error(failureToken);
		return failureToken;
		
	}
	
	
	private Map<Integer, List<Integer>> calcluateFailureToken() {
		Map<Integer, List<Integer>> matchingResult = new LinkedHashMap<Integer, List<Integer>>();	
		List<Integer> assertionLines = new ArrayList<Integer>(failureAssertions.keySet()).stream().distinct().sorted().collect(Collectors.toList());
		List<Integer> uiLines = trackers.stream().map(x->x.getLineNumber()).distinct().collect(Collectors.toList());

		if (assertionLines.isEmpty() || uiLines.isEmpty()){
			return matchingResult;
		}
		LOGGER.error(assertionLines);
		LOGGER.error(uiLines);
        Collections.sort(uiLines, Collections.reverseOrder());
        
        while(uiLines.get(0) > assertionLines.get(assertionLines.size()-1)){
        	uiLines = uiLines.subList(1, uiLines.size());
        }
        
        
        for(int i = 0; i<uiLines.size(); i++){
           int j = assertionLines.size()-1;
           List<Integer> matched = new ArrayList<>();
           while (j >= 0 && uiLines.get(i) < assertionLines.get(j)){
                 j--;
           }
           matched = assertionLines.subList(j+1, assertionLines.size());
           matchingResult.put(uiLines.get(i), matched);
           assertionLines = assertionLines.subList(0, j+1);
        }
        
		return matchingResult;
	}
	/**
	 * Get case name
	 * 
	 * @return case name
	 */
	public String getCaseName() {
		return caseName;
	}

	public String getDescription() {
		return description;
	}

	public List<String> getGroups() {
		return groups;
	}

	public String getPackage() {
		return packageLocation;
	}

	public String getAlmId() {
		return almId;
	}

	public List<UsageUITracker> getTrackers() {
		return trackers;
	}
	
	public Map<Integer, String> getFailureAssertions() {
		return failureAssertions;
	}

	public void setFailureAssertions(Map<Integer, String> failureAssertions) {
		this.failureAssertions = failureAssertions;
	}
	
	public String getScreenshot() {
		return screenshot;
	}

	public List<String> getElink() {
		return elink;
	}

	/**
	 * Get Tracker database object.
	 * 
	 * @return case name: List
	 * @throws KronosCoreCommonException
	 * 			:  customized kronos core common exception
	 */
	public List<DBObject> getTrackersAsDBObject() throws KronosCoreCommonException {
		KronosLogger.traceEnter();
		try
		{
			List<DBObject> tempList = new ArrayList<DBObject>();
			int order = 1;
			for(UsageUITracker ut: this.trackers){
				DBObject t = new BasicDBObject();
				t.put("order", order++);
				t.put("name", ut.getLocatorName());
				t.put("action", ut.getAction());
				t.put("navigation", ut.getNavigation());
				tempList.add(t);
			}
			LOGGER.info("Successfully Get Trackers As DBObjec.");
			return tempList;
		}catch (Exception e)
		{
			String message = "Get Trackers As DBObject failed.";
			LOGGER.error(message, e);
			throw new KronosCoreCommonException(message,e);
		}
	}

}
