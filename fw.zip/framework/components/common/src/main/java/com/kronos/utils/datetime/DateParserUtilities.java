package com.kronos.utils.datetime;

import java.util.AbstractMap.SimpleEntry;
import java.util.Arrays;
import java.util.Date;
import java.util.TimeZone;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.joda.time.DateTime;
import org.joda.time.DateTimeConstants;
import org.joda.time.DateTimeZone;

import com.kronos.exception.KronosCoreCommonException;
import com.kronos.testng.Configurator;
import com.kronos.utils.common.ContextConstant;

public class DateParserUtilities {
	
	private Date currentDate;
	protected Configurator configurator = Configurator.getInstance();
	private static final Pattern SYMBOLIC_DAY_PATTERN = Pattern.compile("(today|yesterday|tomorrow|dayaftertomorrow|daybeforeyesterday)",Pattern.CASE_INSENSITIVE);
	private static final Pattern DAY_PATTERN = Pattern.compile("(-?|\\+?)(\\d+)d");
	private static final Pattern MONTH_PATTERN = Pattern.compile("(-?|\\+?)(\\d+)M(?![ondayONDAY])");
	private static final Pattern YEAR_PATTERN = Pattern.compile("(-?|\\+?)(\\d+)y");
	private static final Pattern WEEK_PATTERN = Pattern.compile("(-?|\\+?)(\\d+)w(?!(ednesday|EDNESDAY))");
	private static final Pattern WEEK_DAY_PATTERN = Pattern.compile("(-?|\\+?)(\\d+)?(monday|tuesday|wednesday|thursday|friday|saturday|sunday)",Pattern.CASE_INSENSITIVE);
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private static final SimpleEntry[] WEEKDAYS = new SimpleEntry[] {new SimpleEntry("monday",DateTimeConstants.MONDAY) ,
			new SimpleEntry("tuesday",DateTimeConstants.TUESDAY) ,
			new SimpleEntry("wednesday",DateTimeConstants.WEDNESDAY) ,
			new SimpleEntry("thursday",DateTimeConstants.THURSDAY) ,
			new SimpleEntry("friday",DateTimeConstants.FRIDAY) ,
			new SimpleEntry("saturday",DateTimeConstants.SATURDAY) ,
			new SimpleEntry("sunday",DateTimeConstants.SUNDAY) };

	/**
	 * Constructor of DateParserUtilities
	 */
	public DateParserUtilities(){
		this.currentDate = new Date();
	}
	
	/**
	 * Constructor of DateParserUtilities with one parameter
	 * @param date: Date
	 */
	public DateParserUtilities(Date date) {
		this.currentDate = date;
	}

	/**
	 * Get current date
	 * 
	 * @return current date time
	 */
	public DateTime getCurrentDate() {
		String timeZone = configurator.getParameter(ContextConstant.TIME_ZONE);
		if (!timeZone.isEmpty()) {
			DateTime dateTime = new DateTime(currentDate);
			DateTime formattedDate = dateTime.withZone(DateTimeZone.forTimeZone(TimeZone.getTimeZone(timeZone)));
			return formattedDate;
		} else {
			return new DateTime(currentDate);
		}
	}
	
	/**
	 * Get current date
	 * 
	 * @param date: Date
	 * @return current date time 
	 */
	public DateTime getDate(Date date) {
		return new DateTime(date);
	}
	
	/**
	 * Get day of the week
	 * 
	 * @return day of the week
	 */
	public int getDayOfWeek(){
		return new DateTime(currentDate).getDayOfWeek();
	}
	
	/**
	 * Get day of the week
	 * 
	 * @param date: DATE
	 * @return day of the week
	 */
	public int getDayOfWeek(Date date){
		return new DateTime(date).getDayOfWeek();
	}
	
	/**
	 * Check a date expression is valid or not
	 * 
	 * @param dateExpression: String
	 * @return true or false
	 */
	public boolean isValidPattern(String dateExpression){
		return WEEK_DAY_PATTERN.matcher(dateExpression).find() ||
				DAY_PATTERN.matcher(dateExpression).find() ||
				MONTH_PATTERN.matcher(dateExpression).find() ||
				WEEK_PATTERN.matcher(dateExpression).find() ||
				YEAR_PATTERN.matcher(dateExpression).find() ||
				SYMBOLIC_DAY_PATTERN.matcher(dateExpression).find();
	}
	
	/**
	 * Check if a week day pattern is present or not
	 * 
	 * @param dateExpression: String
	 * @return true or false
	 */
	public boolean isWeekDayPatternPresents(String dateExpression){
		return WEEK_DAY_PATTERN.matcher(dateExpression).find();
	}
	
	/**
	 * Calculate the date pattern
	 * 
	 * @param dt: DateTime
	 * @param dateExpression: String
	 * @return a date time
	 */
	public DateTime calculateDatePattern(DateTime dt, String dateExpression){
		Matcher dayMatcher = DAY_PATTERN.matcher(dateExpression);
		
		DateTime result = calcaulateSymbolicDatePattern(dt, dateExpression);
		if(result==null){
			result = dt;
		}
		
		if (dayMatcher.find()) {
			result = (dayMatcher.group(1).isEmpty() || "+".equals(dayMatcher.group(1)))
					? result.plusDays(Integer.parseInt(dayMatcher.group(2)))
					: result.minusDays(Integer.parseInt(dayMatcher.group(2)));
		}
		result = calculateDatePattern(dateExpression,result);
	
		
		return result;
	}
	
	private DateTime calculateDatePattern(String dateExpression, DateTime dt){
		Matcher weekMatcher = WEEK_PATTERN.matcher(dateExpression);
		Matcher monthMatcher = MONTH_PATTERN.matcher(dateExpression);
		Matcher yearMatcher = YEAR_PATTERN.matcher(dateExpression);

		if (weekMatcher.find()) {
			dt = (weekMatcher.group(1).isEmpty() || "+".equals(weekMatcher.group(1)))
					? dt.plusWeeks(Integer.parseInt(weekMatcher.group(2)))
					: dt.minusWeeks(Integer.parseInt(weekMatcher.group(2)));
		}
		
		if (monthMatcher.find()) {
			dt = (monthMatcher.group(1).isEmpty() || "+".equals(monthMatcher.group(1)))
					? dt.plusMonths(Integer.parseInt(monthMatcher.group(2)))
					: dt.minusMonths(Integer.parseInt(monthMatcher.group(2)));
		}
		if (yearMatcher.find()) {
			dt = (yearMatcher.group(1).isEmpty() || "+".equals(yearMatcher.group(1)))
					? dt.plusYears(Integer.parseInt(yearMatcher.group(2)))
					: dt.minusYears(Integer.parseInt(yearMatcher.group(2)));
		}
		
		return dt;
	}
	
	private DateTime calcaulateSymbolicDatePattern(DateTime dt, String dateExpression) {
		Matcher symDayMatcher = SYMBOLIC_DAY_PATTERN.matcher(dateExpression);
		DateTime result = null;
		if (symDayMatcher.find()) {
			String symDay = symDayMatcher.group(1);
			if ("today".equalsIgnoreCase(symDay)){
				result = dt.plusDays(0);
			}else if("yesterday".equalsIgnoreCase(symDay)){
				result = dt.plusDays(-1);
			}else if("tomorrow".equalsIgnoreCase(symDay)){
				result = dt.plusDays(1);
			}else if("dayaftertomorrow".equalsIgnoreCase(symDay)){
				result = dt.plusDays(2);
			}else if("daybeforeyesterday".equalsIgnoreCase(symDay)){
				result = dt.plusDays(-2);
			}
		}
		return result;
	}
	
	/**
	 * Calculate the arbitrary text
	 * 
	 * @param dateExpression: String
	 * @return the calculated text
	 */
	public String calculateArbitraryText(String dateExpression){
		Matcher symDayMatcher = SYMBOLIC_DAY_PATTERN.matcher(dateExpression);
		Matcher dayMatcher = DAY_PATTERN.matcher(dateExpression);
		Matcher weekMatcher = WEEK_PATTERN.matcher(dateExpression);
		Matcher monthMatcher = MONTH_PATTERN.matcher(dateExpression);
		Matcher yearMatcher = YEAR_PATTERN.matcher(dateExpression);
		Matcher weekDayMatcher = WEEK_DAY_PATTERN.matcher(dateExpression);
		
		String arbitrary = dateExpression;
		if (symDayMatcher.find()) {
			arbitrary = arbitrary.replace(symDayMatcher.group(0), "");
		}
		if (dayMatcher.find()) {
			arbitrary = arbitrary.replace(dayMatcher.group(0), "");
		}
		if (weekMatcher.find()) {
			arbitrary = arbitrary.replace(weekMatcher.group(0), "");
		}
		if (monthMatcher.find()) {
			arbitrary = arbitrary.replace(monthMatcher.group(0), "");
		}
		if (yearMatcher.find()) {
			arbitrary = arbitrary.replace(yearMatcher.group(0), "");
		}
		if (weekDayMatcher.find()) {
			arbitrary = arbitrary.replace(weekDayMatcher.group(0), "");
		}
		return arbitrary;
	}

	/**
	 * Calculate the week day pattern
	 * 
	 * @param dg: DateGeneratorUtilities
	 * @param startDayOfWeek: int
	 * @param dateExpression: String
	 * @return a date time
	 * @throws KronosCoreCommonException
	 * 			: cutomized kronos core common exception
	 */
	public DateTime calculateWeekDayPattern(DateGeneratorUtilities dg, int startDayOfWeek, String dateExpression) throws KronosCoreCommonException {
		Matcher weekDayMatcher = WEEK_DAY_PATTERN.matcher(dateExpression);
		if (weekDayMatcher.find()) {
			String weekDayInString = weekDayMatcher.group(3).toLowerCase();
			int weekDay = (int) Arrays.asList(WEEKDAYS).stream().filter(x -> ((String) x.getKey()).equalsIgnoreCase(weekDayInString)).findFirst().get().getValue();
	
			if (weekDayMatcher.group(1).isEmpty()){
				if (weekDayMatcher.group(2) != null){
					return dg.getNthWeekDayAs(startDayOfWeek, Integer.parseInt(weekDayMatcher.group(2)), weekDay);
				}else{
					return dg.getNthWeekDayAs(startDayOfWeek, 0, weekDay);					
				}
			}else if ("+".equals(weekDayMatcher.group(1))){
				return dg.getNthWeekDayAs(startDayOfWeek, Integer.parseInt(weekDayMatcher.group(2)), weekDay);
			}else{
				return dg.getNthWeekDayAs(startDayOfWeek, -Integer.parseInt(weekDayMatcher.group(2)), weekDay);
			}
		}else{
			throw new KronosCoreCommonException("Cannot find proper Week symblic day for the date expression " + dateExpression);
		}
	}
	
}
