package com.kronos.report;

import java.util.ArrayList;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;

public class KronosExtentReports extends ExtentReports{

	public KronosExtentReports(String filePath) {
		super(filePath);
	}

	public KronosExtentReports(String filePath, boolean replaceExisting) {
		super(filePath, replaceExisting);
	}

	public synchronized void startTest(ExtentTest test) {
        if (testList == null) {
            testList = new ArrayList<ExtentTest>();
        }
        updateTestQueue(test);
    }
}
