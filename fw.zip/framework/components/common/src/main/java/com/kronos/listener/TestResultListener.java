package com.kronos.listener;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.testng.IInvokedMethod;
import org.testng.IInvokedMethodListener;
import org.testng.ITestContext;
import org.testng.ITestNGMethod;
import org.testng.ITestResult;
import org.testng.internal.IResultListener;

import com.kronos.assertion.KronosSoftAssertion;
import com.kronos.report.Reporter;
import com.kronos.report.StepStatus;

public class TestResultListener implements IResultListener, IInvokedMethodListener{
	private Reporter reporter=Reporter.getInstance();
	public static Map<String,String> testMethods= new HashMap<String,String>();
	public static final String ALM_NAME_PATTERN = "ALM";
	
	@Override
	public void onTestSkipped(ITestResult tr) {
		String reason = null;
		String stackTrace = null;
		if(tr != null){
			/*
			 * Fix SUP-7750
			 */
			String[] groups = tr.getMethod().getGroups();
			String[] dependsOnMethods = tr.getMethod().getMethodsDependedUpon();
			String description = tr.getMethod().getDescription();
			
			reporter.addSkipExtentTest(tr.getName(), description, groups, tr.getInstanceName(), dependsOnMethods);
			
			if(tr.getThrowable() != null){
				/*
				 * Fix missing error message in skipped test case
				*/
				reason = tr.getThrowable().toString();
				stackTrace = Arrays.asList(tr.getThrowable().getStackTrace()).stream().map(x->x.toString()).collect(Collectors.joining("\n"));
				reporter.reportStep(StepStatus.SKIPPED, "Skipped test case ["+Thread.currentThread().getName()+"] : "+ tr.getName()+ "<BR>" + tr.getThrowable().getMessage());
			}else{
				reporter.reportStep(StepStatus.SKIPPED, "Skipped test case ["+Thread.currentThread().getName()+"] : "+ tr.getName());
			}
			if(tr.getName().contains(ALM_NAME_PATTERN))
				testMethods.put(tr.getName().split("("+ALM_NAME_PATTERN+")")[1].split("_")[0], "No Run");
			else
				reporter.reportStep("Test method \'" + tr.getName() + "\' is not following recommended guidelines so its status will not be updated in ALM");
		}
		reporter.endTest(reason,stackTrace);
	}
	
	@Override
	public void onTestFailure(ITestResult tr) {
		String reason = null;
		String stackTrace = null;
		if(tr.getThrowable() != null){
			reason = tr.getThrowable().toString();
			stackTrace = Arrays.asList(tr.getThrowable().getStackTrace()).stream().map(x->x.toString()).collect(Collectors.joining("\n"));
			reporter.reportStep(StepStatus.FAIL, "Finish test case  [" + Thread.currentThread().getName() + "] with failure : <br>" 
					+ "<a style=\"cursor:pointer\" onclick=\"$(this).next('xmp').toggle()\"> Exceptions: (Click to Expand)</a>"
					+ "<xmp style=\"display:none\">"
					+ "Failure at [" + reason + "]\n"
					+ stackTrace
					+" </xmp>");
		}else{
			reporter.reportStep(StepStatus.FAIL, "Finish test case   [" + Thread.currentThread().getName() + "] with failure");
		}		
		reporter.endTest(reason,stackTrace);
		
		if(tr.getName().contains(ALM_NAME_PATTERN))
			testMethods.put(tr.getName().split("("+ALM_NAME_PATTERN+")")[1].split("_")[0], "Failed");
		else
			reporter.reportStep("Test method \'" + tr.getName() + "\' is not following recommended guidelines so its status will not be updated in ALM");
	}
	
	/***
	  * Invoked each time a test fails.
	  * @param tr
	  *          :ITestResult
	  */
	@Override
	public void onTestSuccess(ITestResult tr) {
		reporter.reportStep(StepStatus.PASS, "Finish test case ["+Thread.currentThread().getName()+"] with success");
		
		//Fix for SUP-8385
		/*All the previous retry attempts of current test would have status as SKIP (if any). Check and remove them.
		 */
		cleanUpTestResults(tr);
		
		reporter.endTest();
		if(tr.getName().contains(ALM_NAME_PATTERN))
			testMethods.put(tr.getName().split("("+ALM_NAME_PATTERN+")")[1].split("_")[0], "Passed");
		else
			reporter.reportStep("Test method \'" + tr.getName() + "\' is not following recommended guidelines so its status will not be updated in ALM");
	}
	
	
	@Override
	public void afterInvocation(IInvokedMethod method, ITestResult testResult) {
		if (method.isTestMethod()) {
			KronosSoftAssertion assertion = (KronosSoftAssertion)testResult.getAttribute("assertion");
			if(assertion != null){

				if (!assertion.getVerificationFailures().isEmpty() && testResult.getStatus() == ITestResult.SUCCESS) {
					// set the SUCCESS test to FAILURE
					testResult.setStatus(ITestResult.FAILURE);
				}
				
				int size = assertion.getVerificationFailures().size();
				
				//no user customized assertion, test case fail due to other type of exception throwed
				if (size == 0 && testResult.getStatus() == ITestResult.FAILURE) {
					//set the failure reason
					reporter.reportStepWithAPITracking(testResult.getThrowable().getStackTrace(), 
							testResult.getThrowable().toString() );
				} else if (size == 1) {
	                // if there's only one user assertion failure just set that
                	testResult.setThrowable((Throwable) assertion.getVerificationFailures().get(0));
                } else if (size != 0){
                    // create a failure message with all failures and stack traces (except last failure)
                	StringBuilder failureMessage = new StringBuilder("Multiple validation failures (")
					                	.append(size)
					            		.append("): Please refer to the report for exact location of the failure\n")
					            		.append(assertion.getVerificationFailures()
					            				.stream()
					            				.map(x->x.getMessage())
					            				.collect(Collectors.joining("\n")));
                    // set merged throwable
                    Throwable merged = new Throwable(failureMessage.toString());
                    testResult.setThrowable(merged);
                }
			}
		}
	}
	
	/**
	 * If retry is triggered, the test case will be considered as skip, but this skip test actually count in the total test case
	 * For example, 2 test cases are executed, one failed and got retried for 3 times, and at the end the total run will be 5 test cases 
	 * but in reality, we only run 2 test cases.
	 * This code will remove the retry from the total run count.
	 */
	@Override
	public void onFinish(ITestContext context) {
		Set<ITestResult> failedResultSet = context.getFailedTests().getAllResults();
		for (ITestResult failedResult : failedResultSet) {
            ITestNGMethod failedMethod = failedResult.getMethod();
            if (context.getFailedTests().getResults(failedMethod).size() > 1) {
                failedResultSet.remove(failedResult);
            }
            if (!context.getPassedTests().getResults(failedMethod).isEmpty()) {
                failedResultSet.remove(failedResult);
            }
        }
        
        Set<ITestResult> skippedResultSet = context.getSkippedTests().getAllResults();
        for (ITestResult skippedResult : skippedResultSet) {
            ITestNGMethod skippedMethod = skippedResult.getMethod();
            if (!context.getSkippedTests().getResults(skippedMethod).isEmpty()) {
            	skippedResultSet.remove(skippedResult);
            }
            if (!context.getPassedTests().getResults(skippedMethod).isEmpty()) {
            	skippedResultSet.remove(skippedResult);
            }
            if (!context.getFailedTests().getResults(skippedMethod).isEmpty()) {
            	skippedResultSet.remove(skippedResult);
            }
        }
	}
	
	/*
	 * This method is to remove previous skipped test results for the current test
	 * @param tr ITestResult
	 */
	private void cleanUpTestResults(ITestResult tr)
	{
		ITestContext context = tr.getTestContext();	
        Set<ITestResult> skippedResultSet = context.getSkippedTests().getAllResults();
        for (ITestResult skippedResult : skippedResultSet) {
            if (tr.getMethod().getMethodName() == skippedResult.getMethod().getMethodName())
            	skippedResultSet.remove(skippedResult);
        }
	}
	
	@Override
	public void beforeInvocation(IInvokedMethod method, ITestResult testResult) {
		/**
		 * Won't implement
		 */
	}
	
	@Override
	public void onTestStart(ITestResult result) {
		/**
		 * Won't implement
		 */
	}

	@Override
	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
		/**
		 * Won't implement
		 */
	}

	@Override
	public void onStart(ITestContext context) {
		/**
		 * Won't implement
		 */
	}	

	@Override
	public void onConfigurationSuccess(ITestResult itr) {
		/**
		 * Won't implement
		 */
	}

	@Override
	public void onConfigurationFailure(ITestResult itr) {
		/**
		 * Won't implement
		 */
	}

	@Override
	public void onConfigurationSkip(ITestResult itr) {
		/**
		 * Won't implement
		 */
	}
	
}
