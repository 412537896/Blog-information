package com.kronos.tracking;

import java.util.Date;

import org.apache.log4j.Logger;
import org.bson.Document;

import com.kronos.exception.KronosCoreCommonException;
import com.kronos.utils.common.TrackingConstant;
import com.mongodb.BasicDBObject;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoDatabase;

public abstract class SessionUsage {
	private static final String SKIP = "skip";
	private static final String FAIL = "fail";
	private static final String PASS = "pass";
	private static final String TOTAL = "total";

	private static final Logger LOGGER = Logger.getLogger(SessionUsage.class);

	protected MongoDatabase trackerDB;
	protected Document trackerSession;
	protected int passCount;
	protected int failCount;
	protected int skipCount;
	
	public Document findExistSession(Document trackerSession){
		BasicDBObject searchQuery = new BasicDBObject();
		searchQuery.put("build", trackerSession.get("build"));
		searchQuery.put("product", trackerSession.get("product"));
		searchQuery.put("group", trackerSession.get("group"));
		searchQuery.put("team", trackerSession.get("team"));
		searchQuery.put("type", trackerSession.get("type"));

		FindIterable<Document> cursor = this.trackerDB.getCollection(TrackingConstant.SESSIONS_COLLECTION).find(searchQuery);
		return cursor.first();
	}
	
	
	public MongoDatabase getDB() {
		return trackerDB;
	}

	public Document getSession() {
		return trackerSession;
	}


	/**
	 * update end time for session
	 * @param caseUsageAPITracker 
	 * 
	 * @throws KronosCoreCommonException
	 * 		: customized kronos core common exception
	 */
	public void updateSessionEndInformation(){
		if(trackerDB!=null){
			try{
				BasicDBObject updateDoc = new BasicDBObject();
				updateDoc.append("end_date", new Date());
				updateDoc.append(TOTAL, calcualteStatus(TOTAL));
				updateDoc.append(PASS, calcualteStatus(PASS));
				updateDoc.append(FAIL, calcualteStatus(FAIL));
				updateDoc.append(SKIP, calcualteStatus(SKIP));

				BasicDBObject query = new BasicDBObject();
				query.put("_id", trackerSession.get("_id"));
	
				trackerDB.getCollection(TrackingConstant.SESSIONS_COLLECTION).updateOne(query,  new Document("$set",updateDoc));
			}catch (Exception e){
				LOGGER.error("Cannot update session table.",e);
			}
		}
	}
	
	private int calcualteStatus(String type){
		int temp = 0;
		if(type.equalsIgnoreCase(TOTAL)){
			temp = passCount + failCount + skipCount;
			if(trackerSession.get(TOTAL) != null){
				temp += Integer.parseInt(trackerSession.get(TOTAL).toString());
			}
		}else if(type.equalsIgnoreCase(PASS)){
			temp = passCount;
			if(trackerSession.get(PASS) != null){
				temp += Integer.parseInt(trackerSession.get(PASS).toString());
			}
		}else if(type.equalsIgnoreCase(FAIL)){
			temp = failCount;
			if(trackerSession.get(FAIL) != null){
				temp += Integer.parseInt(trackerSession.get(FAIL).toString());
			}
		}else if(type.equalsIgnoreCase(SKIP)){
			temp = skipCount;
			if(trackerSession.get(SKIP) != null){
				temp += Integer.parseInt(trackerSession.get(SKIP).toString());
			}
		}
		return temp;	
	}
}
