package com.kronos.report;

import java.io.File;
import java.util.Map;

import com.kronos.exception.KronosCoreCommonException;

public interface IReport 
{	
	public void initializeReport(String reportRootPath, String imagePath, Map<String, String> params) throws KronosCoreCommonException;
	
	public void addSystemInfo(String key, String value);
	
	//public void startTest(String testName, String desc, String[] groups, String packageLocation);
	public void startTest(String testName, String desc, String[] groups, String packageLocation, String[] dependsOnMethods);
	//SUP-7750
	//public void addSkipExtentTest(String testName, String packageLocation);

	public void reportStep(String stepName) ;
	
	public void reportStep(StepStatus status, String stepName) ;
	
	public void reportStep(StepStatus status, String stepName,  Throwable t);
	
	public void reportStep(StepStatus status, String stepName, String details);
	
	public void reportStep(StepStatus status, String stepName, File file) ;
	
	public void reportStep(StepStatus status, String stepName, File file, Throwable t);
	
	public void reportStep(StepStatus status, String stepName, String details, File file);
	
	public void deepReportStep(StepStatus status, String stepName) ;
	
//	public void deepReportStep(StepStatus status, String stepName,  Throwable t);
//	
//	public void deepReportStep(StepStatus status, String stepName, String details);
//	
//	public void deepReportStep(StepStatus status, String stepName, File file) ;
	
	public void deepReportStep(StepStatus status, String stepName, File file, Throwable t);
	
//	public void deepReportStep(StepStatus status, String stepName, String details, File file);
	
	public void endReport() throws KronosCoreCommonException;
	
	public void endTest();	
	
	public void endTest(String failureReason, String stackTrace);

	public void addSkipExtentTest(String testName, String desc, String[] groups, String packageLocation, String[] dependsOnMethods);

	public void endReportAtMethod() throws KronosCoreCommonException;
		
}