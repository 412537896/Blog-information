package com.kronos.utils.common;

/**
 * 
 * Test case default values
 *
 */
public class TrackingConstant {
	public static final String SESSIONS_COLLECTION = "falcon_usage_sessions";
	public static final String CASES_COLLECTION = "falcon_usage_cases";
	public static final String TRACKER_COLLECTION = "falcon_usage_trackers";
	
	private TrackingConstant(){
		
	}
}
