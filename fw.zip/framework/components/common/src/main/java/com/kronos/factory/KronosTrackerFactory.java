package com.kronos.factory;

import java.util.Date;
import java.util.Map;

import org.apache.log4j.Logger;
import org.bson.Document;

import com.kronos.exception.KronosCoreCommonException;
import com.kronos.tracking.SessionUsageAPI;
import com.kronos.tracking.SessionUsageUI;
import com.kronos.utils.common.ContextConstant;
import com.mongodb.MongoClient;
import com.mongodb.client.MongoDatabase;

public class KronosTrackerFactory {
	private static final String DB_NAME = "automation";
	private static final Logger logger = Logger.getLogger(KronosTrackerFactory.class);
	
	/**
	 * Default constructor
	 */
	private KronosTrackerFactory() {
	}

	/**
	 * Create an REST CALL usage tracker
	 * 
	 * @param name: String
	 * @param  port: String
	 * @return CaseUsageTracker
	 * @throws KronosCoreCommonException
	 * 		: customized kronos core common exception
	 */
	@SuppressWarnings("resource")
	public static SessionUsageAPI createAPISessionTracker(Map<String, String> params) throws KronosCoreCommonException{
		try{
			int port =  params.containsKey(ContextConstant.TRACKER_PORT_NAME) ? Integer.valueOf(params.get(ContextConstant.TRACKER_PORT_NAME)) : 27017;
			MongoDatabase dataBase = new MongoClient(
					params.containsKey(ContextConstant.TRACKER_DB_HOST) ? params.get(ContextConstant.TRACKER_DB_HOST) : params.get(ContextConstant.TRACKER_DB_NAME) , 
					port).getDatabase(params.containsKey(ContextConstant.TRACKER_DB) ? params.get(ContextConstant.TRACKER_DB) : DB_NAME);
			
			logger.info("DataBase Connection is OK. ");
			Document document = new Document()
	        .append("user", System.getProperty("user.name"))
	        .append("os", System.getProperty("os.name"))
	        .append("type", "API")
			.append("product", params.containsKey("Product") ? params.get("Product") : "UNKNOWN" )
			.append("group", params.containsKey("Group") ? params.get("Group") : "UNKNOWN" )
			.append("team", params.containsKey("Team") ? params.get("Team") : "UNKNOWN" )
	        .append("build", params.containsKey("Build") ? params.get("Build") : "UNKNOWN" )
	        .append("version", params.containsKey("Version") ? params.get("Version") : "Latest" )
	        .append("java", System.getProperty("java.version"))
	        .append("start_date", new Date())
	        .append("end_date", new Date())
	        .append("is_archive", false)
	        .append("browser", "-")
	        .append("options", params);
			
			return new SessionUsageAPI(dataBase,document);
		}catch(Exception e){
			String message = "No DataBase connection. No tracking information will be stored";
			logger.error(message, e);
			return null;
		}
	}
	
	/**
	 * Create an REST CALL usage tracker
	 * 
	 * @param name: String
	 * @param  port: String
	 * @return CaseUsageTracker
	 * @throws KronosCoreCommonException
	 * 		: customized kronos core common exception
	 */
	@SuppressWarnings("resource")
	public static SessionUsageUI createUISessionTracker(Map<String, String> params) throws KronosCoreCommonException{
		try{
			int port =  params.containsKey(ContextConstant.TRACKER_PORT_NAME) ? Integer.valueOf(params.get(ContextConstant.TRACKER_PORT_NAME)) : 27017;
			MongoDatabase dataBase = new MongoClient(
					params.containsKey(ContextConstant.TRACKER_DB_HOST) ? params.get(ContextConstant.TRACKER_DB_HOST) : params.get(ContextConstant.TRACKER_DB_NAME) , 
					port).getDatabase(params.containsKey(ContextConstant.TRACKER_DB) ? params.get(ContextConstant.TRACKER_DB) : DB_NAME);
			
			logger.info("DataBase Connection is OK. ");
			Document document = new Document()
	        .append("user", System.getProperty("user.name"))
	        .append("os", System.getProperty("os.name"))
	        .append("type", "UI")
			.append("product", params.containsKey("Product") ? params.get("Product") : "UNKNOWN" )
			.append("group", params.containsKey("Group") ? params.get("Group") : "UNKNOWN" )
			.append("team", params.containsKey("Team") ? params.get("Team") : "UNKNOWN" )
	        .append("build", params.containsKey("Build") ? params.get("Build") : "UNKNOWN" )
	        .append("version", params.containsKey("Version") ? params.get("Version") : "Latest" )
	        .append("java", System.getProperty("java.version"))
	        .append("start_date", new Date())
	        .append("end_date", new Date())
	        .append("is_archive", false)
	        .append("browser", params.get("browser"))
	        .append("options", params);
			
			return new SessionUsageUI(dataBase,document);
		}catch(Exception e){
			String message = "No DataBase connection. No tracking information will be stored";
			logger.error(message, e);
			return null;
		}
	}

}
