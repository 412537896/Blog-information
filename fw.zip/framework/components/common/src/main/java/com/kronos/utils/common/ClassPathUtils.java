package com.kronos.utils.common;

/**
 * Created by abhishek.awale on 31-03-2016.
 */
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

import com.kronos.exception.KronosCoreCommonException;
import com.kronos.logging.KronosLogger;

/**
 * list resources available from the classpath @ *
 */
public class ClassPathUtils {
	
	private ClassPathUtils(){
		
	}
    /**
     * for all elements of java.class.path get a Collection of resources Pattern
     * pattern = Pattern.compile(".*"); gets all resources
     *
     * @param pattern
     *            the pattern to match
     * @return the resources in the order they are found
     */
	
	final  static Logger logger =Logger.getLogger(ClassPathUtils.class);
    public static Collection<String> getResources(
            final Pattern pattern)throws KronosCoreCommonException{
        final List<String> retval = new ArrayList<String>();
        final String classPath = System.getProperty("java.class.path", ".");
        final String[] classPathElements = classPath.split(System.getProperty("path.separator"));
        for(final String element : classPathElements){
            retval.addAll(getResources(element, pattern));
        }
        return retval;
    }
    /**
     * Get resources that matches the pattern.
     *
     * @param element: String
     *  @param : String
     * @return the Collection of resources that matches the pattern
     */
    private static Collection<String> getResources (
            final String element,
            final Pattern pattern)throws KronosCoreCommonException{
        final List<String> retval = new ArrayList<String>();
        final File file = new File(element);
        if(file.isDirectory()){
            retval.addAll(getResourcesFromDirectory(file, pattern));
        } 
        return retval;
    }
    
    /**
     * Get the resources from the Directory
     *
     * @param directory: File
     * @param pattern: Pattern
     * @throws KronosCoreCommonException
     * 		: customized kronos core common exception
     * @return the Collection of resources that matches the pattern
     */
    private static Collection<String> getResourcesFromDirectory(final File directory,final Pattern pattern) throws KronosCoreCommonException{
    	KronosLogger.traceEnter();
        final List<String> retval = new ArrayList<String>();
        final File[] fileList = directory.listFiles();
        for(final File file : fileList){
            if(file.isDirectory()){
                retval.addAll(getResourcesFromDirectory(file, pattern));
            } else{
                try{
                    final String fileName = file.getCanonicalPath();
                    final boolean accept = pattern.matcher(fileName).matches();
                    if(accept){
                        retval.add(fileName);
                    }
                } catch(final IOException e){
                	String errorMsg ="While get Resource from directory ,IO Exception happened";
                	logger.error(errorMsg, e);
                	throw new  KronosCoreCommonException(errorMsg,e);
                }
            }
        }
        KronosLogger.traceLeave();
        return retval;
    }
    /**
     * Loads all the files from the class path
     * 
     * @throws KronosCoreCommonException
     * 		: customized kronos core common exception
     * @return URLClassLoader
     */
    public static URLClassLoader createURLClassLoader() throws KronosCoreCommonException {
    	KronosLogger.traceEnter();
        Collection<String> resources = ClassPathUtils.getResources(Pattern.compile(".*"));
        Collection<URL> urls = new ArrayList<URL>();
        for (String resource : resources) {
            File file = new File(resource);
            // Ensure that the JAR exists
            // and is in the globalclasspath directory.
            if (file.isFile() && "globalclasspath".equals(file.getParentFile().getName())) {
                try {
                    urls.add(file.toURI().toURL());
                } catch (MalformedURLException e) {
                    // This should never happen.
                	String errorMsg="Invalid URL Input";
                	logger.error(errorMsg, e);
                	throw new  KronosCoreCommonException(errorMsg,e);
                }
            }
        }
        KronosLogger.traceLeave();
        return new URLClassLoader(urls.toArray(new URL[urls.size()]));
    }
}
