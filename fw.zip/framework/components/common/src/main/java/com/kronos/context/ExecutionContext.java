package com.kronos.context;

import com.kronos.testng.Configurator;
import com.kronos.utils.common.ContextConstant;

/**
 * 
 * Test case default values
 *
 */
public class ExecutionContext {
	private String tenant;
	private String frontEndServer;
	private String backEndServer;
	private String openAmServer;
	private String APIGatewayServer;
	private String oAuth_clientId;
	private String oAuth_clientSecret;
	
	private Configurator configurator = Configurator.getInstance();

	public ExecutionContext() {
		super();
		this.tenant = configurator.getParameter("Tenant");
		this.frontEndServer = configurator.getParameter("Frontend_Server");
		this.backEndServer = configurator.getParameter("Backend_Server");
		this.openAmServer = configurator.getParameter("OpenAM_Server");
		this.APIGatewayServer = configurator.getParameter(ContextConstant.APIGATEWAY_SERVER);
		this.setoAuth_clientId(configurator.getParameter(ContextConstant.OAUTH_CLIENTID));
		this.setoAuth_clientSecret(configurator.getParameter(ContextConstant.OAUTH_CLIENTSECRET));
	}
	
	public String getAPIGatewayServer() {
		return APIGatewayServer;
	}
	public void setAPIGatewayServer(String apiGatewayServer) {
		APIGatewayServer = apiGatewayServer;
	}

	/**
	 * Get Tenant value
	 * 
	 * @return tenant : String
	 */
	public String getTenant() {
		return tenant;
	}

	/**
	 * Set Tenant to default value
	 */
	public void setTenant() {
		this.tenant = configurator.getParameter("Tenant");
	}

	/**
	 * Set Tenant to given context file parameter's name value
	 * 
	 * @param tenant:String
	 */
	public void setTenant(String tenant) {
		this.tenant = tenant;
	}

	/**
	 * Get FrontEndServer value
	 * 
	 * @return frontEndServer : String
	 */
	public String getFrontEndServer() {
		return frontEndServer;
	}

	/**
	 * Set FrontEndServer to default
	 */
	public void setFrontEndServer() {
		this.frontEndServer = configurator.getParameter("Frontend_Server");
	}

	/**
	 * Set FrontEndServer to given context file parameter's name value
	 * 
	 * @param frontEndServer:String
	 */
	public void setFrontEndServer(String frontEndServer) {
		this.frontEndServer = normalizeURL(frontEndServer);
	}

	/**
	 * Get BackEndServer value
	 * 
	 * @return backEndServer:String
	 */
	public String getBackEndServer() {
		return backEndServer;
	}

	/**
	 * Set BackEndServer value to default
	 */
	public void setBackEndServer() {
		this.backEndServer = configurator.getParameter("Backend_Server");
	}

	/**
	 * Set BackEndServer to given context file parameter's name value
	 * 
	 * @param backEndServer:String
	 */
	public void setBackEndServer(String backEndServer) {
		this.backEndServer = normalizeURL(backEndServer);
	}

	/**
	 * Get OpenAmServer value
	 * 
	 * @return openAmServer:String
	 */
	public String getOpenAmServer() {
		return openAmServer;
	}

	/**
	 * Set OpenAmServer to default
	 */
	public void setOpenAmServer() {
		this.openAmServer = configurator.getParameter("OpenAM_Server");
	}

	/**
	 * Set OpenAmServer to given context file parameter's name value
	 * 
	 * @param openAmServer:String
	 */
	public void setOpenAmServer(String openAmServer) {
		this.openAmServer = normalizeURL(openAmServer);
	}

	@Override
	public String toString() {
		return "ExecutionContext [tenant=" + tenant + ", frontEndServer=" + frontEndServer + ", backEndServer="
				+ backEndServer + ", openAmServer=" + openAmServer + "]";
	}
	
	private String normalizeURL(String url){
		if(url!=null && !url.endsWith("/"))
			url=url+"/";
		if (url!=null && !url.startsWith(ContextConstant.SERVER_PROTOCOL))
			url = ContextConstant.SERVER_PROTOCOL+ContextConstant.SERVER_PROTOCOL_SLASHES+ url;
		return url; 
	}

	public String getoAuth_clientId() {
		return oAuth_clientId;
	}

	public void setoAuth_clientId(String oAuth_clientId) {
		this.oAuth_clientId = oAuth_clientId;
	}

	public String getoAuth_clientSecret() {
		return oAuth_clientSecret;
	}

	public void setoAuth_clientSecret(String oAuth_clientSecret) {
		this.oAuth_clientSecret = oAuth_clientSecret;
	}
}
