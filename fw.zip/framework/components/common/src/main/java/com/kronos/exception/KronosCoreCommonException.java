package com.kronos.exception;

public class KronosCoreCommonException extends Exception {
	 
	 private static final long serialVersionUID = -6725534691869595212L;

	 /**
	  * KronosCoreCommonException's constructor with a message.
	  * 
	  * @param message: String
	  */
	 public KronosCoreCommonException(String message) {
	        super(message);
	    }

	 /**
	  * KronosCoreCommonException's constructor with a message.
	  * 
	  * @param message: String
	  * @param  cause:Throwable
	  */
	 public KronosCoreCommonException(String message, Throwable cause) {
	  super(message, cause);
	 }

	 /**
	  * KronosCoreCommonException's constructor with a message.
	  * 
	  * @param  cause:Exception
	  */
	 public KronosCoreCommonException(Exception cause) {
	  super(cause);
	 }
}
