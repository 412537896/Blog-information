package com.kronos.tracking;

public class CallingClassHelper extends SecurityManager {
    public static final CallingClassHelper INSTANCE = new CallingClassHelper();

    @SuppressWarnings("rawtypes")
	public Class[] getCallingClasses() {
        return getClassContext();
    }
    
    @SuppressWarnings("rawtypes")
    public Class getCallingAPIClass(){
		return "com.kronos.api.rest.driver.APIDriver".equals(getClassContext()[2].getName()) ? getClassContext()[3] : getClassContext()[2];
    }
}