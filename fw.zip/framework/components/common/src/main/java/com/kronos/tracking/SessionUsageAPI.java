package com.kronos.tracking;

import org.apache.log4j.Logger;
import org.bson.Document;

import com.kronos.exception.KronosCoreCommonException;
import com.kronos.report.KronosExtentTest;
import com.kronos.utils.common.TrackingConstant;
import com.mongodb.client.MongoDatabase;

public class SessionUsageAPI extends SessionUsage{
	private static final Logger LOGGER = Logger.getLogger(SessionUsageAPI.class);
		
	/**
	 * Constructor with two parameters
	 * 
	 * @param trackerDB: MongoDatabase
	 * @param trackerSession: Document
	 */
	public SessionUsageAPI(MongoDatabase trackerDB, Document trackerSession) {
		this.trackerDB = trackerDB;
		passCount = 0;
		failCount = 0;
		skipCount = 0;
		if(trackerDB!=null){
			if(trackerSession.get("build") != null && !trackerSession.get("build").toString().isEmpty()){
				//if build number exists, find the latest session has this build number with other parameter
				//if build number exists, we need to reuse the tracker session
				Document existSession = findExistSession(trackerSession);
				if(existSession == null){
					this.trackerSession = trackerSession;
					this.trackerDB.getCollection(TrackingConstant.SESSIONS_COLLECTION).insertOne(this.trackerSession);
				}else{
					this.trackerSession = existSession;
				}
			}else{
				this.trackerSession = trackerSession;
				this.trackerDB.getCollection(TrackingConstant.SESSIONS_COLLECTION).insertOne(this.trackerSession);
			}
		}
	}

	/**
	 * Save the usage 
	 * @param caseUsageAPITracker 
	 * 
	 * @throws KronosCoreCommonException
	 * 		: customized kronos core common exception
	 */
	public void saveTestCaseUsage(KronosExtentTest test){
		CaseUsageAPI caseUsageAPI = test.getApiTracker();
		try{
			if(trackerDB!=null){
				String failureToken = null;
				if(caseUsageAPI.getCaseName().isEmpty()){
					caseUsageAPI.setCaseName(test.getTest().getTest().getName());
				}
				LOGGER.error("Save usage " + caseUsageAPI.getCaseName());
				if("FAIL".equalsIgnoreCase(test.getTest().getRunStatus().name())){
					failCount++;
					failureToken = caseUsageAPI.getFailureToken();
				}else if("PASS".equalsIgnoreCase(test.getTest().getRunStatus().name())){
					passCount++;
				}else if("SKIP".equalsIgnoreCase(test.getTest().getRunStatus().name())){
					skipCount++;
					failureToken = caseUsageAPI.getFailureToken();
				}
				
				Document caseDoc = createCaseDocument(test, caseUsageAPI, failureToken);
				trackerDB.getCollection(TrackingConstant.CASES_COLLECTION).insertOne(caseDoc);
				
				//only store API detail information when team is Integration.
				if("int".equalsIgnoreCase(trackerSession.get("team").toString())){
					insertTrackerDocument(caseUsageAPI, failureToken, caseDoc);
				}
				
			}
		}catch (Exception e){
			LOGGER.error("Save usage failed.",e);
		}
	}

	private void insertTrackerDocument(CaseUsageAPI caseUsageAPI, String failureToken, Document caseDoc) {
		for(UsageAPITracker ut: caseUsageAPI.getTrackers()){
			trackerDB.getCollection(TrackingConstant.TRACKER_COLLECTION).insertOne(
					new Document()
					.append("session", trackerSession.get("_id")).append("case", caseDoc.get("_id"))
					.append("name", caseUsageAPI.getCaseName()).append("line", ut.getLineNumber())
					.append("url", ut.getUrl()).append("action", ut.getAction()).append("object", ut.getAPIObject())
					.append("is_cause_failure", failureToken != null)
					.append("parameter", ut.getParameter())
			);
		}
	}

	private Document createCaseDocument(KronosExtentTest test, CaseUsageAPI caseUsageAPI, String failureToken)
			throws KronosCoreCommonException {
		return new Document()
				.append("session", trackerSession.get("_id")).append("package", caseUsageAPI.getPackage()).append("description", caseUsageAPI.getDescription())
				.append("name", caseUsageAPI.getCaseName()).append("startTime", test.getTest().getStartedTime())
				.append("endTime", test.getTest().getEndedTime()).append("duration", test.getTest().getTest().getRunDuration())
				.append("status", test.getTest().getRunStatus().name()).append("groups", caseUsageAPI.getGroups()).append("alm", caseUsageAPI.getAlmId())
				.append("failReason", test.getFailureReason()).append("stackTrace", test.getStackTrace()).append("failure_token", failureToken)
				.append("apitrackers", caseUsageAPI.getTrackersAsDBObject())
				.append("external_links", caseUsageAPI.getElink());
	}
	/**
	 * Reset the Tracker
	 * @param packageLocation 
	 * @param groups 
	 * 
	 * @param caseName: String
	 * @return 
	 * @throws KronosCoreCommonException
	 * 		: customized kronos core common exception
	 */
	public CaseUsageAPI resetCaseUsage(String caseName, String desc, String[] groups, String packageLocation, String[] dependsOnMethods){
		return new CaseUsageAPI(caseName,desc,groups,packageLocation, dependsOnMethods);
	} 

}
