package com.kronos.tracking;

public class UsageAPITracker {
	private String url;
	private String apiObject;
	private String parameter;
	private String action;
	private int lineNumber;
	private String usedFor;

	/**
	 * Default constructor
	 */
	public UsageAPITracker(){
		
	}

	public UsageAPITracker(String url, String apiObject, String parameter, Actions action) {
		super();
		//process URL
		if (url.startsWith("wfc/restcall/")){
			this.url = url.replace("wfc/restcall/", "");
		}else{
			this.url=url;
		}
		this.apiObject = apiObject;
		this.parameter = parameter;
		this.action = action.toString();
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getAPIObject() {
		return apiObject;
	}

	public void setOriginApiObject(String originApiObject) {
		this.apiObject = originApiObject;
	}

	public String getParameter() {
		return parameter;
	}

	public void setParameter(String parameter) {
		this.parameter = parameter;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public int getLineNumber() {
		return lineNumber;
	}

	public void setLineNumber(int lineNumber) {
		this.lineNumber = lineNumber;
	}

	
	public String getUsedFor() {
		return usedFor;
	}

	public void setUsedFor(String usedFor) {
		this.usedFor = usedFor;
	}

	@Override
	public String toString() {
		return "UsageAPITracker [url=" + url + ", apiObject=" + apiObject + ", parameter=" + parameter + ", action="
				+ action + ", lineNumber=" + lineNumber + "]";
	}
	
}
