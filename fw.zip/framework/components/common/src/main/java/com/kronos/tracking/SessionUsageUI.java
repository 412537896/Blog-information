package com.kronos.tracking;

import org.apache.log4j.Logger;
import org.bson.Document;

import com.kronos.exception.KronosCoreCommonException;
import com.kronos.report.KronosExtentTest;
import com.kronos.utils.common.TrackingConstant;
import com.mongodb.client.MongoDatabase;

public class SessionUsageUI extends SessionUsage{
	private static final Logger LOGGER = Logger.getLogger(SessionUsageUI.class);
	/**
	 * Constructor with two parameters
	 * 
	 * @param trackerDB: MongoDatabase
	 * @param trackerSession: Document
	 */
	public SessionUsageUI(MongoDatabase trackerDB, Document trackerSession) {
		this.trackerDB = trackerDB;
		passCount = 0;
		failCount = 0;
		skipCount = 0;
		if(trackerDB!=null){
			if(trackerSession.get("build") != null && !trackerSession.get("build").toString().isEmpty()){
				//if build number is there, find the latest session has this build number with other parameter
				//if build number exists, we need to reuse the tracker session
				Document existSession = findExistSession(trackerSession);
				if(existSession == null){
					this.trackerSession = trackerSession;
					this.trackerDB.getCollection(TrackingConstant.SESSIONS_COLLECTION).insertOne(this.trackerSession);
				}else{
					this.trackerSession = existSession;
				}
			}else{
				this.trackerSession = trackerSession;
				this.trackerDB.getCollection(TrackingConstant.SESSIONS_COLLECTION).insertOne(this.trackerSession);
			}
		}
	}

	/**
	 * Save the usage 
	 * @param caseUsageAPITracker 
	 * 
	 * @throws KronosCoreCommonException
	 * 		: customized kronos core common exception
	 */
	public void saveTestCaseUsage(KronosExtentTest test){
		CaseUsageUI caseUsage = test.getUiTracker();
		try{
			if(trackerDB!=null){
				String failureToken = null;
				if(caseUsage.getCaseName().isEmpty()){
					caseUsage.setCaseName(test.getTest().getTest().getName());
				}
				LOGGER.error("Save usage " + caseUsage.getCaseName());
				if("FAIL".equalsIgnoreCase(test.getTest().getRunStatus().name())){
					failCount++;
					failureToken = caseUsage.getFailureToken();
				}else if("PASS".equalsIgnoreCase(test.getTest().getRunStatus().name())){
					passCount++;
				}else if("SKIP".equalsIgnoreCase(test.getTest().getRunStatus().name())){
					skipCount++;
					failureToken = caseUsage.getFailureToken();
				}
				
				Document caseDoc = createCaseDocument(test, caseUsage, failureToken);
				trackerDB.getCollection(TrackingConstant.CASES_COLLECTION).insertOne(caseDoc);
				
				//only store UI detail information when team is Integration.
				if("int".equalsIgnoreCase(trackerSession.get("team").toString())){
					insertTrackerDocument(caseUsage, caseDoc);
				}
			}
		}catch (Exception e){
			LOGGER.error("Save usage failed.",e);
		}
	}

	private void insertTrackerDocument(CaseUsageUI caseUsage, Document caseDoc) {
		for(UsageUITracker ut: caseUsage.getTrackers()){
			ut.save(trackerDB,trackerSession.get("_id"),caseDoc.get("_id"));
		}
	}

	private Document createCaseDocument(KronosExtentTest test, CaseUsageUI caseUsage, String failureToken)
			throws KronosCoreCommonException {
		return new Document()
				.append("session", trackerSession.get("_id")).append("package", caseUsage.getPackage()).append("description", caseUsage.getDescription())
				.append("name", caseUsage.getCaseName()).append("startTime", test.getTest().getStartedTime())
				.append("endTime", test.getTest().getEndedTime()).append("duration", test.getTest().getTest().getRunDuration())
				.append("status", test.getTest().getRunStatus().name()).append("groups", caseUsage.getGroups()).append("alm", caseUsage.getAlmId())
				.append("failReason", test.getFailureReason()).append("stackTrace", test.getStackTrace()).append("failure_token", failureToken)
				.append("uitrackers", caseUsage.getTrackersAsDBObject())
				.append("external_links", caseUsage.getElink())
				.append("sc", caseUsage.getScreenshot());
	}
	
	/**
	 * Reset the Tracker
	 * 
	 * @param caseName: String
	 * @throws KronosCoreCommonException
	 * 		: customized kronos core common exception
	 */
	public CaseUsageUI resetCaseUsage(String caseName, String desc, String[] groups, String packageLocation, String[] dependsOnMethoods){
		return new CaseUsageUI(caseName,desc,groups,packageLocation,dependsOnMethoods);
	} 
}
