package com.kronos.factory;

import java.net.InetAddress;
import java.net.UnknownHostException;

import org.apache.log4j.Logger;

import com.kronos.exception.KronosCoreCommonException;
import com.kronos.logging.KronosLogger;
import com.kronos.report.KronosExtentReports;

public class KronosReportFactory {
	
	private static final Logger logger = Logger.getLogger(KronosReportFactory.class);
	
	/**
	 * Constructor of KronosReportFactory
	 */
	private KronosReportFactory() {
	}

	/**
	 * Create extent report
	 * 
	 * @param file: String
	 * @return ExtentReports
	 * @throws KronosCoreCommonException
	 * 		: customized kronos core common exception
	 */
	public static KronosExtentReports createExtentReport(String file) throws KronosCoreCommonException {
		KronosLogger.traceEnter(); 
		KronosExtentReports report = new KronosExtentReports(file, true);
		//setup environment variables
		InetAddress iAddress = null;
		try {
			iAddress = InetAddress.getLocalHost();
		} catch (UnknownHostException e) {
			String message = "Failed to get local host " ;
			logger.error(message, e);
			throw new KronosCoreCommonException(message,e);
		}
		logger.info("Host Name: " + iAddress.getHostName()+ " Address: " + iAddress.getHostAddress());
		String hostName="NA";
		String canonicalHostName="NA";
		if(iAddress != null) {
			hostName = iAddress.getHostName();
	        canonicalHostName = iAddress.getCanonicalHostName();

	        report.addSystemInfo("Host Name", hostName);
	        report.addSystemInfo("Host Name (Canonical)", canonicalHostName);
		}
		KronosLogger.traceLeave(); // leave ---
		return report;
	}
}
