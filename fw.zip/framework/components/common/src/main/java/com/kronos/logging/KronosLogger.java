package com.kronos.logging;

import org.apache.log4j.Logger;

public class KronosLogger {
	
	static Logger log = Logger.getLogger(KronosLogger.class);
	
	private KronosLogger(){
		
	}
	/**
	 * Log trace enter statement for method.
	 */
	public static void traceEnter() {
//		StackTraceElement[] stack = (new Throwable().getStackTrace());
//		String methodName = stack[1].getMethodName();
//		String classNameWithKronosException = stack[1].getClassName();
//		String className = classNameWithKronosException
//				.substring(classNameWithKronosException.lastIndexOf(".") + 1);
//		log.info(String.format("Entering: %s.%s method", className, methodName));
	}

	/**
	 * Log trace leave statement for method.
	 */
	public static void traceLeave() {
//		StackTraceElement[] stack = (new Throwable().getStackTrace());
//		String methodName = stack[1].getMethodName();
//		String classNameWithKronosException = stack[1].getClassName();
//		String className = classNameWithKronosException
//				.substring(classNameWithKronosException.lastIndexOf(".") + 1);
//		log.info(String.format("Exiting: %s.%s method", className, methodName));
	}
}
