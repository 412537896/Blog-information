package com.kronos.utils.common;

public class ContextConstant {
	public static final String BACKEND_SERVER = "Backend_Server";
	public static final String FRONTEND_SERVER = "Frontend_Server";
	
	//API Gateway
	public static final String APIGATEWAY_SERVER= "APIGateway_Server";
	public static final String TMS_DB_SERVER="TMS_DB_SERVER";
	public static final String TMS_DB_SID="TMS_DB_SID";
	public static final String EXTERNAL_APPKEY= "ExternalAppKey";
	public static final String OAUTH_CLIENTID= "OAuth_ClientId";
	public static final String OAUTH_CLIENTSECRET= "OAuth_ClientSecret";
	
	public static final String SERVER_PROTOCOL = "http";
	public static final String SERVER_PROTOCOL_SLASHES = "://";
	public static final String DATE_FORMAT="dateFormat";
	public static final String TIMEOUT = "timeout";
	public static final String START_DAY_OF_WEEK = "startDayOfWeek";
	public static final String DEFAULT_UI_DATE_FORMAT = "yyyy-MM-dd";
	public static final String OPEN_AM_SERVER = "OpenAM_Server";
	public static final String TENANT = "Tenant";
	public static final String DEEPREPORTING = "deepReporting";
	public static final String LOG_LEVEL = "logInfoLevel";
	public static final String PUBLISH_RESULTS_TO_ALM = "PUBLISH_RESULTS_TO_ALM";
	public static final String WFM_URL = "wfm_url";
	public static final String WFM_BUILD_VERSION = "Build_Level";
	
	//reporting
	public static final String REPORT_LOCATION = "Report_Loc";
	public static final String LOG_LOCATION = "Log_Loc";
	
	public static final String RUN_MODE = "runMode";
	public static final String INCLUDE_RETRY_REPORT = "includeRetryReport";

	//tracking constants
    public static final String TRACKER_TYPE = "TrackerType";
	public static final String TRACKER_DB_NAME = "TrackerDBName";
	public static final String TRACKER_DB_HOST = "TrackerDBHost";
	public static final String TRACKER_PORT_NAME = "TrackerDBPort";
	public static final String TRACKER_DB = "TrackerDB";
	
	//WFM constants
	public static final String WFM_USERNAME_KEY = "wfm_username";
	public static final String WFM_PASSWORD_KEY = "wfm_password";
	public static final String WFM_USERNAME_VALUE = "root";
	public static final String WFM_PASSWORD_VALUE = "kronites";
	public static final String TIME_ZONE = "Time_Zone";

	private ContextConstant(){
		
	}
}
