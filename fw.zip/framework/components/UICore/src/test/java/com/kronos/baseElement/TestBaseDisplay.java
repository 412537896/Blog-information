package com.kronos.baseElement;

import java.lang.reflect.Method;

import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.kronos.baseElement.pageObjects.AdvancePage;
import com.kronos.baseElement.pageObjects.BasicPage;
import com.kronos.baseElement.pageObjects.MainPage;
import com.kronos.enums.LaunchBrowserAtLevel;
import com.kronos.exception.KronosCoreCommonException;
import com.kronos.testng.BaseUITest;

public class TestBaseDisplay extends BaseUITest{

	MainPage mainpage;
	BasicPage basicPage;
	AdvancePage advancePage;

	@BeforeClass(alwaysRun = true)
	public void setup(ITestContext context) throws KronosCoreCommonException {
		this.setLaunchBrowserAtLevel(LaunchBrowserAtLevel.TESTCLASS);
	} 

	@BeforeMethod(alwaysRun = true)
	public void beforeMethodTest(Method m, ITestContext context, ITestResult testResult) throws KronosCoreCommonException {
		if(mainpage==null && basicPage==null){
			mainpage = new MainPage(driver);
		}
	}

	@Test(groups = "UNIT", testName = "test_isDisplayForElementDefinedAsNotPresent", description = "", enabled=true)
	public void test_isDisplayForElementDefinedAsNotPresent() throws KronosCoreCommonException {
		mainpage.waitForPageToLoad();
		Assert.assertFalse(mainpage.doesNotExist.isDisplayed());
	}
}