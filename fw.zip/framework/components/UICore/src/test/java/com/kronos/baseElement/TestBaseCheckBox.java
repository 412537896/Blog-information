package com.kronos.baseElement;

import java.lang.reflect.Method;

import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.kronos.assertion.SoftAssertion;
import com.kronos.baseElement.pageObjects.BasicPage;
import com.kronos.baseElement.pageObjects.MainPage;
import com.kronos.enums.LaunchBrowserAtLevel;
import com.kronos.exception.KronosCoreCommonException;
import com.kronos.helpers.BasicBrowserHelper;
import com.kronos.testng.BaseUITest;


public class TestBaseCheckBox extends BaseUITest {
	MainPage main;
	BasicPage basicPage;
	SoftAssertion assertion;

	@BeforeClass(alwaysRun = true)
	public void setup(ITestContext context) throws KronosCoreCommonException {
		this.setLaunchBrowserAtLevel(LaunchBrowserAtLevel.TESTCLASS);
	} 

	@BeforeMethod(alwaysRun = true)
	public void beforeMethodTest(Method m, ITestContext context, ITestResult testResult) throws KronosCoreCommonException {
		if(main==null && basicPage==null){
			main = new MainPage(driver);
			basicPage = main.goToBasicPage();

		}
	} 

	@Test(groups = "UNIT", testName = "ALM_testToSelectAllOptions", description = "", enabled = true)
	public void ALM_testToSelectOption1() throws KronosCoreCommonException {
		BasicBrowserHelper.refreshPage(driver);
		basicPage.testCheckboxTab.click();
		basicPage.testBaseCheckBox1.setCheck(true);
		basicPage.testBaseCheckBox2.setCheck(true);
		basicPage.testBaseCheckBox3.setCheck(true);
		//Assert.assertEquals(basicPage.testBaseCheckBox_label.getText().substring(0, 29),"1 clicked 2 clicked 3 clicked");
	}

	@Test(groups = "UNIT", testName = "ALM_testWhenSelectIsAlreadyTrue", description = "", enabled = true)
	public void ALM_testWhenSelectIsAlreadyTrue() throws KronosCoreCommonException {
		BasicBrowserHelper.refreshPage(driver);
		basicPage.testCheckboxTab.click();
		basicPage.testBaseCheckBox1.setCheck(true);
		if(basicPage.testBaseCheckBox1.isSelected()) {
			basicPage.testBaseCheckBox1.setCheck(true);
			Assert.assertEquals(basicPage.testBaseCheckBox_label.getText(),"1 clicked");
		}
		basicPage.testBaseCheckBox1.setCheck(false);
		Boolean flag;
		if(!basicPage.testBaseCheckBox1.isSelected()){
			basicPage.testBaseCheckBox1.setCheck(false);
			try {
				flag = basicPage.testBaseCheckBox_label.isPresent();
			}
			catch(Exception e){
				flag = true;
			}
			Assert.assertTrue(flag);
		}
	}

	@Test(groups = "UNIT", testName = "ALM_testIfCheckBoxIsDisplayed", description = "", enabled = true)
	public void ALM_testIfCheckBoxIsDisplayed() throws KronosCoreCommonException {
		basicPage.testCheckboxTab.click();
		Assert.assertTrue(basicPage.testBaseCheckBox1.isDisplayed());
	}

	/*getText() is not giving any value because it works on "value" of 
 	element and in current demo page, element does not have "value" attribute*/
	@Test(groups = "UNIT", testName = "ALM_testToGetText", description = "", enabled = true)
	public void ALM_testToGetText() throws KronosCoreCommonException {
		BasicBrowserHelper.refreshPage(driver);
		basicPage.testCheckboxTab.click();
		Assert.assertEquals(basicPage.testBaseCheckBox1.getTagName(), "input");
	}

	@Test(groups = "UNIT", testName = "ALM_testIfCheckBoxIsEnabled", description = "", enabled = true)
	public void ALM_testIfCheckBoxIsEnabled() throws KronosCoreCommonException {
		BasicBrowserHelper.refreshPage(driver);
		basicPage.testCheckboxTab.click();
		Assert.assertTrue(basicPage.testBaseCheckBox1.isEnabled());
	}

	@Test(groups = "UNIT", testName = "ALM_testIfCheckBoxIsPresent", description = "", enabled = true)
	public void ALM_testIfCheckBoxIsPresent() throws KronosCoreCommonException {
		BasicBrowserHelper.refreshPage(driver);
		basicPage.testCheckboxTab.click();
		Assert.assertTrue(basicPage.testBaseCheckBox1.isPresent());
	}
}
