package com.kronos.baseElement;

import java.lang.reflect.Method;

import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.kronos.baseElement.pageObjects.AdvancePage;
import com.kronos.baseElement.pageObjects.BasicPage;
import com.kronos.baseElement.pageObjects.MainPage;
import com.kronos.enums.LaunchBrowserAtLevel;
import com.kronos.exception.KronosCoreCommonException;
import com.kronos.helpers.BasicBrowserHelper;
import com.kronos.testng.BaseUITest;

public class TestBaseButton extends BaseUITest{

	MainPage mainpage;
	BasicPage basicPage;
	AdvancePage advancePage;

	@BeforeClass(alwaysRun = true)
	public void setup(ITestContext context) throws KronosCoreCommonException {
		this.setLaunchBrowserAtLevel(LaunchBrowserAtLevel.TESTCLASS);
	} 

	@BeforeMethod(alwaysRun = true)
	public void beforeMethodTest(Method m, ITestContext context, ITestResult testResult) throws KronosCoreCommonException {
		if(mainpage==null && basicPage==null){
			mainpage = new MainPage(driver);
			basicPage = mainpage.goToBasicPage(); 
		}
	}

	@Test(groups = "UNIT", testName = "test_checkIfIbaseButtonIsPresent", description = "")
	public void testALM_checkIfIbaseButtonIsPresent()
			throws KronosCoreCommonException {
		basicPage.testButtonTab.click();
		Assert.assertTrue(basicPage.testBaseButton.isPresent());      
	}

	@Test(groups = "negative", expectedExceptions = Exception.class, testName = "testALM_checkIfIbaseButtonIsNotPresent", description = "")
	public void testALM_checkIfIbaseButtonIsNotPresent()
			throws KronosCoreCommonException {
		reporter.reportStep("no catch block for isPresent() method, so it will throw element not found exception");
		basicPage.testButtonTab.click();
		Assert.assertTrue(basicPage.testBaseButton2.isPresent());    
	}

	@Test(groups = "UNIT", testName = "test_checkIfIbaseButtonIsDisplayed", description = "")
	public void testALM_checkIfIbaseButtonIsDisplayed()
			throws KronosCoreCommonException {
		basicPage.testButtonTab.click();
		Assert.assertTrue(basicPage.testBaseButton.isDisplayed());      
	}

	@Test(groups = "negative", expectedExceptions = Exception.class, testName = "test_checkIfIbaseButtonIsNotDisplayed", description = "")
	public void test_checkIfIbaseButtonIsNotDisplayed()
			throws KronosCoreCommonException {
		reporter.reportStep("no catch block for isDisplayed() method");
		basicPage.testButtonTab.click();
		Assert.assertTrue(basicPage.testBaseButton2.isDisplayed());      
	}

	@Test(groups = "UNIT", testName = "test_checkIfIbaseButtonIsEnable", description = "")
	public void testALM_checkIfIbaseButtonIsEnable()
			throws KronosCoreCommonException {
		basicPage.testButtonTab.click();
		Assert.assertTrue(basicPage.testBaseButton.isEnabled());      
	}

	@Test(groups = "negative", expectedExceptions = Exception.class, testName = "test_checkIfIbaseButtonIsNotEnable", description = "")
	public void test_checkIfIbaseButtonIsNotEnable()
			throws KronosCoreCommonException {
		reporter.reportStep("no catch block for isEnabled() method");
		basicPage.testButtonTab.click();
		Assert.assertTrue(basicPage.testBaseButton2.isEnabled());      
	}

	@Test(groups = "UNIT", testName = "test_checkIfIbaseButtonContainsText", description = "")
	public void testALM_checkIfIbaseButtonContainsText()
			throws KronosCoreCommonException {
		basicPage.testButtonTab.click();
		basicPage.testBaseButton.waitForDisplay();
		Assert.assertEquals("IBASEBUTTON", basicPage.testBaseButton.getText());     
	}

	@Test(groups = "negative", expectedExceptions = Exception.class, testName = "test_checkIfIbaseButtonContainsTextNegative", description = "")
	public void test_checkIfIbaseButtonContainsTextNegative()
			throws KronosCoreCommonException {
		reporter.reportStep("it will throw element not found exception");
		basicPage.testButtonTab.click();
		basicPage.testBaseButton2.waitForDisplay();
	}

	@Test(groups = "UNIT", testName = "test_checkIfIbaseButtonIsClickable", description = "")
	public void testALM_checkIfIbaseButtonIsClickable()
			throws KronosCoreCommonException {
		basicPage.testButtonTab.click();
		basicPage.testBaseButton.click();
		Assert.assertEquals("testBaseButton clicked 1",basicPage.testBaseButtonLbl.getText());
	}

	@Test(groups = "negative", expectedExceptions = Exception.class, testName = "testALM_checkIfIbaseButtonIsNotClickable", description = "negative")
	public void testALM_checkIfIbaseButtonIsNotClickable() throws KronosCoreCommonException {
		reporter.reportStep("it will throw element not found exception");
		basicPage.testButtonTab.click();
		basicPage.testBaseButton2.click();
	}

	@Test(groups = "UNIT", testName = "test_checkIfIbaseButtonIsClickableThroughclickAsJScript", description = "")
	public void testALM_checkIfIbaseButtonIsClickableThroughclickAsJScript()
			throws KronosCoreCommonException {
		BasicBrowserHelper.refreshPage(driver);
		basicPage.testButtonTab.click();
		basicPage.testBaseButton.clickAsJScript();
		Assert.assertEquals("testBaseButton clicked 1",basicPage.testBaseButtonLbl.getText());
	}

	@Test(groups = "negative", expectedExceptions = Exception.class, testName = "testALM_checkIfIbaseButtonIsNotClickable", description = "negative")
	public void testALM_checkIfIbaseButtonIsNotClickableThroughClickAsJScript() throws KronosCoreCommonException {
		reporter.reportStep("it will throw element not found exception");
		basicPage.testButtonTab.click();
		basicPage.testBaseButton2.clickAsJScript();
	}

	@Test(groups = "UNIT", testName = "test_checkIfIbaseClickIsPresent", description = "")
	public void testALM_checkIfIbaseClickIsPresent()
			throws KronosCoreCommonException {
		basicPage.testButtonTab.click();
		Assert.assertTrue(basicPage.testBaseClick.isPresent());
	}

	@Test(groups = "negative", testName = "test_checkIfIbaseClickIsPresent", description = "")
	public void testALM_checkIfIbaseClickIsNotPresent()
			throws KronosCoreCommonException {
		reporter.reportStep("no catch block for isPresent() method, so it will throw element not found exception");
		try {
			basicPage.testButtonTab.click();
			Assert.assertTrue(basicPage.testBaseClick2.isPresent());
		}
		catch(Exception e){
			String error = e.toString();
			Assert.assertEquals(error.substring(0,73), "java.lang.RuntimeException: Cannot find element with key:[testBaseClick2]");
		}
	}

	@Test(groups = "UNIT", testName = "test_checkIfIbaseClickIsDisplayed", description = "")
	public void testALM_checkIfIbaseClickIsVisble()
			throws KronosCoreCommonException {
		basicPage.testButtonTab.click();
		Assert.assertTrue(basicPage.testBaseClick.isDisplayed());
	}

	@Test(groups = "UNIT", testName = "test_checkIfIbaseClickIsEnable", description = "")
	public void testALM_checkIfIbaseClickIsEnable()
			throws KronosCoreCommonException {
		basicPage.testButtonTab.click();
		Assert.assertTrue(basicPage.testBaseClick.isEnabled());
	}

	@Test(groups = "UNIT", testName = "test_checkIfIbaseClickIsClickable", description = "")
	public void testALM_checkIfIbaseClicknIsClickable()
			throws KronosCoreCommonException {
		BasicBrowserHelper.refreshPage(driver);
		basicPage.testButtonTab.click();
		basicPage.testBaseClick.click();
		basicPage.testBaseClick.click();
		basicPage.testBaseClick.click();
		Assert.assertEquals("testBaseClick clicked 3",basicPage.testBaseClickLbl.getText());
	}


	@Test(groups = "UNIT", testName = "test_checkIfIbaseClickIsClickableThroughclickAsJScript", description = "")
	public void testALM_checkIfIbaseClickIsClickableThroughclickAsJScript()
			throws KronosCoreCommonException {
		basicPage.testButtonTab.click();
		basicPage.testBaseClick.clickAsJScript();
		basicPage.testBaseClick.clickAsJScript();
		basicPage.testBaseClick.clickAsJScript();
		Assert.assertEquals("testBaseClick clicked 3",basicPage.testBaseClickLbl.getText());
	}
}