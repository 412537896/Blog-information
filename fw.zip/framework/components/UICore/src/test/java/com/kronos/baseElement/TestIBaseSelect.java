package com.kronos.baseElement;

import java.lang.reflect.Method;

import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.kronos.baseElement.pageObjects.BasicPage;
import com.kronos.baseElement.pageObjects.MainPage;
import com.kronos.enums.LaunchBrowserAtLevel;
import com.kronos.exception.KronosCoreCommonException;
import com.kronos.helpers.BasicBrowserHelper;
import com.kronos.testng.BaseUITest;

public class TestIBaseSelect extends BaseUITest{
	MainPage main;
	BasicPage basicPage;

	@BeforeClass(alwaysRun = true)
	public void setup(ITestContext context) throws KronosCoreCommonException {
		this.setLaunchBrowserAtLevel(LaunchBrowserAtLevel.TESTCLASS);
	} 

	@BeforeMethod(alwaysRun = true)
	public void beforeMethodTest(Method m, ITestContext context, ITestResult testResult) throws KronosCoreCommonException {
		if(main==null && basicPage==null){
			main = new MainPage(driver);
			basicPage = main.goToBasicPage();

		}
	}

	/*@Test(expectedExceptions = KronosCoreCommonException.class)
	public void throwingAnException() throws KronosCoreCommonException {
		
		
	}*/
	
	
	@Test(groups = "UNIT", testName = "ALM_testToSelectByIndex", description = "", enabled = true)
	public void ALM_testToSelectByIndex() throws KronosCoreCommonException {
		BasicBrowserHelper.refreshPage(driver);
		basicPage.testSelectTab.click();
		basicPage.testBaseSingleSelect.select(0);
		Assert.assertEquals(basicPage.testBaseSingleSelect.getSelectedItemValue(),"1");
	}
	
	@Test(groups = "negative", testName = "ALM_testToSelectByNonExistingIndex", description = "", enabled = true)
	public void ALM_testToSelectByNonExistingIndex() throws KronosCoreCommonException {
		BasicBrowserHelper.refreshPage(driver);
		basicPage.testSelectTab.click();
		try{
		basicPage.testBaseSingleSelect.select(5);
		}
		catch(Exception e){
			Assert.assertEquals(e.toString(), "com.kronos.exception.KronosCoreUIException: select: 5 [ testBaseSingleSelect : By.id: sel1 ]");
		}
		//Assert.assertEquals(basicPage.testBaseSingleSelect.getSelectedItemValue(),"1");
	}

	@Test(groups = "UNIT", testName = "ALM_testToSelectByValue", description = "", enabled = true)
	public void ALM_testToSelectByValue() throws KronosCoreCommonException {
		BasicBrowserHelper.refreshPage(driver);
		basicPage.testSelectTab.click();
		basicPage.testBaseSingleSelect.select("2");
		Assert.assertEquals(basicPage.testBaseSingleSelect.getSelectedItemValue(),"2");
		Assert.assertEquals(basicPage.testBaseSingleSelect.getSelectedItem().getText(),"2");
	}
	
	@Test(groups = "negative", testName = "ALM_testToSelectByNonExistingValue", description = "", enabled = true)
	public void ALM_testToSelectByNonExistingValue() throws KronosCoreCommonException {
		BasicBrowserHelper.refreshPage(driver);
		basicPage.testSelectTab.click();
		try{
		basicPage.testBaseSingleSelect.select("5");
		}
		catch(Exception e){
			Assert.assertEquals(e.toString(), "com.kronos.exception.KronosCoreUIException: select: 5 [ testBaseSingleSelect : By.id: sel1 ]");
		}
	}

	@Test(groups = "UNIT", testName = "ALM_testToSelectByValue", description = "", enabled = true)
	public void ALM_testToSelectByVisibleText() throws KronosCoreCommonException {
		BasicBrowserHelper.refreshPage(driver);
		basicPage.testSelectTab.click();
		basicPage.testBaseSingleSelect.selectByVisibleText("3");
		Assert.assertEquals(basicPage.testBaseSingleSelect.getSelectedItemValue(),"3");
	}
	
	@Test(groups = "negative", testName = "ALM_testToSelectByNonExistingVisibleText", description = "", enabled = true)
	public void ALM_testToSelectByNonExistingVisibleText() throws KronosCoreCommonException {
		BasicBrowserHelper.refreshPage(driver);
		basicPage.testSelectTab.click();
		try{
			basicPage.testBaseSingleSelect.selectByVisibleText("5");
		}
		catch(Exception e){
			Assert.assertEquals(e.toString(), "com.kronos.exception.KronosCoreUIException: selectByVisibleText: 5 [ testBaseSingleSelect : By.id: sel1 ]");
		}
	}

	@Test(groups = "UNIT", testName = "ALM_testToGetTotalOptionsInSelect", description = "", enabled = true)
	public void ALM_testToGetTotalOptionsInSelect() throws KronosCoreCommonException {
		BasicBrowserHelper.refreshPage(driver);
		basicPage.testSelectTab.click();
		Assert.assertEquals(basicPage.testBaseSingleSelect.getSelectCount(),4);
	}

	@Test(groups = "UNIT", testName = "ALM_testToGetAllOptions", description = "", enabled = true)
	public void ALM_testToGetAllOptions() throws KronosCoreCommonException {
		BasicBrowserHelper.refreshPage(driver);
		basicPage.testSelectTab.click();
		Assert.assertEquals(4, basicPage.testBaseSingleSelect.getAllOptions().size());
	}

	@Test(groups = "UNIT", testName = "ALM_testIfAnyOptionsIsSelected", description = "", enabled = true)
	public void ALM_testIfAnyOptionsIsSelected() throws KronosCoreCommonException {
		BasicBrowserHelper.refreshPage(driver);
		basicPage.testSelectTab.click();
		basicPage.testBaseSingleSelect.selectByVisibleText("3");
		Assert.assertFalse(basicPage.testBaseSingleSelect.isSelected(), "option 3 is not selected");
	}

}
