package com.kronos.baseElement.pageObjects;

import org.openqa.selenium.WebDriver;

import com.kronos.element.interfaces.IBaseElement;
import com.kronos.enums.KronosLocateVia;
import com.kronos.exception.KronosCoreCommonException;
import com.kronos.exception.KronosCoreUIException;
import com.kronos.findbysImp.KronosFindBy;

public class AdvancePage extends MainPage {
	
	/*
	 * Synchronization
	 */
	
	@KronosFindBy(id = "testSynchronizationTab", via = KronosLocateVia.ByElementVisible)
	public IBaseElement testSynchronizationTab;
	
	@KronosFindBy(id = "waitForVisible", via = KronosLocateVia.ByElementVisible)
	public IBaseElement waitForVisibleBtn;
	
	@KronosFindBy(id = "waitForVisible_label", via = KronosLocateVia.ByElementPresent)
	public IBaseElement waitForVisibleLbl;
	
	@KronosFindBy(id = "waitForInvisible", via = KronosLocateVia.ByElementVisible)
	public IBaseElement waitForInvisibleBtn;
	
	@KronosFindBy(id = "waitForInvisible_label", via = KronosLocateVia.ByElementPresent)
	public IBaseElement waitForInvisibleLbl;
	
	
	@KronosFindBy(id = "waitForEnable", via = KronosLocateVia.ByElementVisible)
	public IBaseElement waitForEnableBtn;
	
	@KronosFindBy(id = "waitForEnableCheck", via = KronosLocateVia.ByElementPresent)
	public IBaseElement waitForEnableCheckBtn;
	
	
	@KronosFindBy(id = "waitForDisable", via = KronosLocateVia.ByElementVisible)
	public IBaseElement waitForDisableBtn;
	
	@KronosFindBy(id = "waitForDisableCheck", via = KronosLocateVia.ByElementPresent)
	public IBaseElement waitForDisableCheckBtn;
	
	
	@KronosFindBy(id = "waitForCSSEnable", via = KronosLocateVia.ByElementVisible)
	public IBaseElement waitForCSSEnableBtn;
	
	@KronosFindBy(id = "waitForCSSEnableCheck", via = KronosLocateVia.ByElementPresent)
	public IBaseElement waitForCSSEnableCheckBtn;
	
	@KronosFindBy(id = "waitForCSSDisable", via = KronosLocateVia.ByElementVisible)
	public IBaseElement waitForCSSDisableBtn;
	
	@KronosFindBy(id = "waitForCSSDisableCheck", via = KronosLocateVia.ByElementPresent)
	public IBaseElement waitForCSSDisableCheckBtn;
	
	/*
	 * Get Text 
	 */
	@KronosFindBy(id = "testGetTextTab", via = KronosLocateVia.ByElementVisible)
	public IBaseElement testGetTextTab;
	
	@KronosFindBy(xpath = "//*[@id=\"fancytree-id-source-Manager%20Pattern%20Templates15\"]", via = KronosLocateVia.ByElementVisible)
	public IBaseElement testSpecialIdTxt;
	
	/*
	 * Drag and drop 
	 */
	@KronosFindBy(id = "testDNDTab", via = KronosLocateVia.ByElementVisible)
	public IBaseElement testDNDTab;
	
	@KronosFindBy(id = "list_B", via = KronosLocateVia.ByElementVisible)
	public IBaseElement testDropLst;
	
	@KronosFindBy(id = "dndLabelA", via = KronosLocateVia.ByElementVisible)
	public IBaseElement testDNDALbl;
	
	@KronosFindBy(id = "dndLabelB", via = KronosLocateVia.ByElementVisible)
	public IBaseElement testDNDBLbl;
	
	
	public AdvancePage(WebDriver driver) throws KronosCoreCommonException {
		super(driver);
		waitForApplicationToLoad();
	}

	private void waitForApplicationToLoad() throws KronosCoreUIException {
		waitForApplicationToLoad(TEST_ICON);
	}

}
