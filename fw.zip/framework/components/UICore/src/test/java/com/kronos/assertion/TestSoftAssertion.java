package com.kronos.assertion;

import java.util.HashMap;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.kronos.exception.KronosCoreCommonException;
import com.kronos.report.Reporter;

public class TestSoftAssertion  {

	SoftAssertion softAssertion = null;
	HashMap<String, String> parameterMap;
	Reporter reporter;
	
	@Before
	public void setUp() throws Exception {
		softAssertion = new SoftAssertion(null);
		
		reporter = Reporter.getInstance();
		try {
			// configuring param map for report configuration Hard Coded
			parameterMap = new HashMap<String, String>();
			parameterMap.put("deepReporting", "True");
			parameterMap.put("runMode","");
			reporter.initializeReport("","",parameterMap);
			String[] groups = {"P0"};
			String[] DependsOnMethods = {"TestSetup"};
			reporter.startTest("UICore:SoftAssertion", "UICore:SoftAssertion", groups, "location",DependsOnMethods);
		} catch (KronosCoreCommonException e) {
			e.printStackTrace();
		}
	}
	

	@Test
	public void test_verifyTrue() throws KronosCoreCommonException {
		Assert.assertTrue(softAssertion.verifyTrue(true));
		Assert.assertTrue(softAssertion.verifyTrue(Boolean.TRUE));
		Assert.assertTrue(softAssertion.verifyTrue(new Boolean(true)));
		Assert.assertTrue(softAssertion.verifyTrue(1 == 1));
	}
	
	@Test
	public void test_verifyTrue_stepDetail() throws KronosCoreCommonException {
		String stepDetail = "verifyTrue_stepDetail";
		
		softAssertion.verifyTrue(true, stepDetail);
		Assert.assertTrue(softAssertion.verifyTrue(true, stepDetail));
		Assert.assertTrue(softAssertion.verifyTrue(Boolean.TRUE, stepDetail));
		Assert.assertTrue(softAssertion.verifyTrue(new Boolean(true), stepDetail));
		Assert.assertTrue(softAssertion.verifyTrue(1 == 1, stepDetail));
	}
	
	@Test
	public void test_verifyFalse() throws KronosCoreCommonException {
		Assert.assertTrue(softAssertion.verifyFalse(false));
		Assert.assertTrue(softAssertion.verifyFalse(Boolean.FALSE));
		Assert.assertTrue(softAssertion.verifyFalse(new Boolean(false)));
		Assert.assertTrue(softAssertion.verifyFalse(0 == 1));
	}
	
	@Test
	public void test_verifyFalse_stepDetail() throws KronosCoreCommonException {
		String stepDetail = "verifyFalse_stepDetail";
		
		Assert.assertTrue(softAssertion.verifyFalse(false, stepDetail));
		Assert.assertTrue(softAssertion.verifyFalse(Boolean.FALSE, stepDetail));
		Assert.assertTrue(softAssertion.verifyFalse(new Boolean(false), stepDetail));
		Assert.assertTrue(softAssertion.verifyFalse(0 == 1, stepDetail));
	}
	
	@Test
	public void test_verifyEquals() throws KronosCoreCommonException {
		String str = "equals";
		
		Assert.assertTrue(softAssertion.verifyEquals(getClass(), getClass()));
		Assert.assertTrue(softAssertion.verifyEquals(1, 1));
		Assert.assertTrue(softAssertion.verifyEquals(1L, 1L));
		Assert.assertTrue(softAssertion.verifyEquals(str, str));
	}
	
	@Test
	public void test_verifyEquals_stepDetail() throws KronosCoreCommonException {
		String stepDetail = "verifyEquals_stepDetail";
		
		Assert.assertTrue(softAssertion.verifyEquals(getClass(), getClass(), stepDetail));
		Assert.assertTrue(softAssertion.verifyEquals(1, 1, stepDetail));
		Assert.assertTrue(softAssertion.verifyEquals(1L, 1L, stepDetail));
		Assert.assertTrue(softAssertion.verifyEquals(stepDetail, stepDetail, stepDetail));
	}
	
	@Test
	public void test_verifyNotEquals() throws KronosCoreCommonException {
		Assert.assertTrue(softAssertion.verifyNotEquals(new Object(), getClass()));
		Assert.assertTrue(softAssertion.verifyNotEquals(this, getClass()));
		Assert.assertTrue(softAssertion.verifyNotEquals(1, 1L));
	}
	
	@Test
	public void test_verifyNotEquals_stepDetail() throws KronosCoreCommonException {
		String stepDetail = "verifyNotEquals_stepDetail";
		
		Assert.assertTrue(softAssertion.verifyNotEquals(new Object(), getClass(), stepDetail));
		Assert.assertTrue(softAssertion.verifyNotEquals(this, getClass(), stepDetail));
		Assert.assertTrue(softAssertion.verifyNotEquals(1, 1L, stepDetail));
	}
	
}