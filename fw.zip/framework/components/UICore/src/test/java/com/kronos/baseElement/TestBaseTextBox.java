package com.kronos.baseElement;

import java.lang.reflect.Method;

import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.kronos.baseElement.pageObjects.BasicPage;
import com.kronos.baseElement.pageObjects.MainPage;
import com.kronos.enums.LaunchBrowserAtLevel;
import com.kronos.exception.KronosCoreCommonException;
import com.kronos.helpers.BasicBrowserHelper;
import com.kronos.testng.BaseUITest;

public class TestBaseTextBox extends BaseUITest{

	MainPage mainpage ;
	BasicPage basicPage  ;

	@BeforeClass(alwaysRun = true)
	public void setup(ITestContext context) throws KronosCoreCommonException {
		this.setLaunchBrowserAtLevel(LaunchBrowserAtLevel.TESTCLASS);

	} 

	@BeforeMethod(alwaysRun = true)
	public void beforeMethodTest(Method m, ITestContext context, ITestResult testResult) throws KronosCoreCommonException {
		if(mainpage==null && basicPage==null){
			mainpage = new MainPage(driver);
			basicPage = mainpage.goToBasicPage(); 
		}
	}

	@Test(groups = "UNIT", testName = "test_checkIfTextBoxIsEditable", description = "")
	public void testALM_checkIfTextBoxIsEditable()
			throws KronosCoreCommonException {

		basicPage.testTextBoxTab.click();
		basicPage.testBaseTxt.setText("Sample text");
		Assert.assertEquals("Sample text", basicPage.testBaseTxt.getText());
	}
	
	@Test(groups = "UNIT", testName = "test_checkIfTextBoxIsEnable", description = "")
	public void testALM_checkIfTextBoxIsEnable()
			throws KronosCoreCommonException {

		basicPage.testTextBoxTab.click();
		Assert.assertTrue(basicPage.testBaseTxt.isEnabled());
	}


	@Test(groups = "UNIT", testName = "test_checkIfTextBoxIsPresent", description = "")
	public void testALM_checkIfTextBoxIsPresent()
			throws KronosCoreCommonException {

		basicPage.testTextBoxTab.click();
		Assert.assertTrue(basicPage.testBaseTxt.isPresent());
	}


	@Test(groups = "UNIT", testName = "test_checkIfTextBoxIsVisible", description = "")
	public void testALM_checkIfTextBoxIsVisible()
			throws KronosCoreCommonException {

		basicPage.testTextBoxTab.click();
		Assert.assertTrue(basicPage.testBaseTxt.isDisplayed());
	}


	@Test(groups = "UNIT", testName = "test_checkIfTextBoxContainsPlaceHolderText", description = "")
	public void testALM_checkIfTextBoxContainsPlaceHolderText()
			throws KronosCoreCommonException {

		basicPage.testTextBoxTab.click();
		Assert.assertEquals("IBaseTextBox for value entering", basicPage.testBaseTxt.getAttribute("placeholder"));
	}
	
	@Test(groups = "UNIT", testName = "test_checkToClearTextBoxContainsText", description = "")
	public void testALM_checkToClearTextBoxContainsText()
			throws KronosCoreCommonException {

		basicPage.testTextBoxTab.click();
		Assert.assertEquals("Value to clear", basicPage.testBaseTxt1.getText());

		basicPage.testBaseTxt1.clear();
		Assert.assertTrue(basicPage.testBaseTxtLabel1.isPresent());
	}
	
	@Test(groups = "negative", testName = "test_checkToClearTextBoxContainsText", description = "")
	public void testALM_checkNegativeForClear()
			throws KronosCoreCommonException {

		basicPage.testTextBoxTab.click();
		Assert.assertEquals("Value to clear", basicPage.testBaseTxt1.getText());
		try{
			basicPage.testBaseTxt2.clear();
		}
		catch(Exception e){
			Assert.assertEquals(e.toString(), "com.kronos.exception.KronosCoreUIException: clear:  [ testBaseTxt2 : By.id: testBaseTextBox2 ]");
		}
	}

	@Test(groups = "UNIT", testName = "test_checkAppendTextOnClearTextBox", description = "")
	public void testALM_checkAppendTextOnClearTextBox()
			throws KronosCoreCommonException {

		BasicBrowserHelper.refreshPage(driver);
		basicPage.testTextBoxTab.click();
		Assert.assertEquals("Value to clear", basicPage.testBaseTxt1.getText());

		basicPage.testBaseTxt1.clear();
		basicPage.testBaseTxt1.setText("Set Text");
		basicPage.testBaseTxt1.appendText(" Appened Text");
		Assert.assertEquals("Set Text Appened Text", basicPage.testBaseTxt1.getText());

	}


	@Test(groups = "UNIT", testName = "test_verifyValueToGetTxtBoxIsNonEdiatable", description = "")
	public void testALM_verifyClearTextBoxIsNonEdiatable()
			throws KronosCoreCommonException {

		boolean isTextBoxEnable = true;
		if(basicPage.testBaseTxt2.isEnabled()){
			isTextBoxEnable = false;
		}

		Assert.assertTrue(isTextBoxEnable);
	}


	@Test(groups = "UNIT", testName = "test_verifyTextBoxContainsText", description = "")
	public void testALM_checkToTextBoxContainsText()
			throws KronosCoreCommonException {

		basicPage.testTextBoxTab.click();
		String textboxValue = basicPage.testBaseTxt2.getText();
		Assert.assertEquals("Value to get", textboxValue);
	}

	@Test(groups = "UNIT", testName = "test_verifyDisabledTextBox", description = "")
	public void testALM_verifyDisabledTextBox()
			throws KronosCoreCommonException {

		basicPage.testTextBoxTab.click();
		boolean isTxt3Enabled = true;
		if (basicPage.testBaseTxt3.isEnabled()) {
			isTxt3Enabled = false;
		}
		Assert.assertTrue(isTxt3Enabled);
	}


	@Test(groups = "UNIT", testName = "test_checkIfIbaseTextBoxIsClickable", description = "")
	public void testALM_checkIfIbaseTextBoxIsClickable()
			throws KronosCoreCommonException {

		basicPage.testTextBoxTab.click();
		basicPage.testBaseTextBox21.click();
		basicPage.testBaseTextBox21.click();
		basicPage.testBaseTextBox21.click();

		Assert.assertEquals("text box is clicked 3",
				basicPage.testBaseTextBox21Lbl.getText());
	}


	@Test(groups = "UNIT", testName = "test_checkIfIbaseTextBoxIsClickableThroughClickAsJScript", description = "")
	public void testALM_checkIfIbaseTextBoxIsClickableThroughClickAsJScript()
			throws KronosCoreCommonException {

		BasicBrowserHelper.refreshPage(driver);
		basicPage.testTextBoxTab.click();
		basicPage.testBaseTextBox21.clickAsJScript();
		basicPage.testBaseTextBox21.clickAsJScript();
		basicPage.testBaseTextBox21.clickAsJScript();

		Assert.assertEquals("text box is clicked 3",
				basicPage.testBaseTextBox21Lbl.getText());
	}


	@Test(groups = "UNIT", testName = "test_checkIfIbaseTextBoxForDoubleClick", description = "")
	public void testALM_checkIfIbaseTextBoxForDoubleClick()
			throws KronosCoreCommonException {

		basicPage.testTextBoxTab.click();
		basicPage.testBaseTextBox22.doubleClick();
		basicPage.testBaseTextBox22.doubleClick();
		basicPage.testBaseTextBox22.doubleClick();
		basicPage.testBaseTextBox22.doubleClick();

		Assert.assertEquals("text box is double clicked 4",
				basicPage.testBaseTextBox22Lbl.getText());
	}

}
