package com.kronos.baseElement;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.kronos.baseElement.pageObjects.AdvancePage;
import com.kronos.baseElement.pageObjects.MainPage;
import com.kronos.exception.KronosCoreCommonException;
import com.kronos.testng.BaseUITest;

public class TestPostSynchronization extends BaseUITest{

	@Test(groups = "UNIT", testName = "test_post_sync", description = "")
	public void test_post_sync() throws KronosCoreCommonException {
		MainPage main = new MainPage(driver);
		AdvancePage advancePage = main.goToAdvancePage();
		
		advancePage.testSynchronizationTab.click();
		advancePage.waitForVisibleBtn.click();
		advancePage.waitForVisibleLbl.waitForDisplay();
		Assert.assertTrue(advancePage.waitForVisibleLbl.isDisplayed());	
		
		advancePage.waitForInvisibleBtn.click();
		advancePage.waitForInvisibleLbl.waitForDisappear();
		Assert.assertFalse(advancePage.waitForInvisibleLbl.isDisplayed());		
		
		advancePage.waitForEnableBtn.click();
		advancePage.waitForEnableCheckBtn.waitForEnable();
		Assert.assertTrue(advancePage.waitForEnableCheckBtn.isEnabled());
		
		advancePage.waitForDisableBtn.click();
		advancePage.waitForDisableCheckBtn.waitForDisable();
		Assert.assertFalse(advancePage.waitForDisableCheckBtn.isEnabled());
	}
	
	@Test(groups = "UNIT", testName = "test_css_disable", description = "")
	public void test_post_sync_with_css_disable() throws KronosCoreCommonException {
		MainPage main = new MainPage(driver);
		AdvancePage advancePage = main.goToAdvancePage();
		
		advancePage.testSynchronizationTab.click();	
		
		advancePage.waitForCSSEnableBtn.click();
		advancePage.waitForCSSEnableCheckBtn.waitForEnable();
		Assert.assertTrue(advancePage.waitForCSSEnableCheckBtn.isEnabled());
		
		advancePage.waitForCSSDisableBtn.click();
		advancePage.waitForCSSDisableCheckBtn.waitForDisable();
		Assert.assertFalse(advancePage.waitForCSSDisableCheckBtn.isEnabled());
	}
}
