package com.kronos.baseElement.pageObjects;


import org.openqa.selenium.WebDriver;

import com.kronos.element.interfaces.IBaseButton;
import com.kronos.element.interfaces.IBaseCheckBox;
import com.kronos.element.interfaces.IBaseClick;
import com.kronos.element.interfaces.IBaseComboBox;
import com.kronos.element.interfaces.IBaseCommonElement;
import com.kronos.element.interfaces.IBaseElement;
import com.kronos.element.interfaces.IBaseLabel;
import com.kronos.element.interfaces.IBaseLink;
import com.kronos.element.interfaces.IBaseListBox;
import com.kronos.element.interfaces.IBaseRadioButton;
import com.kronos.element.interfaces.IBaseSelect;
import com.kronos.element.interfaces.IBaseTextBox;
import com.kronos.enums.KronosLocateVia;
import com.kronos.exception.KronosCoreCommonException;
import com.kronos.exception.KronosCoreUIException;
import com.kronos.findbysImp.KronosFindBy;

public class BasicPage extends MainPage {
	/**
	 * tabs
	 */
	@KronosFindBy(id = "testCommonTab", via = KronosLocateVia.ByElementVisible)
	public IBaseElement testCommonTab;

	@KronosFindBy(id = "testButtonTab", via = KronosLocateVia.ByElementVisible)
	public IBaseElement testButtonTab;

	@KronosFindBy(id = "testTextBoxTab", via = KronosLocateVia.ByElementVisible)
	public IBaseElement testTextBoxTab;

	@KronosFindBy(id = "testLabelTab", via = KronosLocateVia.ByElementVisible)
	public IBaseElement testLabelTab;

	@KronosFindBy(id = "testLinkTab", via = KronosLocateVia.ByElementVisible)
	public IBaseElement testLinkTab;

	@KronosFindBy(id = "testCheckboxTab", via = KronosLocateVia.ByElementVisible)
	public IBaseElement testCheckboxTab;

	@KronosFindBy(id = "testRadioTab", via = KronosLocateVia.ByElementVisible)
	public IBaseElement testRadioTab;

	@KronosFindBy(id = "testSelectTab", via = KronosLocateVia.ByElementVisible)
	public IBaseElement testSelectTab;


	/**
	 * Elements for IBaseCommon tab
	 */
	@KronosFindBy(id = "testBaseCommonElement", via = KronosLocateVia.ByElementClickable)
	public IBaseCommonElement testBaseCommonElementDiv;

	@KronosFindBy(xpath = "//*[@id=\"testBaseCommonElement_label\"]", via = KronosLocateVia.ByElementVisible)
	public IBaseElement testBaseCommonElement_label;

	@KronosFindBy(id = "testBaseELement", via = KronosLocateVia.ByElementClickable)
	public IBaseElement testBaseELementBtn;

	@KronosFindBy(id = "testBaseELement_label", via = KronosLocateVia.ByElementVisible)
	public IBaseElement testBaseELementLbl;


	/**
	 * Elements for IBaseButton tab
	 */
	@KronosFindBy(name = "testBaseButton")
	public IBaseButton testBaseButton;

	@KronosFindBy(name = "testBaseButton2")
	public IBaseButton testBaseButton2;
	
	@KronosFindBy(id = "testBaseButton_label", via = KronosLocateVia.ByElementVisible)
	public IBaseElement testBaseButtonLbl;

	@KronosFindBy(xpath = "//*[@id=\"testBaseClick\"]", via = KronosLocateVia.ByElementClickable)
	public IBaseClick testBaseClick;
	
	@KronosFindBy(xpath = "//*[@id=\"testBaseClick2\"]", via = KronosLocateVia.ByElementClickable)
	public IBaseClick testBaseClick2;

	@KronosFindBy(id = "testBaseClick_label", via = KronosLocateVia.ByElementVisible)
	public IBaseElement testBaseClickLbl;


	/**
	 * Elements for IBaseTextBox tab
	 */
	@KronosFindBy(id = "testBaseTextBox", via = KronosLocateVia.ByElementClickable)
	public IBaseTextBox testBaseTxt;

	@KronosFindBy(xpath = "//*[@id=\"testTextBox\"]/div[2]/div[1]/h3/span", via = KronosLocateVia.ByElementVisible)
	public IBaseElement testBaseTxtLabel;

	@KronosFindBy(id = "testBaseTextBox1", via = KronosLocateVia.ByElementClickable)
	public IBaseTextBox testBaseTxt1;

	@KronosFindBy(xpath = "//*[@id=\"testTextBox\"]/div[2]/div[2]/h3/span", via = KronosLocateVia.ByElementClickable)
	public IBaseElement testBaseTxtLabel1;

	@KronosFindBy(id = "testBaseTextBox2", via = KronosLocateVia.ByElementPresent)
	public IBaseTextBox testBaseTxt2;

	@KronosFindBy(id = "testBaseTextBox3", via = KronosLocateVia.ByElementPresent)
	public IBaseTextBox testBaseTxt3;

	@KronosFindBy(id = "testBaseTextBox21", via = KronosLocateVia.ByElementClickable)
	public IBaseTextBox testBaseTextBox21;

	@KronosFindBy(xpath = "//*[@id=\"testTextBox\"]/div[3]/div[1]/h3/span", via = KronosLocateVia.ByElementVisible)
	public IBaseElement testBaseTextBox21Lbl;

	@KronosFindBy(id = "testBaseTextBox22", via = KronosLocateVia.ByElementClickable)
	public IBaseTextBox testBaseTextBox22;

	@KronosFindBy(xpath = "//*[@id=\"testTextBox\"]/div[3]/div[2]/h3/span", via = KronosLocateVia.ByElementVisible)
	public IBaseElement testBaseTextBox22Lbl;

	/**
	 * Elements for IBaselabel tab
	 */
	@KronosFindBy(id = "testBaseLabel")
	public IBaseLabel testBaseLbl;

	/**
	 * Elements forIBaseLink tab
	 */
	@KronosFindBy(id = "testBaseLink", via = KronosLocateVia.ByElementClickable)
	public IBaseLink testBaseLnk;

	@KronosFindBy(id = "testBaseLink_label", via = KronosLocateVia.ByElementVisible)
	public IBaseElement testBaseLnkLbl;

	/**
	 * Elements forIBaseCheckBox tab
	 */
	@KronosFindBy(id = "testBaseCheckBox1", via = KronosLocateVia.ByElementClickable)
	public IBaseCheckBox testBaseCheckBox1;

	@KronosFindBy(id = "testBaseCheckBox2", via = KronosLocateVia.ByElementClickable)
	public IBaseCheckBox testBaseCheckBox2;

	@KronosFindBy(id = "testBaseCheckBox3", via = KronosLocateVia.ByElementClickable)
	public IBaseCheckBox testBaseCheckBox3;

	@KronosFindBy(id = "testBaseCheckBox_label", via = KronosLocateVia.ByElementVisible)
	public IBaseElement testBaseCheckBox_label;

	/**
	 * Elements for IBaseRadioButton tab
	 */
	@KronosFindBy(id = "testBaseRadioButton_1", via = KronosLocateVia.ByElementClickable)
	public IBaseRadioButton testBaseRadioButton_1;

	@KronosFindBy(id = "testBaseRadioButton_2", via = KronosLocateVia.ByElementClickable)
	public IBaseRadioButton testBaseRadioButton_2;

	@KronosFindBy(id = "testBaseRadioButton_3", via = KronosLocateVia.ByElementClickable)
	public IBaseRadioButton testBaseRadioButton_3;

	@KronosFindBy(id = "testBaseRadioButton_label", via = KronosLocateVia.ByElementVisible)
	public IBaseElement testBaseRadioButton_label;

	/**
	 * Elements for IBaseSelect tab
	 */
	@KronosFindBy(id = "sel1", via = KronosLocateVia.ByElementClickable)
	public IBaseListBox testBaseSingleSelect;

	@KronosFindBy(id = "sel2", via = KronosLocateVia.ByElementClickable)
	public IBaseListBox testBaseMultipleSelect;
	
	
	public BasicPage(WebDriver driver) throws KronosCoreCommonException {
		super(driver);
		waitForApplicationToLoad();
	}
	
	private void waitForApplicationToLoad() throws KronosCoreUIException {
		waitForPageToLoad();
		waitForApplicationToLoad(TEST_ICON);
	}
	
	public AdvancePage goToAdvancePage() throws KronosCoreCommonException{
		advanceBtn2.click();
		return new AdvancePage(driver);
	}

}