package com.kronos.baseElement;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.kronos.baseElement.pageObjects.AdvancePage;
import com.kronos.baseElement.pageObjects.MainPage;
import com.kronos.exception.KronosCoreCommonException;
import com.kronos.testng.BaseUITest;

public class TestGetText extends BaseUITest{

	@Test(groups = "UNIT", testName = "test_get_text_speical_char_id", description = "")
	public void test_SUP_4631() throws KronosCoreCommonException {
		MainPage main = new MainPage(driver);
		AdvancePage advancePage = main.goToAdvancePage();
		
		advancePage.testGetTextTab.click();
		Assert.assertEquals(advancePage.testSpecialIdTxt.getText(),"Value to get for special id");
	}
	
	
}
