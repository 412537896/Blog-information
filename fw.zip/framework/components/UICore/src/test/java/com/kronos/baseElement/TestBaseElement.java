package com.kronos.baseElement;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.kronos.baseElement.pageObjects.BasicPage;
import com.kronos.baseElement.pageObjects.MainPage;
import com.kronos.exception.KronosCoreCommonException;
import com.kronos.testng.BaseUITest;

public class TestBaseElement extends BaseUITest{

	@Test(groups = "UNIT", testName = "test_basic", description = "")
	public void test_basic_button() throws KronosCoreCommonException {
		MainPage main = new MainPage(driver);
		BasicPage basicPage = main.goToBasicPage();
		basicPage.testBaseELementBtn.click();
		basicPage.testBaseELementBtn.click();
		basicPage.testBaseELementBtn.click();
		basicPage.testBaseELementBtn.click();
		basicPage.testBaseELementBtn.click();
		basicPage.testBaseELementBtn.click();
		Assert.assertEquals("testBaseELement clicked 6", basicPage.testBaseELementLbl.getText());
		
		
		basicPage.testButtonTab.click();
		basicPage.testBaseClick.clickAsJScript();
		Assert.assertEquals("testBaseClick clicked 1", basicPage.testBaseClickLbl.getText());
		
		basicPage.testBaseButton.clickAsJScript();
		Assert.assertEquals("testBaseButton clicked 1", basicPage.testBaseButtonLbl.getText());
		basicPage.testBaseButton.click();
		Assert.assertEquals("testBaseButton clicked 2", basicPage.testBaseButtonLbl.getText());
		basicPage.testBaseButton.doubleClick();
		Assert.assertEquals("testBaseButton clicked 3", basicPage.testBaseButtonLbl.getText());
	}
	
	
}
