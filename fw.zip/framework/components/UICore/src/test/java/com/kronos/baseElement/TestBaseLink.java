package com.kronos.baseElement;

import java.lang.reflect.Method;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.kronos.exception.KronosCoreCommonException;
import com.kronos.helpers.BasicBrowserHelper;
import com.kronos.testng.BaseUITest;



import com.kronos.baseElement.pageObjects.*;
import com.kronos.enums.LaunchBrowserAtLevel;


public class TestBaseLink extends BaseUITest{

	MainPage main;
	BasicPage basicPage;

	@BeforeClass(alwaysRun = true)
	public void setup(ITestContext context) throws KronosCoreCommonException {
		this.setLaunchBrowserAtLevel(LaunchBrowserAtLevel.TESTCLASS);

	} 

	@BeforeMethod(alwaysRun = true)
	public void beforeMethodTest(Method m, ITestContext context, ITestResult testResult) throws KronosCoreCommonException {
		if(main==null && basicPage==null){
			main = new MainPage(driver);
			basicPage = main.goToBasicPage();
			
		}
	} 

	@Test(groups = "UNIT", testName = "ALM_testIfLinkIsClickable", description = "", enabled = true)
	public void ALM_testIfLinkIsClickable() throws KronosCoreCommonException {
		BasicBrowserHelper.refreshPage(driver);
		basicPage.testLinkTab.click();
		basicPage.testBaseLnk.click();
		Assert.assertEquals(basicPage.testBaseLnkLbl.getText(),"testBaseLink clicked 1");
	}

	@Test(groups = "UNIT", testName = "ALM_testIfLinkIsClickableThroughClickAsJScript", description = "", enabled = true)
	public void ALM_testIfLinkIsClickableThroughClickAsJScript() throws KronosCoreCommonException {
		BasicBrowserHelper.refreshPage(driver);
		basicPage.testLinkTab.click();
		basicPage.testBaseLnk.clickAsJScript();
		Assert.assertEquals(basicPage.testBaseLnkLbl.getText(),"testBaseLink clicked 1");
	}

	@Test(groups = "UNIT", testName = "ALM_testIfLinkIsDoubleClickable", description = "", enabled = true)
	public void ALM_testIfLinkIsDoubleClickable() throws KronosCoreCommonException {
		BasicBrowserHelper.refreshPage(driver);
		basicPage.testLinkTab.click();
		basicPage.testBaseLnk.doubleClick();
		Assert.assertEquals(basicPage.testBaseLnkLbl.getText(),"testBaseLink clicked 1");
	}

	@Test(groups = "UNIT", testName = "ALM_testgetTextForIBaseLink", description = "", enabled = true)
	public void ALM_testgetTextForIBaseLink() throws KronosCoreCommonException {
		basicPage.testLinkTab.click();
		Assert.assertEquals(basicPage.testBaseLnk.getText(),"IBaseLink");
	}

	@Test(groups = "UNIT", testName = "ALM_testIfLinkIsDisplayed", description = "", enabled = true)
	public void ALM_testIfLinkIsDisplayed() throws KronosCoreCommonException {
		basicPage.testLinkTab.click();
		Assert.assertTrue(basicPage.testLinkTab.isDisplayed(), "IBaseLink is displayed");
	}

	@Test(groups = "UNIT", testName = "ALM_testIfLinkIsEnabled", description = "", enabled = true)
	public void ALM_testIfLinkIsEnabled() throws KronosCoreCommonException {
		basicPage.testLinkTab.click();
		Assert.assertTrue(basicPage.testLinkTab.isEnabled(), "IBaseLink is enabled");
	}

	@Test(groups = "UNIT", testName = "ALM_testToGetTagNameOfLink", description = "", enabled = true)
	public void ALM_testToGetTagNameOfLink() throws KronosCoreCommonException {
		basicPage.testLinkTab.click();
		Assert.assertEquals(basicPage.testLinkTab.getTagName(), "a");
	}

	@Test(groups = "UNIT", testName = "ALM_testIfLinkIsPresent", description = "", enabled = true)
	public void ALM_testIfLinkIsPresent() throws KronosCoreCommonException {
		basicPage.testLinkTab.click();
		Assert.assertTrue(basicPage.testLinkTab.isPresent(), "IBaseLink is present");
	}
}
