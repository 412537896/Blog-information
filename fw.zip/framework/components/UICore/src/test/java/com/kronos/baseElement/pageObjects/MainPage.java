package com.kronos.baseElement.pageObjects;

import org.openqa.selenium.WebDriver;

import com.kronos.basepageobject.BasePage;
import com.kronos.element.interfaces.IBaseButton;
import com.kronos.element.interfaces.IBaseElement;
import com.kronos.enums.KronosLocateVia;
import com.kronos.exception.KronosCoreCommonException;
import com.kronos.exception.KronosCoreUIException;
import com.kronos.findbysImp.KronosFindBy;

public class MainPage extends BasePage {

	protected static final String TEST_ICON = "//*[@id=\"icon\"]";

	@KronosFindBy(xpath = "/html/body/div/div/div/div[2]/a", via = KronosLocateVia.ByElementClickable)
	public IBaseButton basicBtn;
	
	@KronosFindBy(id = "advanceButton", via = KronosLocateVia.ByElementClickable)
	public IBaseButton advanceBtn;

	@KronosFindBy(xpath = "/html/body/nav/div/ul/li[2]/a", via = KronosLocateVia.ByElementClickable)
	public IBaseButton advanceBtn2;

	@KronosFindBy(id = "does not exists", via = KronosLocateVia.ByElementNotPresent)
	public IBaseElement doesNotExist;
	
	public MainPage(WebDriver driver) throws KronosCoreCommonException {
		super(driver);
		waitForApplicationToLoad();
	}

	private void waitForApplicationToLoad() throws KronosCoreUIException {
//		waitForPageToLoad();
		waitForApplicationToLoad(TEST_ICON);
	}
	
	
	public BasicPage goToBasicPage() throws KronosCoreCommonException{
		basicBtn.click();
		return new BasicPage(driver);
	}
	
	
	public AdvancePage goToAdvancePage() throws KronosCoreCommonException{
		advanceBtn.click();
		return new AdvancePage(driver);
	}
}
