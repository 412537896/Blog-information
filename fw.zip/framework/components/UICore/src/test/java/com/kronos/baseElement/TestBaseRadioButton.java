package com.kronos.baseElement;

import com.kronos.testng.BaseUITest;

import java.lang.reflect.Method;

import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.kronos.baseElement.pageObjects.BasicPage;
import com.kronos.baseElement.pageObjects.MainPage;
import com.kronos.enums.LaunchBrowserAtLevel;
import com.kronos.exception.KronosCoreCommonException;
import com.kronos.helpers.BasicBrowserHelper;

public class TestBaseRadioButton extends BaseUITest{
	MainPage main;
	BasicPage basicPage;

	@BeforeClass(alwaysRun = true)
	public void setup(ITestContext context) throws KronosCoreCommonException {
		this.setLaunchBrowserAtLevel(LaunchBrowserAtLevel.TESTCLASS);
	} 

	@BeforeMethod(alwaysRun = true)
	public void beforeMethodTest(Method m, ITestContext context, ITestResult testResult) throws KronosCoreCommonException {
		if(main==null && basicPage==null){
			main = new MainPage(driver);
			basicPage = main.goToBasicPage();

		}
	}
	@Test(groups = "UNIT", testName = "ALM_testToSelectRadio1", description = "", enabled = true)
	public void ALM_testToSelectRadio1() throws KronosCoreCommonException {
		BasicBrowserHelper.refreshPage(driver);
		basicPage.testRadioTab.click();
		basicPage.testBaseRadioButton_1.click();
		Assert.assertEquals(basicPage.testBaseRadioButton_label.getText(),"testBaseRadioButton 1 clicked");
	}

	@Test(groups = "UNIT", testName = "ALM_testToSelectRadio2", description = "", enabled = true)
	public void ALM_testToSelectRadio2() throws KronosCoreCommonException {
		BasicBrowserHelper.refreshPage(driver);
		basicPage.testRadioTab.click();
		basicPage.testBaseRadioButton_2.click();
		Assert.assertEquals(basicPage.testBaseRadioButton_label.getText(),"testBaseRadioButton 2 clicked");
	}

	@Test(groups = "UNIT", testName = "ALM_testToSelectRadio3", description = "", enabled = true)
	public void ALM_testToSelectRadio3() throws KronosCoreCommonException {
		BasicBrowserHelper.refreshPage(driver);
		basicPage.testRadioTab.click();
		basicPage.testBaseRadioButton_3.click();
		Assert.assertEquals(basicPage.testBaseRadioButton_label.getText(),"testBaseRadioButton 3 clicked");
	}

	@Test(groups = "UNIT", testName = "ALM_testToCheckIfradioIsSelected", description = "", enabled = true)
	public void ALM_testToCheckIfradioIsSelected() throws KronosCoreCommonException {
		BasicBrowserHelper.refreshPage(driver);
		basicPage.testRadioTab.click();
		basicPage.testBaseRadioButton_1.click();
		Assert.assertTrue(basicPage.testBaseRadioButton_1.isSelected());
	}

	@Test(groups = "UNIT", testName = "ALM_testToCheckClickAsJscriptOnRadioButton", description = "", enabled = true)
	public void ALM_testToCheckClickAsJscriptOnRadioButton() throws KronosCoreCommonException {
		BasicBrowserHelper.refreshPage(driver);
		basicPage.testRadioTab.click();
		basicPage.testBaseRadioButton_1.clickAsJScript();
		Assert.assertEquals(basicPage.testBaseRadioButton_label.getText(),"testBaseRadioButton 1 clicked");
	}

	@Test(groups = "UNIT", testName = "ALM_testToCheckRadioButtonIsDsplayed", description = "", enabled = true)
	public void ALM_testToCheckRadioButtonIsDsplayed() throws KronosCoreCommonException {
		BasicBrowserHelper.refreshPage(driver);
		basicPage.testRadioTab.click();
		Assert.assertTrue(basicPage.testRadioTab.isDisplayed());
	}

	@Test(groups = "UNIT", testName = "ALM_testToCheckRadioButtonIsEnabled", description = "", enabled = true)
	public void ALM_testToCheckRadioButtonIsEnabled() throws KronosCoreCommonException {
		BasicBrowserHelper.refreshPage(driver);
		basicPage.testRadioTab.click();
		Assert.assertTrue(basicPage.testRadioTab.isEnabled());
	}

	@Test(groups = "UNIT", testName = "ALM_testToCheckRadioButtonIsPresent", description = "", enabled = true)
	public void ALM_testToCheckRadioButtonIsPresent() throws KronosCoreCommonException {
		BasicBrowserHelper.refreshPage(driver);
		basicPage.testRadioTab.click();
		Assert.assertTrue(basicPage.testRadioTab.isPresent());
	}
}

