function GetUIGridCellValue(element, intRowIndex, intColumnIndex) {
	try {
		var scope = angular.element(element).scope();
		if (scope == undefined) {
			throw new Error("Unable to find the Scope() in UI Grid");
		}

		var rowsScope = scope.grid.rows
		if (rowsScope == undefined) {
			throw new Error("Unable to find the Rows in UI Grid");
		}

		var rowsLength = scope.grid.rows.length
		if (rowsLength == undefined || rowsLength === null || rowsLength === 0) {
			throw new Error("UI Grid doesn't contain any Row");
		}
		var renderRows = scope.grid.api.grid.renderContainers.body.renderedRows
		var renderRowsLength = scope.grid.api.grid.renderContainers.body.renderedRows.length
		var columns = scope.grid.columns;
		if (columns == undefined || columns === null || columns === 0) {
			throw new Error("UI Grid doesn't contain any Column");
		}
		var rows = -1

		if (rowsLength === renderRowsLength) {
			rows = renderRows;
		} else {
			rows = rowsScope;
		}

		// get the correct column index in backend
		var intCIndex = GetColumnIndexInBackEnd(scope, intColumnIndex);

		if (intCIndex !== -1) {
			return scope.grid.getCellValue(rows[intRowIndex],
					columns[intCIndex]);
		} else {
			throw new Error(
					"UI grid extensibility GetUIGridCellValue error: columnIndex is incorrect.");
		}
		return "";
	} catch (e) {
		throw new Error("JavaScript Error : " + e.message + "\n " + e.stack);
	}
}

function GetColumnIndexInBackEnd(scope, intColumnIndex) {
	try {
		var columns = scope.grid.columns;
		if (columns == undefined || columns === null || columns === 0) {
			throw new Error("UI Grid doesn't contain any Column");
		}
		var visibleIndex = -1;

		for (var intIndex = 0; intIndex <= columns.length - 1; intIndex++) {
			var columnVisible = columns[intIndex].visible;
			if (columnVisible == undefined || columnVisible === null
					|| columnVisible === 0) {
				throw new Error("UI Grid doesn't contain any Visible Column");
			}
			if (columnVisible) {
				visibleIndex++;
				if (visibleIndex === intColumnIndex) {
					return intIndex;
				}
			}
		}
		return -1;
	} catch (e) {
		throw new Error("JavaScript Error : " + e.message + "\n " + e.stack);
	}
	return -1;
}

function GetUIGridColumnNames(element) {
	try {
		var scope = angular.element(element).scope();
		if (scope == undefined) {
			throw new Error("Unable to find the Scope() in UI Grid");
		}
		var columns = scope.grid.columns;
		if (columns === undefined || columns === null) {
			throw new Error("UI Grid doesn't contain any Column");
		}

		var columnNames = "";

		for (var intIndex = 0; intIndex <= columns.length - 1; intIndex++) {
			var columnVisible = columns[intIndex].visible;
			if (columnVisible === null || columnVisible === undefined) {
				throw new Error("UI Grid doesn't contain any Visible Column");
			}
			if (columnVisible) {
				var columnName = columns[intIndex].displayName;
				columnNames += columnName + "|";
			}
		}

		// remove the last |
		if (columnNames.length > 0) {
			columnNames = columnNames.substring(0, columnNames.length - 1);
		}
		return columnNames;
	} catch (e) {
		throw new Error("JavaScript Error:  " + e.message + "\n " + e.stack);

	}
}

function GetUIGridColumnID(element, intColumnIndex) {
	try {
		var scope = angular.element(element).scope();
		if (scope == undefined) {
			throw new Error("Unable to find the Scope() in UI Grid");
		}
		var columns = scope.grid.columns;
		if (columns === undefined || columns === null) {
			throw new Error("UI Grid doesn't contain Column at index: " +intColumnIndex);
		}
		var visibleIndex = -1;
		// get the correct column index in backend
		var intCIndex = GetColumnIndexInBackEnd(scope, intColumnIndex);
		if (intCIndex !== -1) {
			return columns[intCIndex].uid;
		} else {
			console
					.log("UI grid extensibility GetUIGridColumnID error: column index is incorrect.")
		}
		return columns;
	} catch (e) {
		throw new Error("JavaScript Error:  " + e.message + "\n " + e.stack);
	}
}

function GetUIGridRowCount(element) {
	try {
		var scope = angular.element(element).scope();
		if (scope == undefined) {
			throw new Error("Unable to find the Scope() in UI Grid");
		}
		return scope.grid.getVisibleRowCount();
	} catch (e) {
		throw new Error("JavaScript Error:  " + e.message + "\n " + e.stack);
	}
}

function GetJQGridCellDataField(elementId, intRowIndex, intColumnIndex) {
	try {
		var dataField = angular.element('#' + elementId + '').jqxGrid(
				'getcolumnat', '' + intColumnIndex + '').datafield;
		return dataField;
	} catch (e) {
		throw new Error("JavaScript Error:  " + e.message + "\n " + e.stack);
	}
}

function GetJQGridCellvalue(elementId, intRowIndex, colDataField) {
	// @param index - the row's display index.
	try {
		var boundRowIndex = angular.element('#' + elementId + '').jqxGrid(
				'getrowboundindex', intRowIndex - 1);
		if (boundRowIndex === undefined || boundRowIndex === null) {
			throw new Error("Unable to find the Row Index in JQ Grid");
		}
		var value = angular.element('#' + elementId + '').jqxGrid(
				'getcelltext', '' + boundRowIndex + '', '' + colDataField + '');
		return value;
	} catch (e) {
		throw new Error("JavaScript Error:  " + e.message + "\n " + e.stack);
	}
}

function GetJQRowCount(elementId) {
	try {
		var count = angular.element('#' + elementId + '').jqxGrid('getrows').length;
		return count;
	} catch (e) {
		throw new Error("JavaScript Error:  " + e.message + "\n " + e.stack);
	}
}

function GetJQRowBoundIndex(elementId, row) {
	try {
		var boundRowIndex = angular.element('#' + elementId + '').jqxGrid(
				'getrowboundindex', row - 1);
		return boundRowIndex;
	} catch (e) {
		throw new Error("JavaScript Error:  " + e.message + "\n " + e.stack);
	}
}

// add to fix SUP #5090 ticket
function GetJQGridScrollToRow(elementId, rowId, row) {
	try {
		if (row > 0) {
			// For scrolling to a
			// row**************************************************
			var firstBoundRowIndex = angular.element('#' + elementId + '')
					.jqxGrid('getrowboundindex', 0);
			angular.element('#' + elementId + '').jqxGrid('unselectallrows');
			angular.element('#' + elementId + '')
					.jqxGrid('ensurerowvisible', 0);
			var rowHeight = angular.element('#' + rowId + '').height();
			var height = rowHeight * (row - 1);
			var gridHeight = angular.element('#' + elementId + '').height();
			var scrollCondition = gridHeight - rowHeight;
			var newRowId = rowId.split("jqxWidget")[0];
			var boundRowIndex = angular.element('#' + elementId + '').jqxGrid(
					'getrowboundindex', row - 1);

			newRowId = newRowId.split("row")[1];
			if (gridHeight > rowHeight) {
				if (height > scrollCondition) {
					// $('#' + elementId + '').jqxGrid('scrolloffset', height,
					// 0);
					angular.element('#' + elementId + '').jqxGrid(
							'ensurerowvisible', row - 1);
					newRowId = (gridHeight / rowHeight) - 1;

					angular.element('#' + elementId + '').jqxGrid('selectrow',
							boundRowIndex);
					return parseInt(newRowId);
				}
			}
			angular.element('#' + elementId + '').jqxGrid('ensurerowvisible',
					row - 1);
			angular.element('#' + elementId + '').jqxGrid('selectrow',
					boundRowIndex);
			// var row = angular.element('#' + elementId +
			// '').jqxGrid('getselectedrowindex');
			return parseInt(row - 1);
		}
	} catch (e) {
		throw new Error("JavaScript Error:  " + e.message + "\n " + e.stack);
	}
	/*
	 * var row = $('#' + elementId + '').jqxGrid('getselectedrowindex'); return
	 * parseInt(row);
	 */
}


/*
* We are not handing this js call in BAseJQGrid class,
* This call is being handled at Page Object Layer in 
 * Platform Tests
* @Anshul Chauhan
*/
function GetJQGridScrollToRowWithoutSelect(elementId, rowId, row) {
       try {
              if (row > 0) {
                     var firstBoundRowIndex = angular.element('#' + elementId + '')
                                  .jqxGrid('getrowboundindex', 0);
                     angular.element('#' + elementId + '').jqxGrid('unselectallrows');
                     angular.element('#' + elementId + '')
                                  .jqxGrid('ensurerowvisible', 0);
                     var rowHeight = angular.element('#' + rowId + '').height();
                     var height = rowHeight * (row - 1);
                     var gridHeight = angular.element('#' + elementId + '').height();
                     var scrollCondition = gridHeight - rowHeight;
                     var newRowId = rowId.split("jqxWidget")[0];
                     var boundRowIndex = angular.element('#' + elementId + '').jqxGrid(
                                  'getrowboundindex', row - 1);

                     newRowId = newRowId.split("row")[1];
                     if (gridHeight > rowHeight) {
                           if (height > scrollCondition) {
                                  angular.element('#' + elementId + '').jqxGrid(
                                                'ensurerowvisible', row - 1);
                                  newRowId = (gridHeight / rowHeight) - 1;

                                  return parseInt(newRowId);
                           }
                     }
                     angular.element('#' + elementId + '').jqxGrid('ensurerowvisible',
                                  row - 1);
                     return parseInt(row - 1);
              }
       } catch (e) {
              throw new Error("JavaScript Error:  " + e.message + "\n " + e.stack);
       }
}



function JQGridUnSelectRow(elementId) {
	try {
		var row = angular.element('#' + elementId + '').jqxGrid(
				'getselectedrowindex');
		if (parseInt(row) > -1)
			angular.element('#' + elementId + '').jqxGrid('unselectrow', row);
	} catch (e) {
		throw new Error("JavaScript Error:  " + e.message + "\n " + e.stack);
	}
}

function ISJQGridColumnResizable(elementId) {
	try {
		var resizable = angular.element('#' + elementId + '').jqxGrid(
				'columnsresize');
		if (resizable == true)
			return 1;
		else
			return 0;
	} catch (e) {
		throw new Error("JavaScript Error:  " + e.message + "\n " + e.stack);
	}
}

function JQGridColumnResize(elementId, intColumnIndex, offset) {
	try {
		var columnDataField = angular.element('#' + elementId + '').jqxGrid(
				'getcolumnat', '' + intColumnIndex + '').datafield;
		var currentWidth = angular.element('#' + elementId + '').jqxGrid(
				'getcolumnproperty', columnDataField, 'width');
		angular.element('#' + elementId + '').jqxGrid('setcolumnproperty',
				columnDataField, 'width', currentWidth + offset);
	} catch (e) {
		throw new Error("JavaScript Error:  " + e.message + "\n " + e.stack);
	}
}
