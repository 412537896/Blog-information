package com.kronos.element.interfaces.complex;

import java.util.List;

import com.kronos.element.interfaces.IBaseCommonElement;
import com.kronos.element.interfaces.IBaseElement;
import com.kronos.exception.KronosCoreUIException;

public interface IBaseGrid extends IBaseCommonElement{
	
	public IBaseElement getCell(int row, int column) throws KronosCoreUIException;
    public IBaseElement getCell(int row, String columnName) throws KronosCoreUIException;

    public IBaseElement getRow(int row) throws KronosCoreUIException;
    public String getRowText(int row) throws KronosCoreUIException;
    
    public int getRowNumber(String valueTofind, int column) throws KronosCoreUIException;
    public int getRowNumber(String valueTofind, String columnName) throws KronosCoreUIException;

    @Deprecated
    public IBaseElement getFirstRow() throws KronosCoreUIException;
    
    public int getColumnNumber(String columnName) throws KronosCoreUIException;
    public String getColumnName(int column) throws KronosCoreUIException;
    
    public boolean isColumnExist(String columnName) throws KronosCoreUIException;
    public boolean isColumnExist(int column) throws KronosCoreUIException;
	
    public int getRowCount() throws KronosCoreUIException;
	public int getColumnCount() throws KronosCoreUIException;

	public List<String> getHeader() throws KronosCoreUIException;
	
	public void waitForGridDataToLoad() throws KronosCoreUIException;
	public void resizeColumn(String columnName, int offset) throws KronosCoreUIException;	
	public void performColumnOperation(String columnName, String buttonLabel) throws KronosCoreUIException;
	public void unHideColumn(String columnName) throws KronosCoreUIException;
}
