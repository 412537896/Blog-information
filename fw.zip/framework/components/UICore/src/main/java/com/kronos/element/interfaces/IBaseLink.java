package com.kronos.element.interfaces;

public interface IBaseLink extends IBaseClick{
	
}
