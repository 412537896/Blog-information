package com.kronos.element.interfaces;

import com.kronos.exception.KronosCoreUIException;

public interface IBaseTextBox extends IBaseClick {
	
	public void setText(CharSequence... keysToSend) throws KronosCoreUIException;

	public void appendText(CharSequence... keysToSend) throws KronosCoreUIException;
	
	public void clear() throws KronosCoreUIException;

}
