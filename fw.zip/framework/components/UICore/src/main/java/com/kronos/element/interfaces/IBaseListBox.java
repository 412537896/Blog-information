package com.kronos.element.interfaces;

import java.util.List;

import com.kronos.exception.KronosCoreUIException;

public interface IBaseListBox extends IBaseSelect {

	public void selectMultipelOptions(List<?> values) throws KronosCoreUIException;

	public void selectRange(int startIndex, int endIndex) throws KronosCoreUIException;

	public List<?> getAllSelectedOptions() throws KronosCoreUIException;

	public boolean isMultiple() throws KronosCoreUIException;

	public void deSelectAll() throws KronosCoreUIException;
	
	public void selectAll() throws KronosCoreUIException;
}
