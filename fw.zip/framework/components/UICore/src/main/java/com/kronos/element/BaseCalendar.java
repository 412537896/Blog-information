package com.kronos.element;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.kronos.element.interfaces.IBaseElement;
import com.kronos.element.interfaces.complex.IBaseCalendar;
import com.kronos.exception.KronosCoreUIException;
import com.kronos.helpers.BasicPageSyncHelper;
import com.kronos.logging.KronosLogger;
import com.kronos.testng.Configurator;
import com.kronos.utils.KronosLocatorLoaderUtil;
import com.kronos.utils.KronosSeleniumUtil;

public class BaseCalendar extends BaseElement implements IBaseCalendar {

	final static Logger logger = Logger.getLogger(BaseCalendar.class);

	// right and left button to go backward and forward
	private static final String LEFT_BTN_SELECTOR = "//*[contains(@id, 'leftNavigationArrowView')]/div";
	private static final String RIGHT_BTN_SELECTOR = "//*[contains(@id, 'rightNavigationArrowView')]/div";

	private static final String CALENDAR_TITLE = "//div[contains(@class, 'calendar-title-content')]";
	private static final String YEARXPATH ="//tr[@id='calendarContent']//table[@role='grid']//td[@role='gridcell']";
	private static final String MONTHXPATH = "//tr[@id='calendarContent']//td[@role='gridcell' and contains(@class,'jqx-calendar-cell-year')]"; //"//td[@role='gridcell']"; 
	private static final String DAYXPATH = "//td[@role='gridcell'][contains(@class, 'jqx-calendar-cell-month')]";
	
	private static final String WAITELTXPATH = "//tr[@role='row']//td[text()='XXX']";
	private static final String WAITDAYXPATH = "//tr[@role='row']//td[text()='XX']";
	
	private static final String DATE_FORMAT = Configurator.getInstance().getParameter("dateFormat");
	private static final String[] MONTH_EN = new String[] { "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug",
			"Sep", "Oct", "Nov", "Dec" };

	private static final String[] DAY_NUM = new String[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11",
			"12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29",
			"30", "31" };

	private static final int TIMEOUT=3;
			
			
	public BaseCalendar(WebDriver driver, WebElement element, String locatorKey, String locator, String navigation) {
		super(driver, element, locatorKey, locator, navigation);
	}

	/**
	 * This method set Calendar date
	 * 
	 * @param date:java.util.Date
	 * @throws KronosCoreUIException
	 *             throw a KronosCoreUIException
	 */
	@Override
	public void setDate(Date date) throws KronosCoreUIException {
		KronosLogger.traceEnter();
		setDate(new SimpleDateFormat(DATE_FORMAT).format(date));
		KronosLogger.traceLeave();
	}

	/**
	 * This method set Calendar date
	 * 
	 * @param stringDate:String
	 * @param format of your choice:String 
	 * @throws KronosCoreUIException
	 *             throw a KronosCoreUIException
	 */
	
	@Override
	public void setDate(String stringDate, String format) throws KronosCoreUIException {
		KronosLogger.traceEnter();
		Calendar cal = Calendar.getInstance();
		
		// #SUP-6196
		List<WebElement> totalCal = element.findElements(By.xpath("." + CALENDAR_TITLE));
		
		WebDriverWait wait = new WebDriverWait(driver, TIMEOUT);
		wait.until(ExpectedConditions.visibilityOf(totalCal.get(totalCal.size()-1)));
		
		/*
		//if (getAttribute("id").isEmpty()) {
			waitForApplicationToLoad(CALENDAR_TITLE);
		} else {
			waitForApplicationToLoad(("//div[@id='" + getAttribute("id") + "']" + CALENDAR_TITLE));
		}
*/
		
		boolean validateFlag = true;
		try {
			logger.info("Input date is:" + stringDate);

			if (stringDate == null || "".equals(stringDate)) {
				logger.info("Input date is null.");
				validateFlag = false;
			} else {
				try {
				    cal.setTime(covertToDate(stringDate,format));
				} catch (Exception ex) {
					logger.info("Format input date error.", ex);
					validateFlag = false;
				}
			}
			// validate passed
			if (validateFlag) {
				setCalendarDate(cal);
			}
		} catch (Exception e) {
			String message = "Method of setDate(java.lang.String date) running failed.";
			logger.error(message, e);
		}
		KronosLogger.traceLeave();
	}
	
	
	/**
	 * This method set Calendar date(MM/dd/yyyy)
	 * 
	 * @param stringDate
	 *            String
	 * @throws KronosCoreUIException
	 *             throw a KronosCoreUIException
	 */
	@Override
	public void setDate(String stringDate) throws KronosCoreUIException {
		KronosLogger.traceEnter();
		Date dateFormat;
		Calendar cal = Calendar.getInstance();
					
		// #SUP-6196
		List<WebElement> totalCal = element.findElements(By.xpath("." + CALENDAR_TITLE));
		
		WebDriverWait wait = new WebDriverWait(driver, TIMEOUT);
		wait.until(ExpectedConditions.visibilityOf(totalCal.get(totalCal.size()-1)));

		boolean validateFlag = true;
		try {
			logger.info("Input date is:" + stringDate);

			if (stringDate == null || "".equals(stringDate)) {
				logger.info("Input date is null.");
				validateFlag = false;
			} else {
				try {
					dateFormat = covertToDate(stringDate,DATE_FORMAT);
				    cal.setTime(dateFormat);
				} catch (Exception ex) {
					logger.info("Format input date error.", ex);
					validateFlag = false;
				}
			}
			// validate passed
			if (validateFlag) {
				setCalendarDate(cal);
			}
		} catch (Exception e) {
			String message = "Method of setDate(java.lang.String date) running failed.";
			logger.error(message, e);
		}
		KronosLogger.traceLeave();
	}

	
	private void setCalendarDate(Calendar cal) throws KronosCoreUIException{

		int paraYear = cal.get(Calendar.YEAR);
	    int paraMonth = cal.get(Calendar.MONTH)+1;
	    int paraDay = cal.get(Calendar.DAY_OF_MONTH);
	    // Should firstly click the title
		findElement(By.xpath("." + CALENDAR_TITLE)).click();
		
		try {
			KronosSeleniumUtil.visibilityOfElementLocated(driver,
					KronosLocatorLoaderUtil.determineByType(WAITELTXPATH), TIMEOUT);
		}catch (Exception e) {
		}
		findElement(By.xpath("." + CALENDAR_TITLE)).click();
		try {
			KronosSeleniumUtil.visibilityOfElementLocated(driver,
					KronosLocatorLoaderUtil.determineByType(WAITELTXPATH), TIMEOUT);
		}catch (Exception e) {
		}
		// Get current year from the title, use the year to decide go
		// forward or backward
		String[] yearRange = findElement(By.xpath("." + CALENDAR_TITLE)).getText().split("-");

		int yearStartRange = Integer.parseInt(yearRange[0].trim());
		int yearEndRange = Integer.parseInt(yearRange[1].trim());
		
		while(!(paraYear >= yearStartRange && paraYear <= yearEndRange)){
			if (paraYear > yearEndRange) {
					this.findElement(By.xpath("." + RIGHT_BTN_SELECTOR)).click();
					try {
						KronosSeleniumUtil.visibilityOfElementLocated(driver,
								KronosLocatorLoaderUtil.determineByType(WAITELTXPATH), TIMEOUT);
					} catch (Exception e) {
					}
			} else if (paraYear < yearStartRange) {
					this.findElement(By.xpath("." + LEFT_BTN_SELECTOR)).click();
					try {
						KronosSeleniumUtil.visibilityOfElementLocated(driver,
								KronosLocatorLoaderUtil.determineByType(WAITELTXPATH), TIMEOUT);
					} catch (Exception e) {
					}
			}
			yearRange = findElement(By.xpath("." + CALENDAR_TITLE)).getText().split("-");
			yearStartRange = Integer.parseInt(yearRange[0].trim());
			yearEndRange = Integer.parseInt(yearRange[1].trim());
		}
		
		this.findElement(By.xpath("." + YEARXPATH + "[text()='" + paraYear + "']")).click();
		try {
			KronosSeleniumUtil.visibilityOfElementLocated(driver,
					KronosLocatorLoaderUtil.determineByType(WAITDAYXPATH), TIMEOUT);
		} catch (Exception ex) {
		}
	
		
		this.findElement(By.xpath("." + MONTHXPATH + "[text()='" + MONTH_EN[paraMonth - 1] + "']")).click();
		try {
			KronosSeleniumUtil.visibilityOfElementLocated(driver,
					KronosLocatorLoaderUtil.determineByType(WAITDAYXPATH), TIMEOUT);
		} catch (Exception ex) {
		}
		
		List<IBaseElement> dayElements = findElements(By.xpath("." + DAYXPATH));
		for (IBaseElement e : dayElements) {
			if (e != null && e.getText().equals(DAY_NUM[paraDay - 1])) {
				if (!e.getAttribute("class").contains("jqx-calendar-cell-othermonth")) {
					e.waitForDisplay();
					e.click();
					try {
						KronosSeleniumUtil.visibilityOfElementLocated(driver,
								KronosLocatorLoaderUtil.determineByType(WAITDAYXPATH), TIMEOUT);
					} catch (Exception ex) {
					}
					break;
				}
			}
		}
	}
	
	
	private Date covertToDate(String stringDate, String format) throws ParseException {
		Date dateFormat;
		dateFormat=new SimpleDateFormat(format).parse(stringDate);
		return dateFormat;
	}

	/**
	 * Wait until the visibility of given element locator is located on the
	 * page.
	 * 
	 * @param locator:String
	 * @throws KronosCoreUIException
	 *             throws a KronosCoreUIException
	 */
	private void waitForApplicationToLoad(String locator) throws KronosCoreUIException {
		BasicPageSyncHelper.waitForApplicationToLoad(driver, locator, TIMEOUT);
	}
}