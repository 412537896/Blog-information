package com.kronos.element.interfaces;

import com.kronos.exception.KronosCoreUIException;

public interface IBaseCheckBox extends IBaseCommonElement{
	// for check box
	public void setCheck(boolean check) throws KronosCoreUIException;
	
	public boolean isSelected() throws KronosCoreUIException;
}
