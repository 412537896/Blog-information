package com.kronos.testng;

import java.io.IOException;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.SessionId;
import org.openqa.selenium.remote.UnreachableBrowserException;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;

import com.kronos.assertion.SoftAssertion;
import com.kronos.enums.LaunchBrowserAtLevel;
import com.kronos.exception.KronosCoreCommonException;
import com.kronos.exception.KronosCoreUIException;
import com.kronos.factory.KronosUtilsFactory;
import com.kronos.logging.KronosLogger;
import com.kronos.report.StepStatus;
import com.kronos.utils.common.ContextConstant;
import com.saucelabs.saucerest.SauceREST;

public abstract class BaseUITest extends BaseTest {
	protected WebDriver driver;
	protected SoftAssertion assertion;
	private static boolean isBrowserInfoSet = false;
	private LaunchBrowserAtLevel browserAtLevel = LaunchBrowserAtLevel.TESTMETHOD;
	private boolean runWithSauceLab=false;
	static final Logger logger = Logger.getLogger(BaseUITest.class);

	@BeforeSuite(alwaysRun = true)
	public void beforeSuiteUI(ITestContext context) throws KronosCoreCommonException {
		Logger.getLogger("org.apache.http").setLevel(Level.ERROR);
	}



	/**
	 * Initialize variables before method test
	 * 
	 * @param m method
	 * @param context ITestContext
	 * @param testResult Describes the result of a test
	 * @throws KronosCoreCommonException throws a KronosCoreCommonException
	 * @throws Exception throw an Exception 
	 */

	@BeforeMethod(alwaysRun = true)
	public void beforeMethodUI(Method m, ITestContext context, ITestResult testResult) throws Exception {
		KronosLogger.traceEnter();
		try {
			if((browserAtLevel!=null && browserAtLevel.equals(LaunchBrowserAtLevel.TESTMETHOD)) || (browserAtLevel!=null) && (browserAtLevel.equals(LaunchBrowserAtLevel.TESTCLASS))){
				driver = KronosUtilsFactory.initWebDriver(context);
				driver.manage().window().maximize();
				driver.manage().timeouts().setScriptTimeout(Integer.parseInt(configurator.getParameter(ContextConstant.TIMEOUT)), TimeUnit.SECONDS);
				//navigate to application URL
				navigateToURL();
				assertion = new SoftAssertion(driver);
				//set the assertion that will be used by listener
				testResult.setAttribute("assertion", assertion);
				// Setup the browser information for only once. we cannot do it at
				// the suites level because there is no driver at that point
				// even this is in before class, it will only set up once.
				Capabilities cap = ((RemoteWebDriver) driver).getCapabilities();
				if (!isBrowserInfoSet) {
					String strSysInfo = "";

					strSysInfo = cap.getBrowserName().toLowerCase();
					logger.info("Browser: " + strSysInfo);
					reporter.addSystemInfo("browser", strSysInfo == null?"":strSysInfo);

					strSysInfo = cap.getVersion().toString();
					logger.info("Browser version: " + strSysInfo);
					reporter.addSystemInfo("browser version", strSysInfo == null?"":strSysInfo);

					strSysInfo = configurator.getParameter(ContextConstant.FRONTEND_SERVER);
					logger.info("Frontend Server: " + strSysInfo);
					reporter.addSystemInfo("Frontend Server", strSysInfo == null?"":strSysInfo);

					strSysInfo = configurator.getParameter(ContextConstant.TENANT);
					logger.info("Browser: " + strSysInfo);
					reporter.addSystemInfo("Tenant", strSysInfo == null?"":strSysInfo);

					isBrowserInfoSet = true;
				}
				runWithSauceLab=context.getCurrentXmlTest().getAllParameters().containsKey("runWithSauceLab") && context.getCurrentXmlTest().getAllParameters().get("runWithSauceLab").equalsIgnoreCase("True");
				
				if(browserAtLevel.equals(LaunchBrowserAtLevel.TESTCLASS)) {
					browserAtLevel=null;
				}
				if(runWithSauceLab)
					((JavascriptExecutor) driver).executeScript("sauce:job-name=" + m.getDeclaringClass().getName());
				
				
			}
			runWithSauceLab=context.getCurrentXmlTest().getAllParameters().containsKey("runWithSauceLab") && context.getCurrentXmlTest().getAllParameters().get("runWithSauceLab").equalsIgnoreCase("True");
			if(runWithSauceLab && browserAtLevel!=null){
				((JavascriptExecutor) driver).executeScript("sauce:job-name=" + m.getName());
			}

			// Initialize trackers object
			// ExtentReportConfigurator.getInstance().resetTrackerCollection(m.getName());
		}catch(KronosCoreCommonException e){
			throw e;
		}catch(UnreachableBrowserException e){
			String erroMsg="";
			if(context.getCurrentXmlTest().getAllParameters().containsKey("runWithSeleniumGrid") && context.getCurrentXmlTest().getAllParameters().get("runWithSeleniumGrid").equalsIgnoreCase("True"))
				erroMsg = "Selenium HUB is Down, Please make it available";
			else
				erroMsg = "Browser could not be instantiated";
			logger.error(erroMsg, e);
			reporter.reportStep(StepStatus.SKIPPED, erroMsg, e);
			throw new KronosCoreUIException(erroMsg, e);

		}catch(WebDriverException e){
			if(configurator.getParameter("runWithSeleniumGrid")==null || configurator.getParameter("runWithSeleniumGrid").equalsIgnoreCase("false")){
				String errorMsg = "Selenium WebDriver instance is not available";
				logger.error(errorMsg, e);
				reporter.reportStep(StepStatus.SKIPPED, errorMsg, e);
				throw new KronosCoreUIException(errorMsg, e);
			}else{
				String errorMsg = "WebDriver instance is not available";
				logger.error(errorMsg, e);
				reporter.reportStep(StepStatus.SKIPPED, errorMsg, e);
				throw new KronosCoreUIException(errorMsg, e); 
			}
		}
		catch (Exception e) {
			String erroMsg = "execute before test method fail";
			logger.error(erroMsg, e);
			reporter.reportStep(StepStatus.SKIPPED, "Intialize driver instance", e);
			throw new KronosCoreUIException(erroMsg, e);
		}catch (Throwable t) {
			logger.error("execute beforeTest method failed due to some Error", t);
			reporter.reportStep(StepStatus.SKIPPED, "Execute beforeTest method failed due to some Error", t);
			if(driver!=null) {
				driver.close();
				driver.quit();
			}
			throw new Error("execute beforeTest method failed due to some Error",t);
		}
		KronosLogger.traceLeave();
	}
	/**
	 * Close driver and quit driver after method test.
	 * 
	 * @param m Method
	 * @param result ITestResult
	 * @throws KronosCoreCommonException throws a KronosCoreCommonException
	 * @throws IOException 
	 */
	@AfterMethod(alwaysRun = true)
	public void afterMethodUI(Method m, ITestResult result) throws KronosCoreCommonException, IOException {
		KronosLogger.traceEnter();
		if(runWithSauceLab && !result.isSuccess()){
			embedSauceLabReportPage(m.getName());
		}

		//Fix : SUP-13137, 13141 : Removing the Browser console Log print in Extent report 
		/*
		 * Browser level logging primarily implemented to capture the
		 * javaScript exception for functions being used in Grid
		 * As now, we are using custom exception handling so this
		 * implementation is not required too.		
		 */
		/*try {
			//SUP-7961 Only add logs in case of chrome
			if (configurator.getParameter("browser").equalsIgnoreCase("chrome"))
			{
				LogEntries lgEntries=driver.manage().logs().get(LogType.BROWSER);
				for(LogEntry entry : lgEntries){
					reporter.reportStep(entry.getTimestamp()+":"+entry.getMessage()+" and level "+entry.getLevel());
				}
			}
		} catch (Exception e) {
			String erroMsg = "execute after test method failed";
			logger.error(erroMsg, e);
			throw new KronosCoreUIException(erroMsg, e);
		}finally {*/
		if(browserAtLevel !=null && browserAtLevel.equals(LaunchBrowserAtLevel.TESTMETHOD)){
			if(runWithSauceLab){
				((JavascriptExecutor) driver).executeScript("sauce:job-result=" + (result.isSuccess() ? "passed" : "failed"));
			}
			if(driver!=null) {
				/*SauceREST client = new SauceREST("FalconPOC","acc0234e-cac8-4d0a-8178-4da1f24a23fe");
					client.updateJobInfo(BaseJunitTest.sessionId, updates);*/
				//	((JavascriptExecutor) driver).executeScript("sauce:job-result=" + (result.isSuccess() ? "passed" : "failed"));
				/*if(publishSaucelabResult)
						((JavascriptExecutor) driver).executeScript("sauce:job-build=" + build);*/
				driver.close();
				driver.quit();
			}
		}
		/*}*/
		KronosLogger.traceLeave();

	}


	@AfterClass(alwaysRun = true)
	public void afterClassUI(ITestContext context) throws KronosCoreCommonException {
		KronosLogger.traceEnter();
		try {
			//browserAtLevel will be null when execution happens at class level
		} catch (Exception e) {
			String erroMsg = "execute after class failed";
			logger.error(erroMsg, e);
			throw new KronosCoreUIException(erroMsg, e);
		}finally {
			if(browserAtLevel ==null && driver!=null){
				if(runWithSauceLab){
					((JavascriptExecutor) driver).executeScript("sauce:job-result=" + (context.getFailedTests().size()==0 ? "passed" : "failed"));
				}
				driver.close();
				driver.quit();
			}
		}
		KronosLogger.traceLeave();
	}


	/**
	 * Navigate to application URL
	 */
	public void navigateToURL() {
		String url = executionContext.getFrontEndServer();
		String tenant = executionContext.getTenant();
		if(url.endsWith("/"))
			url = url.substring(0, url.length()-1);
		if (StringUtils.isNotBlank(tenant)) {
			url = url + "?tenantId=" + tenant;
		}
		driver.get(url);
		reporter.reportStep(StepStatus.INFO, "Navigate to URL- " + url);

	}


	/**
	 * setLaunchBrowserAtLevel set driver launch 
	 * @param browserAtLevel LaunchBrowserAtLevel ENUM
	 */
	public void setLaunchBrowserAtLevel(LaunchBrowserAtLevel browserAtLevel) {
		this.browserAtLevel=browserAtLevel;
	}
	
	public void embedSauceLabReportPage(String methodName) throws IOException{
		SauceREST rest = new SauceREST(KronosUtilsFactory.sauceAccount.getUsername(), KronosUtilsFactory.sauceAccount.getAccesskey());
		SessionId session = ((RemoteWebDriver)driver).getSessionId();
		String publicUrl = rest.getPublicJobLink(session.toString());
		String htmlTag = "Click <a href=\"" + publicUrl + "\" target=\"_blank\"><u>here</u></a> to access saucelab execution video";
		reporter.reportStep(htmlTag);
	}

	public String getActiveDate(){
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, 7);
		Date date = cal.getTime();
		SimpleDateFormat ft = new SimpleDateFormat("YYYY-MM-DD");
		String activeDate = null;
		try {
			activeDate = ft.format(date);
			return ":" + activeDate;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "";
	}
}
