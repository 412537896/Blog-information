package com.kronos.factory;

import java.lang.reflect.Field;

import org.apache.log4j.Logger;
import org.openqa.selenium.SearchContext;
import org.openqa.selenium.support.pagefactory.ElementLocator;
import org.openqa.selenium.support.pagefactory.ElementLocatorFactory;

import com.kronos.findbysImp.KronosDefaultElementLocator;
import com.kronos.logging.KronosLogger;

public class KronosDefaultElementLocatorFactory implements ElementLocatorFactory{
	private final SearchContext searchContext;
	private int timeout;
	final static Logger logger = Logger.getLogger(KronosDefaultElementLocatorFactory.class);
	/**
	 * Constructs a KronosDefaultElementLocatorFactory Object via searchContext and timeout 
	 * with the searchContext and timeout.
	 * 
	 * @param searchContext:SearchContext
	 * @param timeout:int
	 */
	public KronosDefaultElementLocatorFactory(SearchContext searchContext, int timeout) {
	    this.searchContext = searchContext;
	    this.timeout = timeout;
	}
	/**
	 * Create locator with field
	 * 
	 * @param field:Field
	 * @return ElementLocator
	 */
	public ElementLocator createLocator(Field field) {
		KronosLogger.traceEnter();
		ElementLocator elementLocator = new KronosDefaultElementLocator(searchContext, field, timeout);
		KronosLogger.traceLeave();
	    return elementLocator;
	}
}
