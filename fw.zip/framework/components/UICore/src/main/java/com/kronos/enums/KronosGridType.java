package com.kronos.enums;

public enum KronosGridType {
	JQGrid("BaseJQGrid"),
	UIGrid("BaseUIGrid"),
	Default("BaseJQGrid");
	
	String value;
	private KronosGridType(String value) {
		this.value = value;
	}
	
	public String getTypeName(){
		return this.value;
	}
}
