package com.kronos.element.interfaces;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.Rectangle;

import com.kronos.enums.LocatorType;
import com.kronos.exception.KronosCoreUIException;

public interface IBaseCommonElement {

	public Object executeScript(String javascriptToExecute, Object...  parameters) throws KronosCoreUIException;

	public String getText() throws KronosCoreUIException;

	public void hover() throws KronosCoreUIException;
	
	public void hover(int xOffset, int yOffset) throws KronosCoreUIException;
	
	public List<IBaseElement> findElements(By by) throws KronosCoreUIException;
	
	public List<IBaseElement> findElements(String locator, LocatorType type) throws KronosCoreUIException;

	public IBaseElement findElement(By by) throws KronosCoreUIException;

	public boolean isDisplayed() throws KronosCoreUIException;

	public Point getLocation() throws KronosCoreUIException;

	public Dimension getSize() throws KronosCoreUIException;

	public Rectangle getRect()throws KronosCoreUIException;

	public String getCssValue(String propertyName) throws KronosCoreUIException;
	
	public boolean isEnabled() throws KronosCoreUIException;

	public String getAttribute(String name)throws KronosCoreUIException;
	
	public String getTagName();
	
	public boolean isPresent();
	
	public void waitForEnable() throws KronosCoreUIException;
	
	public void waitForDisable() throws KronosCoreUIException;
	
	public void waitForDisplay() throws KronosCoreUIException;

	public void waitForDisappear() throws KronosCoreUIException;

	public void waitForClickable() throws KronosCoreUIException;

}
