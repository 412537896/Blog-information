package com.kronos.element.interfaces.complex;

import java.util.Date;

import com.kronos.element.interfaces.IBaseCommonElement;
import com.kronos.exception.KronosCoreUIException;

public interface IBaseCalendar extends IBaseCommonElement {
	/**
	 * Set Calendar date
	 * @param date Date
	 * @throws  KronosCoreUIException throw a KronosCoreUIException
	 */
	public void setDate(Date date) throws KronosCoreUIException;
	/**
	 * Set Calendar date
	 * @param date String	
	 * @throws  KronosCoreUIException throw a KronosCoreUIException
	 */
	public void setDate(String date) throws KronosCoreUIException;
	
	/**
	 * Set Calendar date
	 * @param date String	
	 * @param format String	
	 * @throws  KronosCoreUIException throw a KronosCoreUIException
	 */
	public void setDate(String date, String format) throws KronosCoreUIException;
}
