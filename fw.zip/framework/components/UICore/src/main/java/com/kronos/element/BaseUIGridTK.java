package com.kronos.element;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import com.kronos.element.interfaces.IBaseElement;
import com.kronos.element.interfaces.complex.IBaseGrid;
import com.kronos.enums.LocatorType;
import com.kronos.exception.KronosCoreUIException;
import com.kronos.logging.KronosLogger;
import com.kronos.utils.KronosGridUtil;

public class BaseUIGridTK extends BaseElement implements IBaseGrid {
	
	Logger logger = Logger.getLogger(BaseUIGridTK.class);
	private Boolean doScroll=true;
	private String requiredRowText = null;
	private WebElement requiredRowElement=null;
	private String XPATH_GRID_ROW;
	private int scrollHeightGrid=0;
	private int scrollHeightRow=0;
	private String gridId;
	private Map<String,String> headerColMapping = new LinkedHashMap<String,String>();
	private List<String> headerColumns;	

	public BaseUIGridTK(WebDriver driver, WebElement element, String locatorKey, String locator, String navigation) {
		super(driver, element, locatorKey, locator, navigation);
		String tempLoc = locator.split(":")[1].trim();
		if (!KronosGridUtil.getGridMap().containsKey(tempLoc))
			KronosGridUtil.generateGridId(driver, tempLoc, LocatorType.valueOf(locator.split(":")[0].trim()));
		this.gridId = KronosGridUtil.getGridId(tempLoc);
		this.headerColMapping = KronosGridUtil.getHeaderColMapping(tempLoc);
		XPATH_GRID_ROW = "//div[@class='ui-grid-contents-wrapper']/div[@id='" + gridId + "-grid-container']//div[@class='ui-grid-canvas']/div[contains(@class,'ui-grid-row')]";		
	}
	
	/**
	 * Get cell by given row index and column index.
	 * 
	 * @param row int
	 * @param column int
	 * @return IBaseElement of cell.
	 * @throws KronosCoreUIException throw KronosCoreUIException
	 */
	@Override
	public IBaseElement getCell(int row, int column) throws KronosCoreUIException {
		KronosLogger.traceEnter();
		int scrolledRow = 0;

		if (column <= 0 || column > getHeader().size()) {
			logger.error("Parameter error, column number: " + column);
			throw new KronosCoreUIException("Parameter error, column number: " + column
					+ " is greater than Grid columncount or less then Zero");
		}
		
		/* scrollToRow(row);
		String pageURL = driver.getCurrentUrl();
		if (pageURL.contains("myTimecard") || pageURL.contains("timekeeping#/timecard")) {
			scrollToRow(row);
		} else {
			scrollToRowRandomScroll(row);
		}
		*/
		int visibleRowCount = getVisibleRowCount();
		if(row>=visibleRowCount){
		scrollToRowRandomScroll(row);
		scrolledRow = makeRowVisible();
		} else{
			scrolledRow = row-1;
		}
		
		String cellId = gridId + "-" + scrolledRow + "-uiGrid-" + headerColMapping.get(headerColumns.get(column-1)) +"-cell";
		WebElement webElement = element.findElement(By.id(cellId));
		KronosLogger.traceLeave();
		return new BaseElement(driver, webElement, locatorKey, locator, navigation);
	}
	
	
	
	/**
     * Get the row count of ui-grid.
     * 
     * @return the row count of the grid you selected.
	 * @throws KronosCoreUIException 
     */
	private int getVisibleRowCount() throws KronosCoreUIException {
		
		WebElement canvas = element.findElements(By.className("ui-grid-canvas")).get(0);
		List<WebElement> visibleRowCount = canvas.findElements(By.xpath(XPATH_GRID_ROW));
		if  (visibleRowCount.size()==0)
			return -1;
		else
			return visibleRowCount.size();
	}

	/**
	 * Get cell by given row index and column name.
	 * 
	 * @param row int
	 * @param columnName String
	 * @return IBaseElement of cell.
	 * @throws KronosCoreUIException throw KronosCoreUIException
	 */
	@Override
	public IBaseElement getCell(int row, String columnName) throws KronosCoreUIException {
		KronosLogger.traceEnter();
		
		IBaseElement baseElement = null;
		if (isColumnExist(columnName)) {
			baseElement = getCell(row, getColumnNumber(columnName));
		}
		
		KronosLogger.traceLeave();
		return baseElement;
	}

	
	/**
	 * Get row by given row index.
	 * 
	 * @param row int
	 * @return IBaseElement of row.
	 * @throws KronosCoreUIException throw KronosCoreUIException
	 */
	@Override
	public IBaseElement getRow(int row) throws KronosCoreUIException {
		KronosLogger.traceEnter();
		scrollToRow(row);
		int scrolledRow= makeRowVisible();	
		List<WebElement> rows = null;
		rows = element.findElements(By.xpath(XPATH_GRID_ROW));		
		KronosLogger.traceLeave();
		return new BaseElement(driver, rows.get(scrolledRow),"getRow","",navigation);
	}
	
	
	/**
	 * Get row text by given row index.
	 * 
	 * @param row int
	 * @return String: IBaseGrid row text
	 * @throws KronosCoreUIException throw KronosCoreUIException
	 */
	@Override
	public String getRowText(int row) throws KronosCoreUIException {
		KronosLogger.traceEnter();
		String rowText="";
		scrollToRow(row);	
		makeRowVisible();
		rowText=requiredRowText.replaceAll("null", "");
		KronosLogger.traceLeave();
		return rowText;		
	}
	

	/**
	 * Get the first row's number which is in given columnNumber and it's value matches given valueToFind
	 * 
	 * @param valueToFind String
	 * @param columnNumber int
	 * @return The first row's number which matches the condition, -1 if not found.
	 * @throws KronosCoreUIException throw KronosCoreUIException
	 */
	@Override
	public int getRowNumber(String valueToFind, int columnNumber) throws KronosCoreUIException {
		KronosLogger.traceEnter();
		Boolean found = false;
		int index= -1;
		int i =0;
		if (!isColumnExist(columnNumber) || valueToFind == null) {
			logger.error("Parameter error, column number: " + columnNumber + ", valueToFind: " + valueToFind);
			throw new KronosCoreUIException("Parameter error, column number: " + columnNumber + ", valueToFind: " + valueToFind);
		}		
		String cellValue = null;
		int visibleRowCount = getVisibleRowCount();
		for (i = 0; i < visibleRowCount; i++) {
			try {
				String rowText = getRowTextAsString(i);
				cellValue = rowText.split("\\|\\|")[columnNumber-1];
				if (valueToFind.equals(cellValue)) {
					logger.info("Find " + valueToFind + " in column: " + columnNumber + "on row: " + i+1);
					index = i+1;
					found = true;
					break;
				}
			} catch (Exception e) {
				logger.error("Failed to get cell , row: " + i + ", column name: " + columnNumber, e);
				throw new KronosCoreUIException("Failed to get cell , row: " + i + ", column name: " + columnNumber, e);
			}
		}
		if (!found)
		{
			int rowCount = getRowCount();
			doScroll=false;
			while (i < rowCount) {
			try {
				scrollToNextRow(i);
					String rowText = getRowTextAsString(getNewRowIndex());
				cellValue = rowText.split("\\|\\|")[columnNumber-1];
				if (valueToFind.equals(cellValue)) {
					logger.info("Find " + valueToFind + " in column: " + columnNumber + "on row: " + i+1);
					index = i+1;
					found = true;
					break;
				}
				i++;
			} catch (Exception e) {
				logger.error("Failed to get cell , row: " + i + ", column name: " + columnNumber, e);
				throw new KronosCoreUIException("Failed to get cell , row: " + i + ", column name: " + columnNumber, e);
			}
		}
		doScroll = true;
		}
		if (!found)
			logger.info("Can't find " + valueToFind + " in column: " + columnNumber);
		KronosLogger.traceLeave();
		return index;
	}

	/**
	 * Get the first row's number which is in given columnName and it's value matches given valueToFind
	 * 
	 * @param valueToFind String
	 * @param columnName String
	 * @return The first row's number which matches the condition, -1 if not found.
	 * @throws KronosCoreUIException throw KronosCoreUIException
	 */
	@Override
	public int getRowNumber(String valueToFind, String columnName) throws KronosCoreUIException {
		KronosLogger.traceEnter();
		
		if (!isColumnExist(columnName) || valueToFind == null) {
			logger.error("Parameter error, column name: " + columnName + ", valueToFind: " + valueToFind);
			throw new KronosCoreUIException("Parameter error, column name: " + columnName + ", valueToFind: " + valueToFind);
		}
		int columnNumber = getColumnNumber(columnName);
		
		KronosLogger.traceLeave();
		return getRowNumber(valueToFind, columnNumber);
	}

	/**
	 * Get first row of grid.
	 * @deprecated
	 * @return IBaseElement of first row.
	 * @throws KronosCoreUIException throw KronosCoreUIException
	 */
	@Deprecated
	@Override
	public IBaseElement getFirstRow() throws KronosCoreUIException {
		return getRow(1);
	}

	/**
	 * Get column index by given column name.
	 * 
	 * @param columnName String
	 * @return Column index by given column name, -1 if not found.
	 * @throws KronosCoreUIException throw KronosCoreUIException
	 */
	@Override
	public int getColumnNumber(String columnName) throws KronosCoreUIException {
		List<String> header = getHeader();
		for(int i = 0; i < header.size(); i++) {
			if(header.get(i).equals(columnName)) {
				return i + 1;
			}
		}		
		return -1;
	}

	/**
	 * Get column name by given column index.
	 * 
	 * @param column int
	 * @return Column name by given column index.
	 * @throws KronosCoreUIException throw KronosCoreUIException
	 */
	@Override
	public String getColumnName(int column) throws KronosCoreUIException {
		List<String> columnNames = getHeader();
		if(!isColumnExist(column)) {
			logger.info("Parameter error, header size is: " + columnNames.size() + ", parameter is: " + column);
			throw new KronosCoreUIException("Parameter error, header size is: " + columnNames.size() + ", parameter is: " + column);
		}
		
		return columnNames.get(column - 1);
	}

	/**
	 * Check whether the column is exist.
	 * 
	 * @param columnName String
	 * @return <b>true</b> if column index exist, <b>false</b> if column index not exist.
	 * @throws KronosCoreUIException throw KronosCoreUIException
	 */
	@Override
	public boolean isColumnExist(String columnName) throws KronosCoreUIException {
		return getHeader().contains(columnName);
	}

	/**
	 * Check whether the column is exist.
	 * 
	 * @param column int
	 * @return <b>true</b> if column index exist, <b>false</b> if column index not exist.
	 * @throws KronosCoreUIException throw KronosCoreUIException
	 */
	@Override
	public boolean isColumnExist(int column) throws KronosCoreUIException {
		return (column > 0) && (column <= getHeader().size());
	}
	
	/**
	 * Get the column names of current grid table
	 * 
	 * @return The column names list of grid
	 * @throws KronosCoreUIException throws a  KronosCoreUIException
	 */
	@Override
	public List<String> getHeader() throws KronosCoreUIException {
		KronosLogger.traceEnter();

		if (headerColumns == null) {
			headerColumns = new ArrayList<>();
			for (String key : headerColMapping.keySet()) {
				headerColumns.add(key);
				}
		}
		logger.info("Get Column names: " + headerColumns);
		KronosLogger.traceLeave();
		return headerColumns;
	}
/**
	 * Scroll down to last row and get the total row count of grid.
	 * 
	 * @return Total row count of UIGrid
	 * @throws KronosCoreUIException throw a KronosCoreUIException
	 * @throws InterruptedException 
	 */
	@Override
	public int getRowCount() throws KronosCoreUIException {
		WebElement gridViewPort = element.findElements(By.className("ui-grid-viewport")).get(0);
		JavascriptExecutor js = (JavascriptExecutor) driver; 
		
		if (scrollHeightGrid==0)
			scrollHeightGrid = Integer.parseInt(gridViewPort.getAttribute("scrollHeight"));
		List<WebElement> rows = element.findElements(By.xpath(XPATH_GRID_ROW));
		if (rows.isEmpty())
			return 0;
		if (scrollHeightRow==0)
			scrollHeightRow = Integer.parseInt(rows.get(0).getAttribute("scrollHeight"));
		while (true)
		{
			scrollHeightGrid = Integer.parseInt(gridViewPort.getAttribute("scrollHeight"));
			String textContent = gridViewPort.getAttribute("textContent");
			js.executeScript("arguments[0].scrollTop=arguments[1];",gridViewPort,scrollHeightGrid);
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {// TODO Auto-generated catch block 
				}
			String newTextContent = gridViewPort.getAttribute("textContent");
			if (textContent.equals(newTextContent))
				break;
		}	
		js.executeScript("arguments[0].scrollTop=arguments[1];",gridViewPort,0);
		return scrollHeightGrid/scrollHeightRow;
	}


	private int getNewRowIndex() throws KronosCoreUIException
	{
		int index=0;
		int visibleRowCount = getVisibleRowCount();
		for (index=visibleRowCount-1; index>=0; index--)
		{	
			String text=getRowTextAsString(index);
			if(text.equals(requiredRowText))
				break;
			else
				text="";
		}
		return index;
		
	}
	
	private int makeRowVisible() throws KronosCoreUIException{
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", requiredRowElement);
		return getNewRowIndex();
	}
	
	private int scrollToNextRow(int row) throws KronosCoreUIException {

		int offsetHeight = 0;
		List<WebElement> gridCanvas = element.findElements(By.className("ui-grid-viewport"));
		List<WebElement> canvas, newLeftRows = null, newRightRows = null;
		JavascriptExecutor js = (JavascriptExecutor) driver;
		canvas = element.findElements(By.className("ui-grid-canvas"));
		String newText = "";
		String scrollTop = gridCanvas.get(0).getAttribute("scrollTop");
		if (scrollTop.contains("."))
			scrollTop = scrollTop.substring(0, scrollTop.indexOf("."));
		offsetHeight = Integer.parseInt(scrollTop) + scrollHeightRow;
		js.executeScript("arguments[0].scrollTop=arguments[1];", gridCanvas.get(0), offsetHeight);
		canvas = element.findElements(By.className("ui-grid-canvas"));
		newLeftRows = canvas.get(0).findElements(By.className("ui-grid-row"));
		newText = getRowTextAsString(newLeftRows.size() - 1);
		newRightRows = canvas.get(1).findElements(By.className("ui-grid-row"));
		requiredRowText = newText;
		return newRightRows.size() - 1;
	}
	
	private int scrollToRow(int row) throws KronosCoreUIException
	{
		requiredRowText = null;
		requiredRowElement = null;
		int offsetHeight=0;	
		int maxScroll = 1;
		List<WebElement> gridCanvas = element.findElements(By.className("ui-grid-viewport"));
		int allRowCount = getRowCount();
		List<WebElement> canvas,prevLeftRows,newLeftRows = null,newRightRows=null;
				
		if (row > allRowCount || row <=0) {
			logger.error("Parameter error, row number: " + row);
			throw new KronosCoreUIException("Parameter error, row number: " + row + " is greater than Grid rowcount or less than One");
		}
		
		JavascriptExecutor js = (JavascriptExecutor) driver; 
		if (doScroll){
			js.executeScript("arguments[0].scrollTop=arguments[1];",gridCanvas.get(0),offsetHeight);
			int visibleRowCount = getVisibleRowCount();			
			if ((visibleRowCount==allRowCount)||(row<=visibleRowCount))
			{
				requiredRowText=getRowTextAsString(row-1);
				requiredRowElement = element.findElements(By.xpath(XPATH_GRID_ROW)).get(row-1);			
				return row-1;
			}
			maxScroll = row-visibleRowCount;
		}
		
		canvas = element.findElements(By.className("ui-grid-canvas"));				
		int rowCount=0;
		String newText="";
		while (rowCount<maxScroll)
		{	
			newText="";
			String prevText="";
			canvas = element.findElements(By.className("ui-grid-canvas"));
			prevLeftRows = canvas.get(0).findElements(By.className("ui-grid-row"));
			prevText=getRowTextAsString(prevLeftRows.size()-1);
			String scrollTop = gridCanvas.get(0).getAttribute("scrollTop");
			if (scrollTop.contains("."))
				scrollTop = scrollTop.substring(0, scrollTop.indexOf("."));
			offsetHeight = Integer.parseInt(scrollTop) + scrollHeightRow;	
			js.executeScript("arguments[0].scrollTop=arguments[1];",gridCanvas.get(0),offsetHeight);	
			canvas = element.findElements(By.className("ui-grid-canvas"));
			newLeftRows = canvas.get(0).findElements(By.className("ui-grid-row"));
			newText = getRowTextAsString(newLeftRows.size()-1);		
			if (!prevText.equals(newText))
				rowCount++;	
			else
			{
				canvas = element.findElements(By.className("ui-grid-canvas"));
				newLeftRows = canvas.get(0).findElements(By.className("ui-grid-row"));
				newText = getRowTextAsString(newLeftRows.size()-1);	
				if (!prevText.equals(newText))
					rowCount++;	
				else
				{
					canvas = element.findElements(By.className("ui-grid-canvas"));
					String newScrollTop = gridCanvas.get(0).getAttribute("scrollTop");
					if (scrollTop.equals(newScrollTop))
					{
						logger.error("Failed to scroll further. Returning -1");
						return -1;
					}
				}
			}
		}
		
		newRightRows = canvas.get(1).findElements(By.className("ui-grid-row"));
		requiredRowElement = newRightRows.get(newRightRows.size()-1);
		requiredRowText = newText;
		return newRightRows.size()-1;
	}
	
	
	private int scrollToRowRandomScroll (int row) throws KronosCoreUIException
	{
		requiredRowText = null;
		requiredRowElement = null;
		int offsetHeight=0;	
		int maxScroll = 1;
		List<WebElement> gridCanvas = element.findElements(By.className("ui-grid-viewport"));
		int allRowCount = getRowCount();
		int visibleRowCount = getVisibleRowCount();
		List<WebElement> canvas,gridRows,newLeftRows = null,newRightRows=null;
				
		if (row > allRowCount || row <=0) {
			logger.error("Parameter error, row number: " + row);
			throw new KronosCoreUIException("Parameter error, row number: " + row + " is greater than Grid rowcount or less than One");
		}
		
		JavascriptExecutor js = (JavascriptExecutor) driver; 
		if (doScroll){
			js.executeScript("arguments[0].scrollTop=arguments[1];",gridCanvas.get(0),offsetHeight);
			
			if ((visibleRowCount==allRowCount)||(row<=visibleRowCount))
			{
				requiredRowText=getRowTextAsString(row-1);
				requiredRowElement = element.findElements(By.xpath(XPATH_GRID_ROW)).get(row-1);			
				return row-1;
			}
			maxScroll = row-visibleRowCount;
		}
		
		//canvas = element.findElements(By.className("ui-grid-canvas"));				
		int rowCount=0;
		int rowNum=0;
		canvas = element.findElements(By.className("ui-grid-canvas"));
		gridRows = canvas.get(0).findElements(By.xpath(XPATH_GRID_ROW));
		String prevText = getRowTextAsString(gridRows.size()-1);
		String newText = getRowTextAsString(gridRows.size()-1);
		
		while (rowCount<maxScroll)
		{	
			ArrayList<String> rowValues = new ArrayList<String>();
			String scrollTop = gridCanvas.get(0).getAttribute("scrollTop");
			if (scrollTop.contains("."))
				scrollTop = scrollTop.substring(0, scrollTop.indexOf("."));
			offsetHeight = Integer.parseInt(scrollTop) + scrollHeightRow;	
			js.executeScript("arguments[0].scrollTop=arguments[1];",gridCanvas.get(0),offsetHeight);	
			canvas = element.findElements(By.className("ui-grid-canvas"));
			newLeftRows = canvas.get(0).findElements(By.xpath(XPATH_GRID_ROW));

				for (int i=0; i<newLeftRows.size(); i++) {
					/*
					 * Inserting dummy text in arrayList to maintain the index 
					 * and avoid the processing of getRowTextAsString() as 
					 * it is time taking function and impacting the performance
					 * and we need only last 5 Values of row list
					*/
					if(i<(visibleRowCount-4)){
						rowValues.add("dummyValue");
					}else{
						rowValues.add(getRowTextAsString(i));
					}	
				}
				
				for (int i = rowValues.size()-1; i > 0; i--) {
					if(rowValues.get(i).equals(newText)){
						rowNum = i;
						if(rowNum!=(rowValues.size()-1)){
						newText = rowValues.get(rowNum+1);
						}
					}	
				}
		
				if(!prevText.equals(newText)){
					rowCount++;
				}
				
				String newScrollTop = gridCanvas.get(0).getAttribute("scrollTop");
				if (scrollTop.equals(newScrollTop))
				{
					logger.error("Failed to scroll further. Returning -1");
					return -1;
				}
		}
		
		newRightRows = canvas.get(1).findElements(By.xpath(XPATH_GRID_ROW));
		requiredRowElement = newRightRows.get(rowNum);
		requiredRowText = newText;
		return newRightRows.size()-1;
	}
	
	
	
	private String getRowTextAsString(int index) throws KronosCoreUIException
	{
		String text="<EMPTY>";
		JavascriptExecutor js = (JavascriptExecutor) driver; 
		try{
			for(String key : headerColMapping.keySet()){
			String cellId = gridId + "-" + (index) + "-uiGrid-" + headerColMapping.get(key) +"-cell";
			WebElement gridCell=element.findElement(By.id(cellId));
			String newContent = (String)js.executeScript("return arguments[0].textContent;", gridCell);
			if(text.equals("<EMPTY>"))
				text=newContent.trim();
			else
				text=text+ "||" +newContent.trim();
		}
		}catch (Exception e) {
			logger.error("Failed to get row content for row: " + index , e);
			throw new KronosCoreUIException("Failed to get row content for row: " + index, e);
		}
		return text;
	}
	
	
	/**
	 * Get columns count of UIGrid
	 * @return Columns count of UIGrid
	 * @throws KronosCoreUIException throw a KronosCoreUIException
	 */
	@Override
	public int getColumnCount() throws KronosCoreUIException {
		return getHeader().size();
	}
	
	/**
	 * wait until grid data is loaded. 
	 */
	public void waitForGridDataToLoad() throws KronosCoreUIException{
		getColumnCount();		
	}
	
	private String getUIGridColumnID(int colNumber)
	{
		return "ui-grid-header-cell ui-grid-clearfix ui-grid-coluiGrid-" + headerColMapping.get(headerColumns.get(colNumber-1));
	}
	/**
	 * resizeColumn of a grid
	 * @param columnName grid column name
	 * @param offset offset, can be negative also
	 * @return Columns count of UIGrid
	 * @throws KronosCoreUIException throw a KronosCoreUIException
	 */
	@Override
	public void resizeColumn(String columnName,int offset) throws KronosCoreUIException {
		KronosLogger.traceEnter();
		int columnNumber = getColumnNumber(columnName);
		/*if (columnNumber != -1) {
			List<IBaseElement> headersWebElement = this.findElements(By.xpath("//div[contains(@class,'ui-grid-column-resizer') and @position='right']"));
			IBaseElement resizeElement=null;
			
			for(int i=0;i<headersWebElement.size();i++){
				if(columnNumber-3==i){
					resizeElement=headersWebElement.get(i);
				}
			}
			if(resizeElement!=null)
				BasicPageElementHelper.drag(driver, ((BaseElement)resizeElement).getWrappedElement(),offset);
			else
				logger.error("Column: " + columnName + " is not resizable on the grid");
		 }else{
			logger.error("Column: " + columnName + " does not exist");
		}*/
        if (columnNumber != -1) {
            String id=getUIGridColumnID(columnNumber);
            try {
            	WebElement col=driver.findElement(By.xpath(".//div[contains(@class,'"+id+"')]"));
                WebElement resizeEle=col.findElement(By.xpath(".//div[contains(@class,'ui-grid-column-resizer') and @position='right']"));
                Actions builder = new Actions(driver);
                builder.clickAndHold(resizeEle).moveByOffset(offset, 0).release().build().perform();
                  
            } catch (Exception e) {
            	logger.error("Error while dragging the column "+e);
            }
            
       }else{
            logger.error("Column: " + columnName + " does not exist");
       }

		KronosLogger.traceLeave();
	}
	
	@Override
	/**
	 * this method will clear all grid filters.
	 * @param columnName Name of the column to work on
	 * @throws KronosCoreUIException throw a KronosCoreUIException
	 */
	public void unHideColumn(String columnName) throws KronosCoreUIException {
		KronosLogger.traceEnter();
		WebElement menuButton = driver.findElement(By.xpath(".//div[contains(@class,'ui-grid-menu-button')]"));
		menuButton.click();
		List<WebElement> menuList = menuButton.findElements(By.xpath(".//ul[contains(@class,'ui-grid-menu-items')]/li"));
		for (WebElement opt : menuList) {
			if (opt.getAttribute("automation-id").equalsIgnoreCase(columnName)) {
				opt.click();
				break;
			}
		}
		KronosLogger.traceLeave();
	}
	
	@Override
	/**
	 * this method will click the arrow besides the grid and then click on the label passed like Hide, Sort etc.
	 * @param columnName Name of the column to work on
	 * @param buttonLabel Name of the option to click, e.g. HideOption
	 * @throws KronosCoreUIException throw a KronosCoreUIException
	 */
	public void performColumnOperation(String columnName, String buttonLabel) throws KronosCoreUIException {
		KronosLogger.traceEnter();
		int columnNumber = getColumnNumber(columnName);

		if (columnNumber != -1) {
			String id = getUIGridColumnID(columnNumber - 1);
			try {
				WebElement col = driver.findElement(By.xpath("//div[contains(@class,'" + id + "')]"));
				WebElement menuButton = col.findElement(By.xpath(".//div[contains(@class,'ui-grid-column-menu-button')]"));
				menuButton.click();
				List<WebElement> menuList = driver.findElements(By.xpath("//ul[contains(@class,'ui-grid-menu-items')]/li"));
				for (WebElement opt : menuList) {
				
					if (opt.getAttribute("automation-id").equalsIgnoreCase(buttonLabel)) {
						opt.click();
						break;
					}
				}
			} catch (Exception e) {
				logger.error("Error while performing a column operation " + e);
			}

		} else {
			logger.error("Column: " + columnName + " does not exist");
		}

		KronosLogger.traceLeave();
	}
	
	
}
