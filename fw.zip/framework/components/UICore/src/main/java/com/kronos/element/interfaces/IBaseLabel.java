package com.kronos.element.interfaces;

public interface IBaseLabel extends IBaseCommonElement{

}
