package com.kronos.element;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.kronos.element.interfaces.IBaseElement;
import com.kronos.element.interfaces.complex.IBaseGrid;
import com.kronos.exception.KronosCoreUIException;
import com.kronos.helpers.BasicPageElementHelper;
import com.kronos.logging.KronosLogger;
import com.kronos.utils.KronosLocatorLoaderUtil;
import com.kronos.utils.KronosSeleniumUtil;


public class BaseUIGrid extends BaseElement implements IBaseGrid {
	
	Logger logger = Logger.getLogger(BaseUIGrid.class);
	
	private static final String rowSelector = "//div[@role=\"row\"]";
	private static final String columnSelector = "//div[@role=\"gridcell\"]";
	private static final int TIMEOUT = 5;

	private List<String> headerColumns;	
	private WebElement jsElement;
	private WebElement jsElementHeader;

	public BaseUIGrid(WebDriver driver, WebElement element, String locatorKey, String locator, String navigation) {
		super(driver, element, locatorKey, locator, navigation);
		jsElement = element.findElement(By.className("ui-grid-contents-wrapper"));
		//jsElement = element.findElement(By.xpath("//div[contains(@class, 'ui-grid-contents-wrapper')]"));
		
		
		jsElementHeader= element.findElement(By.className("ui-grid-header"));
		String jsPath = "javascript/gridScript.js";
		try {
			KronosSeleniumUtil.loadLocalJS(driver, jsPath);
		} catch (IOException e) {
			logger.error("Exception occured when load javascript: " + jsPath, e);
		}
	}
	
	/**
	 * Get cell by given row index and column index.
	 * 
	 * @param row int
	 * @param column int
	 * @return IBaseElement of cell.
	 * @throws KronosCoreUIException throw KronosCoreUIException
	 */
	@Override
	public IBaseElement getCell(int row, int column) throws KronosCoreUIException {
		KronosLogger.traceEnter();
		int rowcount;
		//IBaseElement element = null;
		rowcount = getVisibleRowCount();
		if(row>rowcount){
			rowcount = getRowCount();
		}
		
		if (jsElement == null ||  row<=0 || row > rowcount ) {
			logger.error("Parameter error,  row number: " + row);
			throw new KronosCoreUIException("Parameter error, row number: " + row + " is greater than Grid rowcount or less then Zero");
		}
		
		if (jsElement == null || column<=0 || column > getHeader().size()) {
			logger.error("Parameter error, column number: " + column);
			throw new KronosCoreUIException("Parameter error, column number: " +column+ " is greater than Grid columncount or less then Zero");
		}
		
		scrollToCell(row, 1);
		String script = "var row = angular.element(arguments[0]).scope().grid.rows[" + (row - 1) + "];"
				+ "return row.entity.uid || row.uid;";

		Object uid = KronosSeleniumUtil.executeScript(driver, script, jsElement);
		WebElement webElement = null;

		StringBuffer cellId = new StringBuffer();
		cellId.append(getUIGridColumnID(jsElement, (column - 1))).append("-cell");
		
		String cellXPath = "//div[contains(@id,'" + cellId.toString() + "')]";
		try {
			webElement = jsElement.findElement(By.xpath(".//div[contains(@data-uid, '" + uid + "')]" + cellXPath));
		} catch (NoSuchElementException e) {
			String jsScript = "var row = angular.element(arguments[0]).scope().grid.rows[" + (row - 1) + "];"
					+ "return row.grid.id;";
			Object id = KronosSeleniumUtil.executeScript(driver, jsScript, jsElement);
			webElement = jsElement.findElement(By.xpath(".//div[@id='" + id + "-" + (row - 1) + "-" + cellId + "']"));
		}
		//element = new BaseElement(driver, webElement, locatorKey, locator, navigation);
		KronosLogger.traceLeave();
		return new BaseElement(driver, webElement, locatorKey, locator, navigation);
	}
	
	
		
	
	/**
     * Function Name : getUIGridColumnID
     * Description : This method will get the column id of the grid's index column you selected.
     * 
     * Date of Creation:  3-Jun-2016 
     * Sample Call: getUIGridColumnID(grid,1)
     * @param grid: The grid you selected.
     * @param intColumnIndex: The column index of the grid you selected.
     * @return the column id of the grid's index column you selected.
     * @author CorbinJiang
     * @throws 
     */
	private  String getUIGridColumnID(WebElement jsElement, int intColumnIndex) {
		String script = "return GetUIGridColumnID(arguments[0], arguments[1]);";
		Object obj = KronosSeleniumUtil.executeScript(driver,script, jsElement,intColumnIndex);
		if (obj == null) {
			return null;
		}
		return obj.toString();
	}
	
	/**
     * Get the row count of ui-grid.
     * 
     * @return the row count of the grid you selected.
     */
	private int getVisibleRowCount() {
		String script = "return GetUIGridRowCount(arguments[0]);";
		Object obj = KronosSeleniumUtil.executeScript(driver, script, jsElement);
		if (obj == null) {
			return -1;
		}
		return (Integer.valueOf(obj.toString())).intValue();
	}

	/**
	 * Get cell by given row index and column name.
	 * 
	 * @param row int
	 * @param columnName String
	 * @return IBaseElement of cell.
	 * @throws KronosCoreUIException throw KronosCoreUIException
	 */
	@Override
	public IBaseElement getCell(int row, String columnName) throws KronosCoreUIException {
		KronosLogger.traceEnter();
		
		IBaseElement baseElement = null;
		if (isColumnExist(columnName)) {
			baseElement = getCell(row, getColumnNumber(columnName));
		}
		
		KronosLogger.traceLeave();
		return baseElement;
	}

	
	/**
	 * Get row by given row index.
	 * 
	 * @param row int
	 * @return IBaseElement of row.
	 * @throws KronosCoreUIException throw KronosCoreUIException
	 */
	@Override
	public IBaseElement getRow(int row) throws KronosCoreUIException {
		KronosLogger.traceEnter();
		int rowCount;
		rowCount = getVisibleRowCount();
		if(row>rowCount){
			rowCount = getRowCount();
		}
		
		if (jsElement == null || row > rowCount || row <0) {
			logger.error("Parameter error, row number: " + row);
			throw new KronosCoreUIException("Parameter error, row number: " + row + " is greater than Grid rowcount or less than Zero");
		}
		scrollToCell(row, 1);
		
		String script = "var row = angular.element(arguments[0]).scope().grid.rows[" + (row - 1) + "];"
				+ "return row.entity.uid;";
		
		Object entityUid = KronosSeleniumUtil.executeScript(driver, script, jsElement);
		
		 script = "var row = angular.element(arguments[0]).scope().grid.rows[" + (row - 1) + "];"
				+ "return row.uid;";
		
		Object uid = KronosSeleniumUtil.executeScript(driver, script, jsElement);
		List<WebElement> webElement = null;
		/*
		 * SUP-10218 : Fix for Delete and Add Row Handling. UID, returned form API is different 
		 * If you have performed any delete or Add operation in UI Grid 
		*/
		if(uid== null){
			String jsScript = "var row = angular.element(arguments[0]).scope().grid.rows[" + (row - 1) + "];"
					+ "return row.grid.id;";
			
			Object id = KronosSeleniumUtil.executeScript(driver, jsScript, jsElement);
			
			StringBuffer cellId = new StringBuffer();
			cellId.append(getUIGridColumnID(jsElement,(0))).append("-cell");
			webElement = jsElement.findElements(By.xpath(".//div[@id='" +id + "-" + (row-1) + "-" + cellId+ "']/ancestor::*[contains(@class,'ui-grid-row ng-scope')]")) ;	
		}else {
			webElement = jsElement.findElements(By.xpath("//div[contains(@data-uid, '" + entityUid + "')]")) ;
			if(webElement.size()==0){
				webElement = jsElement.findElements(By.xpath("//div[contains(@data-uid, '" + uid + "')]")) ;
			}
		} 
		KronosLogger.traceLeave();
		return new BaseElement(driver, webElement.get(0),"getRow","",navigation);
	}
	
	
	/**
	 * Get row text by given row index.
	 * 
	 * @param row int
	 * @return String: IBaseGrid row text
	 * @throws KronosCoreUIException throw KronosCoreUIException
	 */
	@Override
	public String getRowText(int row) throws KronosCoreUIException {
		KronosLogger.traceEnter();
		int rowCount;
		rowCount = getVisibleRowCount();
		if(row > rowCount){
			rowCount = getRowCount();
		}
		if (jsElement == null || row > rowCount || row <0) {
			logger.error("Parameter error, row number: " + row);
			throw new KronosCoreUIException("Parameter error, row number: " + row + " is greater than Grid rowcount  or less than Zero");
		}
		
		scrollToCell(row, 1);
		int columnCount=getColumnCount();
		String rowText="";
		
		for(int colIndex=1;colIndex<=columnCount;colIndex++){
			rowText = rowText + getCellValue(row, colIndex) + "||" ;
		}
		rowText=rowText.replaceAll("null", "");
		rowText = rowText.substring(0, rowText.lastIndexOf("||"));
		KronosLogger.traceLeave();
		return rowText;
		
	}
	

	/**
	 * Get the first row's number which is in given columnNumber and it's value matches given valueToFind
	 * 
	 * @param valueToFind String
	 * @param columnNumber int
	 * @return The first row's number which matches the condition, -1 if not found.
	 * @throws KronosCoreUIException throw KronosCoreUIException
	 */
	@Override
	public int getRowNumber(String valueToFind, int columnNumber) throws KronosCoreUIException {
		KronosLogger.traceEnter();
		
		if (!isColumnExist(columnNumber) || valueToFind == null) {
			logger.error("Parameter error, column number: " + columnNumber + ", valueToFind: " + valueToFind);
			throw new KronosCoreUIException("Parameter error, column number: " + columnNumber + ", valueToFind: " + valueToFind);
		}
		
		int rowCount = getRowCount();
		String cellValue = null;
		for (int i = 1; i <= rowCount; i++) {
			try {
				cellValue = getCellValue(i, columnNumber);
				if (valueToFind.equals(cellValue)) {
					logger.info("Find " + valueToFind + " in column: " + columnNumber + "on row: " + i);
					scrollToCell(i, 1);
					KronosLogger.traceLeave();
					return i;
				}
			} catch (Exception e) {
				logger.error("Failed to get cell , row: " + i + ", column name: " + columnNumber, e);
				throw new KronosCoreUIException("Failed to get cell , row: " + i + ", column name: " + columnNumber, e);
			}
		}
		
		logger.info("Can't find " + valueToFind + " in column: " + columnNumber);
		KronosLogger.traceLeave();
		return -1;
	}

	/**
	 * Get the first row's number which is in given columnName and it's value matches given valueToFind
	 * 
	 * @param valueToFind String
	 * @param columnName String
	 * @return The first row's number which matches the condition, -1 if not found.
	 * @throws KronosCoreUIException throw KronosCoreUIException
	 */
	@Override
	public int getRowNumber(String valueToFind, String columnName) throws KronosCoreUIException {
		KronosLogger.traceEnter();
		
		if (!isColumnExist(columnName) || valueToFind == null) {
			logger.error("Parameter error, column name: " + columnName + ", valueToFind: " + valueToFind);
			throw new KronosCoreUIException("Parameter error, column name: " + columnName + ", valueToFind: " + valueToFind);
		}
		int columnNumber = getColumnNumber(columnName);
		
		KronosLogger.traceLeave();
		return getRowNumber(valueToFind, columnNumber);
	}

	/**
	 * Get first row of grid.
	 * @deprecated
	 * @return IBaseElement of first row.
	 * @throws KronosCoreUIException throw KronosCoreUIException
	 */
	@Deprecated
	@Override
	public IBaseElement getFirstRow() throws KronosCoreUIException {
		return getRow(1);
	}

	/**
	 * Get column index by given column name.
	 * 
	 * @param columnName String
	 * @return Column index by given column name, -1 if not found.
	 * @throws KronosCoreUIException throw KronosCoreUIException
	 */
	@Override
	public int getColumnNumber(String columnName) throws KronosCoreUIException {
		List<String> header = getHeader();
		for(int i = 0; i < header.size(); i++) {
			if(header.get(i).equals(columnName)) {
				return i + 1;
			}
		}
		
		return -1;
	}

	/**
	 * Get column name by given column index.
	 * 
	 * @param column int
	 * @return Column name by given column index.
	 * @throws KronosCoreUIException throw KronosCoreUIException
	 */
	@Override
	public String getColumnName(int column) throws KronosCoreUIException {
		List<String> columnNames = getHeader();
		if(!isColumnExist(column)) {
			logger.info("Parameter error, header size is: " + columnNames.size() + ", parameter is: " + column);
			throw new KronosCoreUIException("Parameter error, header size is: " + columnNames.size() + ", parameter is: " + column);
		}
		
		return columnNames.get(column - 1);
	}

	/**
	 * Check whether the column is exist.
	 * 
	 * @param columnName String
	 * @return <b>true</b> if column index exist, <b>false</b> if column index not exist.
	 * @throws KronosCoreUIException throw KronosCoreUIException
	 */
	@Override
	public boolean isColumnExist(String columnName) throws KronosCoreUIException {
		return getHeader().contains(columnName);
	}

	/**
	 * Check whether the column is exist.
	 * 
	 * @param column int
	 * @return <b>true</b> if column index exist, <b>false</b> if column index not exist.
	 * @throws KronosCoreUIException throw KronosCoreUIException
	 */
	@Override
	public boolean isColumnExist(int column) throws KronosCoreUIException {
		return (column > 0) && (column <= getHeader().size());
	}
	
	/**
	 * Get the column names of current grid table
	 * 
	 * @return The column names list of grid
	 * @throws KronosCoreUIException throws a  KronosCoreUIException
	 */
	@Override
	public List<String> getHeader() throws KronosCoreUIException {
		KronosLogger.traceEnter();

		if (headerColumns == null) {
			headerColumns = new ArrayList<>();

			String script = "return GetUIGridColumnNames(arguments[0]);";
			Object obj = KronosSeleniumUtil.executeScript(driver, script, jsElementHeader);
			if (obj != null) {
				String[] columnNameStrs = obj.toString().split("\\|");
				headerColumns.addAll(Arrays.asList(columnNameStrs));
			}
		}

		logger.info("Get Column names: " + headerColumns);
		KronosLogger.traceLeave();
		return headerColumns;
	}
	
	/**
	 * Get the cell's string value
	 * 
	 * @param row int
	 * @param column int
	 * @return cell's string value
	 * @exception  KronosCoreUIException
	 */
	private String getCellValue(int row, int column) throws KronosCoreUIException {
		
		/*if (jsElement == null ||  row<=0 || row > getRowCount() ) {
			logger.error("Parameter error,  row number: " + row);
			throw new KronosCoreUIException("Parameter error, row number: " + row + " is greater than Grid rowcount or less then Zero");
		}*/
		
		if (jsElement == null || column<=0 || column > getHeader().size()) {
			logger.error("Parameter error, column number: " + column);
			throw new KronosCoreUIException("Parameter error, column number: " +column+ " is greater than Grid columncount or less then Zero");
		}
		
		String script = "return GetUIGridCellValue(arguments[0], arguments[1], arguments[2]);";
		Object obj = KronosSeleniumUtil.executeScript(driver, script, jsElement, row-1, column -1);
		if (obj == null) {
			return null;
		}
		return String.valueOf(obj);
	}
	
	/**
	 * Scroll down to last row and get the total row count of grid.
	 * 
	 * @return Total row count of UIGrid
	 * @throws KronosCoreUIException throw a KronosCoreUIException
	 */
	@Override
	public int getRowCount() throws KronosCoreUIException {
		int visibleRowCount = getVisibleRowCount();
		int oldVisibleRowCount = visibleRowCount;
		
		while (true) {
			scrollToCell(visibleRowCount, 1);
			
			/*
			 * Applies the check for 100 because API's getVisibleRowCount() returns rows in multiple of 100 
			 * If number of Rows in grid is more than 100. And Grid is taking time to get Load in DOM
			*/
			if (visibleRowCount >= 100) {
				try {
					KronosSeleniumUtil.visibilityOfElementLocated(driver,
							KronosLocatorLoaderUtil.determineByType("//div[@id=\"__element_not_exist__\"]"), TIMEOUT);
				} catch (Exception e) {
					// nothing to do
				}
			}

			visibleRowCount = getVisibleRowCount();
			if (visibleRowCount > oldVisibleRowCount) {
				oldVisibleRowCount = visibleRowCount;
			} else {
				scrollToCell(0, 1);
				return visibleRowCount;
			}
		}
	}
	
	/**
	 * Scroll grid to cell.
	 * @param row row index
	 * @param column column index
	 */
	private void scrollToCell(int row, int column) {
		String scrollTo = "var scope = angular.element(arguments[0]).scope();"
				+ "scope.grid.scrollTo(scope.uiGrid.data[arguments[1]],scope.uiGrid.columnDefs[arguments[2]]);";
		KronosSeleniumUtil.executeScript(driver, scrollTo, jsElement, row-1, column);
	}

	/**
	 * Get columns count of UIGrid
	 * @return Columns count of UIGrid
	 * @throws KronosCoreUIException throw a KronosCoreUIException
	 */
	@Override
	public int getColumnCount() throws KronosCoreUIException {
		return getHeader().size();
	}
	
/*	private List<WebElement> getElements(String str) {
		return element.findElements(By.xpath(str));
	}*/
	
	/**
	 * wait until grid data is loaded. 
	 */
	public void waitForGridDataToLoad() throws KronosCoreUIException{
		
		int visibleRowCount = 0;
		visibleRowCount= getVisibleRowCount();
		if (visibleRowCount!=0) 
			scrollToCell(visibleRowCount - 1, 1);
		
	}
	
	
	/**
	 * resizeColumn of a grid
	 * @param columnName grid column name
	 * @param offset offset, can be negative also
	 * @throws KronosCoreUIException throw a KronosCoreUIException
	 */
	@Override
	public void resizeColumn(String columnName,int offset) throws KronosCoreUIException {
		KronosLogger.traceEnter();
		int columnNumber = getColumnNumber(columnName);
		/*if (columnNumber != -1) {
			List<IBaseElement> headersWebElement = this.findElements(By.xpath("//div[contains(@class,'ui-grid-column-resizer') and @position='right']"));
			IBaseElement resizeElement=null;
			
			for(int i=0;i<headersWebElement.size();i++){
				if(columnNumber-3==i){
					resizeElement=headersWebElement.get(i);
				}
			}
			if(resizeElement!=null)
				BasicPageElementHelper.drag(driver, ((BaseElement)resizeElement).getWrappedElement(),offset);
			else
				logger.error("Column: " + columnName + " is not resizable on the grid");
		 }else{
			logger.error("Column: " + columnName + " does not exist");
		}*/
        if (columnNumber != -1) {
            String id=getUIGridColumnID(jsElement, columnNumber-1);
            try {
            	WebElement col=driver.findElement(By.xpath("//div[contains(@class,'"+id+"')]"));
                WebElement resizeEle=col.findElement(By.xpath(".//div[contains(@class,'ui-grid-column-resizer') and @position='right']"));
                Actions builder = new Actions(driver);
                builder.clickAndHold(resizeEle).moveByOffset(offset, 0).release().build().perform();
                  
            } catch (Exception e) {
            	logger.error("Error while dragging the column "+e);
            }
            
       }else{
            logger.error("Column: " + columnName + " does not exist");
       }

		KronosLogger.traceLeave();
	}
	
	@Override
	/**
	 * this method will click the arrow besides the grid and then click on the label passed like Hide, Sort etc.
	 * @param columnName Name of the column to work on
	 * @param buttonLabel Name of the option to click, e.g. HideOption
	 * @throws KronosCoreUIException throw a KronosCoreUIException
	 */
	public void performColumnOperation(String columnName, String buttonLabel) throws KronosCoreUIException {
		KronosLogger.traceEnter();
		int columnNumber = getColumnNumber(columnName);

		if (columnNumber != -1) {
			String id = getUIGridColumnID(jsElement, columnNumber - 1);
			try {
				WebElement col = driver.findElement(By.xpath("//div[contains(@class,'" + id + "')]"));
				WebElement menuButton = col.findElement(By.xpath(".//div[contains(@class,'ui-grid-column-menu-button')]"));
				menuButton.click();
				List<WebElement> menuList = driver.findElements(By.xpath("//ul[contains(@class,'ui-grid-menu-items')]/li"));
				for (WebElement opt : menuList) {
				
					if (opt.getAttribute("automation-id").equalsIgnoreCase(buttonLabel)) {
						opt.click();
						break;
					}
				}
			} catch (Exception e) {
				logger.error("Error while performing a column operation " + e);
			}

		} else {
			logger.error("Column: " + columnName + " does not exist");
		}

		KronosLogger.traceLeave();
	}
	
	@Override
	/**
	 * this method will clear all grid filters.
	 * @param columnName Name of the column to work on
	 * @throws KronosCoreUIException throw a KronosCoreUIException
	 */
	public void unHideColumn(String columnName) throws KronosCoreUIException {
		KronosLogger.traceEnter();
		WebElement menuButton = driver.findElement(By.xpath(".//div[contains(@class,'ui-grid-menu-button')]"));
		menuButton.click();
		List<WebElement> menuList = menuButton.findElements(By.xpath(".//ul[contains(@class,'ui-grid-menu-items')]/li"));
		for (WebElement opt : menuList) {
			if (opt.getAttribute("automation-id").equalsIgnoreCase(columnName)) {
				opt.click();
				break;
			}
		}
		KronosLogger.traceLeave();
	}
}
