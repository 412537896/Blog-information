/**
 * @date:Jul 18, 2016
 */
package com.kronos.element.interfaces.complex;

import java.util.List;

import com.kronos.element.interfaces.IBaseCommonElement;
import com.kronos.exception.KronosCoreUIException;

public interface IBaseNonStandardSelect extends IBaseCommonElement{

	/**
	 * Select the item at the given index.
	 * 
	 * @param index The item at this index will be selected and it should be greater than 0 
	 * @param elementLocator must be xPath or CSS that must to locate to the each item's label about the drop-down list
	 * @throws KronosCoreUIException
	 *             throw a KronosCoreUIException 
	 *             
	 * Samplecall_for_Xpath:selectItemByIndex(10,"//*[@id='combo-dropdown-menu']//ul//li")
	 * Samplecall_for_CSS :selectItemByIndex(10,"#combo-dropdown-menu ul li")
	 */
	public void selectItemByIndex(int index,String elementLocator) throws KronosCoreUIException;
	
	
	/**
	 * Select the item at the given Text.
	 * 
	 * @param text
	 *            The visible text to match against elementLocator(xpath or CSS) Must to locate to the
	 *            each item's label about the drop-down list
	 * @param elementLocator 
	 * @throws KronosCoreUIException
	 *             throw a KronosCoreUIException 
	 *             
	 * SampleCall_for_Xpath:selectItemByIndex("Adams, Kevin","//*[@id='combo-dropdown-menu']//ul//li")
	 * SampleCall_for_CSS :selectItemByIndex("Adams, Kevin","#combo-dropdown-menu ul li")
	 */
	public void selectByVisibleText(String text,String elementLocator) throws KronosCoreUIException;
	
	
	/**
	 * Get list of all li belonging to given select element
	 * 
	 * @param xpath
	 *            Must to locate to the each item's label about the drop-down
	 *            list
	 * @return All li belonging to this div tag
	 * @throws KronosCoreUIException
	 *             throw a KronosCoreUIException: While creation of div element
	 * SampleCall:
	 *             getAllItems("//*[@id='combo-dropdown-menu']/ul/li") or
	 *             getAllItems("//*[@class='ng-scope' and @ng-if='opts']/krn-slats-component/div/div")
	 */
	public List<?> getAllOptions(String xpath) throws KronosCoreUIException;

	
	/**
	 * Get list of all item innerText
	 * 
	 * @param xpath
	 *            Must to locate to the each item's label about the drop-down
	 *            list
	 * @return All item belonging to this div tag
	 * @throws KronosCoreUIException
	 *             throw a KronosCoreUIException: While creation of div element
	 * SampleCall:
	 *         getAllOptionValues("//*[@id='combo-dropdown-menu']/ul/li") 
	 *         getAllOptionValues("//*[@class='ng-scope' and @ng-if='opts']/krn-slats-component/div/div")
	 */
	public List<String> getAllOptionValues(String xpath) throws KronosCoreUIException;
	
	
	/**
	 * Get selected item
	 * 
	 * @param xpath
	 *            Must to locate to the each item's label about the drop-down
	 *            list
	 * @return the selected object
	 * @throws KronosCoreUIException
	 *             throw a KronosCoreUIException: While no item is selected
	 * SampleCall:
	 *             getSelectedObject("//*[@id='combo-dropdown-menu']/ul/li")
	 */
	public String getSelectedObject(String xpath) throws KronosCoreUIException;
		

}
