package com.kronos.element.interfaces;

import java.util.List;

import com.kronos.exception.KronosCoreUIException;

public interface IBaseSelect extends IBaseCommonElement {

	public void select(String value) throws KronosCoreUIException;

	public void select(int index) throws KronosCoreUIException;
	
	public void selectByVisibleText(String text) throws KronosCoreUIException;

	public void deselect(String value) throws KronosCoreUIException;

	public void deselect(int index) throws KronosCoreUIException;
	
	public void deselectByVisibleText(String text) throws KronosCoreUIException;
	
	public String getSelectedItemValue() throws KronosCoreUIException;

	public IBaseElement getSelectedItem() throws KronosCoreUIException;

	public List<?> getAllOptions() throws KronosCoreUIException;

	public int getSelectCount() throws KronosCoreUIException;
	
	public boolean isSelected() throws KronosCoreUIException;

}
