package com.kronos.basepageobject;

import java.io.File;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.kronos.element.BaseElement;
import com.kronos.enums.KronosLocateVia;
import com.kronos.enums.LocatorType;
import com.kronos.exception.KronosCoreUIException;
import com.kronos.factory.KronosBasePageFactory;
import com.kronos.helpers.BasicBrowserHelper;
import com.kronos.helpers.BasicPageElementHelper;
import com.kronos.helpers.BasicPageSyncHelper;
import com.kronos.logging.KronosLogger;
import com.kronos.report.Reporter;
import com.kronos.report.StepStatus;
import com.kronos.testng.Configurator;
import com.kronos.utils.KronosLocatorLoaderUtil;
import com.kronos.utils.KronosSeleniumUtil;
import com.kronos.utils.common.ContextConstant;
import com.paulhammant.ngwebdriver.WaitForAngularRequestsToFinish;

/**
 * @author yizhong.ji
 *
 */
public abstract class BasePage {
	protected WebDriver driver;
	protected Map<String, Properties> locatorMap;
	protected List<String> pageHierarchyList;
	protected Reporter reporter = Reporter.getInstance();
	static final Logger logger = Logger.getLogger(BasePage.class);
	private static final int TIMEOUT = Integer.parseInt(Configurator.getInstance().getParameter(ContextConstant.TIMEOUT));
	
	protected String windowHandle;
	// for logging purpose
	protected String navigation;
	
	
	/**
	 * Initializes page with the webDriver 
	 * 
	 * @param driver:WebDriver
	 * @throws KronosCoreUIException throws a KronosCoreUIException
	 */
	public BasePage(WebDriver driver) throws KronosCoreUIException {
		KronosLogger.traceEnter();
		try {
			this.driver = driver;
			// set main window handle
			windowHandle = BasicBrowserHelper.getCurrentWindowHandle(this.driver);

			// for logging purpose
			navigation = getNavigation(this.getClass(), "");
			KronosBasePageFactory.initPage(driver, this);
		} catch (Exception e) {
			String errorMsg = "init kronos page object failed with an exception: ";
			logger.error(errorMsg, e);
			throw new KronosCoreUIException(errorMsg, e);
		}
		KronosLogger.traceLeave();
	}

	public String getWindowHandle() {
		return windowHandle;
	}

	/**
	 * Initialize Element
	 * 
	 * @param locator:String
	 * @param methodName:KronosLocateVia
	 * @throws KronosCoreUIException throws a  KronosCoreUIException
	 * @return BaseElement
	 */
	public BaseElement initElement(String locator, KronosLocateVia methodName) throws KronosCoreUIException{
		KronosLogger.traceEnter();
		BaseElement baseElement = null;
		try {
			Method method = BasicPageElementHelper.class.getDeclaredMethod(methodName.getMethodName(),
					new Class[] { WebDriver.class, By.class, int.class });
			baseElement = new BaseElement(driver,
					(WebElement) method.invoke(null, driver, determineLocatorType(locator), TIMEOUT), locator,
					locator, navigation);
		} catch (Exception e) {
			String errorMsg = "init element failed witn an exception: ";
			logger.error(errorMsg, e);
			throw new KronosCoreUIException(errorMsg, e);
		}
		KronosLogger.traceLeave();
		return baseElement;
	}
	
	/**
	 * Initialize Element with timeout
	 * 
	 * @param locator:String
	 * @param methodName:KronosLocateVia
	 * @param timeout:int
	 * @throws KronosCoreUIException throws a  KronosCoreUIException
	 * @return BaseElement
	 */
	public BaseElement initElement(String locator, KronosLocateVia methodName, int timeout) throws KronosCoreUIException{
		KronosLogger.traceEnter();
		BaseElement baseElement = null;
		try {
			Method method = BasicPageElementHelper.class.getDeclaredMethod(methodName.getMethodName(),
					new Class[] { WebDriver.class, By.class, int.class });
			baseElement = new BaseElement(driver,
					(WebElement) method.invoke(null, driver, determineLocatorType(locator), timeout), locator,
					locator, navigation);
		} catch (Exception e) {
			String errorMsg = "init element failed witn an exception: ";
			logger.error(errorMsg, e);
			throw new KronosCoreUIException(errorMsg, e);
		}
		KronosLogger.traceLeave();
		return baseElement;
	}
	
	/**
	 * Initialize Element
	 * 
	 * @param locator:String
	 * @param type:LocatorType
	 * @param methodName:KronosLocateVia
	 * @return BaseElement
	 * @throws KronosCoreUIException throws a  KronosCoreUIException
	 */
	public BaseElement initElement(String locator, LocatorType type, KronosLocateVia methodName)
			throws KronosCoreUIException {
		KronosLogger.traceEnter();
		BaseElement baseElement = null;
		try {
			Method method = BasicPageElementHelper.class.getDeclaredMethod(methodName.getMethodName(),
					new Class[] { WebDriver.class, By.class, int.class });
			baseElement = new BaseElement(driver,
					(WebElement) method.invoke(null, driver, determineLocatorType(locator, type), TIMEOUT), locator,
					locator, navigation);
		} catch (Exception e) {
			String errorMsg = "initElement element failed with an exception: ";
			logger.error(errorMsg, e);
			throw new KronosCoreUIException(errorMsg, e);
		}

		return baseElement;
	}

	/**
	 * Initialize Element
	 * 
	 * @param locator:String
	 * @param type:LocatorType
	 * @param methodName:KronosLocateVia
	 * @param timeout:int
	 * @return BaseElement
	 * @throws KronosCoreUIException throws a  KronosCoreUIException
	 */
	public BaseElement initElement(String locator, LocatorType type, KronosLocateVia methodName, int timeout)
			throws KronosCoreUIException {
		KronosLogger.traceEnter();
		BaseElement baseElement = null;
		try {
			Method method = BasicPageElementHelper.class.getDeclaredMethod(methodName.getMethodName(),
					new Class[] { WebDriver.class, By.class, int.class });
			baseElement = new BaseElement(driver,
					(WebElement) method.invoke(null, driver, determineLocatorType(locator, type), timeout), locator,
					locator, navigation);
		} catch (Exception e) {
			String errorMsg = "initElement element failed with an exception: ";
			logger.error(errorMsg, e);
			throw new KronosCoreUIException(errorMsg, e);
		}

		return baseElement;
	}
	
	/**
	 * Initialize Elements
	 * 
	 * @param locator:String
	 * @param methodName:KronosLocateVia
	 * @throws KronosCoreUIException throws a  KronosCoreUIException
	 * @return BaseElement
	 */
	@SuppressWarnings("unchecked")
	public List<BaseElement> initElements(String locator, KronosLocateVia methodName) throws KronosCoreUIException{
		KronosLogger.traceEnter();
		List<BaseElement> baseElement = new ArrayList<BaseElement>();
		if(!KronosLocateVia.ByElementsPresent.getMethodName().equals(methodName.getMethodName())){
			throw new KronosCoreUIException("initElements does not support the KronosLocateVia " + methodName.getMethodName());
		}
		try {
			Method method = BasicPageElementHelper.class.getDeclaredMethod(methodName.getMethodName(),
					new Class[] { WebDriver.class, By.class, int.class });
			List<WebElement> temp = (List<WebElement>)method.invoke(null, driver, determineLocatorType(locator), TIMEOUT);
			for(WebElement e:temp){
				baseElement.add(new BaseElement(driver, e, locator, locator, navigation));
			}
		} catch (Exception e) {
			String errorMsg = "init elements failed witn an exception: ";
			logger.error(errorMsg, e);
			throw new KronosCoreUIException(errorMsg, e);
		}
		KronosLogger.traceLeave();
		return baseElement;
	}
	
	/**
	 * Initialize Elements with timeout
	 * 
	 * @param locator:String
	 * @param methodName:KronosLocateVia
	 * @param timeout:int
	 * @throws KronosCoreUIException throws a  KronosCoreUIException
	 * @return BaseElement
	 */
	@SuppressWarnings("unchecked")
	public List<BaseElement> initElements(String locator, KronosLocateVia methodName, int timeout) throws KronosCoreUIException{
		KronosLogger.traceEnter();
		List<BaseElement> baseElement = new ArrayList<BaseElement>();
		if(!KronosLocateVia.ByElementsPresent.getMethodName().equals(methodName.getMethodName())){
			throw new KronosCoreUIException("initElements does not support the KronosLocateVia " + methodName.getMethodName());
		}
		
		try {
			Method method = BasicPageElementHelper.class.getDeclaredMethod(methodName.getMethodName(),
					new Class[] { WebDriver.class, By.class, int.class });
			List<WebElement> temp = (List<WebElement>)method.invoke(null, driver, determineLocatorType(locator), timeout);
			for(WebElement e:temp){
				baseElement.add(new BaseElement(driver, e, locator, locator, navigation));
			}
		} catch (Exception e) {
			String errorMsg = "init elements failed witn an exception: ";
			logger.error(errorMsg, e);
			throw new KronosCoreUIException(errorMsg, e);
		}
		KronosLogger.traceLeave();
		return baseElement;
	}
	
	/**
	 * Initialize Elements
	 * 
	 * @param locator:String
	 * @param type:LocatorType
	 * @param methodName:KronosLocateVia
	 * @return BaseElement
	 * @throws KronosCoreUIException throws a  KronosCoreUIException
	 */
	@SuppressWarnings("unchecked")
	public List<BaseElement> initElements(String locator, LocatorType type, KronosLocateVia methodName)
			throws KronosCoreUIException {

		KronosLogger.traceEnter();
		List<BaseElement> baseElement = new ArrayList<BaseElement>();
		if(!KronosLocateVia.ByElementsPresent.getMethodName().equals(methodName.getMethodName())){
			throw new KronosCoreUIException("This method does not support the given method " + methodName.getMethodName());
		}
		try {
			Method method = BasicPageElementHelper.class.getDeclaredMethod(methodName.getMethodName(),
					new Class[] { WebDriver.class, By.class, int.class });
			List<WebElement> temp = (List<WebElement>) method.invoke(null, driver, determineLocatorType(locator,type), TIMEOUT);
			for(WebElement e:temp){
				baseElement.add(new BaseElement(driver, e, locator, locator, navigation));
			}
		} catch (Exception e) {
			String errorMsg = "initElement elements failed with an exception: ";
			logger.error(errorMsg, e);
			throw new KronosCoreUIException(errorMsg, e);
		}

		return baseElement;
	}

	/**
	 * Initialize Elements
	 * 
	 * @param locator:String
	 * @param type:LocatorType
	 * @param methodName:KronosLocateVia
	 * @param timeout:int
	 * @return BaseElement
	 * @throws KronosCoreUIException throws a  KronosCoreUIException
	 */
	@SuppressWarnings("unchecked")
	public List<BaseElement> initElements(String locator, LocatorType type, KronosLocateVia methodName, int timeout)
			throws KronosCoreUIException {

		KronosLogger.traceEnter();
		List<BaseElement> baseElement = new ArrayList<BaseElement>();
		if(!KronosLocateVia.ByElementsPresent.getMethodName().equals(methodName.getMethodName())){
			throw new KronosCoreUIException("This method does not support the given method " + methodName.getMethodName());
		}
		try {
			Method method = BasicPageElementHelper.class.getDeclaredMethod(methodName.getMethodName(),
					new Class[] { WebDriver.class, By.class, int.class });
			List<WebElement> temp = (List<WebElement>) method.invoke(null, driver, determineLocatorType(locator,type), timeout);
			for(WebElement e:temp){
				baseElement.add(new BaseElement(driver, e, locator, locator, navigation));
			}
		} catch (Exception e) {
			String errorMsg = "initElement elements failed with an exception: ";
			logger.error(errorMsg, e);
			throw new KronosCoreUIException(errorMsg, e);
		}

		return baseElement;
	}
	
	/**
	 * This public method for usage tracking
	 * 
	 * @param c:Class
	 * @param results:String
	 * @return String
	 */
	public String getNavigation(Class<?> c, String results) {
		if (c.getSuperclass() == null) {
			return "";
		}
		if (c.getSuperclass().getSimpleName().endsWith("BasePage")) {
			return c.getSimpleName();
		}
		results += getNavigation(c.getSuperclass(), results) + " -> " + c.getSimpleName();
		return results;
	}

	/**
	 * Go to new URL
	 * 
	 * @param url:String
	 * @throws KronosCoreUIException throws a  KronosCoreUIException
	 */
	public void goToPage(String url) throws KronosCoreUIException {
		driver.get(url);
		waitForPageToLoad();
	}

	public WebDriver getDriver() {
		return driver;
	}

	public String getNavigation() {
		return navigation;
	}

	/**
	 * To a new frame.
	 * 
	 * @param frame:String
	 * @throws KronosCoreUIException throws a  KronosCoreUIException
	 */
	public void switchToFrame(String frame) throws KronosCoreUIException {
		BasicPageSyncHelper.waitForFrameToLoadAndSwitch(driver, frame,TIMEOUT);

	}

	/**
	 * Switch to Default content.
	 */
	public void switchToDefault() {
		driver.switchTo().defaultContent();
	}
	
	/**
	 * Open new Window.
	 * @return an open window
	 * @throws KronosCoreUIException an exception of type KronosCoreUIException 
	 */
	public String openWindow() throws KronosCoreUIException {
		return BasicBrowserHelper.openWindow(driver);
	}
	
	/**
	 * Switch to the given Window/tab from the current page object.
	 * For example: page.switchToWindow(otherWindow)
	 * @param windowHandle:String
	 * @throws KronosCoreUIException an exception of type KronosCoreUIException  
	 */
	public void switchToWindow(String windowHandle) throws KronosCoreUIException {
		BasicBrowserHelper.switchToWindow(driver, windowHandle);
	}
	
	/**
	 * Switch to the Window/tab the current page object belongs to.
	 * For example: page.switchToWindow(otherWindow)
	 * @throws KronosCoreUIException an exception of type KronosCoreUIException   
	 */
	public void switchToWindow() throws KronosCoreUIException {
		BasicBrowserHelper.switchToWindow(driver, windowHandle);
	}
	
	/**
	 * Close Window/tab that the current page object belongs to.
	 * @throws KronosCoreUIException an exception of type KronosCoreUIException   
	 */
	public void closeWindow() throws KronosCoreUIException {
		BasicBrowserHelper.closeWindow(driver, windowHandle);
	}
	
	/**
	 * Wait on the page to be loaded based on the HTML Document state to set to
	 * be complete. Sometime this approach is not enough when Ajax calls are
	 * involved.
	 */
	public void waitForAngularRequestsToFinish() {
		String script = "var requestCount= angular.element(document.body).injector().get('$http').pendingRequests.length;"
				+ "return requestCount;";
		long angularRequestCount = (long) ((JavascriptExecutor) driver).executeScript(script);
		if (angularRequestCount != 0) {
			WaitForAngularRequestsToFinish.waitForAngularRequestsToFinish((JavascriptExecutor) driver);
		}
	}
	
	/**
	 * Wait until the visibility of new Browser Window.
	 * @param locator:Selenium Driver, TimeOut
	 * @throws KronosCoreUIException throws a  KronosCoreUIException
	 */
	public void waitForNewWindowToDisplay() throws KronosCoreUIException {
		BasicPageSyncHelper.waitForNewWindowToDisplay(driver, TIMEOUT);
	}
	
	/**
	 * Wait until the visibility of given element locator is located on the page.
	 * @param locator:String
	 * @throws KronosCoreUIException throws a  KronosCoreUIException
	 */
	public void waitForApplicationToLoad(String locator) throws KronosCoreUIException {
		BasicPageSyncHelper.waitForApplicationToLoad(driver, locator,TIMEOUT);
	}
	
	/**
	 * Wait until the the given locator element goes invisible on the page.
	 * @param locator:String
	 * @throws KronosCoreUIException throws a  KronosCoreUIException
	 */
	public void waitForContentToLoad(String locator) throws KronosCoreUIException {
		BasicPageSyncHelper.waitForContentToLoad(driver, locator,TIMEOUT);
	}
	
	/**
	 * Wait until the visibility of given element locator is located on the page.
	 * @param locator:String
 	 * @param timeout:int
	 * @throws KronosCoreUIException throws a  KronosCoreUIException
	 */
	public void waitForApplicationToLoad(String locator, int timeout) throws KronosCoreUIException {
		BasicPageSyncHelper.waitForApplicationToLoad(driver, locator,timeout);
	}
	
	/**
	 * Wait until the the given locator element goes invisible on the page.
	 * @param locator:String
	 * @param timeout:int
	 * @throws KronosCoreUIException throws a  KronosCoreUIException
	 */
	public void waitForContentToLoad(String locator, int timeout) throws KronosCoreUIException {
		BasicPageSyncHelper.waitForContentToLoad(driver, locator,timeout);
	}
	
	/**
	 * Wait on the page to be loaded based on the HTML Document state to set to
	 * be complete. Sometime this approach is not enough when Ajax calls are
	 * involved.
	 * 
	 * @throws KronosCoreUIException throw a KronosCoreUIException
	 */
	public void waitForPageToLoad() throws KronosCoreUIException {
		BasicPageSyncHelper.waitForPageToLoad(driver,TIMEOUT);
	}
	
	/**
	 * Get By object.
	 * 
	 * @param locator:String
	 * @return By
	 */
	private By determineLocatorType(String locator) {
		return KronosLocatorLoaderUtil.determineByType(locator);
	}
	
	/**
	 * Get By object.
	 * 
	 * @param locator:String
	 * @param type:LocatorType
	 * @return By
	 */
	private By determineLocatorType(String locator, LocatorType type) {
		return KronosLocatorLoaderUtil.determineByType(locator, type);
	}

	/**
	 * Highlight an element in the UI
	 * 
	 * @param element
	 *            The WebElement to highlight
	 * @throws KronosCoreUIException throws a  KronosCoreUIException           
	 */
	public void highlight(WebElement element) throws KronosCoreUIException {
		KronosLogger.traceEnter();
		try {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].setAttribute('style', arguments[1]);", element, "border: 2px solid red;");
		} catch (Exception e) {
			String errorMsg = "Highlight Animation fail";
			logger.error(errorMsg, e);
			reporter.deepReportStep(StepStatus.FAIL, errorMsg , BasicPageSyncHelper.saveAsScreenShot(driver), e);
			throw new KronosCoreUIException(errorMsg, e);

		}
		KronosLogger.traceLeave();

	}

	/**
	 * Take a screenshot of the current page
	 * @return a File contains screenshot
	 * @throws KronosCoreUIException throws a  KronosCoreUIException           
	 */
	public File takeScreenShot() throws KronosCoreUIException {
		return BasicPageSyncHelper.saveAsScreenShot(driver);
	}
	
	
      
}
