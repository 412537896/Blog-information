package com.kronos.enums;

public enum LocatorType {
	ID,
	XPATH,
	CSS,
	NAME,
	TAG_NAME,
	CLASS_NAME;
}
