package com.kronos.factory;

import java.io.Closeable;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.UnknownHostException;
import java.security.CodeSource;
import java.security.ProtectionDomain;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;
import java.util.logging.Level;
import java.util.zip.ZipEntry;
import java.util.zip.ZipException;
import java.util.zip.ZipFile;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerDriverService;
import org.openqa.selenium.logging.LogType;
import org.openqa.selenium.logging.LoggingPreferences;
import org.openqa.selenium.os.WindowsRegistryException;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.safari.SafariDriver;
import org.openqa.selenium.safari.SafariOptions;
import org.testng.ITestContext;

import com.kronos.exception.KronosCoreCommonException;
import com.kronos.exception.KronosCoreUIException;
import com.kronos.facade.DateGenerator;
import com.kronos.logging.KronosLogger;
import com.kronos.testng.Configurator;
import com.kronos.utils.KronosSauceAccount;

public class KronosUtilsFactory {
	static final Logger logger = Logger.getLogger(KronosUtilsFactory.class);
	static int closeAllIEInstance=0;
	static String accountType = "";
	public static KronosSauceAccount sauceAccount = new KronosSauceAccount();
	
		
	
	public static DateGenerator initDateCalculator(Map<String,String> params) {
		return new DateGenerator(params);
	}

	/**
	 * Initializes browser. IE , CHROME and Firefox(default)
	 * For Selenium grid Platform default Platform set is WINDOWS 
	 * The options available are - WINDOWS, Windows 8, Windows 10, Linux, Unix, MAC, Vista
	 * 
	 * @param context:ITestContext 
	 * @return WebDriver
	 * @throws KronosCoreCommonException throws a KronosCoreCommonException
	 * @throws Exception throw a Exception
	 */
	public static WebDriver initWebDriverLocal(ITestContext context) throws Exception{
		String platform = context.getCurrentXmlTest().getAllParameters().get("platform");
		boolean runWithSeleniumGrid = context.getCurrentXmlTest().getAllParameters().containsKey("runWithSeleniumGrid") && context.getCurrentXmlTest().getAllParameters().get("runWithSeleniumGrid").equalsIgnoreCase("True");

		String hubUrl = context.getCurrentXmlTest().getAllParameters().get("HUB_URL");		
		String os = System.getProperty("os.name", "generic").toLowerCase(Locale.ENGLISH);
		Platform env = getEnv(platform, os);

		if(context.getCurrentXmlTest().getAllParameters().containsKey("browser")){
			if(context.getCurrentXmlTest().getAllParameters().get("browser").equalsIgnoreCase("chrome")){
				setWebdriverSystemProperty("chrome");		
				DesiredCapabilities capabilities = DesiredCapabilities.chrome();
				LoggingPreferences logPrefs = new LoggingPreferences();
				logPrefs.enable(LogType.BROWSER, Level.ALL);
				capabilities.setCapability(ChromeOptions.CAPABILITY, setChromeOtions());
				capabilities.setCapability(CapabilityType.LOGGING_PREFS, logPrefs);					
				logger.info("Browser parameter is Chrome");

				if(runWithSeleniumGrid){							
					capabilities.setPlatform(env); 
					KronosLogger.traceLeave();
					return new RemoteWebDriver(new URL(hubUrl),capabilities);
				}else{
					KronosLogger.traceLeave();
					return new ChromeDriver(capabilities);
				}
			}else if (context.getCurrentXmlTest().getAllParameters().get("browser").equalsIgnoreCase("ie")){
				setWebdriverSystemProperty("ie");
				setRuntimeEnvForIE(os, runWithSeleniumGrid);
				// Setting for 32 bit driver
				InternetExplorerDriverService.Builder builder = new InternetExplorerDriverService.Builder();
				InternetExplorerDriverService service = builder.build();
				DesiredCapabilities caps = setIECapabilities();				

				logger.info("Browser parameter is IE");					
				if(runWithSeleniumGrid){							
					caps.setPlatform(env); 
					KronosLogger.traceLeave();
					RemoteWebDriver remoteDriver= new RemoteWebDriver(new URL(hubUrl),caps);

					return remoteDriver;
				}else{
					KronosLogger.traceLeave();
					return new InternetExplorerDriver(service,caps);

				}
			}else if (context.getCurrentXmlTest().getAllParameters().get("browser").equalsIgnoreCase("safari")) {
				SafariOptions options = new SafariOptions();
				options.setUseCleanSession(true);
				DesiredCapabilities capabilities = DesiredCapabilities.safari();
				capabilities.setCapability(SafariOptions.CAPABILITY, options);
				if(runWithSeleniumGrid){                                          
					capabilities.setPlatform(env); 
					KronosLogger.traceLeave();
					return new RemoteWebDriver(new URL(hubUrl),capabilities);
				}else{
					KronosLogger.traceLeave();
					return new SafariDriver(capabilities);
				}      
			}else if (context.getCurrentXmlTest().getAllParameters().get("browser").equalsIgnoreCase("edge")) {
				setWebdriverSystemProperty("edge");
				String cmdZoomAdd = "REG ADD \"HKEY_CURRENT_USER\\SOFTWARE\\Classes\\Local Settings\\Software\\Microsoft\\Windows\\CurrentVersion\\AppContainer\\Storage\\microsoft.microsoftedge_8wekyb3d8bbwe\\MicrosoftEdge\\Zoom\" /F /V \"ResetZoomOnStartup2\" /T REG_DWORD /D \"1\"";

				if (os.indexOf("win") >= 0){ // && osArch.indexOf("amd64")>=0) {
					try {
						Runtime.getRuntime().exec(cmdZoomAdd);
					}catch (Exception e) {
						String message = "Set registry for IE failed";
						logger.error(message , e);
						throw new KronosCoreUIException(message, e);
					}
				}

				EdgeOptions options = new EdgeOptions();
				options.setPageLoadStrategy("eager");

				DesiredCapabilities caps = setEdgeCapabilities();		

				logger.info("Browser parameter is Edge");					
				if(runWithSeleniumGrid){							
					caps.setPlatform(env); 
					KronosLogger.traceLeave();
					RemoteWebDriver remoteDriver= new RemoteWebDriver(new URL(hubUrl),caps);
					return remoteDriver;
				}else{
					KronosLogger.traceLeave();
					return new EdgeDriver(caps);
				}

			}else if ((context.getCurrentXmlTest().getAllParameters().get("browser").equalsIgnoreCase("headlessFirefox")) && ("LINUX".equalsIgnoreCase(env.name())))  {
				logger.info("Browser parameter is headlessFirefox");
				String xPort = System.getProperty("lmportal.xvfb.id", ":1");
				final File firefoxPath = new File(System.getProperty("lmportal.deploy.firefox.path", "/usr/bin/firefox"));
				FirefoxBinary firefoxBinary = new FirefoxBinary(firefoxPath);
				firefoxBinary.setEnvironmentProperty("DISPLAY", xPort);
				return new FirefoxDriver(firefoxBinary, null);
			}
			else{
				logger.info("Browser parameter is Firefox");
				DesiredCapabilities caps = DesiredCapabilities.firefox();
				FirefoxProfile profile = new FirefoxProfile();
				profile.setPreference("dom.disable_open_during_load", false);
				caps.setCapability(FirefoxDriver.PROFILE, profile);
				caps.setPlatform(env);
				if(runWithSeleniumGrid){							
					caps.setPlatform(env); 
					KronosLogger.traceLeave();
					return new RemoteWebDriver(new URL(hubUrl),caps);
				}else{
					KronosLogger.traceLeave();
					//return new FirefoxDriver(profile);
					return new FirefoxDriver(caps);
				}
			}
		}else{
			logger.info("Cannot find browser parameter, firefox will be used as default browser");
			DesiredCapabilities caps = DesiredCapabilities.firefox();
			FirefoxProfile profile = new FirefoxProfile();
			profile.setPreference("dom.disable_open_during_load", false);
			caps.setCapability(FirefoxDriver.PROFILE, profile);
			caps.setPlatform(env);
			if(runWithSeleniumGrid){							
				caps.setPlatform(env); 
				KronosLogger.traceLeave();
				return new RemoteWebDriver(new URL(hubUrl),caps);
			}else{
				KronosLogger.traceLeave();
				return new FirefoxDriver(caps);
			}
		}
	}
	/**
	 * Initializes browser. IE , CHROME and Firefox(default)
	 * For Selenium grid Platform default Platform set is WINDOWS 
	 * The options available are - WINDOWS, Windows 8, Windows 10, Linux, Unix, MAC, Vista
	 * 
	 * @param context:ITestContext 
	 * @return WebDriver
	 * @throws KronosCoreCommonException throws a KronosCoreCommonException
	 * @throws Exception throw a Exception
	 */
	public static WebDriver initWebDriver(ITestContext context) throws Exception{
		KronosLogger.traceEnter();
		boolean runWithSauceLab = context.getCurrentXmlTest().getAllParameters().containsKey("runWithSauceLab") && context.getCurrentXmlTest().getAllParameters().get("runWithSauceLab").equalsIgnoreCase("true");
		if(runWithSauceLab)
			return initWebDriverForSauceLab(context);
		else
			return initWebDriverLocal(context);
	}

	/**
	 * Initializes browser on saucelabs platform.
	 * User needs to provide platform, browser and browser version
	 * @param context:ITestContext 
	 * @return WebDriver
	 * @throws KronosCoreCommonException throws a KronosCoreCommonException
	 * @throws Exception throw a Exception
	 */
	public static WebDriver initWebDriverForSauceLab(ITestContext context) throws Exception{
		try {
			
			HashMap<String, String> browserVersionMap=new HashMap<String, String>();
			browserVersionMap.put("chrome", "64.0");
			browserVersionMap.put("ie", "11.0");
			browserVersionMap.put("firefox", "46.0");
			browserVersionMap.put("edge", "14");
			//browserVersionMap.put("safari", "11.0");
				
			
			String config = context.getCurrentXmlTest().getAllParameters().get("sauceparameters");
			//String accountType = context.getCurrentXmlTest().getAllParameters().containsKey("sl_account_type") && context.getCurrentXmlTest().getAllParameters().get("sl_account_type").equalsIgnoreCase("primary")?"primary":"";
			String extendedDebugging = context.getCurrentXmlTest().getAllParameters().containsKey("extendeddebugging") && context.getCurrentXmlTest().getAllParameters().get("extendeddebugging").equalsIgnoreCase("true")?"true":"false";
			String screenResolution = context.getCurrentXmlTest().getAllParameters().containsKey("screenresolution") && !"".equals(context.getCurrentXmlTest().getAllParameters().get("screenresolution"))?context.getCurrentXmlTest().getAllParameters().get("screenresolution"):"1024*768";
			
			if(context.getCurrentXmlTest().getAllParameters().containsKey("sl_account_type"))
				accountType= context.getCurrentXmlTest().getAllParameters().get("sl_account_type");
			else
				accountType= "";
			
			//String accountType = context.getCurrentXmlTest().getAllParameters().get("sl_account_type");
			DesiredCapabilities caps = null;
			
			String[] params , browserVersionArray ;
			String platform,browser, version;
			platform = "windows 10";
			browser="chrome";
			version = browserVersionMap.get(browser);
			
			if(StringUtils.isNotEmpty(config)) {
				params = config.split("-");
				platform = params[0].trim();
			//	browserVersionArray = params[1].split("-");
				browser=params[1].toLowerCase().trim();
				version = browserVersionMap.get(browser); //browserVersionArray[1];		
			}

			switch (browser) {
				case "chrome":
					caps = DesiredCapabilities.chrome();
					break;
				case "ie":
					caps = DesiredCapabilities.internetExplorer();
					break;
				case "firefox":
					caps = DesiredCapabilities.firefox();
					break;
				case "edge":
					caps = DesiredCapabilities.edge();
					break;
				default:
					caps = DesiredCapabilities.chrome();
					break;
			}
			caps.setCapability("platform", platform);
			caps.setCapability("version", version);
			caps.setCapability("idleTimeout",Integer.parseInt(context.getCurrentXmlTest().getAllParameters().get("timeout")));
			caps.setCapability("maxDuration", 3600);
			caps.setCapability("commandTimeout", Integer.parseInt(context.getCurrentXmlTest().getAllParameters().get("timeout")));
			String build = context.getCurrentXmlTest().getAllParameters().get("build");
			caps.setCapability("build",build );
			caps.setCapability("webdriverRemoteQuietExceptions", true);
			caps.setCapability("recordScreenshots", true);
			caps.setCapability("videoUploadOnPass", true);
			caps.setCapability("seleniumVersion", "2.53.0");
			caps.setCapability("extendedDebugging", extendedDebugging);
			String finalScreenResolution = screenResolution.replace('*', 'x');
			caps.setCapability("screenResolution", finalScreenResolution);
		
			switch (accountType) {
			case "guest":
				caps.setCapability("tunnelIdentifier", "guesttunnelpool");
				break;
			case "primary":
				caps.setCapability("tunnelIdentifier", "batunnelpool");
				break;
			default:
				caps.setCapability("tunnelIdentifier", "regtunnelpool");
				break;
			}
			
			TimeZone timeZone = TimeZone.getDefault();
			logger.info("TimeZone is: " + timeZone.getID());
			//String timezoneString=timeZone.getID().split("(")[0].trim();
			if(timeZone.getID().contains("/"))
				caps.setCapability("timeZone", timeZone.getID().split("/")[1].trim());
			else if(!timeZone.getID().trim().equalsIgnoreCase("UTC"))
				caps.setCapability("timeZone", timeZone.getID().trim());
			
			System.out.println("SAUCELABS BUILD NAME: " + build);
			logger.info("SAUCELABS BUILD NAME: " + build);
			return new RemoteWebDriver(new URL(getSaucelabsURL(accountType)),caps);
		}
		catch (Exception e) {
			String message = "Init webdriver for SauceLabs failed";
			logger.error(message , e);
			throw new KronosCoreUIException(message, e);
		}
	}

	/**
	 * Return env instance after setting its value 
	 * @param platform
	 * @param os
	 * @return Platform
	 */
	public static Platform getEnv(String platform, String os){
		Platform env = null;
		if(platform==null){
			if (os.indexOf("mac") >= 0) 
				env= Platform.MAC;
			else if(os.indexOf("win") >= 0) 
				env= Platform.WINDOWS;
			else if(os.indexOf("nux") >= 0) 
				env= Platform.LINUX;
		}else{
			if(platform!=null && platform.equalsIgnoreCase("Windows")){
				env= Platform.WINDOWS;
			}else if(platform!=null && platform.equalsIgnoreCase("Windows 7")){
				env= Platform.WINDOWS;
			}else if(platform!=null && platform.equalsIgnoreCase("Windows 8")){
				env= Platform.WIN8;
			}else if(platform!=null && platform.equalsIgnoreCase("Windows 10")){
				env= Platform.WIN10;
			}else if(platform!=null && platform.equalsIgnoreCase("MAC")){
				env= Platform.MAC;
			}else if(platform!=null && platform.equalsIgnoreCase("LINUX")){
				env= Platform.LINUX;
			}else if(platform!=null && platform.equalsIgnoreCase("UNIX")){
				env= Platform.UNIX;
			}else if(platform!=null && platform.equalsIgnoreCase("Vista")){
				env= Platform.VISTA;
			}
		}
		return env;
	}

	/**
	 * Set system properties for webdriver - chrome, ie, edge
	 * @param browser
	 * @throws Exception
	 */
	public static void setWebdriverSystemProperty(String browser) throws Exception{
		try {
			if(browser.equalsIgnoreCase("ie")){
				System.setProperty("webdriver.ie.driver", Configurator.getInstance().getDirectoryParameter("ie_driver"));
				URI driver=getDriver(Configurator.getInstance().getDirectoryParameter("ie_driver"));
				System.setProperty("webdriver.ie.driver", new File(driver).getAbsolutePath());
			}
			else if(browser.equalsIgnoreCase("chrome")){
				System.setProperty("webdriver.chrome.driver", Configurator.getInstance().getDirectoryParameter("chrome_driver"));
				URI driver=getDriver(Configurator.getInstance().getDirectoryParameter("chrome_driver"));
				System.setProperty("webdriver.chrome.driver",new File(driver).getAbsolutePath());
			}
			else if(browser.equalsIgnoreCase("edge")){
				System.setProperty("webdriver.edge.driver", Configurator.getInstance().getDirectoryParameter("edge_driver"));
				URI driver=getDriver(Configurator.getInstance().getDirectoryParameter("edge_driver"));
				System.setProperty("webdriver.edge.driver", new File(driver).getAbsolutePath());
			}
		}catch(Exception e){
			if(e instanceof KronosCoreCommonException)
				throw e;
			String message = "Get Webdriver Failed :";
			logger.error(message , e);
			throw new KronosCoreUIException(message, e);
		}		
	}

	/**
	 * Set chrome browser options
	 * @return ChromeOptions
	 */
	public static ChromeOptions setChromeOtions(){
		ChromeOptions options = new ChromeOptions();
		Map<String, Object> prefs = new HashMap<String, Object>();
		prefs.put("credentials_enable_service", false);
		prefs.put("profile.password_manager_enabled", false);
		prefs.put("profile.default_content_settings.popups", 0);
		options.setExperimentalOption("prefs", prefs);

		options.addArguments("test-type");
		options.addArguments("--disable-popup-blocking");
		options.addArguments("disable-infobars");
		options.addArguments("--allow-cross-origin-auth-prompt");

		return options;
	}

	/**
	 * Set runtime env before running IE instance
	 * @param os
	 * @param runWithSeleniumGrid
	 * @throws Exception
	 */
	public static void setRuntimeEnvForIE(String os, boolean runWithSeleniumGrid) throws Exception{
		String osArch=System.getProperty("os.arch");
		String cmd64Bit = "REG ADD \"HKEY_LOCAL_MACHINE\\SOFTWARE\\Wow6432Node\\Microsoft\\Internet Explorer\\Main\\FeatureControl\\FEATURE_BFCACHE\" /F /V \"iexplore.exe\" /T REG_DWORD /D 0";
		String cmd32Bit = "REG ADD \"HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Internet Explorer\\Main\\FeatureControl\\FEATURE_BFCACHE\" /F /V \"iexplore.exe\" /T REG_DWORD /D 0";
		String cmdPopUp64Bit = "REG ADD \"HKEY_CURRENT_USER\\Software\\Wow6432Node\\Microsoft\\Internet Explorer\\New Windows\" /F /V \"PopupMgr\" /T REG_SZ /D \"no\"";
		String cmdPopUp32Bit = "REG ADD \"HKEY_CURRENT_USER\\Software\\Microsoft\\Internet Explorer\\New Windows\" /F /V \"PopupMgr\" /T REG_SZ /D \"no\"";

		String cmdZoomDelete = "REG DELETE \"HKEY_CURRENT_USER\\Software\\Microsoft\\Internet Explorer\\Zoom\" /F /V \"ZoomFactor\" /T REG_DWORD /D \"100000\"";
		String cmdZoomAdd = "REG ADD \"HKEY_CURRENT_USER\\Software\\Microsoft\\Internet Explorer\\Zoom\" /F /V \"ZoomFactor\" /T REG_DWORD /D \"100000\"";
		String cmdUncheckRecovery = "REG ADD \"HKEY_CURRENT_USER\\Software\\Microsoft\\Internet Explorer\\Recovery\" /F /V \"AutoRecover\" /T REG_DWORD /D \"00000002\"";

		String cmdTab = "REG ADD \"HKEY_CURRENT_USER\\Software\\Microsoft\\Internet Explorer\\Main\" /F /V \"TabProcGrowth\" /T REG_SZ /D \"1\"";

		if (os.indexOf("win") >= 0){ // && osArch.indexOf("amd64")>=0) {
			try {
				Runtime.getRuntime().exec(cmdZoomDelete);
				Runtime.getRuntime().exec(cmd64Bit);
				Runtime.getRuntime().exec(cmd32Bit);
				Runtime.getRuntime().exec(cmdPopUp64Bit);
				Runtime.getRuntime().exec(cmdPopUp32Bit);
				Runtime.getRuntime().exec(cmdUncheckRecovery);
				Runtime.getRuntime().exec(cmdZoomAdd);
			}catch (Exception e) {
				String message = "Set registry for IE failed";
				logger.error(message , e);
				throw new KronosCoreUIException(message, e);
			}

			String taskkillIEDriver = null;
			String taskkillIE =null;

			if(!runWithSeleniumGrid){
				try {
					InetAddress ipAddr = InetAddress.getLocalHost();
					taskkillIEDriver = "taskkill /S " + ipAddr.getHostAddress() + " /U KRONOSENG\\superuser /P kronites /F /IM IEDriverServer_32.exe" ;
					taskkillIE = "taskkill /S " + ipAddr.getHostAddress() + " /U KRONOSENG\\superuser /P kronites /F /IM iexplore.exe" ;

				} catch (UnknownHostException ex) {
					ex.printStackTrace();
				}

				//	synchronized (KronosUtilsFactory.class) {
				try{
					if(closeAllIEInstance==0)
						Runtime.getRuntime().exec(taskkillIEDriver);
				}catch (WindowsRegistryException e) {
					logger.info("All open instances of IEDriver closed on test client before starting the execution on IE");
				}
				try{
					if(closeAllIEInstance==0)
						Runtime.getRuntime().exec(taskkillIE);
				}catch (WindowsRegistryException e) {
					logger.info("All open instances of IE browser closed on test client before starting the execution on IE");
				}

				closeAllIEInstance++;
			}
			//}

		}
	}

	/**
	 * Set desired capabilities for IE
	 * @return DesiredCapabilities
	 */
	public static DesiredCapabilities setIECapabilities(){
		DesiredCapabilities caps = DesiredCapabilities.internetExplorer();
		caps.setCapability(InternetExplorerDriver.ENABLE_ELEMENT_CACHE_CLEANUP, false);
		caps.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
		caps.setCapability(CapabilityType.SUPPORTS_ALERTS, true); //uncommneted
		caps.setCapability("ignoreProtectedModeSettings", true);
		caps.setCapability(InternetExplorerDriver.NATIVE_EVENTS, true);
		caps.setCapability("disable-popup-blocking",true);
		caps.setCapability("unexpectedAlertBehaviour","ignore");
		caps.setCapability(InternetExplorerDriver.ENABLE_PERSISTENT_HOVERING, false);
		caps.setCapability("enableFullPageScreenshot", false); //Changed from true to false
		caps.setCapability(CapabilityType.TAKES_SCREENSHOT,"true" );
		caps.setCapability("ignoreZoomSetting", true);
		caps.setCapability(CapabilityType.SUPPORTS_FINDING_BY_CSS, true);
		caps.setCapability(CapabilityType.SUPPORTS_LOCATION_CONTEXT, true);
		caps.setCapability(InternetExplorerDriver.IE_ENSURE_CLEAN_SESSION, true);
		caps.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		// newly added
		caps.setCapability("screenResolution", "1386*768");
		return caps;
	}

	/**
	 * Set desired capabilities for Edge
	 * @return DesiredCapabilities
	 */
	public static DesiredCapabilities setEdgeCapabilities(){
		DesiredCapabilities caps = DesiredCapabilities.edge();

		/*LoggingPreferences logPrefs = new LoggingPreferences();
	        logPrefs.enable(LogType.BROWSER, Level.ALL);*/
		caps.setJavascriptEnabled(true);
		//  caps.setCapability(CapabilityType.LOGGING_PREFS, logPrefs);
		caps.setBrowserName("MicrosoftEdge");
		caps.setPlatform(Platform.WIN10);
		caps.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);

		caps.setCapability("disable-popup-blocking",true);
		caps.setCapability("unexpectedAlertBehaviour","ignore");
		caps.setCapability(CapabilityType.SUPPORTS_FINDING_BY_CSS, true);
		caps.setCapability(CapabilityType.SUPPORTS_LOCATION_CONTEXT, true);			
		return caps;
	}

	/**
	 * Form saucelabs URL
	 * @return String
	 */
	public static String getSaucelabsURL(String accountType){
		switch (accountType) {
		case "primary":
			sauceAccount.setUsername("ba_user");
			sauceAccount.setAccesskey("41222158-9d72-42f2-8c8a-94149c8c1a65");
			break;
		case "guest":
			sauceAccount.setUsername("guest_user");
			sauceAccount.setAccesskey("562ba524-caec-45a8-8c97-b3a7716a90cc");
			break;
		default:
			sauceAccount.setUsername("reg_user");
			sauceAccount.setAccesskey("6dab627d-49b4-4e00-b055-de1188c46128");
			break;
		}
		return "https://" + sauceAccount.getUsername() + ":" + sauceAccount.getAccesskey() + "@ondemand.saucelabs.com:443/wd/hub";
	}

	/**
	 * Get the driver from the jar file. IE , CHROME and Firefox(default)
	 * 
	 * @param driverPath:String
	 * @return URI
	 * @throws URISyntaxException throw an URISyntaxException
	 * @throws ZipException throw a ZipException
	 * @throws IOException throw an IOException
	 */
	public static  URI getDriver(String driverPath) throws URISyntaxException, ZipException, IOException
	{
		final URI uri;
		final URI exe;

		uri = getJarURI();
		exe = getFile(uri, driverPath);
		return exe;
	}


	/**
	 * Get the jar URI
	 * 
	 * @return URI
	 * @throws URISyntaxException  throw an URISyntaxException
	 */
	private static  URI getJarURI() throws URISyntaxException
	{
		final ProtectionDomain domain;
		final CodeSource       source;
		final URL              url;
		final URI              uri;

		domain = KronosUtilsFactory.class.getProtectionDomain();
		source = domain.getCodeSource();
		url    = source.getLocation();
		uri    = url.toURI();

		return (uri);
	}



	/**
	 * Get the driver from the jar file
	 * 
	 * @param where:URI
	 * @param fileName: String
	 * @return URI
	 * @throws ZipException throw a ZipException
	 * @throws IOException throw an IOException
	 */
	private static  URI getFile(final URI where,final String fileName)throws ZipException,IOException
	{
		final File location;
		final URI  fileURI;

		location = new File(where);

		// not in a JAR, just return the path on disk
		if(location.isDirectory())
		{
			fileURI = URI.create(where.toString() + fileName);
		}
		else
		{
			final ZipFile zipFile;

			zipFile = new ZipFile(location);
			try{
				fileURI = extract(zipFile, fileName);
			}
			finally{
				zipFile.close();
			}
		}

		return (fileURI);
	}


	/**
	 * extract the driver exe from the jar file
	 * 
	 * @param ZipFile:ZipFile
	 * @param fileName: String
	 * @return URI
	 * @throws IOException throw an IOException
	 */
	private static  URI extract(final ZipFile zipFile,final String  fileName)throws IOException
	{
		final File         tempFile;
		final ZipEntry     entry;
		final InputStream  zipStream;
		OutputStream       fileStream;

		tempFile = File.createTempFile(fileName, Long.toString(System.currentTimeMillis()));
		tempFile.deleteOnExit();
		entry    = zipFile.getEntry(fileName);

		if(entry == null)
		{
			throw new FileNotFoundException("cannot find file: " + fileName + " in archive: " + zipFile.getName());
		}

		zipStream  = zipFile.getInputStream(entry);
		fileStream = null;

		try
		{
			final byte[] buf;
			int          i;

			fileStream = new FileOutputStream(tempFile);
			buf        = new byte[1024];
			i          = 0;

			while((i = zipStream.read(buf)) != -1)
			{
				fileStream.write(buf, 0, i);
			}
		}
		finally
		{
			close(zipStream);
			close(fileStream);
		}

		tempFile.setExecutable(true);
		/*    String os = System.getProperty("os.name", "generic").toLowerCase(Locale.ENGLISH);
		if (os.indexOf("mac") >= 0) 
		    	Runtime.getRuntime().exec("chmod +x " + tempFile);*/

		return (tempFile.toURI());
	}


	/**
	 * close the stream
	 * 
	 * @param stream:Closeable
	 */
	private static void close(final Closeable stream)
	{
		if(stream != null)
		{
			try
			{
				stream.close();
			}
			catch(final IOException ex)
			{
				logger.error(ex.getMessage(),ex);
			}
		}
	}



}