package com.kronos.enums;

public enum LaunchBrowserAtLevel {
	TESTCLASS,
	TESTMETHOD;
}
