/**
 * @date:Jul 18, 2016
 */
package com.kronos.element;

import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.Quotes;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.kronos.element.interfaces.complex.IBaseNonStandardSelect;
import com.kronos.exception.KronosCoreUIException;
import com.kronos.helpers.BasicPageElementHelper;
import com.kronos.helpers.BasicPageSyncHelper;
import com.kronos.logging.KronosLogger;
import com.kronos.report.Reporter;
import com.kronos.report.StepStatus;
import com.kronos.testng.Configurator;
import com.kronos.utils.KronosSeleniumUtil;
import com.paulhammant.ngwebdriver.WaitForAngularRequestsToFinish;

public class BaseNonStandardElement extends BaseElement implements IBaseNonStandardSelect {

	private static final String JS_SCROLL_INTO_VIEW = "arguments[0].scrollIntoView(true);";
	
	static final Logger logger = Logger.getLogger(BaseNonStandardElement.class);
	private Reporter reporter = Reporter.getInstance();
	private WebElement element;
	private WebElement ulElement;
	protected final WebDriver driver;
	private List<WebElement> matchLiElements = new ArrayList<WebElement>();

	public BaseNonStandardElement(WebDriver driver, WebElement element, String locatorKey, String locator,
			String navigation) {
		super(driver, element, locatorKey, locator, navigation);
		this.element = element;
		this.driver = driver;
		String tagName = element.getTagName();
		//Fix: SUP-6263. Commented "div" condition. Ul exists under div or as an independent element.
		if (null == tagName){// || !"div".equals(tagName)) {
			//throw new UnexpectedTagNameException("div", tagName);
			throw new NullPointerException("NonStandardElement does not exist");
		}
	}

	/**
	 * Select the item at the given index.
	 * 
	 * @param index The item at this index will be selected and it should be greater than 0 
	 * @param elementLocator must be xPath or CSS that must to locate to the each item's label about the drop-down list
	 * @throws KronosCoreUIException
	 *             throw a KronosCoreUIException 
	 *             
	 * Sample call for Xpath:selectItemByIndex(10,"//*[@id='combo-dropdown-menu']//ul//li")
	 * Sample call for CSS :selectItemByIndex(10,"#combo-dropdown-menu ul li")
	 */
	@Override
	public void selectItemByIndex(int index, String elementLocator) throws KronosCoreUIException {
		KronosLogger.traceEnter();
		String infoMsg = "selectItemByIndex: " + index + " [ " + locatorKey + " : " + locator + " ]";
		try {
			BasicPageElementHelper.scrollIntoView(driver, element);
			if (index > 0) {
				selectItemsByIndex(index, elementLocator);
				logger.info(infoMsg);
				reporter.reportStepWithUITracking(StepStatus.INFO, infoMsg, "selectByIndex", locatorKey, locator, navigation);
			}
		} catch (Exception e) {
			logger.error(infoMsg, e);
			reporter.deepReportStep(StepStatus.FAIL, infoMsg, BasicPageSyncHelper.saveAsScreenShot(driver), e);
			throw new KronosCoreUIException(infoMsg, e);
		}
		KronosLogger.traceLeave();

	}

	/**
	 * Select the item at the given Text.
	 * 
	 * @param text
	 *            The visible text to match against elementLocator(xpath or CSS) Must to locate to the
	 *            each item's label about the drop-down list
	 * @throws KronosCoreUIException
	 *             throw a KronosCoreUIException 
	 *             
	 * Sample call for Xpath:selectItemByIndex("Adams, Kevin","//*[@id='combo-dropdown-menu']//ul//li")
	 * Sample call for CSS :selectItemByIndex("Adams, Kevin","#combo-dropdown-menu ul li")
	 */
	@Override
	public void selectByVisibleText(String text, String elementLocator) throws KronosCoreUIException {
		KronosLogger.traceEnter();
		String infoMsg = "selectByVisibleText: " + text + " [ " + locatorKey + " : " + locator + " ]";
		try {
			BasicPageElementHelper.scrollIntoView(driver, element);
			selectItemByVisibleText(text, elementLocator);
			logger.info(infoMsg);
			reporter.reportStepWithUITracking(StepStatus.INFO, infoMsg, "selectByText", locatorKey, locator, navigation);
		} catch (Exception e) {
			logger.error(infoMsg, e);
			reporter.deepReportStep(StepStatus.FAIL, infoMsg, BasicPageSyncHelper.saveAsScreenShot(driver), e);
			throw new KronosCoreUIException(infoMsg, e);
		}
		KronosLogger.traceLeave();

	}

	/**
	 * Get list of all li belonging to given select element
	 * 
	 * @param xpath
	 *            Must to locate to the each item's label about the drop-down
	 *            list
	 * @return All li belonging to this div tag
	 * @throws KronosCoreUIException
	 *             throw a KronosCoreUIException: While creation of div element
	 * Sample Call:
	 *             getAllItems("//*[@id='combo-dropdown-menu']/ul/li") or
	 *             getAllItems("//*[@class='ng-scope' and @ng-if='opts']/krn-slats-component/div/div")
	 */
	@Override
	public List<?> getAllOptions(String xpath) throws KronosCoreUIException {
		KronosLogger.traceEnter();
		String infoMsg = "getAllOptions: " + " [ " + locatorKey + " : " + locator + " ]";
		List<WebElement> allItemList;
		try {
			allItemList = getAllItems(xpath);
		} catch (Exception e) {
			reporter.deepReportStep(StepStatus.FAIL, infoMsg, BasicPageSyncHelper.saveAsScreenShot(driver), e);
			logger.error(infoMsg, e);
			throw new KronosCoreUIException(infoMsg, e);
		}
		logger.info(infoMsg);
		KronosLogger.traceLeave();
		return allItemList;
	}

	/**
	 * Get list of all item innerText
	 * 
	 * @param xpath
	 *            Must to locate to the each item's label about the drop-down
	 *            list
	 * @return All item belonging to this div tag
	 * @throws KronosCoreUIException
	 *             throw a KronosCoreUIException: While creation of div element
	 * Sample Call:
	 *         getAllOptionValues("//*[@id='combo-dropdown-menu']/ul/li") 
	 *         getAllOptionValues("//*[@class='ng-scope' and @ng-if='opts']/krn-slats-component/div/div")
	 */
	@Override
	public List<String> getAllOptionValues(String xpath) throws KronosCoreUIException {
		KronosLogger.traceEnter();
		String infoMsg = "getAllOptionValues: " + " [ " + locatorKey + " : " + locator + " ]";
		List<String> allItemValues;
		/*
		 * Fix : SUP-12657, Added scroll Up before start count 
		*/
		scrollListElements(xpath);
		try {
			allItemValues = getAllItemValues(xpath);
		} catch (Exception e) {
			reporter.deepReportStep(StepStatus.FAIL, infoMsg, BasicPageSyncHelper.saveAsScreenShot(driver), e);
			logger.error(infoMsg, e);
			throw new KronosCoreUIException(infoMsg, e);
		}
		logger.info(infoMsg);
		KronosLogger.traceLeave();
		return allItemValues;
	}

	/**
	 * Get selected item
	 * 
	 * @param xpath
	 *            Must to locate to the each item's label about the drop-down
	 *            list
	 * @throws KronosCoreUIException
	 *             throw a KronosCoreUIException: While no item is selected
	 * Sample Call:
	 *             getSelectedObject("//*[@id='combo-dropdown-menu']/ul/li")
	 */
	@Override
	public String getSelectedObject(String xpath) throws KronosCoreUIException {
		KronosLogger.traceEnter();
		String infoMsg = "getSelectedObject: " + " [ " + locatorKey + " : " + locator + " ]";
		String selectedItem;
		try {
			selectedItem = getSelectedItem(xpath);
		} catch (Exception e) {
			reporter.deepReportStep(StepStatus.FAIL, infoMsg, BasicPageSyncHelper.saveAsScreenShot(driver), e);
			logger.error(infoMsg, e);
			throw new KronosCoreUIException(infoMsg, e);
		}
		logger.info(infoMsg);
		KronosLogger.traceLeave();
		return selectedItem;
	}

	/**
	 * Select the item at the given index.
	 *
	 * @param index The item at this index will be selected and it should be greater than 0 
	 * @param elementLocator must be xPath or CSS that must to locate to the each item's label about the drop-down list
	 * @throws KronosCoreUIException
	 * @throws NoSuchElementException
	 *             If no matching item elements are found
	 * 
	 * Sample call for Xpath:selectItemByIndex(10,"//*[@id='combo-dropdown-menu']//ul//li")
	 * Sample call for CSS :selectItemByIndex(10,"#combo-dropdown-menu ul li")
	 */
	private void selectItemsByIndex(int index, String elementLocator){
		boolean flag = false;
		List<WebElement> oldElements = getItems(elementLocator);
		List<WebElement> newElements = new ArrayList<>();
		
		for (WebElement listElement : oldElements) {
			if(listElement.getText()!=null)
			{
				newElements.add(listElement);
			}
		}
		String elementValue = newElements.get(index-1).getText();
		try {
			selectByVisibleText(elementValue, elementLocator);
		} catch (KronosCoreUIException e) {
			throw new NoSuchElementException("Cannot locate item with index: " + index);
		}
		/*System.out.println(oldElements.size());
		for (WebElement item : oldElements) {
			System.out.println(item.getText());
		}
		List<WebElement> resElements = new ArrayList<WebElement>();

		if (index <= oldElements.size()) {
			KronosSeleniumUtil.executeScript(driver, JS_SCROLL_INTO_VIEW, oldElements.get(index-1));
			oldElements.get(index-1).getText();
			oldElements.get(index - 1).click();
			try {
				WaitForAngularRequestsToFinish.waitForAngularRequestsToFinish((JavascriptExecutor) driver);
			} catch (Exception e) {
				logger.error("Exception occured when excute angular request running: " + e.getMessage(),e);
			}
			return;
		}

		int flagCnt = oldElements.size();
		String js = JS_SCROLL_INTO_VIEW;
		KronosSeleniumUtil.executeScript(driver, js, oldElements.get(oldElements.size() - 1));
		try {
			WaitForAngularRequestsToFinish.waitForAngularRequestsToFinish((JavascriptExecutor) driver);
		} catch (Exception e) {
			logger.error("Exception occured when excute angular request running: " + e.getMessage(),e);
		}
		if (matchLiElements != null && !matchLiElements.isEmpty()) {
			matchLiElements.clear();
		}
		matchLiElements = getItems(xpath);
		resElements.addAll(oldElements);

		if (matchLiElements.size() == flagCnt) {
			while (matchLiElements.size() == flagCnt) {
				if (oldElements.containsAll(matchLiElements)) {// load all items at first time
					if (index <= matchLiElements.size()) {
						matchLiElements.get(index - 1).click();
						try {
							WaitForAngularRequestsToFinish.waitForAngularRequestsToFinish((JavascriptExecutor) driver);
						} catch (Exception e) {
							logger.error("Exception occured when excute angular request running: " + e.getMessage(),e);
						}
						return;
					} else {
						break;
					}
				} else {
					if (resElements.containsAll(matchLiElements)) {// load all items at last time
						if (index <= matchLiElements.size()) {
							matchLiElements.get(index - 1).click();
							try {
								WaitForAngularRequestsToFinish
										.waitForAngularRequestsToFinish((JavascriptExecutor) driver);
							} catch (Exception e) {
								logger.error(
										"Exception occured when excute angular request running: " + e.getMessage(),e);
							}
							return;
						} else {
							break;
						}
					} else {
						for (int i = 0; i < matchLiElements.size(); i++) {
							if (!resElements.contains(matchLiElements.get(i))) {
								resElements.add(matchLiElements.get(i));
							}
						}
						if (index <= resElements.size()) {
							resElements.get(index - 1).click();
							try {
								WaitForAngularRequestsToFinish
										.waitForAngularRequestsToFinish((JavascriptExecutor) driver);
							} catch (Exception e) {
								logger.error(
										"Exception occured when excute angular request running: " + e.getMessage(),e);
							}
							return;
						}
					}
					KronosSeleniumUtil.executeScript(driver, js, matchLiElements.get(matchLiElements.size() - 1));
					try {
						WaitForAngularRequestsToFinish.waitForAngularRequestsToFinish((JavascriptExecutor) driver);
					} catch (Exception e) {
						logger.error("Exception occured when excute angular request running: " + e.getMessage(),e);
					}
					if (matchLiElements != null && !matchLiElements.isEmpty()) {
						matchLiElements.clear();
						matchLiElements = getItems(xpath);
					}
				}
			}

		} else if (matchLiElements.size() > flagCnt) {
			while (matchLiElements.size() > flagCnt) {
				if (index <= matchLiElements.size()) {
					matchLiElements.get(index - 1).click();
					try {
						WaitForAngularRequestsToFinish.waitForAngularRequestsToFinish((JavascriptExecutor) driver);
					} catch (Exception e) {
						logger.error("Exception occured when excute angular request running: " + e.getMessage(),e);
					}
					return;
				}
				flagCnt = matchLiElements.size();
				KronosSeleniumUtil.executeScript(driver, js, matchLiElements.get(matchLiElements.size() - 1));
				try {
					WaitForAngularRequestsToFinish.waitForAngularRequestsToFinish((JavascriptExecutor) driver);
				} catch (Exception e) {
					logger.error("Exception occured when excute angular request running: " + e.getMessage(),e);
				}
				if (matchLiElements != null && !matchLiElements.isEmpty()) {
					matchLiElements.clear();
					matchLiElements = getItems(xpath);
				}
			}
		} else {
			for (int i = 0; i < matchLiElements.size(); i++) {
				if (!resElements.contains(matchLiElements.get(i))) {
					resElements.add(matchLiElements.get(i));
				}
			}

			if (index <= resElements.size()) {
				resElements.get(index - 1).click();
				try {
					WaitForAngularRequestsToFinish.waitForAngularRequestsToFinish((JavascriptExecutor) driver);
				} catch (Exception e) {
					logger.error("Exception occured when excute angular request running: " + e.getMessage(),e);
				}
				return;
			}
		}
		if (!flag) {
			throw new NoSuchElementException("Cannot locate item with index: " + index);
		}*/
	}

	/**
	 * Select all item that display text matching the argument. That is, when
	 * given "Bar" this would select at li like:
	 *
	 * &lt;li value="foo"&gt;Bar&lt;/li&gt;
	 *
	 * @param text
	 *            The visible text to match against elementLocator(Xpath or CSS) Must to locate to the
	 *            each item's label about the drop-down list
	 * @throws KronosCoreUIException
	 * @throws NoSuchElementException
	 *             If no matching item are found
	 * 
	 * Sample call for Xpath:selectItemByIndex("Adams, Kevin","//*[@id='combo-dropdown-menu']//ul//li")
	 * Sample call for CSS :selectItemByIndex("Adams, Kevin","#combo-dropdown-menu ul li")
	 * 
	 */
	private void selectItemByVisibleText(String text, String elementLocator){
		List<WebElement> listVisible = getVisibleTextObject(text, elementLocator);

		boolean matched = false;
		for (WebElement matchLiElement : listVisible) {
			//scroll element into view in case it is not displayed
			/*
			 * SUP-6710, In some dropdown-combobox we have text inside the
			 * anchor link. So we can't perform js-scroll or click on options.
			*/
			if(matchLiElement.getCssValue("cursor").equalsIgnoreCase("pointer")){
				((JavascriptExecutor) driver).executeScript("arguments[0].click()", matchLiElement);
			}else{
				KronosSeleniumUtil.executeScript(driver, JS_SCROLL_INTO_VIEW, matchLiElement);
				matchLiElement.click();
			}
			matched = true;
		}

		if (listVisible.isEmpty() && text.contains(" ")) {
			String subStringWithoutSpace = getLongestSubstringWithoutSpace(text);
			List<WebElement> candidates;
			if ("".equals(subStringWithoutSpace)) {
				//text is either empty or contains only spaces - get all items
				if(elementLocator.contains("//") || elementLocator.contains("/"))
					candidates = element.findElements(By.xpath(elementLocator));
				else
					candidates = element.findElements(By.cssSelector(elementLocator));
					
			} else {
				// get candidates via LOCATOR ...
				if(elementLocator.contains("//") || elementLocator.contains("/")){
				candidates = element
						.findElements(By.xpath(elementLocator+ "[contains(., " + Quotes.escape(subStringWithoutSpace) + ")]"));
				}
				else {
					candidates = element
							.findElements(By.cssSelector(elementLocator + "* " + Quotes.escape(subStringWithoutSpace)));
				}
			}

			if (listVisible != null && !listVisible.isEmpty()) {
				listVisible.clear();
			}
			listVisible.addAll(candidates);
			for (WebElement liElement : candidates) {
				if (text.equals(liElement.getText())) {
					liElement.click();
					matched = true;
				}
			}
		}
		if (!matched) {
			throw new NoSuchElementException("Cannot locate item with text: " + text);
		}
	}

	/**
	 * @param xpath
	 *            Must to locate to the each item's label about the drop-down list
	 *             
	 * Sample Call:
	 *            getAllItems("//*[@id='combo-dropdown-menu']/ul/li") or
	 *            getAllItems("//*[@class='ng-scope' and @ng-if='opts']/krn-slats-component/div/div")
	 * 
	 * @return All child Item belonging to this div tag
	 * @throws KronosCoreUIException
	 */
	private List<WebElement> getAllItems(String xpath){
		List<WebElement> oldElements = getItems(xpath);
		List<WebElement> resElements = new ArrayList<WebElement>();
		resElements.addAll(oldElements);
		int flagCnt = oldElements.size();
		KronosSeleniumUtil.executeScript(driver, JS_SCROLL_INTO_VIEW, oldElements.get(oldElements.size() - 1));
		try {
			WaitForAngularRequestsToFinish.waitForAngularRequestsToFinish((JavascriptExecutor) driver);
		} catch (Exception e) {
			logger.error("Exception occured when excute angular request running: " + e.getMessage(),e);
		}
		if (matchLiElements != null && !matchLiElements.isEmpty()) {
			matchLiElements.clear();
		}
		matchLiElements = getItems(xpath);

		if (matchLiElements.size() == flagCnt) {
			while (matchLiElements.size() == flagCnt) {
				if (oldElements.containsAll(matchLiElements)) {
					return matchLiElements;
				} else {
					if (resElements.containsAll(matchLiElements)) {
						return resElements;
					} else {
						for (int i = 0; i < matchLiElements.size(); i++) {
							if (!resElements.contains(matchLiElements.get(i))) {
								resElements.add(matchLiElements.get(i));
							}
						}
					}
					KronosSeleniumUtil.executeScript(driver, JS_SCROLL_INTO_VIEW, matchLiElements.get(matchLiElements.size() - 1));
					try {
						WaitForAngularRequestsToFinish.waitForAngularRequestsToFinish((JavascriptExecutor) driver);
					} catch (Exception e) {
						logger.error("Exception occured when excute angular request running: " + e.getMessage(),e);
					}
					if (matchLiElements != null && !matchLiElements.isEmpty()) {
						matchLiElements.clear();
						matchLiElements = getItems(xpath);
					}

				}
			}

		} else if (matchLiElements.size() > flagCnt) {
			while (matchLiElements.size() > flagCnt) {
				flagCnt = matchLiElements.size();
				KronosSeleniumUtil.executeScript(driver, JS_SCROLL_INTO_VIEW, matchLiElements.get(matchLiElements.size() - 1));
				try {
					WaitForAngularRequestsToFinish.waitForAngularRequestsToFinish((JavascriptExecutor) driver);
				} catch (Exception e) {
					logger.error("Exception occured when excute angular request running: " + e.getMessage(),e);
				}
				if (matchLiElements != null && !matchLiElements.isEmpty()) {
					matchLiElements.clear();
					matchLiElements = getItems(xpath);
				}
			}
			return matchLiElements;
		} else {
			for (int i = 0; i < matchLiElements.size(); i++) {
				if (!resElements.contains(matchLiElements.get(i))) {
					resElements.add(matchLiElements.get(i));
				}
			}
			return resElements;
		}
		return null;
	}

	/**
	 * @param xpath Must to locate to the each item's label about the drop-down list
	 *             
	 * Sample Call:
	 *            getAllItemValues("//*[@id='combo-dropdown-menu']/ul/li") or
	 *            getAllItemValues("//*[@class='ng-scope' and @ng-if='opts']/krn-slats-component/div/div")
	 * 
	 * @return All Item values belong to this div tag
	 * @throws KronosCoreUIException throw KronosCoreUIException
	 */
	public List<String> getAllItemValues(String xpath) throws KronosCoreUIException {
		List<WebElement> oldElements = getItems(xpath);
		List<WebElement> resElements = new ArrayList<WebElement>();
		List<String> itemValues = new ArrayList<String>();
		int visibleRowCount = 0;

		//Fix - SUP-6877
		if(!oldElements.isEmpty()){
		//KronosSeleniumUtil.executeScript(driver, "arguments[0].scrollIntoView(true);", oldElements.get(0));
			KronosSeleniumUtil.executeScript(driver, "arguments[0].scrollTop=1;", oldElements);
		}
		resElements.addAll(oldElements);
		int flagCnt = oldElements.size();
		Actions builder = new Actions(driver);
		for (WebElement webElement : oldElements) {
			if(webElement.isDisplayed()){
				itemValues.add(webElement.getText());
				builder.sendKeys(Keys.ARROW_DOWN).perform();
				visibleRowCount++;
			}else {
					itemValues.add(oldElements.get(visibleRowCount-1).getText());
					builder.sendKeys(Keys.ARROW_DOWN).perform();
				}
			}
		
		String js = JS_SCROLL_INTO_VIEW;
		KronosSeleniumUtil.executeScript(driver, js, oldElements.get(oldElements.size() - 1));
		try {
			WaitForAngularRequestsToFinish.waitForAngularRequestsToFinish((JavascriptExecutor) driver);
		} catch (Exception e) {
			logger.error("Exception occured when excute angular request running: " + e.getMessage(),e);
		}
		if (matchLiElements != null && !matchLiElements.isEmpty()) {
			matchLiElements.clear();
		}
		matchLiElements = getItems(xpath);
		
		if (matchLiElements.size() == flagCnt) {
			while (matchLiElements.size() == flagCnt) {
				if (oldElements.containsAll(matchLiElements)) {// load all items at first time
					return itemValues;
				} else {
					if (resElements.containsAll(matchLiElements)) {// load all items at last time
						return itemValues;
					} else {
						for (int i = 0; i < matchLiElements.size(); i++) {
							if (!resElements.contains(matchLiElements.get(i))) {
								resElements.add(matchLiElements.get(i));
								if(!itemValues.contains(matchLiElements.get(i).getText()))
									itemValues.add(matchLiElements.get(i).getText());
							}
						}
					}
					KronosSeleniumUtil.executeScript(driver, js, matchLiElements.get(matchLiElements.size() - 1));
					try {
						WaitForAngularRequestsToFinish.waitForAngularRequestsToFinish((JavascriptExecutor) driver);
					} catch (Exception e) {
						logger.error("Exception occured when excute angular request running: " + e.getMessage(),e);
					}
					if (matchLiElements != null && !matchLiElements.isEmpty()) {
						matchLiElements.clear();
						matchLiElements = getItems(xpath);
					}

				}
			}

		} else if (matchLiElements.size() > flagCnt) {
			while (matchLiElements.size() > flagCnt) {
				for (int i = 0; i < matchLiElements.size(); i++) {
					if (!resElements.contains(matchLiElements.get(i))) {
						resElements.add(matchLiElements.get(i));
						if(!itemValues.contains(matchLiElements.get(i).getText()))
						itemValues.add(matchLiElements.get(i).getText());
					}
				}
				flagCnt = matchLiElements.size();
				KronosSeleniumUtil.executeScript(driver, js, matchLiElements.get(matchLiElements.size() - 1));
				try {
					WaitForAngularRequestsToFinish.waitForAngularRequestsToFinish((JavascriptExecutor) driver);
				} catch (Exception e) {
					logger.error("Exception occured when excute angular request running: " + e.getMessage(),e);
				}
				if (matchLiElements != null && !matchLiElements.isEmpty()) {
					matchLiElements.clear();
					matchLiElements = getItems(xpath);
				}
			}
			return itemValues;
		} else {
			for (int i = 0; i < matchLiElements.size(); i++) {
				if (!resElements.contains(matchLiElements.get(i))) {
					if(!itemValues.contains(matchLiElements.get(i).getText()))
					itemValues.add(matchLiElements.get(i).getText());
				}
			}
			return itemValues;
		}
		return null;
	}

	/**
	 *
	 * @throws KronosCoreUIException
	 * @throws NoSuchElementException
	 *             If no matching item elements are found 
	 * Sample call:
	 *             getSelectedItem("//*[@id='combo-dropdown-menu']/ul/li")
	 * 
	 */
	private String getSelectedItem(String xpath){
		List<WebElement> elementList = getItems(xpath);
		int classSameCnt = 0;
		int flagCnt = 0;
		int iterCnt = 0;
		while (elementList.size() > flagCnt) {
			flagCnt = elementList.size();
			for (int i = iterCnt; i < flagCnt; i++) {
				if (classSameCnt != 0) {
					classSameCnt = 0;
				}
				for (int j = iterCnt; j < flagCnt; j++) {
					if (j != i) {
						if (!"".equals(elementList.get(i).getAttribute("class"))
								&& !"".equals(elementList.get(j).getAttribute("class"))) {
							if (elementList.get(i).getAttribute("class").trim()
									.equals(elementList.get(j).getAttribute("class").trim())) {
								classSameCnt++;
							}
						}
					}
					if (classSameCnt >= 2) {// item is not selected
						break;
					}
				}
				if (classSameCnt == 0) {// item is selected
					return elementList.get(i).getText();
				}

			}
			iterCnt = flagCnt;
			String js = JS_SCROLL_INTO_VIEW;
			KronosSeleniumUtil.executeScript(driver, js, elementList.get(elementList.size() - 1));
			try {
				WaitForAngularRequestsToFinish.waitForAngularRequestsToFinish((JavascriptExecutor) driver);
			} catch (Exception e) {
				logger.error("Exception occured when excute angular request running: " + e.getMessage(),e);
			}
			if (elementList != null && !elementList.isEmpty()) {
				elementList.clear();
			}
			elementList = getItems(xpath);
		}
		throw new NoSuchElementException("No item is selected");
	}

	private String getLongestSubstringWithoutSpace(String s) {
		String result = "";
		StringTokenizer st = new StringTokenizer(s, " ");
		while (st.hasMoreTokens()) {
			String t = st.nextToken();
			if (t.length() > result.length()) {
				result = t;
			}
		}
		return result;
	}

	private List<WebElement> getItems(String elementLocator) {
		
		KronosSeleniumUtil.waitForElementToBeEnabled(driver,element, TIMEOUT);
		if(elementLocator.contains("//") || elementLocator.contains("/")){
			return element.findElements(By.xpath(elementLocator));
		}
		else 
			return element.findElements(By.cssSelector(elementLocator));
	}
	
		
	////#Fix SUP-6042
	private void scrollListElements(String elementLocator){
		KronosSeleniumUtil.waitForElementToBeEnabled(driver,element, TIMEOUT);
		try{
			if(elementLocator.contains("//") || elementLocator.contains("/"))
				ulElement = element.findElement(By.xpath("./ul")); //className("search-options"));
			else 
				ulElement = element.findElement(By.cssSelector(" ul"));
		}catch(Exception e){
			
		}
		
		Actions builder = new Actions(driver);
		String elementIndex = getItems(elementLocator).get(0).getAttribute("v-index");
		if(elementIndex!=null){
			while (!elementIndex.equals("0")) {
				if (ulElement != null)
					/*
					 * Fix SUP-11587, scrollTop changed to 0 form 1 Commented
					 * the Arrow Up Code
					 */
					KronosSeleniumUtil.executeScript(driver, "arguments[0].scrollTop=0;", ulElement);
				// builder.sendKeys(Keys.ARROW_UP).perform();
				elementIndex = getItems(elementLocator).get(0).getAttribute("v-index");
			}
		}
	}

	private List<WebElement> getVisibleTextObject(String text, String elementLocator){
		boolean flag = false;
		List<WebElement> resElements = new ArrayList<WebElement>();
		//List<WebElement> oldElements = new ArrayList<WebElement>();
		
		if (matchLiElements != null && !matchLiElements.isEmpty()) {
			matchLiElements.clear();
		}
		String js = JS_SCROLL_INTO_VIEW;
		
		//#Fix SUP-6042
		
		if(elementLocator.contains("/a/span")){
			if(getItems(elementLocator.replace("/a/span", "")).get(0).getAttribute("v-index")!=null){
				scrollListElements(elementLocator.replace("/a/span", ""));
			}
		}
		if(getItems(elementLocator).get(0).getAttribute("v-index")!=null){
			scrollListElements(elementLocator);
		}
		
		KronosSeleniumUtil.executeScript(driver, "arguments[0].scrollTop=1;", element);
		try {
			WaitForAngularRequestsToFinish.waitForAngularRequestsToFinish((JavascriptExecutor) driver);
		} catch (Exception e) {
			logger.error("Exception occured when excute angular request running: " + e.getMessage(),e);
		}
		//matchLiElements = getItems(elementLocator);
		waitForLoadScrollData(elementLocator);	       

		for (WebElement webElement : matchLiElements) {
			//if (webElement.getText().contains(text))
			if (webElement.getText().equalsIgnoreCase(text)){
				resElements.add(webElement);
				flag = true;
				break;
			}
		}
		while ( !flag) { 
			
			String textContent = element.getAttribute("textContent");
			KronosSeleniumUtil.executeScript(driver, js, matchLiElements.get(matchLiElements.size() - 1));
			
			try {
				WaitForAngularRequestsToFinish.waitForAngularRequestsToFinish((JavascriptExecutor) driver);
			} catch (Exception e) {
				logger.error("Exception occured when excute angular request running: " + e.getMessage(),e);
			}
			if (matchLiElements != null && !matchLiElements.isEmpty()) {
				matchLiElements.clear();
			}
		
			waitForLoadScrollData(elementLocator);	        
			//matchLiElements = getItems(elementLocator);
			String newTextContent = element.getAttribute("textContent");
			
			for (WebElement webElement : matchLiElements) {
				//if (!"".equals(webElement.getText()) && webElement.getText().contains(text)) 
				if (!"".equals(webElement.getText()) && webElement.getText().equalsIgnoreCase(text)) {
					resElements.add(webElement);
					flag = true;
					break;
				}
			}
			if(textContent.equals(newTextContent)){
				flag = true;
			}
	
		}
		
		return resElements;
	}
	
	
	private void waitForLoadScrollData(String elementLocator){
        WebDriverWait wait = new WebDriverWait(driver, 15);
        ExpectedCondition<Boolean> condition = new ExpectedCondition<Boolean>() {
             public Boolean apply(WebDriver driver) {
                try {
                		matchLiElements = getItems(elementLocator);
                		return true;
                 } catch (NoSuchElementException e) {
     	        	System.out.println("Failed in scrolling: NoSuchElementException");
    	        	return false;
    	        } catch (StaleElementReferenceException e) {
    	        	System.out.println("Failed in scrolling: StaleElementReferenceException");
    	        	return false;
    	        } catch (Exception e) {
    	        	System.out.println("Failed in scrolling: Exception");
    	        	return false;
    	        }
             }
        };
        try {
            wait.until(condition);
        } catch (Exception e) {
            String errorMsg = "KronosCoreUIException occurs in TestUtils#waitForAttributeNotContains" + e.getMessage();
            logger.error(errorMsg); 
        }
	}


}
