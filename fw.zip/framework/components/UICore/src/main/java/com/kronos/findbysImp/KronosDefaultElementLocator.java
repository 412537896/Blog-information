package com.kronos.findbysImp;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.SearchContext;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.pagefactory.AbstractAnnotations;
import org.openqa.selenium.support.pagefactory.ElementLocator;

import com.kronos.element.BaseJQGrid;
import com.kronos.element.BaseUIGrid;
import com.kronos.element.BaseUIGridTK;
import com.kronos.enums.KronosGridType;
import com.kronos.enums.KronosLocateVia;
import com.kronos.helpers.BasicPageElementHelper;
import com.kronos.report.Reporter;
import com.kronos.testng.Configurator;

public class KronosDefaultElementLocator implements ElementLocator{
	static final Logger logger = Logger.getLogger(KronosDefaultElementLocator.class);
	
	private final SearchContext searchContext;
	private final boolean shouldCache;
	private final By by;
	private WebElement cachedElement;
	private List<WebElement> cachedElementList;
	
	private final KronosLocateVia viaMethod;
	private final KronosGridType tableType;
	private int timeout;
	protected Reporter reporter = Reporter.getInstance();
	public KronosDefaultElementLocator(SearchContext searchContext, Field field, int timeout) {
	    this(searchContext, new KronosBaseAnnotations(field), timeout);	
	}
	/**
	 *  The KronosDefaultElementLocator which find element based on the specified annotations in the search context within 
		the given timeout
	 * 
	 * @param searchContext SearchContext
	 * @param annotations AbstractAnnotations
	 * @param timeout int
	 */
	public KronosDefaultElementLocator(SearchContext searchContext, AbstractAnnotations annotations, int timeout) {
	    this.searchContext = searchContext;
	    this.shouldCache = annotations.isLookupCached();
	    this.by = annotations.buildBy();
	    //get the via method name to call the proper method
	    if (annotations instanceof KronosBaseAnnotations){
	    	this.viaMethod = ((KronosBaseAnnotations)annotations).getKronosFindMethodName();
	    	this.tableType = ((KronosBaseAnnotations)annotations).getKronosGridTableTypeName();
	    	this.timeout = ((KronosBaseAnnotations)annotations).getKronosFindTimeout();
	    	if(this.timeout==-1){
			    this.timeout = timeout;
	    	}
	    }else{
	    	this.viaMethod = KronosLocateVia.Default;
	    	this.tableType = KronosGridType.Default;
		    this.timeout = timeout;
	    }
	    
	}
	/**
	 * Find element  
	 *  
	 *  @return WebElement
	 */  
	@Override
	public WebElement findElement() {
		if (cachedElement != null && shouldCache) {
	      return cachedElement;
	    }
	    WebElement element = null;
	    String methodName = viaMethod.getMethodName();
		Method method;
		try {
			method = BasicPageElementHelper.class.getDeclaredMethod(methodName, new Class[]{WebDriver.class, By.class, int.class});
			element = (WebElement) method.invoke(null, (WebDriver)searchContext,by,timeout);
		} catch (Exception e) {
        	logger.debug(e);
			//We will not do anything here as, exception will be thrown from class KronosLocatingBaseElementHandler, invoke method.
			//Logging and reporting will be done inside BasicPageElementHelper class.
		}
		
	    if (shouldCache && element!=null) 
	    	cachedElement = element;
	    
	    return element;
	}
	
	
	/**
	 * Finds all elements on page for given locator
	 * 
	 * @return List
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<WebElement> findElements() {
		if (cachedElementList != null && shouldCache) {
	      return cachedElementList;
	    }

	    List<WebElement> elements = new ArrayList<WebElement>();
	    String methodName = viaMethod.getMethodName();
		Method method;
		try {
			method = BasicPageElementHelper.class.getDeclaredMethod(methodName, new Class[]{WebDriver.class, By.class, int.class});
			elements = (List<WebElement>) method.invoke(null, (WebDriver)searchContext,by,timeout);
		} catch (Exception e) {
        	logger.debug(e);
			//We will not do anything here as, exception will be thrown from class KronosLocatingBaseElementHandler, invoke method.
			//Logging and reporting will be done inside BasicPageElementHelper class.
		}
		
	    if (shouldCache) {
	      cachedElementList = elements;
	    }

	    return elements;
	}
	
	@Override
	public String toString(){
		return "" + by + "";
	}
	
	public KronosGridType getTableType(){
		return tableType;
	}
	
	public KronosLocateVia getVia(){
		return this.viaMethod;
	}
	
    public Class<?> getGridType(){
    	WebElement grid =  null;
    	try {
    		((WebDriver)searchContext).manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
    		((WebDriver)searchContext).manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			grid = searchContext.findElement(by);
    		((WebDriver)searchContext).manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
        } catch (Exception e) { //ignore
        	logger.debug(e);
        }
    	
        WebElement uiGrid = null;
        WebElement jqxGrid = null;
        if(grid != null){
        	try {
                //uiGrid = grid.findElement(By.xpath(".//*[contains(@class,'ui-grid')]"));
        		uiGrid = grid.findElement(By.cssSelector("div[class*='ui-grid']"));
 	        } catch (Exception e) { //ignore
	        	logger.debug(e);
	        }
	         
        	try {
  	            //jqxGrid = grid.findElement(By.xpath(".//*[contains(@class,'jqx-grid')]"));
  	            jqxGrid = grid.findElement(By.cssSelector("div[class*='jqx-grid']"));
	        } catch (Exception e) { //ignore
	        	logger.debug(e);
	        }
        }
        
        if (uiGrid != null) {
        	boolean isTK=false;
			if ("true".equalsIgnoreCase(Configurator.getInstance().getParameter("DebugInfo")))
				isTK = false;
			else {
				StackTraceElement[] stackTraceElements = Thread.currentThread().getStackTrace();

				for (int i = 0; i < stackTraceElements.length; i++) {
					if (/*stackTraceElements[i].getMethodName().toLowerCase().contains("test_alm")
							&& */stackTraceElements[i].getClassName().toLowerCase()
									.contains("com.kronos.timekeeping")) {
						isTK = true;
						break;
					}
				}
			}
        	if(isTK)
        		return BaseUIGridTK.class;
        	else
               return BaseUIGrid.class;
        } else if (jqxGrid != null) {
               return BaseJQGrid.class;
        } else{
               return BaseJQGrid.class;
        }
  }
}
