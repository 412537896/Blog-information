package com.kronos.element.interfaces;

import com.kronos.exception.KronosCoreUIException;

public interface IBaseRadioButton extends IBaseClick {	
	public boolean isSelected() throws KronosCoreUIException;
}
