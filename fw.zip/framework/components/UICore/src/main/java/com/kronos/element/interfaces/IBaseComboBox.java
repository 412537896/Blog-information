package com.kronos.element.interfaces;

public interface IBaseComboBox extends IBaseSelect {	
}
