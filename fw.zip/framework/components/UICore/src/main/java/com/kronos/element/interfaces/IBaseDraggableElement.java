package com.kronos.element.interfaces;

import com.kronos.exception.KronosCoreUIException;

public interface IBaseDraggableElement extends IBaseCommonElement {
	public void dragTo(IBaseCommonElement element) throws KronosCoreUIException;
}
