package com.kronos.utils;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.kronos.enums.LocatorType;

public class KronosGridUtil {
	
	public static ThreadLocal<Map<String,String>> gridId = new ThreadLocal<Map<String,String>>(){
	    @Override
	    protected HashMap<String, String> initialValue() {
	        return new HashMap<>();
	    }
	};
	public static ThreadLocal<Map<String,Map<String,String>>> headerColMapping = new ThreadLocal<Map<String,Map<String,String>>>(){
	    @Override
	    protected Map<String,Map<String,String>> initialValue() {
	        return new HashMap<String,Map<String,String>>();
	    }
	};
	 
	 public static String getGridId(String loc) {
	        return gridId.get().get(loc);
	    }
	 
	 public static Map<String,String> getGridMap() {
	        return gridId.get();
	    }
	 public static void setGridId(String loc, String id) {
	    	gridId.get().put(loc, id);
	    }
	 
	 public static Map<String,String> getHeaderColMapping(String loc) {
	        return headerColMapping.get().get(loc);
	    }
	 
	 static void setHeaderColMapping(String loc,Map<String,String> mapping) {
		 headerColMapping.get().put(loc, mapping);
	    }
	 
	public static void generateGridId(WebDriver driver,String locator, LocatorType type) {
		Map<String,String> headerMapping = new LinkedHashMap<String,String>();
		Pattern pattern = Pattern.compile("grid\\d+");
		Pattern pattern_col = Pattern.compile("ui-grid-coluiGrid-\\d\\w*");
		WebElement grid = getElement(driver, locator, type);
		WebElement gridWrapper = grid.findElement(By.className("ui-grid-contents-wrapper"));
		WebElement parentElement = gridWrapper.findElement(By.xpath("./.."));
		String classAtr=parentElement.getAttribute("class");
		Matcher m = pattern.matcher(classAtr);	
		while (m.find()) {
			String tmp = m.group(0);
			String id = tmp.substring(4, tmp.length()).trim();
			setGridId(locator, id);
		}	
		List<WebElement> allDescendantsChilds = parentElement.findElements(By.xpath(".//div[@class='ui-grid-header-cell-row']/div[contains(@class,'ui-grid-header-cell')]"));
		WebElement currCol = null;
		WebElement colTitleElement=null;
		String uniqueId = null;
		String title=null;	
		for (int i=0; i<allDescendantsChilds.size();i++)
		{
			currCol=allDescendantsChilds.get(i);
			classAtr = currCol.getAttribute("class");
			m = pattern_col.matcher(classAtr);	
			while (m.find()) {
				String tmp = m.group(0);
				uniqueId=tmp.split("-")[3].trim();
			}
			colTitleElement = currCol.findElement(By.xpath("//div[@class='" + classAtr + "']//div[contains(@class,'ui-grid-cell-contents')]//span[contains(@class,'ui-grid-header-cell')]"));   
			title =  colTitleElement.getText();
			if (title.isEmpty())
				title = Integer.toString(i+1);
			if(headerMapping.containsKey(title)) 
				headerMapping.put(title+ "_1", uniqueId);	
			else
				headerMapping.put(title, uniqueId);	
		}
		setHeaderColMapping(locator, headerMapping);
	}
	
	public static WebElement getElement(WebDriver driver,String locator, LocatorType type)
	{
		WebElement grid= null;
		switch(type){
		case XPATH:
			grid = driver.findElement(By.xpath(locator));
			break;
		case ID:
			grid = driver.findElement(By.id(locator));
			break;
		case CSS:
			grid = driver.findElement(By.cssSelector(locator));
			break;
		case CLASS_NAME:
			grid = driver.findElement(By.className(locator));
			break;
		default:
			break;
		}
		return grid;
	}
}