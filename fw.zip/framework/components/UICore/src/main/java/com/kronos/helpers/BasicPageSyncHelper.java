package com.kronos.helpers;

import java.io.File;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.log4testng.Logger;

import com.kronos.exception.KronosCoreUIException;
import com.kronos.logging.KronosLogger;
import com.kronos.report.Reporter;
import com.kronos.report.StepStatus;
import com.kronos.utils.KronosLocatorLoaderUtil;
import com.kronos.utils.KronosSeleniumUtil;

public class BasicPageSyncHelper {
	private static Reporter reporter = Reporter.getInstance();
	static final Logger logger = Logger.getLogger(BasicPageSyncHelper.class);

	private BasicPageSyncHelper(){
	}
	/**
	 * Capture screenshot as a file.
	 * @param driver WebDriver
	 * @return File. screenshot file
	 */
	public static File saveAsScreenShot(WebDriver driver) {
		KronosLogger.traceEnter();
		File file = null;
		String infoMsg = "saveAsScreenShot: ";
		try {
			file = KronosSeleniumUtil.takeScreenShot(driver);
			logger.info(infoMsg);
		} catch (Exception e) {
			logger.error(infoMsg, e);
			reporter.reportStep(StepStatus.FAIL, infoMsg, e);
		}
		KronosLogger.traceLeave();
		return file;
	}

	/**
	 * Wait for frame until it is present in the DOM and switch to it
	 * @param driver
	 *            WebDriver driver
	 * @param locator
	 *            locator defined in the properties file specific to the current
	 *            page for the the driver to find the element based on
	 * @param timeout:int
	 *				Timeout either from user or context file parameter
	 * @throws KronosCoreUIException throws a  KronosCoreUIException
	 */
	public static void waitForFrameToLoadAndSwitch(WebDriver driver, String locator, int timeout) throws KronosCoreUIException {
		KronosLogger.traceEnter();
		String infoMsg = "waitForFrameToLoadAndSwitch: " + "[ " + locator + " ]";
		try {
			logger.info(infoMsg);
			KronosSeleniumUtil.frameToBeAvailableAndSwitchToIt(driver, KronosLocatorLoaderUtil.determineByType(locator),
					timeout);
		} catch (Exception e) {
			logger.error(infoMsg, e);
			reporter.deepReportStep(StepStatus.FAIL, infoMsg, saveAsScreenShot(driver), e);
			throw new KronosCoreUIException(infoMsg, e);
		}
		KronosLogger.traceLeave();
	}

	/**
	 * Wait for page to be loaded based on the HTML document.readyState attributes
	 * @param driver: SeleniumWebDriver instance
	 * @param timeout int
	 * @throws KronosCoreUIException throws a  KronosCoreUIException
	 */
	public static void waitForPageToLoad(WebDriver driver,int timeout) throws KronosCoreUIException {
		KronosLogger.traceEnter();
		KronosSeleniumUtil.waitForDocumentStateToBeComplete(driver,timeout);
		KronosLogger.traceLeave();
	}

	/**
	 * Wait until the visibility of given element locator is located on the page.
	 * @param driver
	 *            SeleniumWebDriver instance
	 * @param locator
	 *            locator defined in the properties file specific to the current
	 *            page for the the driver to find the element based on
	 * @param timeout:int
	 *				Timeout either from user or context file parameter
	 * @throws KronosCoreUIException throws a  KronosCoreUIException
	 */
	public static void waitForApplicationToLoad(WebDriver driver, String locator, int timeout) throws KronosCoreUIException {
		KronosLogger.traceEnter();
		String infoMsg = "waitForApplicationToLoad: " + "[ " + locator + " ]";
		try {
			logger.info(infoMsg);
			KronosSeleniumUtil.visibilityOfElementLocated(driver, KronosLocatorLoaderUtil.determineByType(locator),
					timeout);
		} catch (Exception e) {
			logger.error(infoMsg, e);
			reporter.deepReportStep(StepStatus.FAIL, infoMsg, saveAsScreenShot(driver), e);
			throw new KronosCoreUIException(infoMsg, e);
		}
		KronosLogger.traceLeave();
	}

	/**
	 * Wait until the the given locator element goes invisible on the page.
	 * @param driver
	 *            SeleniumWebDriver instance
	 * @param locator
	 *            locator defined in the properties file specific to the current
	 *            page for the the driver to find the element based on
	 * @param timeout:int
	 *				Timeout either from user or context file parameter
	 * @throws KronosCoreUIException throws a  KronosCoreUIException
	 * 
	 */
	public static void waitForContentToLoad(WebDriver driver, String locator, int timeout) throws KronosCoreUIException {
		KronosLogger.traceEnter();
		String infoMsg = "waitForContentToLoad: " + "[ " + locator + " ]";
		try {
			logger.info(infoMsg);
			KronosSeleniumUtil.waitUntilElementIsInvisible(driver, KronosLocatorLoaderUtil.determineByType(locator),
					timeout);
		} catch (Exception e) {
			logger.error(infoMsg, e);
			reporter.deepReportStep(StepStatus.FAIL, infoMsg, saveAsScreenShot(driver), e);
			throw new KronosCoreUIException(infoMsg, e);
		}
		KronosLogger.traceLeave();
	}

	/**
	 * Wait until the visibility of given pop-up locator is located. 
	 * @param driver
	 *            selenium webdriver
	 * @param locator
	 *            locator defined in the properties file specific to the current
	 *            page for the the driver to find the element based on
	 * @param timeout:int
	 *				Timeout either from user or context file parameter
	 * @throws KronosCoreUIException throws a  KronosCoreUIException
	 */
	public static void waitForPopupToLoad(WebDriver driver, String locator, int timeout) throws KronosCoreUIException {
		KronosLogger.traceEnter();
		String infoMsg = "waitForPopupToLoad: " + "[ " + locator + " ]";
		try {
			logger.info(infoMsg);
			KronosSeleniumUtil.visibilityOfElementLocated(driver, KronosLocatorLoaderUtil.determineByType(locator),
					timeout);
		} catch (Exception e) {
			logger.error(infoMsg, e);
			reporter.deepReportStep(StepStatus.FAIL, infoMsg, saveAsScreenShot(driver), e);
			throw new KronosCoreUIException(infoMsg, e);
		}
		KronosLogger.traceLeave();
	}

	
	/**
	 * Wait until the enable of given element. 
	 * @param driver
	 *            selenium webdriver
	 * @param element
	 *            Predefined web element for the enable to check upon
	 * @param timeout:int
	 *				Timeout either from user or context file parameter
	 * @throws KronosCoreUIException throws a  KronosCoreUIException
	 */
	public static void waitForElementToEnable(WebDriver driver, WebElement element, int timeout) throws KronosCoreUIException {
		KronosLogger.traceEnter();
		String infoMsg = "waitForElementToEnable: [" + element.toString() + "]";
		try {
			logger.info(infoMsg);
			KronosSeleniumUtil.waitForElementToBeEnabled(driver, element, timeout);
		} catch (Exception e) {
			logger.error(infoMsg, e);
			reporter.deepReportStep(StepStatus.FAIL, infoMsg, saveAsScreenShot(driver), e);
			throw new KronosCoreUIException(infoMsg, e);
		}
		KronosLogger.traceLeave();
	}
	
	
	/**
	 * Wait until given element become Clickable. 
	 * @param driver
	 *            selenium webdriver
	 * @param element
	 *            Predefined web element for the Click to check upon
	 * @param timeout:int
	 *				Timeout either from user or context file parameter
	 * @throws KronosCoreUIException throws a  KronosCoreUIException
	 */
	public static void waitForElementToClickable(WebDriver driver, WebElement element, int timeout) throws KronosCoreUIException {
		KronosLogger.traceEnter();
		String infoMsg = "waitForElementToClickable: [" + element.toString() + "]";
		try {
			logger.info(infoMsg);
			KronosSeleniumUtil.waitForElementToBeClickable(driver, element, timeout);
		} catch (Exception e) {
			logger.error(infoMsg, e);
			reporter.deepReportStep(StepStatus.FAIL, infoMsg, saveAsScreenShot(driver), e);
			throw new KronosCoreUIException(infoMsg, e);
		}
		KronosLogger.traceLeave();
	}
	
	
	
	
	
	/**
	 * Wait until the disable of given element. 
	 * @param driver
	 *            selenium webdriver
	 * @param element
	 *            Predefined web element for the enable to check upon
	 * @param timeout:int
	 *				Timeout either from user or context file parameter
	 * @throws KronosCoreUIException throws a  KronosCoreUIException
	 */
	public static void waitForElementToDisable(WebDriver driver, WebElement element, int timeout) throws KronosCoreUIException {
		KronosLogger.traceEnter();
		String infoMsg = "waitForElementToDisable: [" + element.toString() + "]";
		try {
			logger.info(infoMsg);
			KronosSeleniumUtil.waitForElementToBeDisabled(driver, element, timeout);
		} catch (Exception e) {
			logger.error(infoMsg, e);
			reporter.deepReportStep(StepStatus.FAIL, infoMsg, saveAsScreenShot(driver), e);
			throw new KronosCoreUIException(infoMsg, e);
		}
		KronosLogger.traceLeave();
	}
	
	
	/**
	 * Wait until the display of given element. 
	 * @param driver
	 *            selenium webdriver
	 * @param element
	 *            Predefined web element for the enable to check upon
	 * @param timeout:int
	 *				Timeout either from user or context file parameter
	 * @throws KronosCoreUIException throws a  KronosCoreUIException
	 */
	public static void waitForElementToDisplay(WebDriver driver, WebElement element, int timeout) throws KronosCoreUIException {
		KronosLogger.traceEnter();
		String infoMsg = "waitForElementToDisplay: [" + element.toString() + "]";
		try {
			logger.info(infoMsg);
			KronosSeleniumUtil.waitForElementToBeDisplayed(driver, element, timeout);
		} catch (Exception e) {
			logger.error(infoMsg, e);
			reporter.deepReportStep(StepStatus.FAIL, infoMsg, saveAsScreenShot(driver), e);
			throw new KronosCoreUIException(infoMsg, e);
		}
		KronosLogger.traceLeave();
	}
	
	
	/**
	 * Wait until the display of given element. 
	 * @param driver
	 *            selenium webdriver
	 * @param element
	 *            Predefined web element for the enable to check upon
	 * @param timeout:int
	 *				Timeout either from user or context file parameter
	 * @throws KronosCoreUIException throws a  KronosCoreUIException
	 */
	public static void waitForElementToDisappear(WebDriver driver, WebElement element, int timeout) throws KronosCoreUIException {
		KronosLogger.traceEnter();
		String infoMsg = "waitForElementToDisppear: [" + element.toString() + "]";
		try {
			logger.info(infoMsg);
			KronosSeleniumUtil.waitForElementToBeDisappear(driver, element, timeout);
		} catch (Exception e) {
			logger.error(infoMsg, e);
			reporter.deepReportStep(StepStatus.FAIL, infoMsg, saveAsScreenShot(driver), e);
			throw new KronosCoreUIException(infoMsg, e);
		}
		KronosLogger.traceLeave();
	}
	
	/**
	 * Wait until the display of new Browser Window. 
	 * @param driver
	 *            selenium webdriver
	 * @param timeout:int
	 *				Timeout either from user or context file parameter
	 * @throws KronosCoreUIException throws a  KronosCoreUIException
	 */
	public static void waitForNewWindowToDisplay(WebDriver driver, int timeout) throws KronosCoreUIException{
		KronosLogger.traceEnter();
		String infoMsg = "waitForWindowToDisplay: [" + driver.getWindowHandle() + "]";
		try{
			logger.info(infoMsg);
			KronosSeleniumUtil.waitForNewWindowToDisplay(driver, timeout);
		}catch (Exception e) {
			logger.error(infoMsg, e);
			reporter.deepReportStep(StepStatus.FAIL, infoMsg, saveAsScreenShot(driver), e);
			throw new KronosCoreUIException(infoMsg, e);
		}
		KronosLogger.traceLeave();
	}
}