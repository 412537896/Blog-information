package com.kronos.element;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.kronos.element.interfaces.IBaseElement;
import com.kronos.element.interfaces.complex.IBaseGrid;
import com.kronos.exception.KronosCoreUIException;
import com.kronos.logging.KronosLogger;
import com.kronos.utils.KronosSeleniumUtil;

public class BaseJQGrid extends BaseElement implements IBaseGrid {
	Logger logger = Logger.getLogger(BaseJQGrid.class);
	
	private static final String ROW_SELECTOR = "div[role=\"row\"]";
	private static final String HEADER_SELECTOR = "div[role=\"columnheader\"]";
	private static final String CELL_SELECTOR ="div[role=\"gridcell\"]";
	private static final String SELECTED_CELL_SELECTOR ="div[role=\"gridcell\"][class*=\"jqx-grid-cell-selected\"]"; 
	private static final String SELECTED_ROW ="div[role=\"gridcell\"][class*=\"jqx-grid-cell-selected\"]";
	
	//WebElement parent = we.findElement(By.xpath(".."));
	
	private int rowCount; 
	
	private List<String> headerColumns;
	private WebElement jsElement;
	
	public BaseJQGrid(WebDriver driver, WebElement element, String locatorKey, String locator, String navigation) {
		super(driver, element, locatorKey, locator, navigation);
		jsElement = element; 
				 
		String jsPath = "javascript/gridScript.js";
		try {
				KronosSeleniumUtil.loadLocalJS(driver, jsPath);
		} catch (IOException e) {
			logger.error("Exception occured when load javascript: " + jsPath, e);
		}
	}

	/**
	 * Get cell by given row index and column index.
	 * 
	 * @param row int
	 * @param column int
	 * @return IBaseElement
	 * @throws KronosCoreUIException throws a  KronosCoreUIException
	 */
	@Override
	public IBaseElement getCell(int row, int column) throws KronosCoreUIException {
		
		if (jsElement == null ||  row<=0 || row > getRowCount() ) {
			logger.error("Parameter error,  row number: " + row);
			throw new KronosCoreUIException("Parameter error, row number: " + row + " is greater than Grid rowcount or less then Zero");
		}
		
		if (jsElement == null || column<=0 || column > getHeader().size()) {
			logger.error("Parameter error, column number: " + column);
			throw new KronosCoreUIException("Parameter error, column number: " +column+ " is greater than Grid columncount or less then Zero");
		}
	
		String visibleColName = getHeader().get(column-1);
		int actualColIndex=-1;
		if(!"".equals(visibleColName))
			actualColIndex = getColumnActualIndex(visibleColName);
		
		String rowid=null;
		int scrolledRowId=scrollToRow(row);
		if(scrolledRowId!=-1){
			if(jsElement.findElements(By.cssSelector(SELECTED_CELL_SELECTOR)).size()>1) {
				WebElement element =jsElement.findElement(By.cssSelector(SELECTED_ROW));
				rowid=element.findElement(By.xpath("..")).getAttribute("id");
			}
			else
				rowid="row" + String.valueOf(scrolledRowId);
			String xpath=null;
			if(actualColIndex==-1){
				xpath =   "div[role=\"row\"]" + "[id*=\"" + rowid + "\"] " + CELL_SELECTOR + ":nth-child(" + column + ")";
			}else{
				xpath =   "div[role=\"row\"]" + "[id*=\"" + rowid + "\"] " + CELL_SELECTOR + ":nth-child(" + actualColIndex + ")";
			}
			
			WebElement baseElement = jsElement.findElement(By.cssSelector(xpath));
			BaseElement element=new BaseElement(driver, baseElement, "getCell", locator + xpath, navigation);
			jqGridUnSelectRow();
			return element;
		}
		return null;
		
	}

	/**
	 * Get cell by given row index and column name.
	 * 
	 * @param row int
	 * @param columnName String
	 * @return IBaseElement
	 * @throws KronosCoreUIException throws a  KronosCoreUIException
	 */
	@Override
	public IBaseElement getCell(int row, String columnName) throws KronosCoreUIException {
		List<String> header = getHeader();
		if (header.contains(columnName)) {
			return getCell(row, getColumnNumber(columnName));
		} else {
			return null;
		}
	}

	/**
	 * Get row by given row index.
	 * 
	 * @param row int
	 * @return IBaseElement
	 * @throws KronosCoreUIException throws a  KronosCoreUIException
	 */
	@Override
	public IBaseElement getRow(int row) throws KronosCoreUIException {
		//scrollToRow(row);
		
		if (jsElement == null ||  row<=0 || row > getRowCount() ) {
			logger.error("Parameter error,  row number: " + row);
			throw new KronosCoreUIException("Parameter error, row number: " + row + " is greater than Grid rowcount or less then Zero");
		}
		
		String rowid=null;
		int scrolledRowId=scrollToRow(row);
		if(scrolledRowId!=-1){
			if(jsElement.findElements(By.cssSelector(SELECTED_CELL_SELECTOR)).size()>1) {
				WebElement element =jsElement.findElement(By.cssSelector(SELECTED_ROW));
				rowid=element.findElement(By.xpath("..")).getAttribute("id");
			}
			else
				rowid="row" + String.valueOf(scrolledRowId);
			String xpath =   "div[role=\"row\"]" + "[id*=\"" + rowid + "\"]" ;//+ CELL_SELECTOR + "[" + actualColIndex + "]";
			WebElement baseElement = jsElement.findElement(By.cssSelector(xpath));
			BaseElement element=new BaseElement(driver, baseElement, "getRow", locator + xpath, navigation);
			jqGridUnSelectRow();
			return element;
		}
		return null;
		/*List<IBaseElement> selectedElement = this.findElements(By.xpath("." + CELL_SELECTOR));
		if (!selectedElement.isEmpty()) {
			IBaseElement baseElement = selectedElement.get(0).findElement(By.xpath("./.."));
			jqGridUnSelectRow();
			return new BaseElement(driver, baseElement, "getRow", locator + CELL_SELECTOR, navigation);
		} else {
			logger.error("No rows are selected, row number is " + row);
			throw new KronosCoreUIException("No rows are selected,row number is " + row);
		}*/
	}

	/**
	 * Get the first row's number which is in given columnNumber and it's value matches given valueToFind
	 * 
	 * @param valueToFind String
	 * @param columnNumber int
	 * @return The first row's number which matches the condition, -1 if not found.
	 * @throws KronosCoreUIException throws a  KronosCoreUIException
	 */
	@Override
	public int getRowNumber(String valueToFind, int columnNumber) throws KronosCoreUIException {
		try{
			KronosLogger.traceEnter();
			int rowIndex = -1;
			if(valueToFind == null && "".equals(valueToFind)){
				return rowIndex;
			}
			int rowCount = getRowCount();
			for(int i=1;i<=rowCount;i++){
				String cellValue = getCellValue(i,columnNumber);
				if(valueToFind.equals(cellValue)){
					rowIndex = i ;
					break;
				}
			}
			if(rowIndex < 0){
				logger.info("Can't find " + valueToFind + " in column: " + columnNumber);
			}else{
				logger.info("Find " + valueToFind + " in column: " + columnNumber);
			}
			KronosLogger.traceLeave();
			return rowIndex;
		} catch (Exception e) {
			logger.error("Exception occured when get Row Number, valueToFind: " + valueToFind + ", column index: " + columnNumber + " "
					+ e.getMessage());
			throw new KronosCoreUIException(
					"Exception occured when get Row Number, valueToFind: " + valueToFind + ", column index: " + columnNumber, e);
		}
	}

	/**
	 * Get the first row's number which is in given columnName and it's value matches given valueToFind
	 * 
	 * @param valueToFind String
	 * @param columnName String
	 * @return The first row's number which matches the condition, -1 if not found.
	 * @throws KronosCoreUIException throws a  KronosCoreUIException
	 */
	@Override
	public int getRowNumber(String valueToFind, String columnName) throws KronosCoreUIException {
		try{
			KronosLogger.traceEnter();
			if (!isColumnExist(columnName) || valueToFind == null) {
				logger.error("Parameter error, column name: " + columnName + ", valueToFind: " + valueToFind);
				throw new KronosCoreUIException("Parameter error, column name: " + columnName + ", valueToFind: " + valueToFind);
			}
			int columnIndex = getColumnNumber(columnName);
			int rowIndex = getRowNumber(valueToFind,columnIndex);
			KronosLogger.traceLeave();
			return rowIndex;
		} catch (Exception e) {
			logger.error("Exception occured when get cell, valueToFind: " + valueToFind + ", column name: " + columnName + " " + e.getMessage());
			throw new KronosCoreUIException("Exception occured when get cell, valueToFind: " + valueToFind + ", column name: " + columnName, e);
		}
	}

	/**
	 * Get first row of grid.
	 * 
	 * @return IBaseElement of first row.
	 * @throws KronosCoreUIException throws a  KronosCoreUIException
	 */
	@Override
	public IBaseElement getFirstRow() throws KronosCoreUIException {
		//return new BaseElement(driver, this.findElement(By.xpath("." + rowSelector + "[1]")), "getRowAt",
		return new BaseElement(driver, this.findElement(By.cssSelector(ROW_SELECTOR + ":first-child")), "getRowAt",
				locator + ROW_SELECTOR + ":first-child", navigation);
	}

	/**
	 * Get column index by given column name.
	 * 
	 * @param columnName String
	 * @return Column index by given column name, -1 if not found.
	 * @throws KronosCoreUIException throws a  KronosCoreUIException
	 */
	@Override
	public int getColumnNumber(String columnName) throws KronosCoreUIException {
		List<String> header = getHeader();
		for(int i = 0; i < header.size(); i++) {
			if(header.get(i).equals(columnName)) {
				return i+1;
			}
		}
		
		return -1;
	}

	/**
	 * Get column name by given column index.
	 * 
	 * @param column int
	 * @return Column name by given column index.
	 * @throws KronosCoreUIException throws a  KronosCoreUIException
	 */
	@Override
	public String getColumnName(int column) throws KronosCoreUIException {
		List<String> columnNames = getHeader();
		if(column <= 0 || column > columnNames.size()) {
			logger.info("Parameter error, header size is: " + columnNames.size() + ", parameter is: " + column);
			throw new KronosCoreUIException("Parameter error, header size is: " + columnNames.size() + ", parameter is: " + column);
		}
		
		return columnNames.get(column-1);
	}

	/**
	 * Check whether the column is exist.
	 * 
	 * @param columnName String
	 * @return <b>true</b> if column index exist, <b>false</b> if column index not exist.
	 * @throws KronosCoreUIException throws a  KronosCoreUIException
	 */
	@Override
	public boolean isColumnExist(String columnName) throws KronosCoreUIException {
		return getHeader().contains(columnName);
	}

	/**
	 * Check whether the column is exist.
	 * 
	 * @param column int 
	 * @return <b>true</b> if column index exist, <b>false</b> if column index not exist.
	 * @throws KronosCoreUIException throw a KronosCoreUIException
	 */
	@Override
	public boolean isColumnExist(int column) throws KronosCoreUIException {
		return (column >= 0) && (column < getHeader().size());
	}

	/**
	 * Get the column names of current grid table
	 * 
	 * @return The column names list of grid
	 * @throws KronosCoreUIException throws a KronosCoreUIException
	 */
	@Override
	public List<String> getHeader() throws KronosCoreUIException {
		KronosLogger.traceEnter();
		
		if (headerColumns == null) {
			headerColumns = new ArrayList<>();
			List<IBaseElement> headersWebElement = this.findElements(By.cssSelector(HEADER_SELECTOR));

			for (IBaseElement element : headersWebElement) {
				try {
					String attValue = element.getAttribute("style");
                    if(!attValue.contains("display: none")){
                    	String headerName = element.getText().trim();
    					headerColumns.add(headerName);
                    }
				} catch (Exception e) {
					logger.error("Get column names of the grid table fail " + e);
					throw new KronosCoreUIException("Get column names of the grid table fail " + e.getMessage());
				}
			}
		}

		logger.info("Get Column names: " + headerColumns);
		KronosLogger.traceLeave();
		return headerColumns;
	}
	
	
	/**
	 * resize the column name of current grid table
	 * 
	 * @throws KronosCoreUIException throws a KronosCoreUIException
	 */
	@Override
	public void resizeColumn(String columnName,int offset) throws KronosCoreUIException {
		KronosLogger.traceEnter();
		
		if (getColumnNumber(columnName) != -1) {
			String elementId = jsElement.getAttribute("id");
			String script = "return ISJQGridColumnResizable(arguments[0])";
			Object obj = KronosSeleniumUtil.executeScript(driver, script,elementId);
			if (((Long) obj).intValue()==0){
				logger.info("Grid columnn are not ressizable");
				KronosLogger.traceLeave();
				return;
			}
			int colIndex=getColumnActualIndex(columnName);
			script = "JQGridColumnResize(arguments[0],arguments[1],arguments[2])";
			KronosSeleniumUtil.executeScript(driver, script,elementId,colIndex-1,offset);
		}
		KronosLogger.traceLeave();
	}
	
	
	/**
	 * Get the column names of current grid table
	 * 
	 * @return The column names list of grid
	 * @throws KronosCoreUIException throws a KronosCoreUIException
	 */
	
	private int getColumnActualIndex(String colName) throws KronosCoreUIException {
		List<IBaseElement> headersWebElement = this.findElements(By.cssSelector(HEADER_SELECTOR));
		int colIndex=-1;
		for (IBaseElement element : headersWebElement) {
			colIndex++;
			try {
					String headerName = element.getText().trim();
					if(headerName.equals(colName))
						return colIndex+1;
			} catch (Exception e) {
				logger.error("Get column names of the grid table fail " + e);
				throw new KronosCoreUIException("Get column names of the grid table fail " + e.getMessage());
			}
		}
		
		return colIndex;
	}
	
	/**
	 * Get row count of all visible rows.
	 * @return int row count
	 * @throws KronosCoreUIException throws a  KronosCoreUIException
	 */
	@Override
	public int getRowCount() throws KronosCoreUIException {
		KronosLogger.traceEnter();
		int rowCount = -1;
		
		String elementId = jsElement.getAttribute("id");
		String script = "return GetJQRowCount(arguments[0])";
		Object obj = KronosSeleniumUtil.executeScript(driver, script, elementId);
		if (obj == null) {
			logger.info("Get row count failed.");
			KronosLogger.traceLeave();
			return rowCount;
		}
		
		rowCount = ((Long) obj).intValue();
		logger.info("Get row count: " + rowCount);
		KronosLogger.traceLeave();
		return rowCount;
	}
	
	/**
	 * Get columns count of JQGrid
	 * @return Columns count of JQGrid
	 * @throws KronosCoreUIException throw a KronosCoreUIException
	 * 	
	 */
	@Override
	public int getColumnCount() throws KronosCoreUIException {
		return getHeader().size();
	}
	
	/**
	 * Get the cell's string value
	 * 
	 * @param intRowIndex int
	 * @param intColumnIndex int
	 * @return cell's string value
	 * @throws KronosCoreUIException
	 */
	private String getCellValue(int intRowIndex, int intColumnIndex) throws KronosCoreUIException{
		if (jsElement == null ||  intRowIndex<= 0 || intRowIndex > getRowCount() ) {
			logger.error("Parameter error,  row number: " + intRowIndex);
			throw new KronosCoreUIException("Parameter error, row number: " + intRowIndex + " is greater than Grid rowcount or less then Zero");
		}
		
		if (jsElement == null || intColumnIndex<=0 || intColumnIndex > getHeader().size()) {
			logger.error("Parameter error, column number: " + intColumnIndex);
			throw new KronosCoreUIException("Parameter error, column number: " +intColumnIndex+ " is greater than Grid columncount or less then Zero");
		}
		
		try {
			KronosLogger.traceEnter();
			String elementId = jsElement.getAttribute("id");
			String visibleColName = getHeader().get(intColumnIndex-1);
		
			int actualColIndex = getColumnActualIndex(visibleColName);
		
			String dataFieldScript = "return GetJQGridCellDataField(arguments[0], arguments[1], arguments[2]);";
			Object dataField = KronosSeleniumUtil.executeScript(driver, dataFieldScript, elementId, intRowIndex, actualColIndex-1);
			String colDataField="";
			if (dataField != null) {
				colDataField = dataField.toString();
			}
			String script = "return GetJQGridCellvalue(arguments[0], arguments[1], arguments[2]);";
			Object objCellvalue = KronosSeleniumUtil.executeScript(driver,script,elementId, intRowIndex,colDataField);
			if (objCellvalue != null) {
				KronosLogger.traceLeave();
				return String.valueOf(objCellvalue.toString());
			}
		} catch (Exception e) {
			logger.error("Get cell value of the grid table fail " + e);
			throw new KronosCoreUIException("Get cell value of the grid table fail " + e.getMessage());
		}
		return null;
	}

	/**
	 * when select any row,then scroll grid
	 * 
	 * @param row
	 *            int
	 * 
	 * @throws KronosCoreUIException
	 */
	private int scrollToRow(int row) throws KronosCoreUIException {
		int currentRowId = -1;
		String elementId = jsElement.getAttribute("id");
		
		String rowId = element.findElement(By.xpath(".//div[@role=\"row\"]" + "[" + 1 + "]")).getAttribute("id");
		String script = "return GetJQGridScrollToRow(arguments[0], arguments[1], arguments[2]);";
		
		Object obj = KronosSeleniumUtil.executeScript(driver, script, elementId, rowId, row);
		if (obj == null) {
			logger.info("Get scrolled row rowID .");
			return currentRowId;
		}
		currentRowId = ((Long) obj).intValue();
		return currentRowId;
	}
	
	
	
	/**
	 * To cancel the selected row
	 * 
	 * @param row
	 *            int
	 */
	private void jqGridUnSelectRow() {
		String elementId = jsElement.getAttribute("id");
		String script = "JQGridUnSelectRow(arguments[0]);";
		KronosSeleniumUtil.executeScript(driver, script, elementId);
	}
	
	/**
	 * wait until grid data is loaded. 
	 */
	public void waitForGridDataToLoad() throws KronosCoreUIException{
		rowCount = getRowCount();
		WebDriverWait wait = new WebDriverWait(driver, TIMEOUT);
		ExpectedCondition<Boolean> gridData = new ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver driver) {
				int counter = 0, interationNum=0;
			try {
				int newRowCount = getRowCount();
				boolean result = (newRowCount!=rowCount);
				if(result){
					counter++;
					rowCount=newRowCount;
				}
				if(counter > 1)
					return true;
				if(counter==1){
					interationNum++;
					return true;
				}
				if (counter == 1 && interationNum > 5)
					return true;
				return false;
			} catch (KronosCoreUIException e) {
				return true;
			}
			}
		};
		wait.until(gridData);
	}

	/**
	 * Get row text by given row index.
	 * 
	 * @param row int
	 * @return String: IBaseGrid row text
	 * @throws KronosCoreUIException throw KronosCoreUIException
	 */
	@Override
	public String getRowText(int row) throws KronosCoreUIException {
		return getRow(row).getText();
	}
	
	@Override
	/**
	 * These grid operations are valid for UI grid but not for JQ grid. so just a blank implementation here
	 */
	public void performColumnOperation(String columnName, String buttonLabel) throws KronosCoreUIException{
		
	}
	
	@Override
	/**
	 * These grid operations are valid for UI grid but not for JQ grid. so just a blank implementation here
	 */
	public void unHideColumn(String columnName) throws KronosCoreUIException{
		
	}

}