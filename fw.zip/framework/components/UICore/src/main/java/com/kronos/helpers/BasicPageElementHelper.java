package com.kronos.helpers;

import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;

import com.kronos.exception.KronosCoreUIException;
import com.kronos.logging.KronosLogger;
import com.kronos.report.Reporter;
import com.kronos.report.StepStatus;
import com.kronos.utils.KronosSeleniumUtil;

public class BasicPageElementHelper {

	private static Reporter reporter = Reporter.getInstance();
	static final Logger logger = Logger.getLogger(BasicPageElementHelper.class);
	
	private BasicPageElementHelper(){
	}
	/**
	 * Scroll to the element. Brings element into view
	 *   
	 * @param driver WebDriver
	 * @param elt WebElement
	 */
	public static void scrollIntoView(WebDriver driver, WebElement elt) {
		KronosLogger.traceEnter();
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", elt);
		KronosLogger.traceLeave();
	}

	/**
	 * Find element based on if the element is clickable
	 * 
	 * @param driver
	 *            WebDriver instance
	 * @param locator
	 *            locator defined in the properties file specific to the current
	 *            page for the the driver to find the element based on
	 * @param timeout int
	 * @return WebElement
	 * @throws KronosCoreUIException throws a  KronosCoreUIException
	 */
	public static WebElement findElementByClickable(WebDriver driver, By locator, int timeout)
			throws KronosCoreUIException {
		KronosLogger.traceEnter();
		WebElement webElement = null;
		String infoMsg = "findElementByClickable: " + "[ " + locator + " ]" + " with timeout: " + timeout;
		try {
			webElement = KronosSeleniumUtil.elementToBeClickable(driver, locator, timeout);
			logger.info(infoMsg);
		} catch (Exception e) {
			logger.error(infoMsg, e);
			reporter.deepReportStep(StepStatus.FAIL, infoMsg , BasicPageSyncHelper.saveAsScreenShot(driver), e);
			throw new KronosCoreUIException(infoMsg, e);
		}
		KronosLogger.traceLeave();
		return webElement;
	}

	/**
	 * Find element based on if the element is visible
	 * 
	 * @param driver
	 *            WebDriver instance
	 * @param locator
	 *            locator defined in the properties file specific to the current
	 *            page for the the driver to find the element based on
	 * @param timeout int
	 * @return WebElement
	 * @throws KronosCoreUIException throws a  KronosCoreUIException
	 */
	public static WebElement findElementByVisible(WebDriver driver, By locator, int timeout)
			throws KronosCoreUIException {
		KronosLogger.traceEnter();
		WebElement webElement = null;
		String infoMsg = "findElementByVisible: " + "[ " + locator + " ]" + " with timeout: " + timeout;
		try {
			webElement = KronosSeleniumUtil.visibilityOfElementLocated(driver, locator, timeout);
			logger.info(infoMsg);
		} catch (Exception e) {
			logger.error(infoMsg, e);
			reporter.deepReportStep(StepStatus.FAIL, infoMsg , BasicPageSyncHelper.saveAsScreenShot(driver), e);
			throw new KronosCoreUIException(infoMsg, e);
		}
		KronosLogger.traceLeave();
		return webElement;

	}

	/**
	 * Find element based on if the element is invisible
	 * 
	 * @param driver
	 *            WebDriver instance
	 * @param locator
	 *            locator defined in the properties file specific to the current
	 *            page for the the driver to find the element based on
	 * @param timeout int
	 * @return WebElement
	 * @throws KronosCoreUIException throws a  KronosCoreUIException
	 */
	public static WebElement findElementByInvisible(WebDriver driver, By locator, int timeout)
			throws KronosCoreUIException {
		KronosLogger.traceEnter();
		WebElement webElement = null;
		String infoMsg = "findElementByInvisible: " + "[ " + locator + " ]" + " with timeout: " + timeout;
		try {
			KronosSeleniumUtil.waitUntilElementIsInvisible(driver, locator, timeout);
			logger.info(infoMsg);
		} catch (Exception e) {
			logger.error(infoMsg, e);
			reporter.deepReportStep(StepStatus.FAIL, infoMsg, BasicPageSyncHelper.saveAsScreenShot(driver), e);
			throw new KronosCoreUIException(infoMsg, e);
		}
		KronosLogger.traceLeave();
		return webElement;
	}

	/**
	 * Find element based on if the element is present
	 * 
	 * @param driver
	 *            WebDriver instance
	 * @param locator
	 *            locator defined in the properties file specific to the current
	 *            page for the the driver to find the element based on
	 * @param timeout int
	 * @return WebElement
	 * @throws KronosCoreUIException throws a  KronosCoreUIException
	 */
	public static WebElement findElementByPresence(WebDriver driver, By locator, int timeout)
			throws KronosCoreUIException {
		KronosLogger.traceEnter();
		WebElement webElement = null;
		String infoMsg = "findElementByPresence: " + "[ " + locator + " ]" + " with timeout: " + timeout;
		try {
			webElement = KronosSeleniumUtil.presenceOfElementLocated(driver, locator, timeout);
			logger.info(infoMsg);
		} catch (Exception e) {
			logger.error(infoMsg, e);
			reporter.deepReportStep(StepStatus.FAIL, infoMsg, BasicPageSyncHelper.saveAsScreenShot(driver), e);
			throw new KronosCoreUIException(infoMsg, e);
		}
		KronosLogger.traceLeave();
		return webElement;
	}

	/**
	 * Find element based on if the element is NOT present
	 * 
	 * @param driver
	 *            WebDriver instance
	 * @param locator
	 *            locator defined in the properties file specific to the current
	 *            page for the the driver to find the element based on
	 * @param timeout int
	 * @return WebElement
	 * @throws KronosCoreUIException throws a  KronosCoreUIException
	 */
	public static WebElement findElementByNotPresence(WebDriver driver, By locator, int timeout)
			throws KronosCoreUIException {
		KronosLogger.traceEnter();
		// We don't want the timeout to be too long for not presence
		if(timeout>5){
			timeout = 5;
		}
		
		WebElement webElement = null;
		String infoMsg = "findElementByNotPresence: " + "[ " + locator + " ]" + " with timeout: " + timeout;
		try {
			webElement = KronosSeleniumUtil.presenceOfElementLocated(driver, locator, timeout);
			logger.error(infoMsg);
		} catch (Exception e) {
			// Not action required element should not be there on page.
			logger.debug("Ignored Exception: ",e);
		}
		KronosLogger.traceLeave();
		return webElement;
	}

	/*
	 * Multiple elements location
	 */
	/**
	 * Find all elements based on if the element is present
	 * 
	 * @param driver
	 *            WebDriver instance
	 * @param locator
	 *            locator defined in the properties file specific to the current
	 *            page for the the page.driver to find the element based on
	 * @param timeout int           
	 * @return List. list of WebElement
	 * @throws KronosCoreUIException throws a  KronosCoreUIException
	 */
	public static List<WebElement> findElementsByPresence(WebDriver driver, By locator, int timeout)
			throws KronosCoreUIException {
		KronosLogger.traceEnter();
		List<WebElement> webElements = null;
		String infoMsg = "findElementsByPresence: " + "[ " + locator + " ]" + " with timeout: " + timeout;
		try {
			webElements = KronosSeleniumUtil.presenceOfAllElementsLocatedBy(driver, locator, timeout);
			logger.info(infoMsg);
		} catch (Exception e) {
			logger.error(infoMsg, e);
			reporter.deepReportStep(StepStatus.FAIL, infoMsg, BasicPageSyncHelper.saveAsScreenShot(driver), e);
			throw new KronosCoreUIException(infoMsg, e);
		}

		KronosLogger.traceLeave();
		return webElements;
	}
	/*
	 * Actions utils functions
	 */

	/**
	 * 
	 * @param driver
	 *            WebDriver instance
	 * @param elt WebElement
	 * @throws KronosCoreUIException throws a  KronosCoreUIException
	 */
	public static void clickInvisible(WebDriver driver, WebElement elt) throws KronosCoreUIException {
		KronosLogger.traceEnter();
		String infoMsg = "clickInvisible: " + "[ " + elt + " ]";
		try {
			KronosSeleniumUtil.clickOnInvisible(driver, elt);
			logger.info(infoMsg);
			KronosLogger.traceLeave();
		} catch (Exception e) {
			logger.error(infoMsg, e);
			reporter.deepReportStep(StepStatus.FAIL, infoMsg, BasicPageSyncHelper.saveAsScreenShot(driver), e);
			throw new KronosCoreUIException(infoMsg, e);
		}
	}

	/**
	 * Get selected web elements count
	 * 
	 * @param driver WebDriver
	 * @param xpath String
	 * @param timeout int
	 * @return int
	 * @throws KronosCoreUIException throws a  KronosCoreUIException
	 */
	public static int getElementCountByXpath(WebDriver driver, String xpath, int timeout) throws KronosCoreUIException {
		KronosLogger.traceEnter();
		int count = 0;
		String infoMsg = "getElementCountByXpath: " + "[ " + xpath + " ]" + " with timeout: " + timeout;
		try {
			count = KronosSeleniumUtil.presenceOfAllElementsLocatedBy(driver, By.xpath(xpath), timeout).size();
			logger.info(infoMsg);
		} catch (Exception e) {
			logger.error(infoMsg, e);
			reporter.deepReportStep(StepStatus.FAIL, infoMsg, BasicPageSyncHelper.saveAsScreenShot(driver), e);
			throw new KronosCoreUIException(infoMsg, e);
		}
		KronosLogger.traceLeave();
		return count;
	}

	/**
	 * Set an attribute of the WebElement
	 * 
	 * @param driver
	 *            The WebDriver
	 * @param element
	 *            The WebElement to change
	 * @param attributeName
	 *            The attribute to change
	 * @param value
	 *            The value to set
	 * 
	 * @exception KronosCoreUIException throws a  KronosCoreUIException
	 */
	public static void setAttribute(WebDriver driver, WebElement element, String attributeName, String value)
			throws KronosCoreUIException {
		KronosLogger.traceEnter();
		String infoMsg = "setAttribute: " + "[ " + element + " ]" + " attribute name: " + attributeName + " value: "
				+ value;
		try {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].setAttribute(arguments[1], arguments[2])", element, attributeName, value);
			logger.info(infoMsg);
		} catch (Exception e) {
			logger.error(infoMsg, e);
			reporter.deepReportStep(StepStatus.FAIL, infoMsg, BasicPageSyncHelper.saveAsScreenShot(driver), e);
			throw new KronosCoreUIException(infoMsg, e);
		}
		KronosLogger.traceLeave();
	}
	
	/**
	 * Execute the javascript code using JavascriptExecutor with given parameters
	 * 
	 * @param driver WebDriver
	 * @param javascriptToExecute String
	 * @param parameters Object...
	 * @return Return value of executed javascript code with given parameters.
	 * @throws KronosCoreUIException :KronosCoreUIException
	 */
	public static Object executeScript(WebDriver driver, String javascriptToExecute, Object... parameters)
			throws KronosCoreUIException {
		KronosLogger.traceEnter();
		Object object = null;
		String infoMsg = "executeScript: " + javascriptToExecute + " with parameter: " + parameters;
		try {
			object = KronosSeleniumUtil.executeScript(driver, javascriptToExecute, parameters);
			logger.info(infoMsg);
			reporter.deepReportStep(StepStatus.INFO, infoMsg);
		} catch (Exception e) {
			logger.error(infoMsg, e);
			reporter.deepReportStep(StepStatus.FAIL, infoMsg, BasicPageSyncHelper.saveAsScreenShot(driver), e);
			throw new KronosCoreUIException(infoMsg, e);
		}
		KronosLogger.traceLeave();
		return object;
	}

	
	/**
	 * Perform drag and drop from source element to target element
	 * @param driver WebDriver
	 * @param source WebElement
	 * @param target WebElement
	 * @throws KronosCoreUIException throw a KronosCoreUIException
	 */
	public static void dragAndDrop(WebDriver driver, WebElement source, WebElement target) throws KronosCoreUIException{
		KronosLogger.traceEnter();
		String infoMsg = "Drag and Drop: element";
		try {
			Actions builder = new Actions(driver);
			/* To bring element on focus before perform action on it
			 * Fix : SUP-10496
			*/
			builder.moveToElement(source).perform();
			Action dragAndDrop = builder.clickAndHold(source).moveToElement(target).release(target).build();
			dragAndDrop.perform();
			logger.error(infoMsg);
		} catch (Exception e) {
			logger.error(infoMsg, e);
			reporter.deepReportStep(StepStatus.FAIL, infoMsg, BasicPageSyncHelper.saveAsScreenShot(driver), e);
			throw new KronosCoreUIException(infoMsg, e);
		}
		KronosLogger.traceLeave();
	}
	
	
	/**
	 * Perform drag from source element
	 * @param driver WebDriver
	 * @param source WebElement
	 * @param offset int
	 * @throws KronosCoreUIException throw a KronosCoreUIException
	 */
	public static void drag(WebDriver driver, WebElement source, int offset) throws KronosCoreUIException{
		KronosLogger.traceEnter();
		String infoMsg = "Drag: element";
		try {
			Actions builder = new Actions(driver);
			builder.clickAndHold(source).moveByOffset(offset, 0).release().build().perform();
			logger.error(infoMsg);
		} catch (Exception e) {
			logger.error(infoMsg, e);
			reporter.deepReportStep(StepStatus.FAIL, infoMsg, BasicPageSyncHelper.saveAsScreenShot(driver), e);
			throw new KronosCoreUIException(infoMsg, e);
		}
		KronosLogger.traceLeave();
	}
}
