package com.kronos.element.interfaces;

import com.kronos.exception.KronosCoreUIException;

public interface IBaseClick extends IBaseCommonElement {

	public void rightClick() throws KronosCoreUIException;

	public void doubleClick() throws KronosCoreUIException;

	public void clickAsJScript() throws KronosCoreUIException;

	public void click() throws KronosCoreUIException;
	
	public String clickToOpenNewWindow() throws KronosCoreUIException;
}
