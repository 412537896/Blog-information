package com.kronos.exception;

import com.kronos.exception.KronosCoreCommonException;

public class KronosCoreUIException extends KronosCoreCommonException {
	
	private static final long serialVersionUID = 689088837052178789L;

	/**
	 * Constructs a KronosCoreUIException Object via message
	 * 
	 * @param message:String
	 */
	public KronosCoreUIException(String message) {
	        super(message);
	 }
	/**
	 * Constructs a KronosCoreUIException Object via message and cause
	 * 
	 * @param message:String
	 * @param cause:Throwable
	 */
	 public KronosCoreUIException(String message, Throwable cause) {
	        super(message, cause);
	 }
	 
	 /**
	  * Constructs a KronosCoreUIException Object via cause
	  * 
	  * @param cause:Exception
	  */
	 public KronosCoreUIException(Exception cause) {
	        super(cause);
	 }
}
