package com.kronos.factory;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.kronos.basepageobject.BasePage;
import com.kronos.exception.KronosCoreCommonException;
import com.kronos.exception.KronosCoreUIException;
import com.kronos.findbysImp.KronosBaseElementDecorator;
import com.kronos.logging.KronosLogger;
import com.kronos.testng.Configurator;

public class KronosBasePageFactory extends PageFactory {

	final static Logger logger = Logger.getLogger(KronosBasePageFactory.class);
	/**
	 * Initializes page
	 * 
	 * @param driver:WebDriver
	 * @param seleniumPageObject:BasePage
	 * @throws KronosCoreCommonException throws a KronosCoreCommonException
	 */
	public static void initPage(WebDriver driver, BasePage seleniumPageObject) throws KronosCoreCommonException {
		KronosLogger.traceEnter();
		KronosBaseElementDecorator decorator;
		try{
			decorator = new KronosBaseElementDecorator(
					new KronosDefaultElementLocatorFactory(driver, Integer.parseInt(Configurator.getInstance().getParameter("timeout"))), 
					seleniumPageObject);
		} catch (Exception e1) {
			if (e1 instanceof KronosCoreCommonException)
				throw e1;
			String message1 = "Page initilization failed :";
			logger.error(message1 , e1);
			throw new KronosCoreUIException(message1, e1);
		}
	    PageFactory.initElements(decorator, seleniumPageObject);
		logger.info("Page initilization is OK.");
		KronosLogger.traceLeave();
	}
}
