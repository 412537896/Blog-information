package com.kronos.helpers;

import java.util.Set;

import org.apache.log4j.Logger;
import org.openqa.selenium.Alert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

import com.kronos.exception.KronosCoreUIException;
import com.kronos.logging.KronosLogger;
import com.kronos.report.Reporter;
import com.kronos.report.StepStatus;

public class BasicBrowserHelper {

	static final Logger logger = Logger.getLogger(BasicPageSyncHelper.class);
	protected static Reporter reporter = Reporter.getInstance();
	
	private BasicBrowserHelper(){
	}
	/**
	 * Navigate to target URL
	 * 
	 * @param url String
	 * @param driver WebDriver
	 */
	public static void navigate(String url, WebDriver driver) {
		KronosLogger.traceEnter();
		driver.navigate().to(url);
		String infoMsg = "navigate: " + url;
		logger.info(infoMsg);
		reporter.deepReportStep(StepStatus.INFO, infoMsg);
		KronosLogger.traceLeave();
	}

	/**
	 * Navigate back from current URL
	 * 
	 * @param driver WebDriver
	 */
	public static void navigateBack(WebDriver driver) {
		KronosLogger.traceEnter();
		driver.navigate().back();
		String infoMsg = "navigateBack: " + driver.getCurrentUrl();
		logger.info(infoMsg);
		reporter.deepReportStep(StepStatus.INFO, infoMsg);
		KronosLogger.traceLeave();
	}

	/**
	 * Navigate forward from current URL
	 * 
	 * @param driver WebDriver
	 */
	public static void navigateForward(WebDriver driver) {
		KronosLogger.traceEnter();
		driver.navigate().forward();
		String infoMsg = "navigateForward: " + driver.getCurrentUrl();
		logger.info(infoMsg);
		reporter.deepReportStep(StepStatus.INFO, infoMsg);
		KronosLogger.traceLeave();
	}

	/**
	 * Refresh current URL
	 * 
	 * @param driver WebDriver
	 */
	public static void refreshPage(WebDriver driver) {
		KronosLogger.traceEnter();
		driver.navigate().refresh();
		String infoMsg = "refreshPage: " + driver.getCurrentUrl();
		logger.info(infoMsg);
		reporter.deepReportStep(StepStatus.INFO, infoMsg);
		KronosLogger.traceLeave();
	}

	/**
	 * Find cookie's value corresponding to given cookie name
	 * 
	 * @param driver WebDriver
	 * @param cookieName String
	 * @return Cookie's value corresponding to given cookie name, <br>
	 *         null<br>
	 *         if cookie with given cookie name is not present
	 */
	public static String getCookieValueByName(WebDriver driver, String cookieName) {
		KronosLogger.traceEnter();
		String cookieValue = null;
		cookieValue = driver.manage().getCookieNamed(cookieName).getValue();
		String infoMsg = "getCookieValueByName: " + cookieName;
		logger.info(infoMsg);
		KronosLogger.traceLeave();
		return cookieValue;
	}

	/**
	 * Store current window handle
	 * 
	 * @param driver WebDriver
	 * @return String
	 */
	public static String getCurrentWindowHandle(WebDriver driver) {
		String winHandle = driver.getWindowHandle();
		logger.info("getCurrentWindowHandle: [" + winHandle + "]");
		return winHandle;
	}
	
	/**
	 * Switch to window with given window handle
	 * 
	 * @param driver WebDriver
	 * @return WindowHandle
	 * @throws KronosCoreUIException throw a KronosCoreUIException
	 */
	public static String openWindow(WebDriver driver) throws KronosCoreUIException {		
		String infoMsg = "Open Window ";
		//handles before new open widonws
		Set<String> beforeWinHandles = driver.getWindowHandles();
		Set<String> afterWinHandles;
		
		((JavascriptExecutor)driver).executeScript("window.open();");
        
        afterWinHandles = driver.getWindowHandles();
		//remove all the difference to leave only the newly opened window handle
		afterWinHandles.removeAll(beforeWinHandles);
		
		logger.info(infoMsg);
		
		if(afterWinHandles.isEmpty()){
			return null;
		}else{
			return (String) afterWinHandles.toArray()[0];		
		} 
	}
	/**
	 * Closing new opened window and switch back to original window
	 * 
	 * @param driver WebDriver
	 * @param windowHandle String
	 * @throws KronosCoreUIException throw a KronosCoreUIException
	 */
	public static void switchAndCloseWindow(WebDriver driver, String windowHandle) throws KronosCoreUIException {
		KronosLogger.traceEnter();
		String infoMsg = "switchAndCloseWindow: ";

		if(!driver.getWindowHandles().contains(windowHandle)){
			infoMsg = infoMsg + "Cannot find the window [" + windowHandle + "] which you are trying to close.";
			logger.error(infoMsg);
			reporter.deepReportStep(StepStatus.FAIL, infoMsg);
			throw new KronosCoreUIException(infoMsg);
		}
		switchToWindow(driver, windowHandle);
		driver.close();
		logger.info(infoMsg);
		KronosLogger.traceLeave();
	}
	
	/**
	 * Switch to window with given window handle
	 * 
	 * @param driver WebDriver
	 * @param windowHandle String
	 * @throws KronosCoreUIException throw a KronosCoreUIException
	 */
	public static void closeWindow(WebDriver driver, String windowHandle) throws KronosCoreUIException {		
		String infoMsg = "Close Window: ";
		if(driver.getWindowHandles().contains(windowHandle)){
			try {
				driver.close();
			} catch (Exception e) {
				logger.error(infoMsg, e);
				reporter.deepReportStep(StepStatus.FAIL, infoMsg);
				throw new KronosCoreUIException(infoMsg, e);
			}
		}else{
			infoMsg = infoMsg + "Cannot find the window [" + windowHandle + "] which you are trying to close.";
			logger.error(infoMsg);
			reporter.deepReportStep(StepStatus.FAIL, infoMsg);
			throw new KronosCoreUIException(infoMsg);
		}
	}
	
	/**
	 * Switch to window with given window handle
	 * 
	 * @param driver WebDriver
	 * @param windowHandle String
	 * @throws KronosCoreUIException throw a KronosCoreUIException
	 */
	public static void switchToWindow(WebDriver driver, String windowHandle) throws KronosCoreUIException {
		String infoMsg = "switchToWindow: ";
		if(driver.getWindowHandles().contains(windowHandle)){
			try {
				driver.switchTo().window(windowHandle);
			}catch (Exception e) {
				logger.error(infoMsg, e);
				reporter.deepReportStep(StepStatus.FAIL, infoMsg);
				throw new KronosCoreUIException(infoMsg, e);
			}
		}else{
			infoMsg = infoMsg + "Cannot find the window [" + windowHandle + "] which you are trying to switch to";
			logger.error(infoMsg);
			reporter.deepReportStep(StepStatus.FAIL, infoMsg);
			throw new KronosCoreUIException(infoMsg);
		}
	}

	/**
	 * Get alert object
	 * 
	 * @param driver WebDriver
	 * @return Alert
	 * @throws KronosCoreUIException throw a KronosCoreUIException
	 */
	public static Alert getAlert(WebDriver driver) throws KronosCoreUIException {
		KronosLogger.traceEnter();
		String infoMsg = "getAlert: ";
		try {
			Alert alert = driver.switchTo().alert();
			logger.info(infoMsg);
			KronosLogger.traceLeave();
			return alert;
		} catch (Exception e) {
			reporter.deepReportStep(StepStatus.FAIL, infoMsg, BasicPageSyncHelper.saveAsScreenShot(driver), e);
			logger.error(infoMsg, e);
			throw new KronosCoreUIException(infoMsg, e);
		}

	}

	/**
	 * Accept alert handle
	 * 
	 * @param driver WebDriver
	 * @throws KronosCoreUIException throw a KronosCoreUIException
	 */
	public static void acceptAlert(WebDriver driver) throws KronosCoreUIException {
		KronosLogger.traceEnter();
		String infoMsg = "getAlert: ";
		try {
			Alert alert = getAlert(driver);
			alert.accept();
			logger.info(infoMsg);
		} catch (Exception e) {
			logger.error(infoMsg, e);
			reporter.deepReportStep(StepStatus.FAIL, infoMsg, BasicPageSyncHelper.saveAsScreenShot(driver), e);
			throw new KronosCoreUIException(infoMsg, e);
		}
		KronosLogger.traceLeave();
	}

	/**
	 * Dismiss alert handle
	 * 
	 * @param driver WebDriver
	 * @throws KronosCoreUIException throw a KronosCoreUIException
	 */
	public static void dismissAlert(WebDriver driver) throws KronosCoreUIException {
		KronosLogger.traceEnter();
		String infoMsg = "dismissAlert:";
		try {
			Alert alert = getAlert(driver);
			alert.dismiss();
			logger.info(infoMsg);
		} catch (Exception e) {
			logger.error(infoMsg, e);
			reporter.deepReportStep(StepStatus.FAIL, infoMsg, BasicPageSyncHelper.saveAsScreenShot(driver), e);
			throw new KronosCoreUIException(infoMsg, e);
		}
		KronosLogger.traceLeave();
	}

	/**
	 * Get alert text
	 * 
	 * @param driver WebDriver
	 * @return String
	 * @throws KronosCoreUIException throw a KronosCoreUIException
	 */
	public static String getAlertText(WebDriver driver) throws KronosCoreUIException {
		KronosLogger.traceEnter();
		String alertText = null;
		String infoMsg = "getAlertText: %s";
		try {
			Alert alert = getAlert(driver);
			alertText = alert.getText();
			infoMsg = String.format(infoMsg, alertText);
			logger.info(infoMsg);
		} catch (Exception e) {
			infoMsg = String.format(infoMsg, alertText);
			logger.error(infoMsg, e);
			reporter.deepReportStep(StepStatus.FAIL, infoMsg, BasicPageSyncHelper.saveAsScreenShot(driver), e);
			throw new KronosCoreUIException(infoMsg, e);
		}
		KronosLogger.traceLeave();
		return alertText;
	}

	/**
	 * Get Page title
	 * 
	 * @param driver WebDriver
	 * @return String
	 */
	public static String getTitle(WebDriver driver) {
		String title = null;
		KronosLogger.traceEnter();
		title = driver.getTitle();
		String infoMsg = "getTitle: " + title;
		logger.info(infoMsg);
		KronosLogger.traceLeave();
		return title;

	}

	/**
	 * Get Page url
	 * 
	 * @param driver WebDriver
	 * @return String
	 */
	public static String getPageUrl(WebDriver driver) {
		String title = null;
		KronosLogger.traceEnter();
		title = driver.getCurrentUrl();
		String infoMsg = "getPageUrl: " + title;
		logger.info(infoMsg);
		KronosLogger.traceLeave();
		return title;

	}

}
