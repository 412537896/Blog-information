package com.kronos.enums;

public enum KronosLocateVia {
	ByElementClickable("findElementByClickable"),
	ByElementVisible("findElementByVisible"), 
	ByElementInvisible("findElementByInvisible"),
	ByElementPresent("findElementByPresence"),
	ByElementNotPresent("findElementByNotPresence"),
	ByElementsVisible("findElementsByPresence"),
	ByElementsPresent("findElementsByPresence"),
	Default("findElementByPresence");
	String value;
	
	private KronosLocateVia(String value) {
		this.value = value;
	}
	
	public String getMethodName(){
		return this.value;
	}
}
