package com.kronos.element.interfaces;

import com.kronos.exception.KronosCoreUIException;

public interface IBaseButton extends IBaseClick {

	public void submit() throws KronosCoreUIException;

}
