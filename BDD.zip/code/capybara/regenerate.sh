#---
# Excerpted from "The Cucumber for Java Book",
# published by The Pragmatic Bookshelf.
# Copyrights apply to this code. It may not be used to create training material, 
# courses, books, articles, and the like. Contact us if you are in doubt.
# We make no guarantees that this code is fit for any purpose. 
# Visit http://www.pragmaticprogrammer.com/titles/srjcuc for more book information.
#---
set -e
rm -Rf 00 01 02 03 04 05 06 07 08 09 10 11

./00.sh
./01.sh
./02.sh
./03.sh
./04.sh
./05.sh
./06.sh
./07.sh
./08.sh
./09.sh
./10.sh
./11.sh
